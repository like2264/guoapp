// 黄果旧版（旧 API 剧库）：作者 2.0.0+112 把站源改成 JS 模块时把这站去掉了，
// 这里按 1.0.x 的旧接口重新接回来。
//
// 站点结构：
//   前端（Cloudflare 上的 SPA）  https://d2pypzndaqisk.cloudfront.net/
//   API                          https://dr6skssi3nxbk.cloudfront.net（带备用域名）
//   接口一律 GET/POST，参数放在 data=<base64(AES-CBC(JSON))>，响应同样是密文。
//
// 协议参数（interfaceKey / parameterKey / parameterIv）不在安装包里，得从
// 前端 JS 里现场抠；interfaceKey 还参与响应的密钥编排，站点一换包就得重新抠，
// 所以抠到之后连同访客 token 一起存起来，过期或解不开再重新抠一次。
var FRONT = "https://d2pypzndaqisk.cloudfront.net";
var API_HOSTS = [
  "https://dr6skssi3nxbk.cloudfront.net",
  "https://d18ka9rqpfd3lo.cloudfront.net",
  "https://d37n0wjehmw08f.cloudfront.net",
];
var CDN = "https://sjljsla.lkkwip.cn";
var UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1";
var X_UA =
  "BuildID=com.abc.Butterfly;SysType=ios;DevID={dev};Ver=1.0.0;DevType=iPhone;DeviceBrand=APPLE;DeviceModel=iPhone;SystemName=iOS;SystemVersion=18.7;Terminal=1;IsH5=1;Sid=00000000000000000000000000000000";
var CHANNEL = "黄果旧版";
var PAGE_SIZE = 30;
var MAX_PAGE = 40;
var MAX_POOL = 1200;
var RECOMMEND_ID = "recommend";
var RECOMMEND_NAME = "推荐";
var CATALOG_TTL = 10 * 60 * 1000;
var STATE_KEY = "session";
var PROTOCOL_TTL = 24 * 60 * 60 * 1000;
var RATE_CODE = "4010";
var TOKEN_CODE = "5005";

function bytes() {
  var arrays = [];
  var total = 0;
  for (var index = 0; index < arguments.length; index++) {
    var part = arguments[index];
    var data = typeof part === "string" ? host.utf8Encode(part) : part;
    arrays.push(data);
    total += data.length;
  }
  var out = new Uint8Array(total);
  var at = 0;
  for (var position = 0; position < arrays.length; position++) {
    out.set(arrays[position], at);
    at += arrays[position].length;
  }
  return out;
}

function pad(data) {
  var missing = 16 - (data.length % 16);
  var out = new Uint8Array(data.length + missing);
  out.set(data, 0);
  for (var index = data.length; index < out.length; index++) out[index] = missing;
  return out;
}

function unpad(data) {
  if (data.length === 0 || data.length % 16 !== 0) return data;
  var size = data[data.length - 1];
  if (size <= 0 || size > 16 || size > data.length) return data;
  return data.slice(0, data.length - size);
}

function encryptParam(value, protocol) {
  var json = JSON.stringify(value);
  var sealed = host.aesCbcEncrypt(
    host.utf8Encode(protocol.paramKey),
    host.utf8Encode(protocol.paramIv),
    pad(host.utf8Encode(json))
  );
  return host.base64Encode(sealed);
}

// 与 1.0.x 的 decryptResponse 一致：接口密钥 + 响应头 12 字节随机数拼起来，
// 取两半分别哈希，交叉拼出 AES-256 的 key 与 iv。
function decryptResponse(text, interfaceKey) {
  var raw = host.base64Decode(String(text || "").trim());
  if (raw.length < 28) throw new Error("黄果旧版返回的密文过短");
  var vector = raw.slice(0, 12);
  var sealed = raw.slice(12);
  var material = bytes(interfaceKey, vector);
  var half = material.length >> 1;
  var seed = host.sha256(material).slice(8, 24);
  var left = host.sha256(bytes(seed, material.slice(0, half)));
  var right = host.sha256(bytes(material.slice(half), seed));
  var aesKey = bytes(left.slice(0, 8), right.slice(8, 24), left.slice(24));
  var aesIv = bytes(right.slice(0, 4), left.slice(12, 20), right.slice(28));
  return host.utf8Decode(unpad(host.aesCbcDecrypt(aesKey, aesIv, sealed)));
}

function protocolValue(script, name) {
  var pattern = new RegExp("[\"']" + name + "[\"']\\s*[:,]\\s*[\"']([^\"'\\\\\\r\\n]+)[\"']");
  var match = pattern.exec(script);
  return match ? match[1] : "";
}

function loadSession() {
  try {
    var text = host.loadState(STATE_KEY);
    if (!text) return {};
    var parsed = JSON.parse(text);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (error) {
    return {};
  }
}

function saveSession(session) {
  try {
    host.saveState(STATE_KEY, JSON.stringify(session));
  } catch (error) {}
}

function fetchText(address, headers) {
  var response = host.fetch({
    url: address,
    headers: headers || { "User-Agent": UA },
    limit: 1 << 21,
    timeoutMs: 20000,
  });
  return response.body || "";
}

function discoverProtocol(session) {
  var now = new Date().getTime();
  if (
    session.protocol &&
    session.protocolAt &&
    now - session.protocolAt < PROTOCOL_TTL
  ) {
    return session.protocol;
  }
  var html = fetchText(FRONT + "/", { "User-Agent": UA });
  var pattern = /<script[^>]+src="([^"]+)"/gi;
  var match;
  while ((match = pattern.exec(html)) !== null) {
    var address = match[1];
    if (!/^https?:/i.test(address)) {
      address = address.charAt(0) === "/" ? FRONT + address : FRONT + "/" + address;
    }
    var script = "";
    try {
      script = fetchText(address, { "User-Agent": UA });
    } catch (error) {
      continue;
    }
    var protocol = {
      interfaceKey: protocolValue(script, "interfaceKey"),
      paramKey: protocolValue(script, "parameterKey"),
      paramIv: protocolValue(script, "parameterIv"),
    };
    if (
      protocol.interfaceKey &&
      protocol.paramKey.length === 16 &&
      protocol.paramIv.length === 16
    ) {
      session.protocol = protocol;
      session.protocolAt = now;
      saveSession(session);
      return protocol;
    }
  }
  throw new Error("黄果旧版协议已变化，无法识别接口参数");
}

function deviceId(session) {
  if (!session.device) {
    session.device = "ios" + new Date().getTime();
    saveSession(session);
  }
  return session.device;
}

function apiBase(session) {
  if (session.base) return session.base;
  for (var index = 0; index < API_HOSTS.length; index++) {
    try {
      var response = host.fetch({
        url: API_HOSTS[index] + "/api/app/playlet-tab/all",
        headers: baseHeaders(session, ""),
        limit: 1 << 16,
        timeoutMs: 12000,
        anyStatus: true,
      });
      if (response.status && response.status < 500) {
        session.base = API_HOSTS[index];
        saveSession(session);
        return session.base;
      }
    } catch (error) {}
  }
  return API_HOSTS[0];
}

function baseHeaders(session, token) {
  var headers = {
    "User-Agent": UA,
    Accept: "application/json",
    temp: "test",
    "X-User-Agent": X_UA.replace("{dev}", deviceId(session)),
    Origin: FRONT,
    Referer: FRONT + "/",
  };
  if (token) headers.Authorization = token;
  return headers;
}

function claimToken(session) {
  var body = JSON.stringify({
    data: encryptParam(
      { devID: deviceId(session), sysType: "ios", isAppStore: false },
      session.protocol
    ),
  });
  var headers = baseHeaders(session, "");
  headers["Content-Type"] = "application/json";
  var response = host.fetch({
    url: apiBase(session) + "/api/app/mine/login/h5",
    method: "POST",
    headers: headers,
    body: body,
    limit: 1 << 20,
    timeoutMs: 20000,
  });
  var payload = null;
  try {
    payload = unwrap(response.body, session);
  } catch (error) {
    if (String(error.code || "") === "4007") {
      throw new Error("黄果旧版访客登录过于频繁，请过几分钟再试");
    }
    throw error;
  }
  if (!payload || !payload.token) throw new Error("黄果旧版访客登录未返回令牌");
  session.token = payload.token;
  saveSession(session);
  return session.token;
}

function unwrap(body, session) {
  var envelope = null;
  try {
    envelope = JSON.parse(String(body || ""));
  } catch (error) {
    throw new Error("黄果旧版返回的数据格式无效");
  }
  var code = envelope && envelope.code !== undefined ? String(envelope.code) : "";
  if (code !== "" && code !== "null" && code !== "200" && code !== "0") {
    var failure = new Error(
      "黄果旧版接口返回 " + code + "：" + String(envelope.msg || "请稍后重试")
    );
    failure.code = code;
    throw failure;
  }
  var data = envelope ? envelope.data : null;
  if (typeof data === "string" && envelope && envelope.hash) {
    var plain = decryptResponse(data, session.protocol.interfaceKey);
    if (plain === "nil" || plain === "") return null;
    try {
      return JSON.parse(plain);
    } catch (error) {
      return plain;
    }
  }
  if (data === "nil" || data === null || data === undefined) return null;
  return data;
}

function apiGet(session, path, params, attempt) {
  var round = attempt || 0;
  if (!session.token) claimToken(session);
  var address = apiBase(session) + path;
  if (params) address += "?data=" + encodeURIComponent(encryptParam(params, session.protocol));
  var response = host.fetch({
    url: address,
    headers: baseHeaders(session, session.token),
    limit: 1 << 22,
    timeoutMs: 25000,
    anyStatus: true,
  });
  if (response.status === 401 || response.status === 403) {
    session.token = "";
    saveSession(session);
    if (round < 2) return apiGet(session, path, params, round + 1);
  }
  try {
    return unwrap(response.body, session);
  } catch (error) {
    var code = error && error.code ? String(error.code) : "";
    if (code === TOKEN_CODE) {
      session.token = "";
      saveSession(session);
      if (round < 2) return apiGet(session, path, params, round + 1);
    }
    if (code === RATE_CODE && round < 2) {
      return apiGet(session, path, params, round + 1);
    }
    throw error;
  }
}

function text(value) {
  if (typeof value === "string") return value.trim();
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  return "";
}

function number(value) {
  var parsed = typeof value === "number" ? value : parseInt(text(value), 10);
  return isFinite(parsed) && parsed > 0 ? parsed : 0;
}

function coverAddress(raw) {
  var address = text(raw);
  if (address === "") return "";
  if (/^https?:\/\//i.test(address)) return address;
  return CDN + "/" + address.replace(/^\/+/, "");
}

function tagsOf(row) {
  var value = row && row.tags;
  if (Array.isArray(value)) {
    var out = [];
    for (var index = 0; index < value.length; index++) {
      var tag = text(value[index]);
      if (tag !== "") out.push(tag);
    }
    return out;
  }
  var single = text(value);
  return single === "" ? [] : [single];
}

function dramaFrom(row, channel) {
  if (!row || typeof row !== "object") return null;
  var id = text(row.id);
  if (id === "") return null;
  var title = text(row.title) || text(row.name);
  if (title === "") return null;
  var cover = coverAddress(
    row.cover ||
      row.coverUrl ||
      row.cover_url ||
      row.image ||
      row.imageUrl ||
      row.img ||
      row.pic ||
      row.poster ||
      row.thumb
  );
  var category = text(row.categoryName) || text(row.category_name) || text(row.category) || text(row.typeName);
  var episodes =
    number(row.totalEpisode) ||
    number(row.total_episode) ||
    number(row.episodeCount) ||
    number(row.episode_count) ||
    number(row.chapterCount) ||
    number(row.total) ||
    number(row.episodes);
  return {
    id: host.dramaId(id),
    // 必填：少了它，原生侧只能从 id 前缀反推站源，海报缓存/下载都按空站源算。
    source: host.source,
    sourceId: id,
    title: title,
    name: title,
    cover: cover,
    coverUrl: cover,
    desc: text(row.description) || text(row.intro) || text(row.remark),
    intro: text(row.description) || text(row.intro),
    categoryName: category || channel || CHANNEL,
    remark: text(row.remark),
    episodes: episodes,
    tags: tagsOf(row),
    score: text(row.score),
    views: text(row.views) || text(row.play_count),
    releaseStatus: text(row.releaseStatus) || text(row.release_status),
  };
}

function tabList(session) {
  var payload = apiGet(session, "/api/app/playlet-tab/all", {});
  var rows = payload && Array.isArray(payload.list) ? payload.list : [];
  var out = [];
  var seen = {};
  for (var index = 0; index < rows.length; index++) {
    var row = rows[index];
    var id = text(row && row.id);
    if (id === "" || seen[id]) continue;
    seen[id] = true;
    out.push({ id: id, name: text(row.name) || "分类" + (out.length + 1) });
  }
  return out;
}

function feedsFor(session, category) {
  if (category === RECOMMEND_ID) {
    return [{ id: RECOMMEND_ID, name: RECOMMEND_NAME, path: "/api/app/playlet-recommend/home/choose", tab: false }];
  }
  var tabs = tabList(session);
  if (category !== "") {
    for (var index = 0; index < tabs.length; index++) {
      if (tabs[index].id === category) {
        return [
          {
            id: tabs[index].id,
            name: tabs[index].name,
            path: "/api/app/playlet/home/tab/" + encodeURIComponent(tabs[index].id),
            tab: true,
          },
        ];
      }
    }
    throw new Error("此分类已调整，请刷新分类列表");
  }
  if (tabs.length === 0) throw new Error("黄果旧版未返回可用分类");
  var feeds = [];
  for (var position = 0; position < tabs.length; position++) {
    feeds.push({
      id: tabs[position].id,
      name: tabs[position].name,
      path: "/api/app/playlet/home/tab/" + encodeURIComponent(tabs[position].id),
      tab: true,
    });
  }
  feeds.push({ id: RECOMMEND_ID, name: RECOMMEND_NAME, path: "/api/app/playlet-recommend/home/choose", tab: false });
  return feeds;
}

function walkKey(category) {
  return "walk:" + (category === "" ? "*" : category);
}

function loadWalk(session, category) {
  var cached = null;
  try {
    var raw = host.cacheGet(walkKey(category));
    cached = typeof raw === "string" ? JSON.parse(raw) : raw;
  } catch (error) {}
  if (!cached || typeof cached !== "object") return null;
  if (!cached.at || new Date().getTime() - cached.at > CATALOG_TTL) return null;
  return cached;
}

function saveWalk(category, walk) {
  try {
    host.cacheSet(walkKey(category), JSON.stringify(walk), CATALOG_TTL);
  } catch (error) {}
}

function newWalk(session, category) {
  var feeds = feedsFor(session, category);
  var next = {};
  var exhausted = {};
  for (var index = 0; index < feeds.length; index++) {
    next[feeds[index].id] = 1;
    exhausted[feeds[index].id] = false;
  }
  return {
    at: new Date().getTime(),
    feeds: feeds,
    next: next,
    exhausted: exhausted,
    seen: [],
    pool: [],
  };
}

function seenSet(walk) {
  var set = {};
  for (var index = 0; index < walk.seen.length; index++) set[walk.seen[index]] = true;
  return set;
}

function feedPage(session, feed, page, size) {
  var params = { pageNumber: page, pageSize: size };
  if (feed.tab) params.tabSortType = 1;
  var payload = apiGet(session, feed.path, params);
  var rows = payload && Array.isArray(payload.list) ? payload.list : [];
  return rows;
}

function fillWalk(session, walk, want) {
  var target = Math.min(want, MAX_POOL);
  while (walk.pool.length < target) {
    var before = walk.pool.length;
    for (var index = 0; index < walk.feeds.length; index++) {
      var feed = walk.feeds[index];
      if (walk.exhausted[feed.id]) continue;
      var page = walk.next[feed.id] || 1;
      if (page > MAX_PAGE) {
        walk.exhausted[feed.id] = true;
        continue;
      }
      var rows = null;
      try {
        rows = feedPage(session, feed, page, PAGE_SIZE);
      } catch (error) {
        continue;
      }
      walk.next[feed.id] = page + 1;
      if (rows.length === 0) walk.exhausted[feed.id] = true;
      var seen = seenSet(walk);
      for (var position = 0; position < rows.length; position++) {
        var drama = dramaFrom(rows[position], feed.name);
        if (!drama || seen[drama.sourceId]) continue;
        seen[drama.sourceId] = true;
        walk.seen.push(drama.sourceId);
        walk.pool.push(drama);
      }
      walk.seen = walk.seen.slice(-MAX_POOL);
      if (walk.pool.length >= target) break;
    }
    if (walk.pool.length === before) break;
  }
}

function more(walk, end) {
  if (walk.pool.length > end) return true;
  if (walk.pool.length >= MAX_POOL) return false;
  for (var index = 0; index < walk.feeds.length; index++) {
    if (!walk.exhausted[walk.feeds[index].id]) return true;
  }
  return false;
}

function catalogPage(page, category) {
  var session = loadSession();
  discoverProtocol(session);
  var current = Math.max(1, Math.min(number(page) || 1, MAX_PAGE));
  var walk = loadWalk(session, category) || newWalk(session, category);
  var from = (current - 1) * PAGE_SIZE;
  var to = from + PAGE_SIZE;
  fillWalk(session, walk, to);
  saveWalk(category, walk);
  var items = walk.pool.slice(from, Math.min(to, walk.pool.length));
  return { items: items, hasMore: more(walk, to) };
}

function searchPage(page, query) {
  var keyword = text(query);
  if (keyword === "") return { items: [], hasMore: false };
  var session = loadSession();
  discoverProtocol(session);
  var current = Math.max(1, number(page) || 1);
  var payload = apiGet(session, "/api/app/playlet/keyword/search", {
    keyword: keyword,
    pageNumber: current,
    pageSize: PAGE_SIZE,
  });
  var rows = payload && Array.isArray(payload.list) ? payload.list : [];
  var items = [];
  var seen = {};
  for (var index = 0; index < rows.length; index++) {
    var drama = dramaFrom(rows[index], "");
    if (!drama || seen[drama.sourceId]) continue;
    seen[drama.sourceId] = true;
    items.push(drama);
  }
  return { items: items, hasMore: rows.length >= PAGE_SIZE };
}

function detail(sourceId) {
  var id = text(sourceId);
  if (id === "") throw new Error("黄果旧版剧集编号无效");
  var session = loadSession();
  discoverProtocol(session);
  var payload = apiGet(session, "/api/app/playlet/detail/" + encodeURIComponent(id), null);
  if (!payload || typeof payload !== "object") throw new Error("黄果旧版没有返回这部剧的详情");
  var row =
    payload.drama && typeof payload.drama === "object"
      ? payload.drama
      : payload.playlet && typeof payload.playlet === "object"
      ? payload.playlet
      : payload;
  var drama = dramaFrom(row, CHANNEL) || dramaFrom({ id: id, title: text(row.title) || text(row.name) || id }, CHANNEL);
  drama.id = host.dramaId(id);
  drama.sourceId = id;
  var chapters = Array.isArray(payload.chapters)
    ? payload.chapters
    : Array.isArray(payload.chapterList)
    ? payload.chapterList
    : Array.isArray(row.chapters)
    ? row.chapters
    : [];
  if (chapters.length === 0) {
    var list = apiGet(session, "/api/app/playlet-chapter/list/" + encodeURIComponent(id), null);
    chapters = Array.isArray(list) ? list : [];
  }
  var episodes = [];
  for (var index = 0; index < chapters.length; index++) {
    var chapter = chapters[index] || {};
    var key = text(chapter.id);
    if (key === "") key = String(index + 1);
    var numberText = text(chapter.currentEpisode) || text(chapter.episode) || String(index + 1);
    episodes.push({
      id: host.chapterId(id, key),
      sourceId: id,
      key: key,
      title: text(chapter.title) || "第" + numberText + "集",
      number: number(chapter.currentEpisode) || number(chapter.episode) || index + 1,
      videoUrl: text(chapter.videoUrl) || text(chapter.video_url) || text(chapter.playUrl),
      vip: chapter.vip === true || chapter.isVip === true,
    });
  }
  if (episodes.length > 0) {
    drama.episodes = episodes.length;
    drama.badge = "共 " + episodes.length + " 集";
  }
  return { drama: drama, chapters: episodes };
}

function resolveMedia(task) {
  var selection = task && task.chapter ? task.chapter : {};
  var videoUrl = text(selection.videoUrl);
  if (videoUrl === "") throw new Error("这一集没有可用的播放地址");
  var session = loadSession();
  discoverProtocol(session);
  if (!session.token) claimToken(session);
  var base = apiBase(session);
  var address = videoUrl;
  if (!/^https?:\/\//i.test(address)) {
    address =
      base +
      "/api/app/vid/h5/m3u8/" +
      encodeURIComponent(address.replace(/^\/+|\/+$/g, "")) +
      "?token=" +
      encodeURIComponent(session.token) +
      "&c=" +
      encodeURIComponent(CDN);
  }
  return { url: address, referer: FRONT + "/" };
}

module.exports = {
  validCategory(category) {
    var value = text(category);
    if (value === "" || value === RECOMMEND_ID) return true;
    var session = loadSession();
    discoverProtocol(session);
    var tabs = tabList(session);
    for (var index = 0; index < tabs.length; index++) {
      if (tabs[index].id === value) return true;
    }
    return false;
  },

  categories() {
    var session = loadSession();
    discoverProtocol(session);
    var tabs = tabList(session);
    var items = [{ id: RECOMMEND_ID, name: RECOMMEND_NAME }];
    for (var index = 0; index < tabs.length; index++) items.push(tabs[index]);
    return { items: items };
  },

  catalogPage(page, category) {
    return catalogPage(page, text(category));
  },

  search(page, query) {
    return searchPage(page, query);
  },

  detail(sourceId) {
    return detail(sourceId);
  },

  resolveMedia(task) {
    return resolveMedia(task);
  },
};
