/// 站源观测量：顶栏标题旁边那行「共 4,379 部 / 今日更新 56 集 · 新上 4 部」。
///
/// - `site`：站源目录的**作品总量**，来自站源目录首页自己给的数字
///   （黄桃/91短剧/柚子/X短剧/夜社 = 总页数 × 每页条数，剧果/野果 = 站点 total，
///   黄果视频 = 列表页页眉，黄果AI = 各分类 total 之和，禁果 = 一次拉回的全量，
///   黑桃 = 总页数 × 每页条数 + 末页）。站源给不出时是 0，这时退回本地已见数。
/// - `local`：**「全部」分类里见过的作品数**（按 id 去重）。
///   它只累计「全部」目录里出现过的剧，搜索、排行榜、单独切开的分类都不计入，
///   所以往下翻多少就是多少，不会被别的入口撑大。站源给不出总量时才用它。
/// - `updated`：今天观察到「本来就在库里、集数变多了」的增量之和。
///   今天才第一次翻到的剧不算更新（否则往下翻几页就虚增几百集），跨天归零。
/// - `arrived`：今天「全部」第一页里第一次见到的作品数。
///   有些站源的目录列表压根不给集数（野果、91短剧的 JSON 接口），
///   `updated` 对它们永远是 0；这一项保证顶栏在任何站源上都有变化可看。
///   只统计第一页刷新，翻页、搜索、分类都不计入。
///
/// 第二行的口径对所有站源统一：永远是「今日更新 N 集 · 新上 M 部」，
/// 没有的那一项照实写 0，不再出现「黄果视频两项、黄桃只有一项」这种不一致。
class SourceFacts {
  const SourceFacts({
    this.site = 0,
    this.local = 0,
    this.updated = 0,
    this.arrived = 0,
    this.probed = false,
  });

  final int site;
  final int local;
  final int updated;
  final int arrived;

  /// 这个站源有没有成功观测过（至少拉回来过一页目录）。
  /// 没观测过时不显示任何数字——否则会先闪一下「已收录 24 部」再跳到「共 2,040 部」。
  final bool probed;

  bool get known => site > 0 || local > 0;

  /// 4,379 —— 数量上千后加千分位，扫一眼就知道是「几千部」还是「几十部」。
  static String count(int value) => '$value'.replaceAllMapped(
    RegExp(r'(\d)(?=(\d{3})+$)'),
    (match) => '${match[1]},',
  );

  /// 顶栏第一行：「共 4,379 部」或「已收录 2,051 部」。没数据时返回空串。
  String get headline {
    if (!probed) return '';
    final total = site > 0 ? site : local;
    if (total <= 0) return '';
    return site > 0 ? '共 ${count(total)} 部' : '已收录 ${count(total)} 部';
  }

  /// 顶栏第二行：固定「今日更新 N 集 · 新上 M 部」，两项都写，0 也照实说。
  String get detail {
    if (!probed) return '';
    return '今日更新 ${count(updated)} 集 · 新上 ${count(arrived)} 部';
  }

  /// 2.0.0+136 起顶栏拆成三行，这两句各占一行 —— 顺序按用户要求：
  /// 第二行「新上 N 部」、第三行「今日更新 N 集」。
  String get arrivalsLabel => probed ? '新上 ${count(arrived)} 部' : '';

  String get updatesLabel => probed ? '今日更新 ${count(updated)} 集' : '';

  /// 单行版本（电视顶栏、无障碍播报用）。
  String get label => [headline, detail].where((part) => part.isNotEmpty).join(' · ');
}

String factsDay(DateTime time) {
  String two(int value) => value.toString().padLeft(2, '0');
  return '${time.year}-${two(time.month)}-${two(time.day)}';
}

/// 每个站源记多少个「见过的作品 id」。只用来判断「这一部我今天以前见过没有」，
/// 记第一页到前几十页足够，记太多会把偏好存储撑肿。
const factsSeenLimit = 1500;

/// 每个站源记多少部剧的集数快照（用来算「今日更新」）。
/// 目录第一页每部都记，一千多部足够覆盖常用的几个分类入口。
const factsEpisodeLimit = 1200;

/// 今天优先显示的作品 id 记多少个。
const factsFreshLimit = 240;

int? _int(Object? value) => value is num ? value.toInt() : null;

/// 某个站源「全部」分类里见过的作品 id，用来接着往下累计。
List<String> readKnown(Map<String, Object?> raw, String source) =>
    _stringList(raw, source, 'all');

List<String> readFresh(Map<String, Object?> raw, String source, {DateTime? now}) {
  final row = raw[source];
  if (row is! Map) return const [];
  if (row['day'] != factsDay(now ?? DateTime.now())) return const [];
  return _stringList(raw, source, 'fresh');
}

List<String> _stringList(Map<String, Object?> raw, String source, String key) {
  final row = raw[source];
  if (row is! Map) return const [];
  final list = row[key];
  if (list is! List) return const [];
  return [
    for (final id in list)
      if (id is String && id.isNotEmpty) id,
  ];
}

/// 某个站源上次看到的「剧 id → 集数」。只记集数大于 0 的条目：
/// 站点不给集数的剧本来就无法比较，记下来只会白占地方。
Map<String, int> readEpisodes(Map<String, Object?> raw, String source) {
  final row = raw[source];
  if (row is! Map) return <String, int>{};
  final map = row['ep'];
  if (map is! Map) return <String, int>{};
  final out = <String, int>{};
  for (final entry in map.entries) {
    final key = entry.key;
    final value = _int(entry.value);
    if (key is String && key.isNotEmpty && value != null && value > 0) {
      out[key] = value;
    }
  }
  return out;
}

/// 这个站源有没有做过第一次基线观测。没做过时第一页整页都会被当成「新上」，
/// 得先安静地把名单和集数存下来，下次开始才算增量。
bool readSeeded(Map<String, Object?> raw, String source) {
  final row = raw[source];
  return row is Map && row['seeded'] == true;
}

/// 从存储的原始表里读某个站源的观测值；跨天自动把「今日更新 / 新上」归零。
SourceFacts readFacts(
  Map<String, Object?> raw,
  String source, {
  DateTime? now,
}) {
  final row = raw[source];
  if (row is! Map) return const SourceFacts();
  // 2.0.0+123 之前只存了 total（当时等于本地收录数），旧值按 local 读。
  final site = _int(row['site']) ?? 0;
  final local = _int(row['local']) ?? _int(row['total']) ?? 0;
  final today = row['day'] == factsDay(now ?? DateTime.now());
  final updated = today ? _int(row['updated']) ?? 0 : 0;
  final arrived = today ? _int(row['arrived']) ?? 0 : 0;
  return SourceFacts(
    site: site < 0 ? 0 : site,
    local: local < 0 ? 0 : local,
    updated: updated < 0 ? 0 : updated,
    arrived: arrived < 0 ? 0 : arrived,
    // 老数据（2.0.0+123 之前）没有这个标记，但有数字就说明观测过。
    probed: row['probed'] == true || site > 0,
  );
}

/// 把一次观测写回原始表。返回新的表，调用方负责持久化。
///
/// `known` 是「全部」里见过的作品 id（判「新上」用），`episodes` 是上次看到的
/// 集数（判「今日更新」用），`fresh` 是今天变化过的作品 id（首页优先显示用）。
/// 这三份都由上层维护，这里只负责裁剪长度后落盘。
Map<String, Object?> writeFacts(
  Map<String, Object?> raw,
  String source, {
  required int site,
  required int local,
  int gained = 0,
  int arrived = 0,
  Iterable<String>? known,
  Map<String, int>? episodes,
  Iterable<String>? fresh,
  bool seeded = true,
  DateTime? now,
}) {
  final clock = now ?? DateTime.now();
  final day = factsDay(clock);
  final row = raw[source];
  // 同一天才累加，跨天从 0 重新开始。
  final sameDay = row is Map && row['day'] == day;
  final carried = sameDay ? _int(row['updated']) ?? 0 : 0;
  final updated = carried + (gained > 0 ? gained : 0);
  final carriedArrived = sameDay ? _int(row['arrived']) ?? 0 : 0;
  final arrivedTotal = carriedArrived + (arrived > 0 ? arrived : 0);
  final ids = _tail(known, factsSeenLimit);
  final freshIds = _tail(fresh, factsFreshLimit);
  final snapshot = <String, int>{};
  if (episodes != null) {
    // 只保留最后写进来的若干条：Map 保持插入顺序，越靠前越旧。
    final keys = episodes.keys.toList(growable: false);
    final start = keys.length > factsEpisodeLimit ? keys.length - factsEpisodeLimit : 0;
    for (var index = start; index < keys.length; index++) {
      final key = keys[index];
      final value = episodes[key];
      if (value != null && value > 0) snapshot[key] = value;
    }
  }
  return {
    ...raw,
    source: {
      'day': day,
      'updated': updated < 0 ? 0 : updated,
      'arrived': arrivedTotal < 0 ? 0 : arrivedTotal,
      'site': site < 0 ? 0 : site,
      'local': local < 0 ? 0 : local,
      'probed': true,
      if (seeded) 'seeded': true,
      if (ids.isNotEmpty) 'all': ids,
      if (snapshot.isNotEmpty) 'ep': snapshot,
      if (freshIds.isNotEmpty) 'fresh': freshIds,
    },
  };
}

List<String> _tail(Iterable<String>? values, int limit) {
  if (values == null) return const [];
  final list = [
    for (final value in values)
      if (value.isNotEmpty) value,
  ];
  if (list.length <= limit) return list;
  return list.sublist(list.length - limit);
}
