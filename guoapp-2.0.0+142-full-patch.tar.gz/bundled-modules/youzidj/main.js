// 柚子短剧（youzidj.com）：Cloudflare Workers SSR 自建站。
//
// 列表：/dramas/、/ai-face-swap/、/ai-adult/，翻页 /{栏目}/page/{n}/，每页 24 条。
// 搜索：/api/catalogue/search?q=&kind=works&page={n}，返回 HTML 片段，带 data-pages。
// 详情：/dramas/{slug}/ 是系列页（ld+json 为 TVSeries），新作品的分集地址是
//       /dramas/{slug}/{n}/，老作品是 /dramas/{slug}/season-1-episode-{n}/；
//       单片是 /ai-face-swap/{code}/ 与 /ai-adult/{code}/（ld+json 为 VideoObject）。
// 播放：分集页 <section id="player" data-video="..."> 给出视频 ID，然后
//       POST /api/account/bootstrap                      -> Set-Cookie eden_account
//       POST /api/playback/{videoID}?mode=mse            -> {url, expires_at}
//                                                          + Set-Cookie eden_play_{videoID}
//       m3u8 主列表、子列表与分片都要带 eden_play 这个 HttpOnly Cookie。
//
// ⚠️ 站点 2026-11 起给 /api/* 与 /media/* 加了入口年龄确认（Cookie eden_age_v2，
//    值形如 accepted.<iat>.<exp>.<HMAC>，只能在 POST /age-check 的 303 响应头里拿到）。
//    拿它需要宿主支持 fetch 的 noRedirect 选项（保留 3xx 响应、不跟随跳转）。
//    宿主不支持时会跟随到 200，此时取不到 Set-Cookie，播放会给出明确提示而不是静默失败。

var SITE = "https://youzidj.com";
var UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
var CHANNEL = "柚子短剧";
var PAGE_SIZE = 24;
var MAX_PAGE = 2000;
var MAX_EPISODES = 2000;
var KIND_DRAMAS = "dramas";
var KIND_FACE_SWAP = "face-swap";
var KIND_ADULT = "adult";
var ACCOUNT_COOKIE = "eden_account";
var AGE_COOKIE = "eden_age_v2";

var CATEGORIES = [
  { id: KIND_DRAMAS, name: "AI短剧" },
  { id: KIND_FACE_SWAP, name: "AI换脸" },
  { id: KIND_ADULT, name: "AI成人视频" },
];

var RE_ARTICLE = /<article[^>]*class="[^"]*\bdrama-card\b[^"]*"[^>]*>[\s\S]*?<\/article>/gi;
var RE_CARD_HREF = /href="(?:https?:\/\/[^"/]+)?(\/(?:dramas\/[a-z0-9][a-z0-9-]*\/season-\d+|ai-face-swap\/[a-z0-9]{4,32}|ai-adult\/[a-z0-9]{4,32})\/)"/i;
var RE_CARD_HREF_FLAT = /href="(?:https?:\/\/[^"/]+)?(\/(?:dramas\/[a-z0-9][a-z0-9-]*|ai-face-swap\/[a-z0-9]{4,32}|ai-adult\/[a-z0-9]{4,32})\/)"/i;
var RE_CARD_TITLE = /<p[^>]*class="[^"]*\bdrama-card-title\b[^"]*"[^>]*title="([^"]*)"/i;
var RE_CARD_TITLE_TEXT = /<p[^>]*class="[^"]*\bdrama-card-title\b[^"]*"[^>]*>([\s\S]*?)<\/p>/i;
var RE_CARD_IMAGE = /<img[^>]+src="([^"]+)"/i;
var RE_CARD_EPISODES = /<span[^>]*class="[^"]*\bhome-card-episodes-(?:long|short)\b[^"]*"[^>]*>([\s\S]*?)<\/span>/i;
// 「更新至 12 集」「全 23 集」里的数字。列表条目的集数以前一直是 0，
// 顶栏「今日更新」只有在原有剧集数变大时才算增量，拿不到集数就永远是 0 集。
var RE_REMARK_EPISODES = /(?:更新至|更新中|全|共|第)?\s*(\d{1,5})\s*(?:集|话|期)/;
function remarkEpisodes(text) {
  var match = RE_REMARK_EPISODES.exec(String(text || ""));
  if (!match) return 0;
  var count = asNumber(match[1], 0);
  return count > 0 && count <= 100000 ? count : 0;
}
// 卡片下方那排标签（<a class="drama-card-tag"><span>调教</span></a>）以前整块
// 没解析。它们虽然带 hidden（前端折叠用），但服务端渲染的 HTML 里文本是全的，
// 是这批剧唯一能拿到的题材信息——不解析的话「标签命中」这一档在本站永远空。
var RE_CARD_TAGS = /<a[^>]*class="[^"]*\bdrama-card-tag\b[^"]*"[^>]*>[\s\S]*?<span[^>]*>([\s\S]*?)<\/span>/gi;
var RE_NEXT_PAGE = /<a[^>]*rel="next"[^>]*href="([^"]+)"/i;
var RE_NEXT_PAGE_ALT = /<a[^>]*href="([^"]+)"[^>]*rel="next"/i;
var RE_PAGE_COUNT = /data-pages="(\d+)"/i;
// 分页控件的页码链接会带 aria-label="第 37 页"，取最大值即总页数。
var RE_PAGE_LABEL = /第\s*(\d+)\s*页/g;
var RE_EPISODE_LINK = /href="(?:https?:\/\/[^"/]+)?\/dramas\/([a-z0-9][a-z0-9-]*)\/season-(\d+)-episode-(\d+)\/"/gi;
var RE_EPISODE_PATH = /href="(?:https?:\/\/[^"/]+)?\/dramas\/([a-z0-9][a-z0-9-]*)\/(\d+)\/"/gi;
var RE_LDJSON = /<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi;
var RE_PLAYER = /<section[^>]*id="player"[^>]*>/i;
var RE_DATA_VIDEO = /data-video="([^"]+)"/i;
var RE_TAG_LINK = /<a[^>]*href="(?:https?:\/\/[^"/]+)?\/tags\/([a-z0-9-]+)\/"[^>]*>([\s\S]*?)<\/a>/gi;
var RE_OG_IMAGE = /<meta[^>]*property="og:image"[^>]*content="([^"]+)"/i;
var RE_OG_TITLE = /<meta[^>]*property="og:title"[^>]*content="([^"]+)"/i;
var RE_HTML_TAG = /<[^>]+>/g;
var RE_SLUG = /^[a-z0-9][a-z0-9-]{0,79}$/;
var RE_CODE = /^[a-z0-9]{4,32}$/;

function unescapeHtml(text) {
  return String(text)
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&#(\d+);/g, function (_, code) {
      return String.fromCharCode(parseInt(code, 10));
    });
}

function clean(text) {
  if (text === null || text === undefined) return "";
  var raw = unescapeHtml(String(text).replace(RE_HTML_TAG, " "));
  raw = raw.replace(/\u3000/g, " ").replace(/\u00a0/g, " ");
  return raw.replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
}

function clip(text, limit) {
  var value = String(text === null || text === undefined ? "" : text);
  return value.length > limit ? value.slice(0, limit) : value;
}

function absUrl(raw) {
  var value = String(raw || "").replace(/^\s+|\s+$/g, "");
  value = unescapeHtml(value);
  if (value === "") return "";
  if (value.indexOf("//") === 0) return "https:" + value;
  if (/^https?:\/\//i.test(value)) return value;
  if (value.charAt(0) === "/") return SITE + value;
  return SITE + "/" + value;
}

function asNumber(value, fallback) {
  var parsed = parseInt(String(value), 10);
  return isNaN(parsed) ? fallback : parsed;
}

function splitSourceId(id) {
  var value = String(id || "").replace(/^\s+|\s+$/g, "").replace(/^\/+|\/+$/g, "");
  if (value.indexOf(KIND_DRAMAS + "/") === 0) return { kind: KIND_DRAMAS, rest: value.slice(7) };
  if (value.indexOf("ai-face-swap/") === 0) return { kind: KIND_FACE_SWAP, rest: value.slice(13) };
  if (value.indexOf("ai-adult/") === 0) return { kind: KIND_ADULT, rest: value.slice(9) };
  return { kind: "", rest: "" };
}

function validSourceId(id) {
  var parts = splitSourceId(id);
  if (parts.rest === "") return false;
  if (parts.kind === KIND_DRAMAS) return RE_SLUG.test(parts.rest);
  if (parts.kind === KIND_FACE_SWAP || parts.kind === KIND_ADULT) return RE_CODE.test(parts.rest);
  return false;
}

function kindName(kind) {
  if (kind === KIND_FACE_SWAP) return "AI换脸";
  if (kind === KIND_ADULT) return "AI成人视频";
  return "AI短剧";
}

function validCategory(category) {
  var value = String(category || "").replace(/^\s+|\s+$/g, "");
  return value === "" || value === KIND_DRAMAS || value === KIND_FACE_SWAP || value === KIND_ADULT;
}

function textGet(path, cookie) {
  var address = path.indexOf("http") === 0 ? path : SITE + path;
  var request = { url: address, referer: SITE + "/", userAgent: UA };
  if (cookie) request.cookie = cookie;
  var response = host.fetchText(request);
  return response && response.body ? response.body : "";
}

function headerValue(headers, name) {
  if (!headers) return "";
  var wanted = String(name).toLowerCase();
  for (var key in headers) {
    if (!Object.prototype.hasOwnProperty.call(headers, key)) continue;
    if (String(key).toLowerCase() !== wanted) continue;
    var value = headers[key];
    if (value instanceof Array) return value.length > 0 ? String(value[0]) : "";
    return String(value);
  }
  return "";
}

function cookieValue(raw, name) {
  if (!raw) return "";
  var parts = String(raw).split(";");
  for (var index = 0; index < parts.length; index++) {
    var part = parts[index];
    var cut = part.indexOf("=");
    if (cut <= 0) continue;
    if (part.slice(0, cut).replace(/^\s+|\s+$/g, "") !== name) continue;
    return part.slice(cut + 1).replace(/^\s+|\s+$/g, "");
  }
  return "";
}

function joinCookies() {
  var kept = [];
  for (var index = 0; index < arguments.length; index++) {
    var part = String(arguments[index] || "").replace(/^\s+|\s+$/g, "");
    if (part !== "") kept.push(part);
  }
  return kept.join("; ");
}

function ageTtl(value) {
  var parts = String(value).split(".");
  var expires = parts.length >= 3 ? asNumber(parts[2], 0) : 0;
  var now = Math.floor(new Date().getTime() / 1000);
  if (expires > now + 120) return (expires - now - 60) * 1000;
  return 6 * 3600 * 1000;
}

function ageCookie() {
  var cached = host.cacheGet("age");
  if (cached !== null && cached !== undefined && String(cached) !== "") return String(cached);
  var response = null;
  try {
    response = host.fetch({
      method: "POST",
      url: SITE + "/age-check",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "text/html,application/xhtml+xml",
        Origin: SITE,
        Referer: SITE + "/",
        "User-Agent": UA,
      },
      body: "return_to=%2F&decision=accepted",
      anyStatus: true,
      noRedirect: true,
      timeoutMs: 20000,
    });
  } catch (error) {
    return "";
  }
  var value = cookieValue(headerValue(response && response.headers, "set-cookie"), AGE_COOKIE);
  if (value !== "") {
    host.cacheSet("age", value, ageTtl(value));
    return value;
  }
  // 303 说明宿主保留了跳转响应，只是站点没下发 Cookie；否则是宿主把 303 跟丢了。
  if (!response || response.status !== 303) host.log("柚子短剧：宿主未保留 303 响应，无法读取年龄凭证");
  return "";
}

function dropAgeCookie() {
  host.cacheSet("age", null, 0);
}

function ageHint() {
  return "柚子短剧需要在网站入口完成一次年龄确认，而当前 App 版本取不到这一步的凭证；请换用带站源补丁的 2.0 构建，或暂时用定制版观看柚子";
}

function apiPost(path, cookie) {
  var headers = {
    "Content-Type": "application/json",
    Accept: "application/json, text/plain, */*",
    Origin: SITE,
    Referer: SITE + "/",
    "User-Agent": UA,
  };
  if (cookie) headers.Cookie = cookie;
  return host.fetch({
    method: "POST",
    url: SITE + path,
    headers: headers,
    body: "{}",
    acceptStatus: [401, 403],
    anyStatus: true,
    timeoutMs: 25000,
  });
}

function makeDrama(sourceId, title, cover, extra) {
  var drama = {
    id: host.dramaId(sourceId),
    source: host.source,
    sourceId: sourceId,
    title: title,
    name: title,
    channelName: CHANNEL,
  };
  if (cover) {
    drama.cover = cover;
    drama.coverUrl = cover;
  }
  if (extra) {
    for (var key in extra) {
      if (Object.prototype.hasOwnProperty.call(extra, key) && extra[key] !== "" && extra[key] !== null) {
        drama[key] = extra[key];
      }
    }
  }
  if (!drama.categoryName) drama.categoryName = "AI短剧";
  return drama;
}

function sourceIdFromPath(path) {
  var trimmed = String(path || "").replace(/^\s+|\s+$/g, "").replace(/^\/+|\/+$/g, "");
  if (trimmed.indexOf(KIND_DRAMAS + "/") === 0) {
    var rest = trimmed.slice(7);
    var season = rest.indexOf("/season-");
    if (season > 0) rest = rest.slice(0, season);
    if (RE_SLUG.test(rest)) return KIND_DRAMAS + "/" + rest;
    return "";
  }
  if (trimmed.indexOf("ai-face-swap/") === 0) {
    var swap = trimmed.slice(13);
    if (RE_CODE.test(swap)) return "ai-face-swap/" + swap;
  }
  if (trimmed.indexOf("ai-adult/") === 0) {
    var adult = trimmed.slice(9);
    if (RE_CODE.test(adult)) return "ai-adult/" + adult;
  }
  return "";
}

// cardTags 从一张卡片里把标签抠出来。卡片里的标签既有可见的也有 hidden 的，
// 都算——hidden 只是前端折叠，文本本身是站点给的题材词。
function cardTags(chunk) {
  var tags = [];
  var seen = {};
  RE_CARD_TAGS.lastIndex = 0;
  var match;
  while ((match = RE_CARD_TAGS.exec(chunk)) !== null) {
    var value = clip(clean(match[1]), 24);
    if (value === "" || seen[value]) continue;
    seen[value] = true;
    tags.push(value);
    if (tags.length >= 8) break;
  }
  return tags;
}

function parseCards(body) {
  var items = [];
  var seen = {};
  RE_ARTICLE.lastIndex = 0;
  var block;
  while ((block = RE_ARTICLE.exec(body)) !== null) {
    var chunk = block[0];
    var match = RE_CARD_HREF.exec(chunk) || RE_CARD_HREF_FLAT.exec(chunk);
    if (!match) continue;
    var sourceId = sourceIdFromPath(match[1]);
    if (sourceId === "" || seen[sourceId]) continue;
    var title = "";
    var titleMatch = RE_CARD_TITLE.exec(chunk);
    if (titleMatch) title = clean(titleMatch[1]);
    if (title === "") {
      var textMatch = RE_CARD_TITLE_TEXT.exec(chunk);
      if (textMatch) title = clean(textMatch[1]);
    }
    if (title === "") continue;
    var coverMatch = RE_CARD_IMAGE.exec(chunk);
    var remark = "";
    var epMatch = RE_CARD_EPISODES.exec(chunk);
    if (epMatch) remark = clip(clean(epMatch[1]), 32);
    seen[sourceId] = true;
    var parts = splitSourceId(sourceId);
    var tags = cardTags(chunk);
    var extra = {
      categoryName: kindName(parts.kind),
      remark: remark,
    };
    var episodes = remarkEpisodes(remark);
    if (episodes > 0) {
      extra.episodeCount = episodes;
      extra.totalEpisode = episodes;
    }
    if (tags.length > 0) extra.tags = tags;
    items.push(
      makeDrama(sourceId, clip(title, 512), coverMatch ? absUrl(coverMatch[1]) : "", extra)
    );
  }
  return items;
}

function listPath(category, page) {
  var base = "/" + KIND_DRAMAS + "/";
  var value = String(category || "").replace(/^\s+|\s+$/g, "");
  if (value === KIND_FACE_SWAP) base = "/ai-face-swap/";
  else if (value === KIND_ADULT) base = "/ai-adult/";
  return page > 1 ? base + "page/" + page + "/" : base;
}

function hasNext(body, page, count) {
  if (RE_NEXT_PAGE.test(body) || RE_NEXT_PAGE_ALT.test(body)) return true;
  var match = RE_PAGE_COUNT.exec(body);
  if (match) {
    var pages = asNumber(match[1], 0);
    if (pages > 0) return page < pages;
  }
  return count >= PAGE_SIZE;
}

// 目录作品总量：分页控件里最靠后的「第 N 页」（站点会带一个省略号 + 末页）。
// 只在第一页算，每页条数取第一页实际条数，末页不满最多差一页。
function catalogTotal(body, page, pageSize) {
  if (page !== 1 || pageSize <= 0) return 0;
  var last = lastPageOf(body);
  return last > 0 ? last * pageSize : 0;
}

// 分页控件里最靠后的页码。三种来源依次尝试：「第 N 页」文案、data-pages、
// /page/N/ 链接（柚子这版把末页做成了省略号 + 末页链接，前两种常常没有）。
function lastPageOf(body) {
  var last = 0;
  var match;
  RE_PAGE_LABEL.lastIndex = 0;
  while ((match = RE_PAGE_LABEL.exec(body)) !== null) {
    var index = asNumber(match[1], 0);
    if (index > last && index <= MAX_PAGE) last = index;
  }
  if (last > 0) return last;
  var counted = RE_PAGE_COUNT.exec(body);
  if (counted) return asNumber(counted[1], 0);
  var links = body.match(/\/page\/(\d+)\//g) || [];
  for (var slot = 0; slot < links.length; slot++) {
    var value = asNumber(String(links[slot]).replace(/[^0-9]/g, ""), 0);
    if (value > last && value <= MAX_PAGE) last = value;
  }
  return last;
}

function ldItems(body) {
  var items = [];
  RE_LDJSON.lastIndex = 0;
  var match;
  while ((match = RE_LDJSON.exec(body)) !== null) {
    try {
      var value = JSON.parse(match[1]);
      if (value && value["@type"]) items.push(value);
    } catch (error) {}
  }
  return items;
}

function ldImage(value) {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") return value;
  if (value instanceof Array) {
    for (var index = 0; index < value.length; index++) {
      if (typeof value[index] === "string" && value[index] !== "") return value[index];
    }
  }
  if (typeof value === "object") return ldImage(value.url || value.contentUrl);
  return "";
}

function seriesChapters(body, sourceId) {
  var parts = splitSourceId(sourceId);
  var slug = parts.rest;
  if (slug === "") return [];
  var seen = {};
  var keys = [];
  var seasons = {};
  var flat = false;
  RE_EPISODE_LINK.lastIndex = 0;
  var match;
  while ((match = RE_EPISODE_LINK.exec(body)) !== null) {
    if (match[1] !== slug) continue;
    var season = asNumber(match[2], 0);
    var episode = asNumber(match[3], 0);
    if (season < 1 || episode < 1) continue;
    var key = season + "-" + episode;
    if (seen[key] || keys.length >= MAX_EPISODES) continue;
    seen[key] = true;
    seasons[season] = true;
    keys.push({ season: season, episode: episode });
  }
  if (keys.length === 0) {
    RE_EPISODE_PATH.lastIndex = 0;
    while ((match = RE_EPISODE_PATH.exec(body)) !== null) {
      if (match[1] !== slug) continue;
      var number = asNumber(match[2], 0);
      if (number < 1 || keys.length >= MAX_EPISODES) continue;
      var flatKey = "1-" + number;
      if (seen[flatKey]) continue;
      seen[flatKey] = true;
      seasons[1] = true;
      keys.push({ season: 1, episode: number });
    }
    flat = keys.length > 0;
  }
  keys.sort(function (left, right) {
    if (left.season !== right.season) return left.season - right.season;
    return left.episode - right.episode;
  });
  var multiSeason = false;
  for (var seasonKey in seasons) {
    if (Object.prototype.hasOwnProperty.call(seasons, seasonKey) && seasonKey !== "1") multiSeason = true;
  }
  if (Object.prototype.hasOwnProperty.call(seasons, "1") === false) multiSeason = true;
  var chapters = [];
  for (var index = 0; index < keys.length; index++) {
    var entry = keys[index];
    var chapterKey = flat ? String(entry.episode) : "season-" + entry.season + "-episode-" + entry.episode;
    var title = multiSeason ? "第" + entry.season + "季 第" + entry.episode + "集" : "第" + entry.episode + "集";
    chapters.push({
      id: host.chapterId(sourceId, chapterKey),
      source: host.source,
      title: clip(title, 128),
      currentEpisode: index + 1,
      videoUrl: "youzidj-play://" + chapterKey,
      pageUrl: SITE + "/" + sourceId + "/" + chapterKey + "/",
      referer: SITE + "/",
    });
  }
  return chapters;
}

function seasonChapters(item, sourceId) {
  var parts = splitSourceId(sourceId);
  if (parts.rest === "" || !(item.episode instanceof Array) || item.episode.length === 0) return [];
  var episodes = [];
  for (var index = 0; index < item.episode.length; index++) {
    var entry = item.episode[index] || {};
    var number = asNumber(entry.episodeNumber, 0);
    if (number <= 0) number = index + 1;
    episodes.push(number);
  }
  episodes.sort(function (left, right) {
    return left - right;
  });
  var chapters = [];
  for (var inner = 0; inner < episodes.length; inner++) {
    var chapterKey = "season-1-episode-" + episodes[inner];
    chapters.push({
      id: host.chapterId(sourceId, chapterKey),
      source: host.source,
      title: clip("第" + episodes[inner] + "集", 128),
      currentEpisode: inner + 1,
      videoUrl: "youzidj-play://" + chapterKey,
      pageUrl: SITE + "/" + sourceId + "/" + chapterKey + "/",
      referer: SITE + "/",
    });
  }
  return chapters;
}

function tagsOf(body) {
  var tags = [];
  var seen = {};
  RE_TAG_LINK.lastIndex = 0;
  var match;
  while ((match = RE_TAG_LINK.exec(body)) !== null) {
    var tag = clip(clean(match[2]), 16);
    if (tag === "" || seen[tag] || tags.length >= 8) continue;
    seen[tag] = true;
    tags.push(tag);
  }
  return tags;
}

function playerVideoId(body) {
  var tag = RE_PLAYER.exec(body);
  if (!tag) return "";
  var match = RE_DATA_VIDEO.exec(tag[0]);
  return match ? String(match[1]).replace(/^\s+|\s+$/g, "") : "";
}

function accountCookie() {
  var cached = host.loadState("account");
  if (cached && String(cached) !== "") return String(cached);
  var age = ageCookie();
  var response = apiPost("/api/account/bootstrap", age ? AGE_COOKIE + "=" + age : "");
  if (!response || response.status !== 200) return "";
  var value = cookieValue(headerValue(response.headers, "set-cookie"), ACCOUNT_COOKIE);
  if (value !== "") host.saveState("account", value);
  return value;
}

function resetAccount() {
  host.saveState("account", "");
}

function requestPlayback(videoId, pageUrl, bootstrap) {
  var age = ageCookie();
  var account = accountCookie();
  if (bootstrap && account === "") {
    return { response: null, payload: null, broken: age === "" ? "age" : "account", age: age, account: "" };
  }
  var response = apiPost(
    "/api/playback/" + encodeURIComponent(videoId) + "?mode=mse",
    joinCookies(age ? AGE_COOKIE + "=" + age : "", account ? ACCOUNT_COOKIE + "=" + account : "")
  );
  var payload = null;
  try {
    payload = JSON.parse(response && response.body ? response.body : "");
  } catch (error) {}
  var message = payload && payload.error ? String(payload.error) : "";
  var broken = "";
  if (response && response.status === 403 && message.indexOf("年龄") >= 0) broken = "age";
  else if (response && response.status === 401) broken = "account";
  return { response: response, payload: payload, broken: broken, age: age, account: account };
}

// 清晰度：站点给的主列表通常是 720 与 1080 两档。手机上 1080 的 2 秒分片
// 有 1.4~2.6MB，拖动到没缓冲的位置时单块实测要 7~8 秒才回来，播放器等不到
// 就把「分片没到」当成片尾 —— 现象就是黑屏。这里在模块里先把主列表读掉，
// 只把最轻的一档交给宿主，字节数直接砍一半，宿主那边也不用再挑档。
//
// 顺带解决另一件事：站点每次重新领凭证会重新挑档（同一集有时给 1920、
// 有时给 1280），一换档所有分片都要重下一遍。钉死最轻一档之后，缓存能复用。
function resolveAgainst(base, reference) {
  var text = String(reference).replace(/^\s+|\s+$/g, "");
  if (/^https?:\/\//i.test(text)) return text;
  var origin = /^(https?:\/\/[^\/]+)/i.exec(String(base));
  var prefix = origin ? origin[1] : SITE;
  if (text.indexOf("//") === 0) return (origin ? origin[1].split(":")[0] : "https") + ":" + text;
  if (text.charAt(0) === "/") return prefix + text;
  var clean = String(base).split("?")[0];
  return clean.slice(0, clean.lastIndexOf("/") + 1) + text;
}

function lightestVariant(masterUrl, text) {
  var lines = String(text).replace(/\r\n/g, "\n").split("\n");
  var best = "";
  var bestBand = -1;
  for (var index = 0; index < lines.length; index++) {
    var line = lines[index].replace(/^\s+|\s+$/g, "");
    if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
    var average = /AVERAGE-BANDWIDTH=(\d+)/i.exec(line);
    var peak = /(?:^|[^-])BANDWIDTH=(\d+)/i.exec(line);
    var band = asNumber(average ? average[1] : peak ? peak[1] : 0, 0);
    var uri = "";
    for (var next = index + 1; next < lines.length; next++) {
      var candidate = lines[next].replace(/^\s+|\s+$/g, "");
      if (candidate === "" || candidate.charAt(0) === "#") continue;
      uri = candidate;
      break;
    }
    if (uri === "") continue;
    if (bestBand < 0 || band < bestBand) {
      bestBand = band;
      best = resolveAgainst(masterUrl, uri);
    }
  }
  return best;
}

// 只认主列表（带 #EXT-X-STREAM-INF）。站点有时候直接给子列表，那就原样用。
function lightestMediaUrl(mediaUrl, cookie) {
  if (!/\.m3u8(\?|$)/i.test(mediaUrl)) return "";
  var text = "";
  try {
    text = textGet(mediaUrl, cookie);
  } catch (error) {
    return "";
  }
  if (!text || text.indexOf("#EXTM3U") < 0) return "";
  if (text.indexOf("#EXT-X-STREAM-INF:") < 0) return "";
  return lightestVariant(mediaUrl, text);
}

// 搜索结果补简介。
//
// 搜索结果页的卡片只有标题和标签，简介在详情页的 ld+json 里。缺简介时 native
// 判不到「仅简介命中」这一档，这些条目会被当成无关丢掉。这里对「标题和标签
// 都没命中」的条目按需补一次简介，按 id 缓存 7 天。
// 柚子单页要现场查 PG（3 秒起），所以预算比别的站更紧。
var INTRO_TTL_MS = 7 * 24 * 60 * 60 * 1000;
var INTRO_PAGE_BUDGET = 4;
var INTRO_PAGE_BUDGET_MS = 8000;
var INTRO_LATER_BUDGET = 2;
var INTRO_LATER_BUDGET_MS = 4000;

function introUnknown(drama, keyword, words) {
  var title = String(drama.title || drama.name || "").toLowerCase();
  if (title.indexOf(keyword) >= 0) return false;
  for (var index = 0; index < words.length; index++) {
    if (title.indexOf(words[index]) >= 0) return false;
  }
  var meta = [String(drama.categoryName || drama.category || "")].concat(drama.tags || []);
  for (var position = 0; position < meta.length; position++) {
    var value = String(meta[position]).toLowerCase();
    if (value === "") continue;
    if (value.indexOf(keyword) >= 0) return false;
    for (var word = 0; word < words.length; word++) {
      if (value.indexOf(words[word]) >= 0) return false;
    }
  }
  return true;
}

function attachIntros(items, keyword, page) {
  // 首屏补得多一点，后面几页补得少一点：只补第一页的话，用户往下翻到的
  // 那些「只有简介沾边」的作品会被 native 当无关丢掉，看起来就是搜不全。
  var budget = page === 1 ? INTRO_PAGE_BUDGET : INTRO_LATER_BUDGET;
  var budgetMs = page === 1 ? INTRO_PAGE_BUDGET_MS : INTRO_LATER_BUDGET_MS;
  var lowered = String(keyword || "").toLowerCase();
  if (lowered === "") return;
  var words = lowered.split(/\s+/).filter(function (word) {
    return word !== "";
  });
  var started = Date.now();
  var filled = 0;
  for (var index = 0; index < items.length; index++) {
    if (filled >= budget || Date.now() - started > budgetMs) return;
    var drama = items[index];
    if (drama.desc || drama.intro) continue;
    if (!introUnknown(drama, lowered, words)) continue;
    var id = String(drama.sourceId || "");
    if (id === "") continue;
    var cached = null;
    try {
      cached = host.cacheGet("intro:" + id);
    } catch (error) {
      cached = null;
    }
    if (cached !== null && cached !== "") {
      drama.desc = cached;
      drama.intro = cached;
      continue;
    }
    var intro = "";
    try {
      intro = fetchIntro(id);
    } catch (error) {
      intro = "";
    }
    if (intro === "") continue;
    drama.desc = intro;
    drama.intro = intro;
    try {
      host.cacheSet("intro:" + id, intro, INTRO_TTL_MS);
    } catch (error) {}
    filled++;
  }
}

function fetchIntro(sourceId) {
  var id = String(sourceId || "").replace(/^\s+|\s+$/g, "").replace(/^\/+|\/+$/g, "");
  var parts = splitSourceId(id);
  var cookie = ageCookie() ? AGE_COOKIE + "=" + ageCookie() : "";
  var pageUrl = SITE + "/" + id + "/";
  var body = "";
  try {
    body = textGet(pageUrl, cookie);
  } catch (error) {
    if (parts.kind !== KIND_DRAMAS) throw error;
    body = textGet(pageUrl + "season-1/", cookie);
  }
  var entries = ldItems(body);
  for (var index = 0; index < entries.length; index++) {
    var kind = entries[index]["@type"];
    if (kind !== "TVSeries" && kind !== "TVSeason" && kind !== "VideoObject" && kind !== "Movie") continue;
    var value = clip(clean(entries[index].description), 4000);
    if (value !== "") return value;
  }
  return "";
}

// ---- 「全部」= 各栏目拼接 ----------------------------------------------------
//
// 柚子三个栏目是并列的：/dramas/（AI短剧）、/ai-face-swap/（AI换脸）、
// /ai-adult/（AI成人视频）。站点没有把三者合起来的总列表，老写法拿 /dramas/
// 当「全部」，另外两栏的作品在「全部」里永远翻不到。
//
// 这里按页把三个栏目接成一个虚拟列表；每个栏目的总页数从它自己那页的分页
// 控件学到并缓存一天，没学到时用实测页数兜底。
var SECTIONS = [KIND_DRAMAS, KIND_FACE_SWAP, KIND_ADULT];
var SECTION_PAGES_KEY = "sections:pages";
var SECTION_PAGES_TTL_MS = 24 * 60 * 60 * 1000;
var SECTION_PAGES_DEFAULT = {
  "dramas": 37,
  "face-swap": 3,
  "adult": 8,
};

function sectionPages() {
  var stored = null;
  try {
    stored = host.cacheGet(SECTION_PAGES_KEY);
  } catch (error) {
    stored = null;
  }
  var pages = {};
  var key;
  if (stored && typeof stored === "object") {
    for (key in stored) {
      if (Object.prototype.hasOwnProperty.call(stored, key)) {
        pages[key] = asNumber(stored[key], 0);
      }
    }
  }
  for (key in SECTION_PAGES_DEFAULT) {
    if (!pages[key] || pages[key] <= 0) pages[key] = SECTION_PAGES_DEFAULT[key];
  }
  return pages;
}

function rememberSectionPages(category, count) {
  if (!count || count <= 0) return;
  var pages = sectionPages();
  if (pages[category] === count) return;
  pages[category] = count;
  try {
    host.cacheSet(SECTION_PAGES_KEY, pages, SECTION_PAGES_TTL_MS);
  } catch (error) {}
}

// 拉某个栏目的一页，顺手把它真实的总页数记下来（不额外发请求）。
function loadSection(category, page) {
  var cookie = ageCookie() ? AGE_COOKIE + "=" + ageCookie() : "";
  var body = textGet(listPath(category, page), cookie);
  var items = parseCards(body);
  var pages = lastPageOf(body);
  if (pages > 0) rememberSectionPages(category, pages);
  return {
    items: items,
    pages: pages > 0 ? pages : sectionPages()[category],
  };
}

module.exports = {
  validCategory: validCategory,

  categories: function () {
    return CATEGORIES.slice();
  },

  catalogPage: function (page, category) {
    var index = asNumber(page, 0);
    if (index < 1 || index > MAX_PAGE) throw new Error("柚子短剧目录页码无效");
    if (!validCategory(category)) throw new Error("柚子短剧内容分类无效");
    var value = String(category || "").replace(/^\s+|\s+$/g, "");
    if (value !== "") {
      var single = loadSection(value, index);
      if (single.items.length === 0) return { items: [], hasMore: false };
      return {
        items: single.items,
        hasMore: index < single.pages,
        total: 0,
      };
    }
    // 「全部」= AI短剧 / AI换脸 / AI成人视频 三个栏目按页接起来。
    // 站点没有跨栏目的总列表，老写法直接抓 /dramas/（只有 AI短剧 这一栏，
    // 37 页 ≈ 888 部），另外两栏（换脸 3 页、成人视频 8 页）在「全部」里
    // 一条都翻不到。
    var pages = sectionPages();
    var totalPages = 0;
    for (var each = 0; each < SECTIONS.length; each++) {
      totalPages += pages[SECTIONS[each]];
    }
    var total = totalPages * PAGE_SIZE;
    var remaining = index;
    for (var slot = 0; slot < SECTIONS.length; slot++) {
      var span = pages[SECTIONS[slot]];
      if (remaining > span) {
        remaining -= span;
        continue;
      }
      var section = loadSection(SECTIONS[slot], remaining);
      return {
        items: section.items,
        hasMore: index < totalPages,
        total: total,
      };
    }
    return { items: [], hasMore: false, total: total };
  },

  search: function (page, query) {
    var index = asNumber(page, 0);
    var keyword = String(query || "").replace(/^\s+|\s+$/g, "");
    if (keyword === "") return { items: [], hasMore: false };
    if (index < 1 || index > MAX_PAGE) throw new Error("柚子短剧搜索页码无效");
    if (keyword.length > 40) throw new Error("柚子短剧搜索关键词无效");
    var cookie = ageCookie() ? AGE_COOKIE + "=" + ageCookie() : "";
    var body = "";
    try {
      body = textGet(
        "/api/catalogue/search?q=" + encodeURIComponent(keyword) + "&kind=works" + (index > 1 ? "&page=" + index : ""),
        cookie
      );
    } catch (error) {
      return { items: [], hasMore: false, warning: ageHint() };
    }
    var items = parseCards(body);
    if (items.length === 0) return { items: [], hasMore: false };
    attachIntros(items, keyword, index);
    return { items: items, hasMore: hasNext(body, index, items.length) };
  },

  detail: function (sourceId) {
    var id = String(sourceId || "").replace(/^\s+|\s+$/g, "").replace(/^\/+|\/+$/g, "");
    if (!validSourceId(id)) throw new Error("柚子短剧剧集标识无效");
    var parts = splitSourceId(id);
    var cookie = ageCookie() ? AGE_COOKIE + "=" + ageCookie() : "";
    var pageUrl = SITE + "/" + id + "/";
    var body = "";
    try {
      body = textGet(pageUrl, cookie);
    } catch (error) {
      if (parts.kind !== KIND_DRAMAS) throw error;
      body = textGet(pageUrl + "season-1/", cookie);
    }

    var series = null;
    var season = null;
    var video = null;
    var items = ldItems(body);
    for (var index = 0; index < items.length; index++) {
      var kind = items[index]["@type"];
      if (kind === "TVSeries" && !series) series = items[index];
      else if (kind === "TVSeason" && !season) season = items[index];
      else if ((kind === "VideoObject" || kind === "Movie") && !video) video = items[index];
    }

    var title = "";
    var description = "";
    var cover = "";
    var chapters = [];
    if (series) {
      title = clean(series.name);
      description = clean(series.description);
      cover = ldImage(series.image);
      chapters = seriesChapters(body, id);
      if (chapters.length === 0 && season) chapters = seasonChapters(season, id);
    } else if (season) {
      title = clean(season.name);
      description = clean(season.description);
      cover = ldImage(season.image);
      chapters = seriesChapters(body, id);
      if (chapters.length === 0) chapters = seasonChapters(season, id);
    } else if (video) {
      title = clean(video.name);
      description = clean(video.description);
      cover = ldImage(video.thumbnailUrl);
    }
    if (title === "") {
      var ogTitle = RE_OG_TITLE.exec(body);
      if (ogTitle) title = clean(ogTitle[1]);
    }
    if (cover === "") {
      var ogImage = RE_OG_IMAGE.exec(body);
      if (ogImage) cover = absUrl(ogImage[1]);
    }
    if (title === "") throw new Error("柚子短剧详情缺少剧集名称");

    if (chapters.length === 0 && parts.kind !== KIND_DRAMAS) {
      chapters = [
        {
          id: host.chapterId(id, "single"),
          source: host.source,
          title: "正片",
          currentEpisode: 1,
          videoUrl: "youzidj-play://single",
          pageUrl: pageUrl,
          referer: SITE + "/",
        },
      ];
    }
    if (chapters.length === 0) throw new Error("柚子短剧该剧暂无可用分集");

    var extra = {
      desc: clip(description, 12000),
      intro: clip(description, 12000),
      categoryName: kindName(parts.kind),
      episodeCount: chapters.length,
      totalEpisode: chapters.length,
      remark: "全" + chapters.length + "集",
    };
    var tags = tagsOf(body);
    if (tags.length > 0) extra.tags = tags;
    return { drama: makeDrama(id, clip(title, 512), absUrl(cover), extra), chapters: chapters };
  },

  resolveMedia: function (task) {
    var chapter = task && task.chapter ? task.chapter : {};
    var dramaId = String((task && task.dramaId) || host.source + ":");
    var prefix = host.source + ":";
    var rest = dramaId.indexOf(prefix) === 0 ? dramaId.slice(prefix.length) : "";
    var sourceId = rest;
    var chapterKey = "";
    var separator = rest.indexOf(":");
    if (separator > 0) {
      sourceId = rest.slice(0, separator);
      chapterKey = rest.slice(separator + 1);
    }
    sourceId = sourceId.replace(/^\/+|\/+$/g, "");
    if (!validSourceId(sourceId)) throw new Error("柚子短剧播放信息无效，请刷新详情");

    var pageUrl = String(chapter.pageUrl || "").replace(/^\s+|\s+$/g, "");
    if (pageUrl === "") {
      pageUrl = SITE + "/" + sourceId + "/";
      if (chapterKey !== "" && chapterKey !== "single") pageUrl = SITE + "/" + sourceId + "/" + chapterKey + "/";
    }

    var cookie = ageCookie() ? AGE_COOKIE + "=" + ageCookie() : "";
    var body = "";
    try {
      body = textGet(pageUrl, cookie);
    } catch (error) {
      throw new Error(ageHint());
    }
    var videoId = playerVideoId(body);
    if (videoId === "") throw new Error("柚子短剧该集暂无可播放地址，可能需要在站点解锁");

    var outcome = requestPlayback(videoId, pageUrl, true);
    if (outcome.broken === "age") {
      dropAgeCookie();
      outcome = requestPlayback(videoId, pageUrl, true);
    } else if (outcome.broken === "account") {
      resetAccount();
      outcome = requestPlayback(videoId, pageUrl, true);
    }
    if (outcome.broken === "age") throw new Error(ageHint());
    var response = outcome.response;
    var payload = outcome.payload;
    if (!response || response.status !== 200) {
      var message = payload && payload.error ? String(payload.error) : "";
      throw new Error("柚子短剧播放凭证获取失败：" + (message || "站点返回 HTTP " + (response ? response.status : 0)));
    }
    var path = String((payload && payload.url) || "").replace(/^\s+|\s+$/g, "");
    if (path === "") throw new Error("柚子短剧未返回播放地址");
    var mediaUrl = path.indexOf("/") === 0 ? SITE + path : /^https?:\/\//i.test(path) ? path : SITE + "/" + path;

    var expires = asNumber((payload && payload.expires_at) || 0, 0) * 1000;
    if (expires <= 0) expires = new Date().getTime() + 8 * 60 * 1000;
    var playCookie = cookieValue(headerValue(response.headers, "set-cookie"), "eden_play_" + videoId);
    var mediaCookie = joinCookies(
      outcome.age ? AGE_COOKIE + "=" + outcome.age : "",
      outcome.account ? ACCOUNT_COOKIE + "=" + outcome.account : ""
    );
    if (playCookie !== "") mediaCookie = joinCookies(mediaCookie, "eden_play_" + videoId + "=" + playCookie);

    // 钉死最轻一档：播放器（libavformat 的 hls）拿到主列表会按带宽自己切档，
    // 拖动时正好切档就换掉整集分片地址，缓存全作废，播放器等不到分片就报片尾。
    // 这里把主列表读掉、只交一档出去，播放器没有可切的东西。
    var originalUrl = mediaUrl;
    var lightest = lightestMediaUrl(mediaUrl, mediaCookie);
    if (lightest !== "" && lightest !== mediaUrl) {
      host.log("柚子短剧：已锁定最轻一档清晰度 " + lightest);
      mediaUrl = lightest;
    }

    var media = null;
    try {
      media = host.prepareWebMedia(
        {
          url: mediaUrl,
          referer: pageUrl,
          credentials: {
            cookie: mediaCookie,
            origin: SITE,
            referer: pageUrl,
            userAgent: UA,
            expiresMs: expires,
          },
        },
        CHANNEL
      );
    } catch (error) {
      // 钉死的那一档万一取不到（站点换签名、分档下线），退回原来的主列表，
      // 宁可让播放器自己挑，也不要整集播不了。
      if (mediaUrl === originalUrl) throw error;
      host.log("柚子短剧：锁定的清晰度取不到，退回主列表：" + String(error && error.message ? error.message : error));
      media = host.prepareWebMedia(
        {
          url: originalUrl,
          referer: pageUrl,
          credentials: {
            cookie: mediaCookie,
            origin: SITE,
            referer: pageUrl,
            userAgent: UA,
            expiresMs: expires,
          },
        },
        CHANNEL
      );
    }
    media.referer = pageUrl;
    return media;
  },
};
