import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:duanju_app/drama_feed.dart';
import 'package:duanju_app/models.dart';
import 'package:duanju_app/source_stats.dart';
import 'package:duanju_app/ui/widgets/drama_grid.dart';

/// 部数口径：顶栏、列表底部、最后一张卡片的序号，三者必须是同一个数。
///
/// 真机上出现过「顶栏 2,056 部 / 底部 1,951 部」这种自相矛盾的写法：顶栏报站点
/// 声明的全站总量（含别的分类、含已下架），底部报这次真正摆出来的条数。
/// +143 起把「翻到底实测」的条数写回存储，两边都用它。
void main() {
  test('实测条数比站点声明少时，用实测条数', () {
    const facts = SourceFacts(site: 2056, listed: 1951, probed: true);
    expect(facts.total, 1951);
    expect(facts.headline, '共 1,951 部');
  });

  test('还没滚到底（没有实测值）就用站点声明', () {
    const facts = SourceFacts(site: 2056, probed: true);
    expect(facts.total, 2056);
    expect(facts.headline, '共 2,056 部');
  });

  test('实测条数比站点声明多时，仍以实测为准（否则会和底部差一截）', () {
    const facts = SourceFacts(site: 1900, listed: 1951, probed: true);
    expect(facts.total, 1951);
    expect(facts.headline, '共 1,951 部');
  });

  test('只有实测值（站点给不出总量）也报「共 N 部」', () {
    const facts = SourceFacts(listed: 843, probed: true);
    expect(facts.total, 843);
    expect(facts.headline, '共 843 部');
  });

  test('writeListed 只改这一个字段，其它观测值原样保留', () {
    final raw = <String, Object?>{
      'huangtao': {
        'day': factsDay(DateTime.now()),
        'site': 2056,
        'local': 300,
        'updated': 12,
        'probed': true,
        'all': ['huangtao:1'],
      },
    };
    final saved = writeListed(raw, 'huangtao', 1951);
    final facts = readFacts(saved, 'huangtao');
    expect(facts.listed, 1951);
    expect(facts.total, 1951);
    expect(facts.site, 2056);
    expect(facts.updated, 12);
    expect(readKnown(saved, 'huangtao'), ['huangtao:1']);
  });

  test('writeFacts 重写整行时不会把实测值抹掉', () {
    final raw = <String, Object?>{
      'huangtao': {
        'day': factsDay(DateTime.now()),
        'site': 2056,
        'local': 300,
        'updated': 3,
        'listed': 1951,
        'probed': true,
      },
    };
    final saved = writeFacts(raw, 'huangtao', site: 2060, local: 301, gained: 2);
    final facts = readFacts(saved, 'huangtao');
    expect(facts.listed, 1951, reason: '站点总量变了也不该丢掉实测值');
    expect(facts.site, 2060);
    expect(facts.updated, 5);
  });

  testWidgets('底栏滚到底只报一个数字', (tester) async {
    final feed = DramaFeed(
      load: (page, force) async => CatalogPage(const [], hasMore: false),
    );
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(body: FeedFooter(feed: feed, count: 1951)),
      ),
    );
    expect(find.text('已经到底了 · 共 1,951 部'), findsOneWidget);
    expect(find.textContaining('顶栏'), findsNothing);
    feed.dispose();
  });
}
