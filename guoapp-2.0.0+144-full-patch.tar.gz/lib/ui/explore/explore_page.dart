import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../drama_feed.dart';
import '../../explore_feed.dart';
import '../../local_store.dart';
import '../../models.dart';
import '../app_scope.dart';
import '../cover_blur.dart';
import '../shell/app_shell.dart';
import '../theme/motion.dart';
import '../detail/detail_page.dart';
import '../widgets/bar_button.dart';
import '../widgets/category_tabs.dart';
import '../widgets/choice_panel.dart';
import '../widgets/drama_actions.dart';
import '../widgets/drama_grid.dart';
import '../widgets/motion/motion_widgets.dart';
import '../widgets/page_header.dart';
import '../widgets/source_bar.dart';
import '../widgets/status_view.dart';
import '../widgets/swipe_switch.dart';
import 'explore_hero.dart';
import 'source_actions.dart';
import '../widgets/shell_inset.dart';

class ExplorePage extends StatefulWidget {
  const ExplorePage({super.key, required this.store});
  final LocalStore store;

  @override
  State<ExplorePage> createState() => ExplorePageState();
}

class ExplorePageState extends State<ExplorePage> {
  ExploreFeed? _explore;
  final _scroll = ScrollController();
  final _search = TextEditingController();
  final _tabsKey = GlobalKey();
  final _refreshKey = GlobalKey<RefreshIndicatorState>();
  String _shown = '';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _explore ??= ExploreFeed(AppScope.of(context).repository, widget.store);
  }

  @override
  void dispose() {
    _explore?.dispose();
    _scroll.dispose();
    _search.dispose();
    super.dispose();
  }

  Future<void> refresh() async {
    if (_scroll.hasClients) _scroll.jumpTo(0);
    await _explore?.refresh();
  }

  void reselect() {
    if (!_scroll.hasClients) return;
    if (_scroll.offset <= 0) {
      unawaited(_refreshKey.currentState?.show());
      return;
    }
    unawaited(
      _scroll.animateTo(
        0,
        duration: Motion.of(context, Motion.long),
        curve: Motion.enter,
      ),
    );
  }

  void _selectTab(String id) {
    if (id != _explore!.tab.id) {
      _explore!.select(id);
      return;
    }
    if (!_scroll.hasClients || _scroll.offset <= 0) return;
    unawaited(
      _scroll.animateTo(
        0,
        duration: Motion.of(context, Motion.long),
        curve: Motion.enter,
      ),
    );
  }

  void _open(Drama drama, {bool autoplay = false}) => openPage<void>(
    context,
    (_) => DetailPage(store: widget.store, drama: drama, autoplay: autoplay),
  );

  Future<void> _pickCategory(BuildContext anchor) async {
    final explore = _explore!;
    final value = await showChoicePanel<String>(
      context: anchor,
      title: '全部分类',
      options: [for (final tab in explore.tabs) ChoiceOption(tab.id, tab.name)],
      selected: explore.tab.id,
      grid: ChoiceGrid.categories,
    );
    if (value != null) explore.select(value);
  }

  void _searchSubmitted(SourceSite source, String query) {
    if (query.trim().isEmpty) return;
    _search.clear();
    openSearch(context, widget.store, source, query: query);
  }

  void _resetScroll(ExploreFeed explore, {required bool deferred}) {
    final source = '${explore.source?.id}|';
    final shown = '$source${explore.tab.id}';
    if (shown == _shown) return;
    final switched = _shown.startsWith(source);
    _shown = shown;
    if (deferred && switched) return;
    WidgetsBinding.instance.addPostFrameCallback((_) => _toTop());
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: Listenable.merge([_explore!, widget.store]),
    builder: (context, _) {
      final explore = _explore!;
      final source = explore.source;
      final form = AppScope.formFactorOf(context);
      final television = form == FormFactor.television;
      final desktop = form == FormFactor.window;
      _resetScroll(explore, deferred: _swipes(form));
      if (source == null) {
        return Scaffold(
          body: SafeArea(
            bottom: false,
            child: Column(
              children: [
                if (!television) const PageHeader(title: '发现'),
                Expanded(
                  child: SourceSite.values.isEmpty
                      ? StatusView(
                          title: '还没有安装站源',
                          message: widget.store.profile.admin
                              ? '站源以模块的形式提供，请在「模块」页安装。'
                              : '请联系管理员安装站源模块。',
                          icon: Icons.extension_off_rounded,
                        )
                      : const StatusView(
                          title: '暂无可用站源',
                          message: '请在站源管理中开启站源，或联系管理员开放权限。',
                          icon: Icons.public_off_rounded,
                        ),
                ),
              ],
            ),
          ),
        );
      }
      final inset = switch (form) {
        FormFactor.phone => 16.0,
        FormFactor.pad || FormFactor.window => 24.0,
        FormFactor.television => televisionInset,
      };
      final tabs = Padding(
        padding: EdgeInsets.symmetric(
          horizontal: form == FormFactor.phone ? 0 : inset,
        ),
        child: CategoryTabs<String>(
          key: _tabsKey,
          options: [
            for (final tab in explore.tabs) ChoiceOption(tab.id, tab.name),
          ],
          selected: explore.tab.id,
          onSelected: _selectTab,
          onShowAll: _pickCategory,
        ),
      );
      return Scaffold(
        body: SafeArea(
          bottom: false,
          child: Column(
            children: [
              if (!television)
                SourceBar(
                  source: source.name,
                  // 只留「共 N 部」一行，贴着站名右边竖排。
                  // 「今日更新 M 集」在 2.0.0+143 去掉了：它每 90 秒重探一次第一页，
                  // 数字一直在跳，用户真正想看的只有站点到底有多少部。
                  // 注意别再往 subtitle 里塞同一句话 —— +140 顶栏散架就是这么来的：
                  // subtitle 与统计行在 Row 里各占一个 Flexible，标题被挤成 0 宽。
                  note: explore.facts.headline,
                  // 玻璃拉成长条，把右边三颗按钮（模糊封面 / 切换站源 / 搜索）
                  // 一起包进去；「共 N 部」用主题色标出来。
                  stretch: true,
                  noteColor: Theme.of(context).colorScheme.primary,
                  searchController: _search,
                  onSwitchSource: (anchor) => pickSource(anchor, widget.store),
                  onOpenSearch: () => openSearch(context, widget.store, source),
                  onSearchSubmitted: (query) => _searchSubmitted(source, query),
                  leading: [
                    if (widget.store.blurCoversButton)
                      if (CoverBlurScope.of(context) case final blur?)
                        BarButton(
                          icon: blur.mode != CoverBlur.off
                              ? Icons.visibility_off_rounded
                              : Icons.visibility_rounded,
                          tooltip: blur.mode != CoverBlur.off ? '显示封面' : '模糊封面',
                          onPressed: blur.onToggle,
                        ),
                  ],
                  actions: [
                    // 全站搜索不再占顶栏一颗按钮：搜索框右侧那颗「全站」已经够用，
                    // 两个入口并存容易点错。
                    if (desktop)
                      BarButton(
                        icon: Icons.refresh_rounded,
                        tooltip: '刷新',
                        onPressed: explore.refresh,
                      ),
                  ],
                ),
              if (!television || explore.feed!.items.isEmpty) tabs,
              Expanded(
                child: _swipeTabs(
                  explore,
                  form,
                  _content(explore, inset, television, tabs),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );

  // 手机端整页横滑已经被「左右滑动切栏目」占用（AppShell 里的 PageView），
  // 两者都是横向手势，放一起只会互相抢；所以手机上横滑改为切栏目，切分类
  // 用上面的分类条点选。平板没有底部 PageView，仍保留横滑切分类。
  bool _swipes(FormFactor form) =>
      form == FormFactor.phone || form == FormFactor.pad;

  Widget _swipeTabs(ExploreFeed explore, FormFactor form, Widget child) {
    final tabs = explore.tabs;
    final index = tabs.indexWhere((tab) => tab.id == explore.tab.id);
    if (!_swipes(form) || index < 0) return child;
    return SwipeSwitch(
      key: ValueKey(explore.source?.id),
      index: index,
      count: tabs.length,
      ready: switch (explore.feed) {
        final feed? => feed.items.isNotEmpty || !feed.loading,
        null => true,
      },
      onSwitch: (index) => explore.select(tabs[index].id),
      onEnter: _toTop,
      child: child,
    );
  }

  void _toTop() {
    if (_scroll.hasClients) _scroll.jumpTo(0);
  }

  Widget _content(
    ExploreFeed explore,
    double inset,
    bool television,
    Widget tabs,
  ) {
    final feed = explore.feed!;
    final hero = _hero(explore);
    final items = explore.items;
    if (feed.items.isEmpty) {
      return FadeSwitcher(child: _status(feed));
    }
    final phone = AppScope.formFactorOf(context) == FormFactor.phone;
    final desktop = AppScope.formFactorOf(context) == FormFactor.window;
    return _grid(
      explore,
      feed,
      hero,
      items,
      inset,
      television,
      tabs,
      phone,
      desktop,
    );
  }

  Widget _status(DramaFeed feed) {
    if (feed.loading) {
      return const StatusView.loading(key: ValueKey('loading'));
    }
    if (feed.error.isNotEmpty) {
      return StatusView(
        key: const ValueKey('error'),
        title: '暂时无法加载',
        message: feed.error,
        icon: Icons.cloud_off_rounded,
        action: '重试',
        onAction: () => feed.reload(force: true),
      );
    }
    return StatusView(
      key: const ValueKey('empty'),
      title: '这里还没有剧',
      message: '换一个分类看看',
      icon: Icons.inbox_outlined,
      action: '刷新',
      onAction: () => feed.reload(force: true),
    );
  }

  Widget _grid(
    ExploreFeed explore,
    DramaFeed feed,
    Widget? hero,
    List<Drama> items,
    double inset,
    bool television,
    Widget tabs,
    bool phone,
    bool desktop,
  ) {
    final heroSection = hero == null
        ? const SizedBox(key: ValueKey('none'), width: double.infinity)
        : Padding(
            key: hero.key,
            padding: EdgeInsets.fromLTRB(inset, phone ? 12 : 16, inset, 0),
            child: hero,
          );
    // 「全部」是唯一按站点目录顺序一路排下来的分类，也只有它值得报序号：
    // 其他分类、推荐、排行榜的排列会随站点改动作战，序号没意义。
    //
    // `hero == null` 是硬条件：有头条时 explore.items 已经 skip(1)（头条单独
    // 用大图渲染、不占列表序号），而底部与顶栏报的是含头条的条数。此时再编号，
    // 最后一张卡片的序号就会比「共 N 部」少 1 —— 宁可这一页不显示序号，
    // 也不能让三个数对不上。
    final numbering = !explore.recommending &&
        hero == null &&
        explore.tab.id == CatalogCategory.all.id;
    return LayoutBuilder(
      builder: (context, constraints) {
        final scroll = CustomScrollView(
          controller: _scroll,
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            if (television)
              SliverPadding(
                padding: const EdgeInsets.only(top: 8),
                sliver: SliverToBoxAdapter(child: tabs),
              ),
            SliverToBoxAdapter(
              child: television
                  ? heroSection
                  : AnimatedSize(
                      key: ValueKey(explore.tab.id),
                      duration: Motion.of(context, Motion.long),
                      curve: Motion.enter,
                      alignment: Alignment.topCenter,
                      clipBehavior: Clip.none,
                      child: FadeSwitcher(
                        alignment: Alignment.topCenter,
                        child: heroSection,
                      ),
                    ),
            ),
            SliverPadding(
              padding: EdgeInsets.fromLTRB(inset, desktop ? 20 : 16, inset, 0),
              sliver: DramaSliverGrid(
                width: constraints.maxWidth - inset * 2,
                items: items,
                rankOf: explore.rankOf,
                numberFrom: numbering ? 1 : null,
                autofocus:
                    television && hero == null && ShellForeground.of(context),
                heroScope: 'drama',
                showScore: !explore.recommending,
                exploreBlur: true,
                onOpen: _open,
                // 长按在卡片封面内直接浮出「追剧 / 下载」，不再弹底部面板。
                actionsOf: (context, drama) =>
                    dramaActions(context, widget.store, drama),
              ),
            ),
            SliverPadding(
              padding: EdgeInsets.fromLTRB(
                inset,
                8,
                inset,
                (television ? 27 : 16) + shellBottomInset(context),
              ),
              sliver: SliverToBoxAdapter(
                // 报的是「列表里一共摆了多少部」，含被顶栏抽走做头条的那一部。
                // 顶栏那个「共 N 部」滚到底时会被写回同一个实测值，
                // 所以这里不用再把两个数一起写出来（以前会出现
                // 「已列出 1,951 部（顶栏 2,056 部）」这种自相矛盾的写法）。
                child: FeedFooter(feed: feed, count: feed.items.length),
              ),
            ),
          ],
        );
        return Stack(
          children: [
            AutoLoadMore(
              feed: feed,
              child: television
                  ? scroll
                  : RefreshIndicator(
                      key: _refreshKey,
                      onRefresh: explore.refresh,
                      child: scroll,
                    ),
            ),
            // 侧栏滚动条独立成一个 widget：拖动时只重建它自己，
            // 不再每帧 setState 把整页（含全部封面）重建一遍。
            // 下沿要停在玻璃底栏上面：底栏是浮在页面之上的，
            // 轨道伸到它底下时最后一段既点不到、又被底栏吃掉手势。
            Positioned(
              right: 0,
              top: 2,
              bottom: 2 + shellBottomInset(context),
              width: _ScrollRail.width,
              child: _ScrollRail(controller: _scroll, feed: feed),
            ),
            Positioned(
              left: 0,
              right: 0,
              top: 0,
              child: IgnorePointer(
                child: ExcludeSemantics(
                  excluding: !feed.loading,
                  child: AnimatedOpacity(
                    opacity: feed.loading ? 1 : 0,
                    duration: Motion.of(context, Motion.medium),
                    curve: Motion.standard,
                    child: TickerMode(
                      enabled: feed.loading,
                      child: const LinearProgressIndicator(minHeight: 2),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget? _hero(ExploreFeed explore) {
    if (explore.resume case final entry?) {
      final drama = entry.drama;
      final total = drama.episodes;
      final next = entry.finished && entry.episode < total
          ? entry.episode + 1
          : entry.episode;
      return ExploreHero(
        key: ValueKey(('resume', drama.id)),
        drama: drama,
        kicker: '继续观看',
        meta: total > 0
            ? '看到第 ${entry.episode} 集 · 共 $total 集'
            : '看到第 ${entry.episode} 集',
        progress: total > 0 ? entry.episode / total : null,
        action: '继续第 $next 集',
        onPlay: () => _open(drama, autoplay: true),
        onDetail: () => _open(drama),
      );
    }
    if (explore.featured case final drama?) {
      return ExploreHero(
        key: ValueKey(('featured', drama.id)),
        drama: drama,
        kicker: '今日推荐',
        meta: [
          if (drama.category.isNotEmpty) drama.category,
          if (drama.episodes > 0) '共 ${drama.episodes} 集',
        ].join(' · '),
        action: '立即观看',
        onPlay: () => _open(drama, autoplay: true),
        onDetail: () => _open(drama),
      );
    }
    return null;
  }
}

/// 发现页右侧的自绘滚动条。
///
/// 之前那版的问题：滑块位置跟着「滚动通知里上一次算出来的值」走，拖到底时
/// 因为列表还在自动加载下一页，松手就停在半路，永远摸不到末页；而且每次
/// 滚动都 setState 整页，滑起来发涩。现在：
/// 1. 位置每帧现算（extentTotal / pixels 都是当前值）；
/// 2. 拖动按「手指抓在滑块上的偏移」换算，拖到轨道末端就是真正的末尾，
///    松手时若贴底再补一次 jumpTo(maxScrollExtent)；
/// 3. 状态只在滚动条内部重建。
class _ScrollRail extends StatefulWidget {
  const _ScrollRail({required this.controller, required this.feed});

  final ScrollController controller;

  /// 拖到底要能一直加载下去，所以得拿到当前分类的 feed。
  final DramaFeed feed;

  /// 触摸热区宽度。太窄在手机上抓不住。
  static const width = 30.0;

  @override
  State<_ScrollRail> createState() => _ScrollRailState();
}

class _ScrollRailState extends State<_ScrollRail> {
  static const _minThumb = 44.0;

  bool _visible = false;
  bool _dragging = false;
  double _track = 1;
  double _thumb = _minThumb;
  double _top = 0;
  double _grab = 0;
  Timer? _hide;

  /// 正在把后面的页一路拉到底，避免拖动过程中反复触发。
  bool _draining = false;

  /// 用户又抓住滚动条 / 往回拖了：把上一轮「一路拉到底」停掉，
  /// 否则松手后列表还在自己往下长，看着像页面在自己翻。
  bool _stopDrain = false;

  /// 上一次震动过的进度档位（每 10% 震一下），拖动时给手指反馈。
  int _notch = -1;

  ScrollPosition? get _position =>
      widget.controller.hasClients && widget.controller.position.hasContentDimensions
      ? widget.controller.position
      : null;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onScroll);
  }

  @override
  void didUpdateWidget(_ScrollRail old) {
    super.didUpdateWidget(old);
    if (old.controller != widget.controller) {
      old.controller.removeListener(_onScroll);
      widget.controller.addListener(_onScroll);
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onScroll);
    _hide?.cancel();
    super.dispose();
  }

  void _onScroll() {
    if (!mounted || _dragging) return;
    final position = _position;
    if (position == null) return;
    if (position.extentTotal <= position.viewportDimension + 1) {
      if (_visible) setState(() => _visible = false);
      return;
    }
    setState(() {
      _measure(position);
      _visible = true;
    });
    _schedule(1400);
  }

  void _schedule(int milliseconds) {
    _hide?.cancel();
    _hide = Timer(Duration(milliseconds: milliseconds), () {
      if (!mounted || _dragging) return;
      setState(() => _visible = false);
    });
  }

  void _measure(ScrollPosition position) {
    final total = position.extentTotal;
    final view = position.viewportDimension;
    if (total <= 0) return;
    _thumb = (view / total * _track).clamp(_minThumb, _track);
    final usable = _track - _thumb;
    final progress = total - view <= 0
        ? 0.0
        : (position.pixels / (total - view)).clamp(0.0, 1.0);
    _top = usable <= 0 ? 0 : progress * usable;
  }

  void _start(DragStartDetails details) {
    final position = _position;
    if (position == null) return;
    if (position.extentTotal <= position.viewportDimension + 1) return;
    _hide?.cancel();
    // 抓住滚动条先给一次震动：确认「按到了」，不用盯着屏幕看。
    HapticFeedback.selectionClick();
    _stopDrain = true;
    _notch = -1;
    setState(() {
      _measure(position);
      _dragging = true;
      _visible = true;
    });
    final y = details.localPosition.dy;
    if (y >= _top && y <= _top + _thumb) {
      _grab = y - _top;
    } else {
      // 按在轨道空白处：先把滑块中心挪到手指位置，再接着拖。
      _grab = _thumb / 2;
      _seek(y - _grab);
    }
  }

  void _update(DragUpdateDetails details) => _seek(details.localPosition.dy - _grab);

  /// 把滑块顶端放到 [top]，换算成滚动位置。拖到轨道末端就是真正的末尾。
  void _seek(double top) {
    final position = _position;
    if (position == null) return;
    final total = position.extentTotal;
    final view = position.viewportDimension;
    if (total <= view) return;
    _thumb = (view / total * _track).clamp(_minThumb, _track);
    final usable = _track - _thumb;
    if (usable <= 0) return;
    final next = top.clamp(0.0, usable);
    position.jumpTo(next / usable * (total - view));
    setState(() => _top = next);
    // 每跨过 10% 震一下，手指不用看屏幕也知道拖了多远。
    final notch = (next / usable * 10).floor();
    if (notch != _notch) {
      _notch = notch;
      // 比轻点一下更明确一档，拖的时候能隔着壳子感觉到。
      HapticFeedback.lightImpact();
    }
    // 已经拖到底：底下还有没加载的页就继续要，直到这个分类真的到底。
    if (usable - next < 1.5) {
      _stopDrain = false;
      unawaited(_drain());
    } else {
      // 往回拖了，别让上一轮的连载还挂着。
      _stopDrain = true;
    }
  }

  /// 把当前分类剩下的页一路拉完。
  ///
  /// 以前拖到底只是 `jumpTo(maxScrollExtent)`：那只滚到「已经拿到的最后一页」，
  /// 后台还得等用户再滑一下才会要下一页，所以拖到底看到的仍是半截。
  /// 这里在拖动贴底时连着 `loadMore()`，每拉完一页就把视图顶到新的末尾。
  Future<void> _drain() async {
    if (_draining) return;
    _draining = true;
    _stopDrain = false;
    try {
      var stalled = 0;
      var loaded = -1;
      for (var round = 0; round < 60; round++) {
        if (!mounted || _stopDrain) break;
        if (widget.feed.loading || widget.feed.loadingMore) {
          await Future<void>.delayed(const Duration(milliseconds: 60));
          continue;
        }
        if (!widget.feed.hasMore) break;
        await widget.feed.loadMore();
        if (!mounted || _stopDrain) break;
        // 这里**不再** jumpTo(maxScrollExtent)：以前每拉完一页就把视图顶到新的
        // 末尾，松手后整页还在自己往下滚，看着像「还在自动翻页」。现在只把后面的
        // 页悄悄拉进来，视图停在用户松手的位置。
        final grown = widget.feed.items.length;
        stalled = grown > loaded ? 0 : stalled + 1;
        loaded = grown;
        // 无限流站源（怎么翻都有下一页）靠这个收手：连着几页都没变长就停。
        if (stalled >= 3) break;
      }
      if (mounted && !widget.feed.hasMore) HapticFeedback.mediumImpact();
    } finally {
      _draining = false;
    }
  }

  void _end() {
    if (!_dragging) return;
    setState(() => _dragging = false);
    final position = _position;
    if (position != null && _track - _thumb - _top < 1.5) {
      // 贴底松手：继续把剩下的页拉完（视图不再跟着滚），
      // 手上一路拖到底就等于「这个分类全部加载好」。
      unawaited(_drain());
    } else {
      _stopDrain = true;
    }
    _schedule(900);
  }

  @override
  Widget build(BuildContext context) {
    final ink = Theme.of(context).colorScheme.onSurface;
    return LayoutBuilder(
      builder: (context, constraints) {
        final track = constraints.maxHeight;
        if ((track - _track).abs() > 0.5) {
          _track = track;
          final position = _position;
          if (position != null) _measure(position);
        }
        final thumb = _thumb;
        return IgnorePointer(
          ignoring: !_visible,
          child: AnimatedOpacity(
            opacity: _visible ? 1 : 0,
            duration: const Duration(milliseconds: 160),
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onVerticalDragStart: _start,
              onVerticalDragUpdate: _update,
              onVerticalDragEnd: (_) => _end(),
              onVerticalDragCancel: _end,
              child: Stack(
                children: [
                  Positioned(
                    right: 7,
                    top: 0,
                    bottom: 0,
                    child: Container(
                      width: 4,
                      decoration: BoxDecoration(
                        color: ink.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  Positioned(
                    right: 4,
                    top: _top,
                    child: Container(
                      width: 9,
                      height: thumb,
                      decoration: BoxDecoration(
                        color: ink.withValues(alpha: _dragging ? 0.80 : 0.58),
                        borderRadius: BorderRadius.circular(5),
                        boxShadow: _dragging
                            ? [
                                BoxShadow(
                                  color: ink.withValues(alpha: 0.28),
                                  blurRadius: 8,
                                  spreadRadius: 1,
                                ),
                              ]
                            : null,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
