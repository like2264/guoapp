import 'dart:async';

import 'package:flutter/material.dart';

import '../../core_bridge.dart';
import '../../local_store.dart';
import '../../models.dart';
import '../../source_color.dart';
import '../app_scope.dart';
import '../widgets/focus_ring.dart';
import 'settings_rows.dart';
import 'sorani_account_view.dart';

/// +182：单站源初始化确认。只清该站源的缓存与统计快照，不碰其它站源、
/// 追剧、观看记录和已下载视频；清完会重新联网拉这个站源。
Future<void> _confirmReset(
  BuildContext context,
  LocalStore store,
  AppRepository repository,
  SourceSite site,
) async {
  final accepted = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text('初始化「${site.name}」？'),
      content: const Text(
        '清除这个站源的目录缓存、分类、搜索索引、联想词和统计快照，'
        '等同于删掉 App 重装后第一次打开这个站源。\n\n'
        '其它站源、追剧、观看记录和已下载视频都不会被删除。',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('取消'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(context, true),
          child: const Text('初始化'),
        ),
      ],
    ),
  );
  if (accepted != true || !context.mounted) return;
  try {
    await repository.resetSource(site.id);
    await store.resetSourceStats(site.id);
    if (!context.mounted) return;
    ScaffoldMessenger.maybeOf(
      context,
    )?.showSnackBar(SnackBar(content: Text('${site.name} 已初始化')));
  } catch (failure) {
    if (!context.mounted) return;
    ScaffoldMessenger.maybeOf(
      context,
    )?.showSnackBar(SnackBar(content: Text('初始化失败：$failure')));
  }
}

class SourcesView extends StatelessWidget {
  const SourcesView({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      final admin = store.profile.admin;
      final repository = AppScope.of(context).repository;
      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          if (!admin) ...[
            const _Note('需要管理员才能开启或关闭站源'),
            const SizedBox(height: 12),
          ],
          SettingsCard(
            children: [
              for (final site in SourceSite.values)
                _SourceTile(
                  site: site,
                  enabled: store.sourceEnabled(site.id),
                  onChanged: admin
                      ? (value) => saveSetting(context, () async {
                          await store.setSourceEnabled(site.id, value);
                          if (!value && repository.supportsDownloads) {
                            await repository.controlDownloads(
                              'pauseSource',
                              id: site.id,
                            );
                          }
                        })
                      : null,
                  onReset: admin && SourceSite.isAvailable(site.id)
                      ? () => _confirmReset(context, store, repository, site)
                      : null,
                ),
            ],
          ),
          const SizedBox(height: 12),
          const _Note(
            '关闭的站源不在发现、搜索、追剧、观看记录和下载中显示，记录保留，重新开启后恢复。正在下载的集会暂停，重新开启后可在下载页继续。',
          ),
        ],
      );
    },
  );
}

class SourceAccountsView extends StatelessWidget {
  const SourceAccountsView({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      final admin = store.profile.admin;
      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          if (!admin) ...[
            const _Note('需要管理员才能登录或退出站源账号'),
            const SizedBox(height: 12),
          ],
          if (soraniAccountAvailable())
            SettingsCard(children: [SoraniAccountTile(admin: admin)])
          else
            const _Note('没有已安装且需要登录的站源'),
        ],
      );
    },
  );
}

class _SourceTile extends StatelessWidget {
  const _SourceTile({
    required this.site,
    required this.enabled,
    required this.onChanged,
    this.onReset,
  });
  final SourceSite site;
  final bool enabled;
  final ValueChanged<bool>? onChanged;
  final VoidCallback? onReset;

  @override
  Widget build(BuildContext context) => MergeSemantics(
    child: TileFocus(
      builder: (focusNode) => ListTile(
        focusNode: focusNode,
        minTileHeight: 68,
        contentPadding: const EdgeInsets.fromLTRB(20, 4, 16, 4),
        title: Text(
          site.name,
          style: TextStyle(
            color: sourceColor(context, site.name),
            fontWeight: FontWeight.w700,
          ),
        ),
        subtitle: Text(site.description),
        onTap: onChanged == null ? null : () => onChanged!(!enabled),
        trailing: ExcludeFocus(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (onReset != null)
                IconButton(
                  tooltip: '初始化数据',
                  icon: const Icon(Icons.restart_alt_rounded),
                  onPressed: onReset,
                ),
              Switch(value: enabled, onChanged: onChanged),
            ],
          ),
        ),
      ),
    ),
  );
}

class _Note extends StatelessWidget {
  const _Note(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    child: Text(
      text,
      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
        color: Theme.of(context).colorScheme.onSurfaceVariant,
        height: 1.6,
      ),
    ),
  );
}
