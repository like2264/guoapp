package core

import (
	"errors"
	"os"
	"path/filepath"
	"strings"
)

// 单站源初始化（2.0.0+182）：把某个站源恢复到「删掉 App 重装、第一次打开这个
// 站源」的状态 —— 这个站源的目录缓存、分类、统计快照、模块会话状态、搜索索引、
// 选集时长、联想词缓存全部清掉，其它站源、追剧、观看记录、下载一律不碰。
//
// 清完内存后立刻把 catalogs.json / provider-states.json / durations.json 重写落盘，
// 否则进程还在时看着干净、重启又被旧缓存填回来。

// resetSourceData 返回清理的项目数，给自检和排查用。
func (engine *nativeEngine) resetSourceData(source string) (map[string]any, error) {
	source = canonicalProviderSource(source)
	if source == "" || !nativeSourceAvailable(source) {
		return nil, errors.New("站源无效或未安装")
	}
	// 模块状态文件名形如 module-<站源>-<名字>。站源 id 来自注册表，不含路径分隔符，
	// 但仍做一次白名单校验，避免将来有人传进来带斜杠的名字删到别处。
	if strings.ContainsAny(source, `/\,:`+"\x00") || source == "." || source == ".." {
		return nil, errors.New("站源标识无效")
	}

	counts := map[string]any{"source": source}

	// 目录缓存：键为 source 或 source|category。
	engine.mu.Lock()
	catalogs, states, categories, versions, recommendations, providers := 0, 0, 0, 0, 0, 0
	for key := range engine.catalogs {
		owner, _, _ := strings.Cut(key, "|")
		if owner == source {
			delete(engine.catalogs, key)
			catalogs++
		}
	}
	for key := range engine.catalogStates {
		owner, _, _ := strings.Cut(key, "|")
		if owner == source {
			delete(engine.catalogStates, key)
			states++
		}
	}
	if _, ok := engine.categoryOptions[source]; ok {
		delete(engine.categoryOptions, source)
		categories++
	}
	if _, ok := engine.moduleVersions[source]; ok {
		delete(engine.moduleVersions, source)
		versions++
	}
	for key := range engine.recommendations {
		owner, _, _ := strings.Cut(key, "|")
		if owner == source {
			delete(engine.recommendations, key)
			recommendations++
		}
	}
	if _, ok := engine.providerStates[source]; ok {
		delete(engine.providerStates, source)
		providers++
	}
	counts["catalogs"], counts["states"] = catalogs, states
	counts["categories"], counts["moduleVersions"] = categories, versions
	counts["recommendations"], counts["providerStates"] = recommendations, providers
	if err := engine.writeCatalogDiskLocked(); err != nil {
		engine.mu.Unlock()
		return nil, err
	}
	engine.mu.Unlock()

	// 本地搜索索引（search-index/<source>.tsv）。
	engine.dropSearchIndex(source)

	// 选集时长缓存：按剧 id 的 <source>: 前缀筛，其它站源的记录原样留着。
	engine.durationMu.Lock()
	durations := 0
	disk := engine.loadDurationCache()
	for id := range disk.Dramas {
		if owner, _, ok := strings.Cut(id, ":"); ok && owner == source {
			delete(disk.Dramas, id)
			durations++
		}
	}
	if durations > 0 {
		engine.saveDurationCache(disk)
	}
	engine.durationMu.Unlock()
	counts["durations"] = durations

	// 联想词缓存（进程内，按 <source>\x00 前缀）。
	counts["suggestions"] = nativeClearSuggestions(source)

	// 模块会话状态文件：module-<source>-*。只删状态，不删模块安装包。
	statesRemoved := 0
	if engine.downloader != nil && engine.downloader.cfg.dataDir != "" {
		entries, err := os.ReadDir(engine.downloader.cfg.dataDir)
		if err == nil {
			prefix := moduleStatePrefix + source + "-"
			for _, entry := range entries {
				if entry.IsDir() || !strings.HasPrefix(entry.Name(), prefix) {
					continue
				}
				if err := os.Remove(filepath.Join(engine.downloader.cfg.dataDir, entry.Name())); err == nil {
					statesRemoved++
				}
			}
		}
	}
	counts["moduleStates"] = statesRemoved

	// 让模块实例带着空状态重新初始化。
	if engine.downloader != nil {
		loadedModules.Lock()
		engine.downloader.reloadModuleLocked(source)
		loadedModules.Unlock()
	}
	return counts, nil
}
