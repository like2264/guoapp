import 'package:flutter/material.dart';

/// 站源名的稳定配色。
///
/// 按站源的显示名取一个固定色相：内置站源、第三方/文件安装的站源都会拿到自己的
/// 颜色，且同一个站源在卡片、顶栏、详情页、下载页等处颜色一致。
/// 不用 `String.hashCode`（跨平台/版本不稳定），这里用固定实现的 FNV-1a。
int _fnv1a(String value) {
  var hash = 2166136261;
  for (final unit in value.codeUnits) {
    hash ^= unit;
    hash = (hash * 16777619) & 0xFFFFFFFF;
  }
  return hash;
}

double _hue(String name) => (_fnv1a(name) % 360).toDouble();

/// 深色背景（黑色封面角标、深色玻璃）上的亮色。
Color sourceColorOnDark(String name) =>
    HSLColor.fromAHSL(1, _hue(name), 0.68, 0.76).toColor();

/// 浅色背景（设置页、下载标签）上的深色。
Color sourceColorOnLight(String name) =>
    HSLColor.fromAHSL(1, _hue(name), 0.62, 0.40).toColor();

/// 跟随当前主题取色（普通页面文字）。
Color sourceColor(BuildContext context, String name) =>
    Theme.of(context).brightness == Brightness.dark
        ? sourceColorOnDark(name)
        : sourceColorOnLight(name);

/// 给一段已有样式附上站源色，用于 `RichText` / `TextSpan`。
/// [onDark] 为空时跟随主题，显式传值用于固定在深/浅背景上的角标。
TextSpan sourceSpan(
  BuildContext context,
  String name,
  TextStyle? style, {
  bool? onDark,
}) {
  final color = onDark == null
      ? sourceColor(context, name)
      : onDark
      ? sourceColorOnDark(name)
      : sourceColorOnLight(name);
  return TextSpan(
    text: name,
    style: (style ?? const TextStyle()).copyWith(color: color),
  );
}
