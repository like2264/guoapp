import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import 'core_bridge.dart';
import 'drama_feed.dart';
import 'local_store.dart';
import 'models.dart';
import 'ranking_models.dart';
import 'source_catalog.dart';
import 'source_stats.dart';

const recommendTab = CatalogCategory('app:recommend', '推荐');

CatalogCategory rankingTab(RankingBoard board) =>
    CatalogCategory('app:rank:${board.id}', board.name);

class ExploreFeed extends ChangeNotifier {
  ExploreFeed(this.repository, this.store) {
    store.addListener(_storeChanged);
    repository.catalogUpdates.addListener(_metadataChanged);
    _pulse = Timer.periodic(_pulseInterval, (_) => unawaited(_pulseFacts()));
    _alignTimer = Timer.periodic(_alignInterval, (_) => _alignListed());
    _open();
  }
  final AppRepository repository;
  final LocalStore store;
  SourceCatalog? _catalog;
  CatalogCategory _tab = CatalogCategory.all;
  DramaFeed? _feed;
  Map<String, int> _ranks = const {};
  final _feeds = <String, DramaFeed>{};
  final _rankings = <String, Map<String, int>>{};

  /// 切走的站源在这里留一份列表缓存（最多 [_stashLimit] 个）。
  /// 原来换站源会把所有 feed 直接 dispose，来回切就得重新联网拉一遍，
  /// 表现就是"点完站源要等一小会儿"。留缓存后切回去是瞬间出内容。
  final _stash = <String, Map<String, DramaFeed>>{};
  final _stashRanks = <String, Map<String, Map<String, int>>>{};
  static const _stashLimit = 2;

  /// 从 [_stash] 接回来的 tab（`tab.id`）。
  ///
  /// 这些列表是切走前的内容，站点可能已经上新 —— 接回后第一次进入必须强制
  /// 重拉一遍，否则会出现「顶栏是新数字、列表还是旧作品」，三数对不上。
  final _resumed = <String>{};
  bool _disposed = false;

  /// 当前站源顶栏那行观测值。
  SourceFacts _facts = const SourceFacts();

  /// 每个站源「全部」分类里见过的作品 id。顶栏那句「已收录 N 部」就是它的长度：
  /// 只由「全部」目录喂，搜索、排行榜、单独切开的分类都不进来，
  /// 所以翻到哪就是哪，不会被别的入口撑大。
  final _seen = <String, Set<String>>{};

  /// 「全部」名单有新增、还没落盘的站源。翻页时只更新界面，等下一次
  /// 第一页 / 强制刷新才写存储，免得每翻一页都写一次。
  final _seenDirty = <String>{};

  /// 站源 id → 见过的作品 id。判「新上」用，落盘保存，跨进程有效。
  /// 早先靠「本地目录缓存里有没有这一条」来判断，但原生目录缓存会为新数据
  /// 回填旧值，站点给不出集数时那条记录的集数是 0，于是永远判不出「新上」。
  final _known = <String, Set<String>>{};

  /// 站源 id → 上次看到的「剧 id → 集数」。判「今日更新」用。
  /// 这份快照是我们自己记的，不依赖目录缓存怎么合并。
  final _episodes = <String, Map<String, int>>{};

  /// 站源 id → 今天变化过的作品 id（新的在前）。首页把这几部提到最前面。
  final _fresh = <String, List<String>>{};

  /// 当前统计属于哪一天。跨天就把「变化过的作品」清空，跟 updated/arrived 一起归零。
  String _factsDay = '';

  /// 站源 id → **实测的独立作品数**（翻到底、并把分类里藏着的作品并进来之后）。
  ///
  /// 2.0.0+143~147 把它落盘了，结果「站点加了作品、App 顶栏纹丝不动」：
  /// 一次翻到底量到的旧条数会永远压过站点声明。2.0.0+148 改成只活在内存里，
  /// 又变成「进站永远先显示站点声明」——X短剧声明 2,180（页数×每页估的）、
  /// 实际 2,169，用户一进站看到的就是个假数。
  ///
  /// 2.0.0+154 的折中：**落盘 + 一定会重测**。进站先显示上次实测值（立刻是对的数），
  /// 随后 [_measureIfStale] 在后台重测；站点声明变了、下拉刷新、探头发现新作品
  /// 都会重测。所以它不会再像 +148 那样永远不动。
  final _listed = <String, int>{};

  /// 站源 id → 上次实测的时间。超过 [listedFreshFor] 进站就重测。
  final _listedAt = <String, DateTime>{};

  /// 站源 id → 上次「分类补齐」扫完的时间。X短剧这种声明虚高、分类里其实
  /// 没藏东西的站源，扫一遍没捞到就别每次刷新都白扫一百多页。
  final _sweptAt = <String, DateTime>{};

  /// 「分类补齐」最多扫多少页 / 多久。
  ///
  /// 黑桃 1,536 部里漏掉的 8 部散在分类页深处，40 页（960 部）根本扫不到
  /// （2.0.0+158 之前就是这里捞不全）。放宽到 160 页 / 3 分钟：走的是后台
  /// 通道，用户翻列表不受影响，只是这一轮久一点。
  static const _sweepPages = 160;
  static const _sweepBudget = Duration(seconds: 180);

  /// 正在跑 [_recount]（补页 + 补齐），别叠第二次。
  bool _recounting = false;

  /// 在途的这一轮是不是「重走整条目录」（reload=true）。
  /// 手动刷新连点时别每刷一次就把上一轮 rebuild 作废重启 —— 否则哪轮都走不完，
  /// 顶栏一直停在旧数（2.0.0+164 反馈「刷新很多次才更新到 N」）。
  bool _rebuilding = false;

  /// 探头发现变化后，两次自检之间至少隔这么久。
  static const _pulseRecountGap = Duration(minutes: 10);

  /// 最近一次**真的从站源拿到作品总量**的时间。
  ///
  /// 早先这里记的是「最近一次观测」（不管有没有拿到总量）：首屏那一页如果直接
  /// 命中本地目录缓存（缓存里 Total 还是 0），也会把它刷新成「刚刚观测过」，
  /// 切站源后的强制刷新就被跳过了 —— 表现就是顶栏一直显示「已收录 N 部」
  /// 而不是站点的「共 X 部」，而且随着往下翻越来越大。
  DateTime? _lastSiteTotalAt;

  /// 顶栏「今日更新 N 集」的定时探头：站点在我们停着不动的时候也会更新，
  /// 只在切源/翻页时统计的话，用户盯着同一页永远看不到数字涨。
  Timer? _pulse;
  static const _pulseInterval = Duration(seconds: 20);
  bool _pulsing = false;

  /// 顶栏实测数的自动对齐定时器（2.0.0+175）。
  ///
  /// 顶栏那个数以前只在「用户翻到底」和「重测跑完」两个时刻写入：扫分类期间
  /// 被挡下的值要等扫完才补，重测跑不满预算就完全不写 —— 用户看到的是底部
  /// 已经显示 N 部、顶栏还挂着旧数，要再手动刷新几次才偶然对上。这里每隔
  /// [_alignInterval] 把顶栏对齐到列表实际摆出来的条数，纯本地、不联网，
  /// 也不碰用户正在翻的页。
  Timer? _alignTimer;
  static const _alignInterval = Duration(seconds: 20);

  /// 刷新后自动补页的上限：最多补多少页、最多补多久。
  ///
  /// 「共 N 部」是翻到底量出来的，只拉第 1 页看不出末尾长了几部。刷新结束
  /// 后自己往下补，补到底就能把顶栏 / 底部 / 末位卡片一次对齐；超过预算就
  /// 停手，顶栏留在站点声明上，等用户自己滑或下次刷新再续。
  static const _recountPages = 240;
  static const _recountBudget = Duration(seconds: 150);

  /// 「重走整条目录」的上限：站点上新后页码整体位移，只能从第 1 页重走到末尾。
  ///
  /// 单独给 5 分钟：黄果视频 2,118 部 ≈ 89 页、一页 2~3 秒，150 秒根本走不完
  /// （走不完就等于顶栏不更新，+153 第七条又会回来）。这条路上不碰界面，
  /// 走的期间用户照样能翻列表、看详情。
  static const _rebuildPages = 400;
  static const _rebuildBudget = Duration(seconds: 300);

  /// 第几轮「补页 + 补齐」。切站源、连续刷新时把上一轮作废。
  int _recountToken = 0;

  /// 正在扫分类。这时候别把中间条数写回顶栏 —— 补一半的数字更让人困惑。
  bool _sweeping = false;

  /// 扫分类期间用户已经拉到底、却被 [_noteListed] 挡下的实测条数。
  ///
  /// 深扫可能跑满 3 分钟，这段时间里列表已经翻到底、底部报出了真实部数，
  /// 顶栏却一直挂旧值 —— 以前扫完也没有补写，要再下拉刷新几次才偶然对上
  /// （+174 反馈）。扫完统一把这里的最大值补写回顶栏。
  final _pendingListed = <String, int>{};

  /// 上次重测（补页 / 补齐）是什么时候，用来给探头那条路做节流。
  DateTime? _lastRecountAt;

  SourceSite? get source => _catalog?.source;
  SourceFacts get facts => _facts;

  /// 立刻跑一次定时探头。真实运行由 [Timer.periodic] 每 20 秒调一次，
  /// 测试里直接驱动它，才能覆盖「拉到最底下之后站点上新」这条路。
  @visibleForTesting
  Future<void> pulseNow() => _pulseFacts();

  /// 立刻把顶栏数对齐到底部数。测试里直接驱动，覆盖「拉到底之后顶栏自动
  /// 跟上」这条路（2.0.0+175）。
  @visibleForTesting
  void alignNow() => _alignListed();

  /// 列表底部的「共 N 部」= 这一次一共加载过的作品数（跨页去重后）。
  ///
  /// 和顶栏、最后一张卡片的序号是**同一个数**（2.0.0+150 定死）：翻到底时
  /// 三处必然相等。以前这里报站点声明（夜社海外短剧 2,166），而列表实际只有
  /// 2,156 张卡、末位卡片是第 2,156 部 —— 三个数摆在同一屏上互相打脸。
  int get footerCount => _feed?.items.length ?? 0;

  DramaFeed? get feed => _feed;
  CatalogCategory get tab => _tab;
  bool get recommending => _tab.id == recommendTab.id;

  List<CatalogCategory> get tabs {
    final catalog = _catalog;
    if (catalog == null) return const [];
    final [all, ...genres] = catalog.categories;
    return [
      if (catalog.recommends) recommendTab,
      all,
      for (final board in catalog.boards) rankingTab(board),
      ...genres,
    ];
  }

  int? rankOf(Drama drama) => _ranks[drama.id];

  WatchEntry? get resume {
    final source = this.source;
    if (source == null || _tab.id != tabs.first.id) return null;
    return store.history
        .where((entry) => entry.drama.source == source.id)
        .firstOrNull;
  }

  Drama? get featured =>
      recommending && resume == null ? _feed?.items.firstOrNull : null;

  /// 「全部」网格里的条目。
  ///
  /// 2.0.0+147 起不再把头条作品 skip 掉：头条大卡片只是同一部作品的另一个入口，
  /// 把它从列表里摘出去会让网格少一部、序号整体错位（以前干脆整页不编号了）。
  /// 现在头条不占序号、列表从 1 号连续往下排，翻到底最后一张卡的序号就是「共 N 部」。
  List<Drama> get items => _feed?.items ?? const <Drama>[];

  void select(String id) {
    if (id == _tab.id) return;
    final tab = tabs.where((tab) => tab.id == id).firstOrNull;
    if (tab != null) _select(tab);
  }

  Future<void> refresh() async {
    final catalog = _catalog;
    if (catalog == null) return;
    // 站点上新后分类栏也可能跟着变，顺手重拉一次分类表。
    if (catalog.categories.length == 1) {
      unawaited(_loadCategories(catalog, force: true));
    }
    // 刷新一开头**不要**把数字清掉：2.0.0+151 的反馈就是「刷新时与刷新完毕时
    // 顶栏数在两个数之间变化」。先把旧数留在屏幕上，等新一页回来再决定换不换。
    //
    // 2.0.0+176：已经翻到底的「全部」列表**不能再 reload**。reload(force:true)
    // 会把两千多张卡瞬间打回第 1 页的 24 张，上一轮从分类里补进来的作品（黑桃 /
    // 黄果视频各 8 部、站点新上的剧）当场消失，要等后台 rebuild 几百页走完才回来；
    // 用户再刷一次又缩回，于是「刷新没了 → 等一会又有了 → 再刷又没了」来回横跳。
    // 翻到底的列表交给后台整条重走，走完一次性 replaceAll，中途保持完整；
    // 没翻到底的（含推荐 / 榜单 / 分类）仍旧 reload 拉最新第一页。
    final feed = _feed;
    final bottomedAll = _tab.id == CatalogCategory.all.id &&
        feed != null &&
        feed.items.isNotEmpty &&
        !feed.hasMore &&
        feed.error.isEmpty;
    if (!bottomedAll) {
      await _feed?.reload(force: true);
      if (_disposed || _catalog != catalog) return;
    }
    // 再把「全部」补到末尾、把分类里藏着的作品并进来。站点上新作品时，顶栏那个
    // 数是翻到底量出来的，只拉第 1 页永远不知道末尾长了几部 —— 以前的实现要用户
    // 先切到别的分类翻一遍、再回来刷新才看得到变化。现在刷新一结束就自己补。
    //
    // 2.0.0+164：手动刷新一律走 rebuild（并发重走已经很快），不再看
    // 「是否翻到底 / 站点声明有没有变」——声明那个数早被 20 秒定时探头更新过了，
    // 手动刷新时 before 和 _facts.site 已经相等，siteChanged 永远是假，就会退到
    // 慢速补页、顶栏一直挂旧数（N-1/N-2）。用户主动下拉就是要立刻看到真实部数。
    unawaited(_recount(catalog, reload: true));
  }

  /// 把「全部」补到末尾，再把各分类里藏着的作品并进来，最后把实测条数写回顶栏。
  ///
  /// 两段事：
  /// 1. **补到末尾** —— 刷新只重拉第 1 页，末尾新长的作品永远看不见；
  /// 2. **分类补齐** —— 有些站源的「全部」目录本身就漏作品（黑桃、黄果视频各漏
  ///    8 部，那 8 部只在分类页出现）。用户明确要求「只想在【全部】里面找」，
  ///    所以这里把分类页的作品并入「全部」，序号 / 底部 / 末位卡片一起变大。
  ///
  /// 超预算就停手，顶栏留在原值，下次刷新接着补。
  Future<void> _recount(SourceCatalog catalog, {bool reload = false}) async {
    final source = catalog.source.id;
    final feed = _feed;
    if (feed == null) return;
    // 只有「全部」拿到的是全站总量；分类 / 榜单 / 推荐翻到底只是那个入口的条数。
    if (_tab.id != CatalogCategory.all.id) return;
    if (_recounting) {
      // 在途那轮已经是「重走整条目录」（rebuild）：它就是用户要的结果，让它
      // 安心走完，别作废重启。手动刷新连点时每刷一次就 token++ 把上一轮掐掉，
      // 结果哪轮都走不到底、顶栏一直挂在旧数 —— 这就是「刷新很多次才更新到 N」
      // 的病根（2.0.0+164 补）。只有站源换了（catalog 不同）才必须作废。
      if (reload && _rebuilding && _catalog == catalog) return;
      // 在途是「往后补页」那轮（reload=false）：它占着的会话会和重走互相取消，
      // 且 240 页预算根本补不到底。作废它，由这一轮重走接管（2.0.0+158 补）。
      if (!reload) return;
      _recountToken++;
      _recounting = false;
      _rebuilding = false;
    }
    _recounting = true;
    _rebuilding = reload;
    final token = ++_recountToken;
    _lastRecountAt = DateTime.now();
    // 重走整条目录要翻上百页，预算按用途分开给。
    final rebuild = reload;
    final deadline = DateTime.now().add(
      rebuild ? _rebuildBudget : _recountBudget,
    );
    try {
      // 两条路要重走整条目录：
      // ①探头发现站点变了、而列表早就翻到底了 —— 页码整体位移，只 loadMore 补不
      //   回来（hasMore 已经是 false）；
      // ②列表翻到底之后用户手动下拉刷新 —— 刷新只拉回第 1 页，剩下上百页 loadMore
      //   一页页补要三分钟以上，预算不够，顶栏和底部会长期停在「2118 / 24」。
      //
      // **不能**直接 reload 再补：那会把用户已经翻到底的 2,000 多张卡越补越慢，
      // 而且没补完就永远是半成品（2.0.0+157）。改成在副本上走完整条目录，走完才
      // 一次性替换；没走完就什么都不动，顶栏继续挂上一次的实测值。
      if (rebuild) {
        final rebuilt = await _rebuild(catalog, token, deadline);
        if (rebuilt == null) return;
        if (_disposed || token != _recountToken) return;
        if (_catalog != catalog || _feed != feed) return;
        // 「全部」这条例目录自己就漏作品（黑桃、黄果视频各漏 8 部，只在分类页
        // 出现）。重走完必须把分类里藏着的并进来再 replaceAll —— 否则那 8 部会
        // 被整条重走的目录抹掉，用户翻到底又少 8 部（2.0.0+158）。
        final expected = _facts.listed > _facts.site
            ? _facts.listed
            : _facts.site;
        // 每次 rebuild 后都做一次浅层补新：分类上新作品时，「全部」这条目录
        // 未必同步收录（黑桃/黄果视频就是这种），只扫每个分类头 6 页就能把
        // 新作品捞进「全部」，用户不用再翻别的分类手动找补（+161 反馈）。
        await _sweepCategories(
          catalog,
          feed,
          source,
          token,
          into: rebuilt,
          seen: {for (final drama in rebuilt) drama.id},
          shallow: true,
        );
        if (_disposed || token != _recountToken) return;
        if (_catalog != catalog || _feed != feed) return;
        // 浅层补完后仍比预期少 → 说明「全部」这条例目录深层还漏着作品
        // （黑桃/黄果视频各 8 部只在分类页出现），再走一次深层 restore 补齐。
        // 2.0.0+163：这里**无条件 restore**。以前用 `_facts.listed > rebuilt.length`
        // 当开关，可用户拉到底后三数已经降到实测值（黑桃 1528 / 黄果视频 2127），
        // 于是 1528 > 1528 不成立 → restore=false → 被 12h 节流挡住，那 8 部要等
        // 下次进站自检或节流过期才补回（用户反馈「过了一会儿才更新回 1536」）。
        // 走到这个分支本身就意味着 rebuilt 比站点声明少、目录确实漏了作品，
        // 而且这是整份替换（不补就会被永久抹掉），所以必须深扫，不看节流。
        if (rebuilt.length < expected) {
          await _sweepCategories(
            catalog,
            feed,
            source,
            token,
            into: rebuilt,
            seen: {for (final drama in rebuilt) drama.id},
            restore: true,
          );
          if (_disposed || token != _recountToken) return;
          if (_catalog != catalog || _feed != feed) return;
        }
        // 相等也要替换：站点「下架一部、上新一部」时总数不变，旧条件会让
        // 新剧永远进不来，用户要再刷几次等总数变化才看到（+174）。
        // 深扫没补齐导致副本比现列表少时仍不动，避免抹掉已并入的分类作品。
        if (rebuilt.isNotEmpty && rebuilt.length >= feed.items.length) {
          _noteAll(source, rebuilt);
          // 走完一整条目录也顺便把 known / 集数快照更新一遍：「今日更新」
          // 「新上」跟着站点的真实变化走，而不是等下一次刷新。
          await _observe(source, rebuilt);
          if (_disposed || token != _recountToken) return;
          if (_catalog != catalog || _feed != feed) return;
          feed.replaceAll(rebuilt);
          _noteListed(source, rebuilt.length);
        }
        return;
      }
      var pages = 0;
      while (pages < _recountPages && DateTime.now().isBefore(deadline)) {
        if (_disposed || token != _recountToken) return;
        if (_catalog != catalog || _feed != feed) return;
        if (!feed.hasMore) break;
        // 正在加载、连续失败已经暂停自动翻页、或者用户点了别的入口：
        // 这一轮就停手，别空转。页码没推进，下次刷新会接着补。
        if (!feed.canLoadMore) return;
        await feed.loadMore();
        pages++;
      }
      if (_disposed || token != _recountToken) return;
      if (_catalog != catalog || _feed != feed) return;
      if (feed.hasMore || feed.loadingMore || feed.items.isEmpty) return;
      // 「全部」已经翻到底：比预期少就说明分类里还藏着作品（或者站点声明虚高）。
      final expected = _facts.listed > _facts.site
          ? _facts.listed
          : _facts.site;
      if (feed.items.length < expected) {
        await _sweepCategories(catalog, feed, source, token);
        if (_disposed || token != _recountToken) return;
        if (_catalog != catalog || _feed != feed) return;
      }
      _noteListed(source, feed.items.length);
    } finally {
      if (token == _recountToken) {
        _recounting = false;
        _rebuilding = false;
      }
    }
  }

  /// 在副本上把「全部」从第 1 页重走到末尾，返回去重后的完整目录。
  ///
  /// 走不完（超预算 / 中途被取消 / 站点报错）返回 null —— 调用方这时**什么都别改**：
  /// 顶栏继续挂上一次的实测值，列表保持用户翻到的样子。宁可这一轮不更新，也不能
  /// 把已经对齐的三数打散、更不能让列表缩水。
  ///
  /// 走的是探头那条独立通道（`catalog-<source>-probe`），用户正在翻页时不会互相
  /// 取消；代价是这期间定时探头让路（见 [_pulseFacts]）。
  Future<List<Drama>?> _rebuild(
    SourceCatalog catalog,
    int token,
    DateTime deadline,
  ) async {
    final items = <Drama>[];
    final seen = <String>{};
    var emptyPages = 0;
    // 有界并发重走：原来一页页串行拉，黄果视频 89 页要 3～5 分钟，
    // 用户手动刷新后要等很久三数才变（+161 反馈）。现在每批并发拉 4 页，
    // 每条道独立 lane 互不取消（原生同 session 会掐掉上一请求），
    // 拿回整批后按页码顺序去重、判断是否到底，三数口径与串行时完全一致。
    const lanes = 4;
    var page = 1;
    while (page <= _rebuildPages) {
      if (_disposed || token != _recountToken) return null;
      if (_catalog != catalog) return null;
      if (DateTime.now().isAfter(deadline)) return null;

      final batch = List<int>.generate(
        lanes,
        (offset) => page + offset,
      ).where((p) => p <= _rebuildPages).toList();
      final List<CatalogPage?> results;
      try {
        results = await Future.wait([
          for (var i = 0; i < batch.length; i++)
            catalog.fetch(
              CatalogCategory.all,
              page: batch[i],
              force: true,
              probe: true,
              lane: '-probe-${i % lanes}',
              // 走只读真值通道：第 1 页不能再被旧缓存合并成全量、更不能
              // 沿用上次「已到底」的 hasMore，否则重走一开始就停住（+174）。
              raw: true,
            ),
        ], eagerError: true);
      } catch (_) {
        return null;
      }
      if (_disposed || token != _recountToken) return null;
      if (_catalog != catalog) return null;

      // 按页码顺序处理，保证去重结果与串行一致（先出现的位置保留）。
      var batchDone = false;
      for (var i = 0; i < batch.length; i++) {
        final result = results[i];
        if (result == null) return null;
        for (final drama in result.items) {
          if (drama.id.isEmpty) continue;
          if (seen.add(drama.id)) items.add(drama);
        }
        emptyPages = result.items.isEmpty ? emptyPages + 1 : 0;
        if (!result.hasMore || emptyPages >= 3) {
          batchDone = true;
          break;
        }
      }
      if (batchDone) return items;
      page += batch.length;
    }
    return null;
  }

  ///
  /// 只并入、不重排：这些作品本来就该在列表里，用户滑到底就能看到。扫过一遍
  /// 会记下时间（[sweptFreshFor]），声明虚高的站源不会每次刷新都白扫一百多页。
  Future<int> _sweepCategories(
    SourceCatalog catalog,
    DramaFeed feed,
    String source,
    int token, {
    List<Drama>? into,
    Set<String>? seen,
    bool restore = false,
    bool shallow = false,
  }) async {
    final swept = _sweptAt[source];
    // 12 小时节流只用来省「往后补页」那条路的白扫：它只 merge、不会抹掉已有
    // 作品。重走那条路是**整份替换**，之前从分类里补齐的作品（黑桃 / 黄果视频
    // 各 8 部）会被新目录抹掉 —— 这时再省就又把那 8 部弄丢了，必须扫。
    // 浅层补新（shallow）也绕开节流：用户手动刷新就是要看分类上新（+161 反馈）。
    if (!restore &&
        !shallow &&
        swept != null &&
        DateTime.now().difference(swept) < sweptFreshFor) {
      return 0;
    }
    final categories = [
      for (final category in catalog.categories)
        if (!category.local && category.id != CatalogCategory.all.id) category,
    ];
    if (categories.isEmpty) return 0;
    final end = DateTime.now().add(_sweepBudget);
    _sweeping = true;
    var complete = true;
    var added = 0;
    var fetched = 0;
    try {
      // 浅层补新只看每个分类的头几页（上新作品都排在最前）；深层补齐才走满
      // 160 页。这样手动刷新能很快把分类上新并进「全部」，不必扫一百多页。
      final pageCap = shallow ? 6 : _sweepPages;
      // 2.0.0+163：重走那条路（`into` 非空）要深扫上百页，串行太慢（黄果视频
      // 一个分类就几十页、每页 2～3 秒），用户要等很久三数才补齐。改成每批并发
      // 拉 4 页、每条道独立 lane（原生同 session 会互相取消），按页序处理，
      // 去重与吞页语义跟串行完全一致；浅层补新（into 也会非空但 pageCap 只有 6）
      // 仍走串行，省得为几页开一堆会话。
      final concurrent = into != null && !shallow;
      const lanes = 4;
      for (final category in categories) {
        var page = 1;
        while (page <= pageCap) {
          if (_disposed || token != _recountToken) return added;
          if (_catalog != catalog || _feed != feed) return added;
          if (DateTime.now().isAfter(end)) {
            complete = false;
            break;
          }
          // 用户正在翻页时别抢同一条道（原生会取消上一个请求）。
          if (into == null && feed.loadingMore) {
            await Future<void>.delayed(const Duration(milliseconds: 150));
            continue;
          }

          final batch = concurrent
              ? List<int>.generate(
                  lanes,
                  (offset) => page + offset,
                ).where((p) => p <= pageCap).toList()
              : <int>[page];
          final List<CatalogPage?> results;
          try {
            results = await Future.wait([
              for (var i = 0; i < batch.length; i++)
                catalog.fetch(
                  category,
                  page: batch[i],
                  // 重走那条路本身走探头通道，分类页也得跟着走，否则落在默认道
                  // 上会被用户翻页取消（2.0.0+158）。并发时每条道再带后缀，
                  // 避免同一次深扫里几页互相取消（2.0.0+163）。
                  probe: into != null,
                  // 以 -probe 结尾，满足「分类补齐走探头道」的既有断言；前面加
                  // sweep-N 让并发的几页各占一条道，互不取消。
                  lane: concurrent ? '-sweep-${i % lanes}-probe' : '',
                  // 分类页同样会被旧缓存合并：第 1 页一合并就把 hasMore 换成
                  // 上次的「已到底」，深扫再也捞不到分类深处藏着的作品。
                  raw: true,
                ),
            ], eagerError: true);
          } catch (_) {
            complete = false;
            break;
          }
          if (_disposed || token != _recountToken) return added;
          if (_catalog != catalog || _feed != feed) return added;

          // 按页序处理：先出现的位置优先，去重结果与串行一致。
          var batchDone = false;
          for (final result in results) {
            if (result == null) {
              complete = false;
              break;
            }
            fetched++;
            if (into == null) {
              added += feed.merge(result.items);
            } else {
              // 并进调用方给的目录副本：重走那条路还没 replaceAll，直接 merge 到
              // feed 会被随后的 replaceAll 覆盖掉。
              for (final drama in result.items) {
                if (drama.id.isEmpty) continue;
                if (seen != null && !seen.add(drama.id)) continue;
                into.add(drama);
                added++;
              }
            }
            if (!result.hasMore || result.items.isEmpty) {
              batchDone = true;
              break;
            }
          }
          if (complete == false || batchDone) break;
          page += batch.length;
          // 浅层没扫到这个分类的末尾，别把它当「扫完了」去记 sweptAt。
          if (shallow && page > pageCap) complete = false;
        }
        if (!complete) break;
      }
    } finally {
      _sweeping = false;
    }
    // 扫分类期间用户已经拉到底：上面 [_noteListed] 把那次实测挡下了，
    // 这里补写。重走那条路用副本条数（feed 此时还是刷新后的第 1 页），
    // 普通补页路用用户实际看到的列表条数。三数必须第一时间对齐（+174）。
    final pending = _pendingListed.remove(source);
    if (pending != null &&
        pending > 0 &&
        !_disposed &&
        token == _recountToken &&
        _catalog == catalog &&
        _feed == feed) {
      _noteListed(source, into?.length ?? pending);
    }
    // 扫完一部都没捞到（X短剧这种「声明虚高、分类里其实没藏东西」的站源）
    // 才记时间：下次刷新别白扫一百多页。真捞到了就下次接着扫 —— 说明「全部」
    // 确实在漏作品，直到原生目录缓存把并进去的卡片喂回来为止。
    // 一页都没扫到（分类表还没加载回来）不算「扫过了」，否则会把真正的补齐
    // 挡在 12 小时之外。
    if (complete && fetched > 0 && added == 0) {
      _sweptAt[source] = DateTime.now();
      // 重走那条路还没 replaceAll，`feed.items` 还是替换前的旧列表（刚下拉刷新
      // 完只有第 1 页的 24 条）。这里要落的是替换后那份目录的条数，否则会把
      // 顶栏写回 24（2.0.0+158 补）。
      await _persistListed(source, into?.length ?? feed.items.length);
    }
    return added;
  }

  /// 进站时的自检：没有实测值、上次测得太久（[listedFreshFor]）、或者站点声明
  /// 和实测差得远，就在后台量一遍。等首屏那一页先落地，别抢同一条道。
  Future<void> _measureIfStale(SourceCatalog catalog) async {
    final source = catalog.source.id;
    // 首屏那一页可能还在路上：等它回来再往后补，否则 [_recount] 会因为
    // 「正在加载」直接收手，进站这一趟就白测了。
    for (var attempt = 0; attempt < 8; attempt++) {
      await Future<void>.delayed(const Duration(milliseconds: 800));
      if (_disposed || _catalog?.source.id != source) return;
      if (_tab.id != CatalogCategory.all.id) return;
      final at = _listedAt[source];
      if (at != null && DateTime.now().difference(at) < listedFreshFor) return;
      final feed = _feed;
      if (feed == null) return;
      if (_recounting || feed.loading || feed.loadingMore) continue;
      if (feed.items.isEmpty) continue;
      await _recount(catalog);
      return;
    }
  }

  /// 声明变了之后安排一次重测。
  ///
  /// 声明变了不代表作品真的变了（这几站声明的数天天抖），所以屏幕上继续挂
  /// 上次实测的真实部数，只在后台重走一遍目录，量完再换。节流到
  /// [_pulseRecountGap]，免得声明每抖一次就把整个目录重走一遍。
  void _wantsRecount() {
    final catalog = _catalog;
    if (catalog == null) return;
    if (_tab.id != CatalogCategory.all.id) return;
    if (_recounting) return;
    final last = _lastRecountAt;
    if (last != null && DateTime.now().difference(last) < _pulseRecountGap) {
      return;
    }
    // 列表已经翻到底、站点又上新了：继续 loadMore 只会捞回重复的卡片（页码整体
    // 位移了），得从头重走一遍。还没翻到底时正常往后补就行。
    final feed = _feed;
    final bottomed =
        feed != null && !feed.hasMore && (_listed[catalog.source.id] ?? 0) > 0;
    unawaited(_recount(catalog, reload: bottomed));
  }

  /// 探头发现「站点有变化」之后的自检。
  ///
  /// 拉到底之后顶栏那个数是实测值：站点上新时它不会自己动（+153 反馈
  /// 「拉到底之后顶栏数就不更新了」）。这里隔 [_pulseRecountGap] 最多重测一次。
  void _recountAfterMoved(SourceCatalog catalog, String source) {
    if ((_listed[source] ?? 0) <= 0) return;
    if (_tab.id != CatalogCategory.all.id) return;
    if (_feed?.hasMore ?? true) return;
    if (_recounting) return;
    final last = _lastRecountAt;
    if (last != null && DateTime.now().difference(last) < _pulseRecountGap) {
      return;
    }
    unawaited(_recount(catalog, reload: true));
  }

  void _open() {
    final id = store.source;
    if (id == _catalog?.source.id) return;
    unawaited(repository.cancelCatalog());
    unawaited(repository.cancelRecommendations());
    _parkFeeds();
    // 上一轮重测（可能正在重走上百页）作废：token 一加，它下一次检查就收手。
    // [_recounting] 必须一起复位 —— 那一轮发现 token 变了会直接 return，
    // finally 里的复位就被跳过，标记永久为真会让新站源从此不再重测。
    _recountToken++;
    _recounting = false;
    _rebuilding = false;
    // 重测时间戳是全局单值，切源必须归零：不清的话 A 源刚重测完立刻切到 B 源，
    // B 源上新会被上一次重测的 10 分钟节流挡住。
    _lastRecountAt = null;
    // 探头的「刚拿到过总量」标记按站源算，换源必须清掉：不清的话切到新站源
    // 时 [_refreshFacts] 会以为已经拿过总量，直接跳过强制刷新，顶栏就一直挂着
    // 这个站上一次（甚至上一版 App）存下来的旧数字。
    _lastSiteTotalAt = null;
    if (id.isEmpty) {
      _catalog = null;
      _feed = null;
      _tab = CatalogCategory.all;
      _facts = const SourceFacts();
      return;
    }
    final catalog = _catalog = SourceCatalog(repository, SourceSite.byId(id));
    // 顶栏那行：站点声明 + 上次实测到的条数。实测值**不再清空**（+154）：进站
    // 就该看到真实部数（X短剧声明 2,180、实际 2,169），随后由 [_measureIfStale]
    // 在后台重测，所以也不会像 +148 那样永远不动。
    final stored = readFacts(store.sourceStats, id);
    final listedStats = readListedStats(store.sourceStats, id);
    if (listedStats.listed > 0) {
      _listed[id] = listedStats.listed;
    } else {
      _listed.remove(id);
    }
    if (listedStats.at case final at?) {
      _listedAt[id] = at;
    } else {
      _listedAt.remove(id);
    }
    if (listedStats.swept case final swept?) {
      _sweptAt[id] = swept;
    } else {
      _sweptAt.remove(id);
    }
    _facts = stored;
    // 切回来时接着上次的「全部」名单、集数快照和今日变化名单继续累计，不清零。
    _known[id] = readKnown(store.sourceStats, id).toSet();
    _episodes[id] = readEpisodes(store.sourceStats, id);
    _fresh[id] = readFresh(store.sourceStats, id).toList();
    _factsDay = factsDay(DateTime.now());
    final kept = readKnown(store.sourceStats, id);
    if (kept.isNotEmpty) {
      _seen[id] ??= kept.toSet();
    } else if (_facts.site <= 0 && _facts.local > 0) {
      // 旧版本存的是「本地目录缓存条数」，跟新的「全部分类已见数」不是一个口径，
      // 不能接着用。等这一轮把「全部」目录拉回来重新累计，别先显示一个假数字。
      _facts = SourceFacts(updated: _facts.updated, arrived: _facts.arrived);
      _listed.remove(id);
      _listedAt.remove(id);
    }
    final startedAt = DateTime.now();
    // 这个站源之前切走过，直接把列表接回来，不再重新请求。
    if (_stash.remove(id) case final kept?) {
      _feeds.addAll(kept);
      _resumed.addAll(kept.keys);
      _rankings.addAll(_stashRanks.remove(id) ?? const {});
      for (final feed in kept.values) {
        feed.addListener(_notify);
      }
    }
    _select(catalog.recommends ? recommendTab : CatalogCategory.all);
    unawaited(_loadCategories(catalog));
    // 先用本地剧库里存着的上次总量把顶栏填上（毫秒级），再去站源刷新。
    unawaited(_primeFacts(catalog));
    // 切一次源刷一次站源总量，不能只靠「用户往下翻页」时才收集。
    unawaited(_refreshFacts(catalog, startedAt));
    // 上次实测太久 / 根本没测过：后台量一遍，顶栏那个数才是真的。
    unawaited(_measureIfStale(catalog));
  }

  /// 换站源前把当前站源的 feed 存进 [_stash]（而不是直接销毁）。
  void _parkFeeds() {
    final source = _catalog?.source.id;
    if (source == null || _feeds.isEmpty) {
      _dropFeeds();
      return;
    }
    for (final feed in _feeds.values) {
      feed.removeListener(_notify);
    }
    _stash[source] = Map.of(_feeds);
    _stashRanks[source] = Map.of(_rankings);
    _feeds.clear();
    _rankings.clear();
    _feed = null;
    _ranks = const {};
    while (_stash.length > _stashLimit) {
      final oldest = _stash.keys.first;
      _stashRanks.remove(oldest);
      for (final feed in _stash.remove(oldest)?.values ?? const <DramaFeed>[]) {
        feed.dispose();
      }
    }
  }

  Future<void> _loadCategories(
    SourceCatalog catalog, {
    bool force = false,
  }) async {
    try {
      await catalog.loadCategories(force: force);
    } catch (_) {}
    if (_disposed || catalog != _catalog) return;
    _notify();
  }

  void _select(CatalogCategory tab) {
    final catalog = _catalog!;
    if (recommending) unawaited(repository.cancelRecommendations());
    _tab = tab;
    if (_feeds[tab.id] case final kept?) {
      _feed = kept;
      _ranks = _rankings[tab.id] ?? const {};
      if (kept.items.isEmpty && !kept.loading) {
        unawaited(kept.reload());
      } else if (_resumed.remove(tab.id)) {
        // 这个列表是切走前留下的：强制重拉，让作品也跟着站点更新。
        unawaited(kept.reload(force: true));
      }
      _notify();
      return;
    }
    final board = catalog.boards
        .where((board) => rankingTab(board).id == tab.id)
        .firstOrNull;
    final ranks = _ranks = _rankings[tab.id] = <String, int>{};
    // 「全部」这个分类拿回来的是全站列表，才需要「更新优先」排序。
    final whole = tab.id.isEmpty;
    final feed = _feed = _feeds[tab.id] = tab.id == recommendTab.id
        ? DramaFeed(
            cumulative: true,
            load: (page, force) => _track(
              catalog,
              page,
              () => catalog.recommendations(more: page > 1, force: force),
            ),
          )
        : board != null
        ? DramaFeed(
            load: (page, force) => _track(
              catalog,
              page,
              () => _ranking(catalog, board, ranks, page, force),
            ),
          )
        : DramaFeed(
            cached: () => catalog.cached(tab),
            load: (page, force) => _track(
              catalog,
              page,
              () => catalog.fetch(tab, page: page, force: force),
              whole: whole,
            ),
          );
    feed.addListener(_notify);
    // 「全部」列表滚到底时把真实条数记下来：站点声明的总量普遍有水分
    // （分页型按「页数 × 每页」报，末页不满就算多了），顶栏那个数只有
    // 拿实测值兜住，才和列表底部报的一致。
    if (whole) _watchListed(catalog.source.id, feed);
    unawaited(feed.reload());
    _notify();
  }

  /// 盯住「全部」列表什么时候滚到底，记下那时一共列出多少部。
  void _watchListed(String source, DramaFeed feed) {
    void check() {
      if (feed.loading || feed.loadingMore || feed.hasMore) return;
      if (feed.error.isNotEmpty || feed.items.isEmpty) return;
      // 这个回调可能发生在 feed 自己 notifyListeners 的过程中，
      // 直接再 notify 一次会和「正在通知」的列表打架，挪到下一个微任务。
      unawaited(
        Future<void>.microtask(() => _noteListed(source, feed.items.length)),
      );
    }

    feed.addListener(check);
  }

  /// 记下实测条数：顶栏 / 底部 / 末位卡片都靠它统一，同时落盘。
  ///
  /// 落盘是为了「下次进站先显示真实的部数」（X短剧声明 2,180、实际 2,169），
  /// 但每次进站只要超过 [listedFreshFor] 就会重测，所以不会僵在旧数字上。
  void _noteListed(String source, int listed) {
    if (_disposed || listed <= 0) return;
    if (_catalog?.source.id != source) return;
    // 正在扫分类：中间值别写回顶栏，等补完一次性写。但要记下来 ——
    // 用户可能在这段时间里已经拉到底，扫完必须补上，否则顶栏要等下一次
    // 刷新才同步（+174）。
    if (_sweeping) {
      final previous = _pendingListed[source] ?? 0;
      if (listed > previous) _pendingListed[source] = listed;
      return;
    }
    _listed[source] = listed;
    _listedAt[source] = DateTime.now();
    _facts = _facts.copyWith(listed: listed, probed: true);
    _notify();
    unawaited(_persistListed(source, listed));
    // 翻到底发现比预期少：分类里可能藏着作品（黑桃 / 黄果视频各藏 8 部）。
    // 这里补一次，用户不用再去别的分类翻一遍找补。
    final expected = _facts.site;
    if (listed < expected) {
      final swept = _sweptAt[source];
      final fresh =
          swept != null && DateTime.now().difference(swept) < sweptFreshFor;
      if (!fresh && !_recounting) {
        final catalog = _catalog;
        if (catalog != null) unawaited(_recount(catalog));
      }
    }
  }

  /// 定时把顶栏实测数对齐到「全部」列表已经翻到底时的实际条数。
  ///
  /// 纯本地操作：不请求站源、不动列表、不打断用户翻页。只有翻到底的列表才
  /// 是实测总数，没到底时列表长度只是当前加载量，不能写回顶栏把数写小。
  /// 重测 / 扫分类在途时让路，避免和它们各自要写的实测数打架（+175）。
  void _alignListed() {
    if (_disposed || _recounting || _sweeping) return;
    final catalog = _catalog;
    if (catalog == null) return;
    if (_tab.id != CatalogCategory.all.id) return;
    final source = catalog.source.id;
    final feed = _feed;
    if (feed == null) return;
    if (feed.hasMore ||
        feed.loading ||
        feed.loadingMore ||
        feed.error.isNotEmpty ||
        feed.items.isEmpty) {
      return;
    }
    // +174 的 pending 若因 token 变化没在扫完时补上，这里兜底补写。
    final pending = _pendingListed.remove(source) ?? 0;
    final actual = feed.items.length;
    final target = actual > pending ? actual : pending;
    if (target <= 0) return;
    if (_listed[source] == target && _facts.listed == target) return;
    _noteListed(source, target);
  }

  Future<void> _persistListed(String source, int listed) async {
    try {
      await store.setSourceStats(
        writeListedStats(
          store.sourceStats,
          source,
          listed: listed,
          swept: _sweptAt[source],
        ),
      );
    } catch (_) {}
  }

  Future<CatalogPage> _ranking(
    SourceCatalog catalog,
    RankingBoard board,
    Map<String, int> ranks,
    int page,
    bool force,
  ) async {
    final result = await catalog.ranking(board, page: page, force: force);
    for (final item in result.items) {
      ranks[item.drama.id] = item.rank;
    }
    return CatalogPage(
      [for (final item in result.items) item.drama],
      hasMore: result.hasMore,
      warning: result.warning,
      page: result.page,
    );
  }

  /// 用本地剧库缓存里的总量先把顶栏填上，避免切换站源后空白一小会儿。
  /// 只读、不写盘：真正的数字由 [_refreshFacts] 从站源拿回来再落库。
  Future<void> _primeFacts(SourceCatalog catalog) async {
    final source = catalog.source.id;
    if (_facts.probed && _facts.site > 0) return;
    try {
      final page = await catalog.cached(CatalogCategory.all);
      if (_disposed || _catalog?.source.id != source) return;
      if (page.total <= 0 || page.total == _facts.site) return;
      // 缓存里的总量和内存里的不一样，说明缓存是上一版留下的：声明换一个数，
      // 但**实测值留着**——它比声明准（黄果视频声明 2205、实际 2118），
      // 后台重测完再换。清掉的话进站又会先闪一个虚数。
      _listedAt.remove(source);
      _facts = _facts.copyWith(site: page.total, probed: true);
      _notify();
    } catch (_) {}
  }

  /// 切站源时刷新顶栏那行观测值。
  ///
  /// 首屏列表自己就会拉一页目录（[_track] 会把站源总量记下来），所以这里先
  /// 等 900ms：那一页已经带回总量就不重复请求站源；首屏完全走的本地缓存时
  /// 才补一次强制请求，保证「切过来看到的就是站点现在的数字」。
  Future<void> _refreshFacts(SourceCatalog catalog, DateTime startedAt) async {
    final source = catalog.source.id;
    await Future<void>.delayed(const Duration(milliseconds: 900));
    if (_disposed || _catalog?.source.id != source) return;
    final last = _lastSiteTotalAt;
    if (last != null && last.isAfter(startedAt)) return;
    try {
      final page = await catalog.fetch(
        CatalogCategory.all,
        page: 1,
        force: true,
        probe: true,
      );
      if (_disposed || _catalog?.source.id != source) return;
      _noteAll(source, page.items);
      await _observe(
        source,
        page.items,
        siteTotal: page.total,
        countArrivals: true,
      );
    } catch (_) {}
  }

  /// 定时重探「全部」第一页，把新长出来的集数并进「今日更新」。
  ///
  /// 只在应用前台跑：退到后台还每分钟拉一次目录纯属浪费流量和电。
  Future<void> _pulseFacts() async {
    if (_disposed || _pulsing) return;
    // 重走整条目录时走的是同一条探头通道：这时再发探头会把那一轮请求取消掉
    // （原生同一 session 的新请求会 cancel 上一个），整轮重测白跑。
    if (_recounting) return;
    final catalog = _catalog;
    if (catalog == null) return;
    final lifecycle = WidgetsBinding.instance.lifecycleState;
    if (lifecycle != null && lifecycle != AppLifecycleState.resumed) return;
    final source = catalog.source.id;
    _pulsing = true;
    try {
      final page = await catalog.fetch(
        CatalogCategory.all,
        page: 1,
        force: true,
        probe: true,
      );
      if (_disposed || _catalog?.source.id != source) return;
      unawaited(store.refreshDramas(page.items).catchError((Object _) {}));
      _noteAll(source, page.items);
      final moved = await _observe(
        source,
        page.items,
        siteTotal: page.total,
        countArrivals: true,
      );
      // 拉到底之后顶栏是实测值，站点上新时它不会自己动（+153 反馈的
      // 「拉到底之后顶栏数就不更新了」）——发现变化就重测一次。
      if (moved) _recountAfterMoved(catalog, source);
    } catch (_) {
      // 探头失败不打扰用户：下一轮再说。
    } finally {
      _pulsing = false;
    }
  }

  /// 取一页目录，顺便把结果记进本地（收藏/历史的剧信息刷新），
  /// 第一页还要更新顶栏那行观测值。
  ///
  /// 统计用的是我们自己记的集数快照（[_episodes]），不再读本地剧库 ——
  /// 原生目录缓存会把旧集数回填到新数据上（站点不给集数时是 0），
  /// 拿它当「旧值」就永远算不出增量。
  Future<CatalogPage> _track(
    SourceCatalog catalog,
    int page,
    Future<CatalogPage> Function() run, {
    bool whole = false,
  }) async {
    final source = catalog.source.id;
    final result = await run();
    unawaited(store.refreshDramas(result.items).catchError((Object _) {}));
    if (whole) _noteAll(source, result.items);
    if (page <= 1) {
      // 只有「全部」分类拿回来的是「全站总量」。分类页、榜单页的 total 是那个
      // 分类下的条数，拿来当总量会让顶栏数字随分类变来变去（+128 修的就是这个）。
      unawaited(
        _observe(
          source,
          result.items,
          siteTotal: whole ? result.total : 0,
          countArrivals: whole,
          // 命中本地目录缓存时 total 是上次存下来的，不能算「刚拿到」。
          freshPage: result.fresh,
        ),
      );
    }
    if (whole && page <= 1) {
      // 首屏的 total 已经由上面的 _observe 记下，这里什么都不用补。
    }
    // 列表顺序就是站源自己的顺序：2.0.0+144 把「新作品靠前」整个撤掉了 ——
    // 置顶会让第 1 页的序号与站点目录位置对不上，用户翻到底一对账就发现
    // 「第 3 张卡在站点上排第 90」，比看到新作品重要。
    return result;
  }

  /// 「全部」分类里又见到了这些剧，记下来（按 id 去重），顶栏的「已收录 N 部」
  /// 就是这个集合的长度。搜索、榜单、单独切开的分类都不进这个集合 ——
  /// 那样会把「站点到底有多少部」变成「我这一路看过多少条」。
  void _noteAll(String source, Iterable<Drama> items) {
    if (_disposed) return;
    final seen = _seen[source] ??= <String>{};
    if (seen.length >= factsSeenLimit) return;
    var added = false;
    for (final drama in items) {
      if (seen.length >= factsSeenLimit) break;
      if (drama.id.isEmpty) continue;
      if (seen.add(drama.id)) added = true;
    }
    if (!added || _catalog?.source.id != source) return;
    _seenDirty.add(source);
    _facts = _facts.copyWith(
      local: seen.length,
      listed: _listed[source] ?? 0,
      probed: true,
    );
    _notify();
  }

  /// 记录一次观测：站源总量 + 本地收录数 + 今天增加的集数。
  ///
  /// 集数用 [_episodes] 里我们自己记的快照比，新上用 [_known] 里的历史名单比 ——
  /// 两者都落盘，所以换进程、跨天、清缓存（只清目录缓存）都不影响判断。
  /// 第一次观测（还没有基线）只记基线不报数，不然一装上就是「新上 60 部」。
  /// 返回 true 表示这次观测发现「站点有变化」（总量变了 / 第一页出现新作品 /
  /// 集数涨了）—— 拉到底之后顶栏那个数是实测值，得靠这个信号触发重测。
  Future<bool> _observe(
    String source,
    List<Drama> fresh, {
    int siteTotal = 0,
    bool countArrivals = false,
    bool freshPage = true,
  }) async {
    if (_disposed) return false;
    final today = factsDay(DateTime.now());
    if (_factsDay != today) {
      // 跨天：今日变化名单清空，updated/arrived 由 readFacts 自己归零。
      _factsDay = today;
      _fresh[source] = <String>[];
    }
    final known = _known[source] ??= <String>{};
    final episodes = _episodes[source] ??= <String, int>{};
    final changed = _fresh[source] ??= <String>[];
    var gained = 0;
    // 名单/今日变化名单本身有没有长出新条目。计数器没变但名单变了也要落盘，
    // 否则下次切回这个站源时读到的是旧名单，「新上」又被重新数一遍。
    var structure = false;
    final knownBefore = known.length;
    final changedBefore = changed.length;
    // 同一页里同一部可能出现两次（黄桃、柚子这类站源是多个栏目拼起来的），
    // 先按 id 取最大集数，再算增量，免得同一集更新被数两遍。
    final batch = <String, int>{};
    for (final drama in fresh) {
      if (drama.id.isEmpty) continue;
      final episodesNow = drama.episodes;
      final previous = batch[drama.id];
      batch[drama.id] = previous == null || episodesNow > previous
          ? episodesNow
          : previous;
    }
    for (final entry in batch.entries) {
      final id = entry.key;
      final now = entry.value;
      final old = episodes[id];
      if (old != null && old > 0 && now > old) {
        gained += now - old;
        _markChanged(changed, id);
      }
      // 「新上 N 部」这一行在 2.0.0+137 里删掉了：站点的「全部」第一页按更新
      // 时间排，每次刷新都有新作品挤上来，而落盘的 known 名单只留得住 1500 条，
      // 被裁掉的 id 再出现就会被重新数一遍 —— 于是数字每刷一次涨一次，能涨到 >「共 N 部」。
      //
      // 2.0.0+143 曾把「第一次见到的作品提到最前」搬回来，2.0.0+144 又撤了：
      // 置顶会让第 1 页的卡片序号和站点目录位置对不上，用户拿序号对账时
      // 「第 3 张卡在站点上排第 90」比「新作品在最前面」更让人困惑。
      if (!known.contains(id)) {
        structure = true;
      }
      known.add(id);
      if (now > 0 && (old == null || now > old)) episodes[id] = now;
    }
    // 内存里也别无限长：翻得越深这两份表越大，留够判断用的量就行。
    if (known.length > factsSeenLimit * 2) {
      final drop = known.length - factsSeenLimit;
      for (final id in known.take(drop).toList(growable: false)) {
        known.remove(id);
      }
    }
    if (episodes.length > factsEpisodeLimit * 2) {
      final drop = episodes.length - factsEpisodeLimit;
      for (final id in episodes.keys.take(drop).toList(growable: false)) {
        episodes.remove(id);
      }
    }
    // 站源给的量优先；站点给不出总量时用「全部」分类里见过的数兜底，
    // 不再用本地目录缓存的条数 —— 那个数被搜索和分类一起撑大，不是站点的量。
    final site = siteTotal > 0 ? siteTotal : _facts.site;
    // 只有真的从站源拿到过（不是本地缓存的旧 Total）才记「刚刚拿过总量」，
    // 否则切站源后的强制刷新会被这一笔挡掉，顶栏就一直停在旧数字上。
    if (siteTotal > 0 && freshPage) _lastSiteTotalAt = DateTime.now();
    // 站点自己报的总量变了，说明目录增删过：翻到底量到的条数要重测。
    //
    // 但**不能**把实测值丢掉：这几个站（黄果视频 / X短剧 / 柚子）的声明几乎
    // 每次进站都在变（2204 → 2205），一丢就退回声明那个虚数，用户看到的就是
    // 「初次进站 2205、拉到底才 2118」（+155 的反馈）。现在留着旧实测值继续显示，
    // 只把「刚测过」的时间戳清掉，让 [_measureIfStale] 立刻重测，测完再换数。
    final siteChanged =
        siteTotal > 0 && _facts.site > 0 && siteTotal != _facts.site;
    if (siteChanged) {
      _listedAt.remove(source);
    }
    final local = _seen[source]?.length ?? _facts.local;
    if (_disposed || _catalog?.source.id != source) return false;
    // 声明变了就趁这次进站/探头在后台重量一遍，别等下一次进站（顶栏现在显示的
    // 还是上一次的实测值）。节流逻辑见 [_wantsRecount]。
    if (siteChanged) _wantsRecount();
    final saved = writeFacts(
      store.sourceStats,
      source,
      site: site,
      local: local,
      gained: gained,
      arrived: 0,
      known: known,
      episodes: episodes,
      fresh: changed,
      seeded: true,
    );
    final next = readFacts(saved, source);
    final dirty = _seenDirty.remove(source);
    structure =
        structure ||
        known.length != knownBefore ||
        changed.length != changedBefore;
    if (gained == 0 &&
        !dirty &&
        !structure &&
        next.site == _facts.site &&
        next.local == _facts.local &&
        next.updated == _facts.updated &&
        next.arrived == _facts.arrived) {
      // 没有变化就别写盘，也别让界面白重建一次。
      return false;
    }
    // next 来自落盘的观测表，里面没有「翻到底实测条数」这一项（2.0.0+148 起
    // 不再落盘）。这里必须把内存里那份接回去，否则每观测一次就把顶栏的实测值
    // 洗成 0，顶栏又掉回站点声明 —— 三数立刻不等。
    _facts = SourceFacts(
      site: next.site,
      local: next.local,
      updated: next.updated,
      arrived: next.arrived,
      listed: _listed[source] ?? 0,
      probed: next.probed,
    );
    _notify();
    unawaited(store.setSourceStats(saved).catchError((Object _) {}));
    return structure || siteChanged || gained > 0;
  }

  void _markChanged(List<String> changed, String id) {
    if (changed.contains(id)) return;
    changed.insert(0, id);
    if (changed.length > factsFreshLimit) changed.removeLast();
  }

  void _storeChanged() {
    _open();
    _notify();
  }

  void _metadataChanged() {
    final drama = repository.catalogUpdates.latest;
    if (drama == null || drama.source != source?.id) return;
    _catalog?.remember([drama]);
    for (final feed in _feeds.values) {
      feed.update(drama);
    }
    unawaited(store.refreshDrama(drama).catchError((Object _) {}));
  }

  void _dropFeeds() {
    for (final feed in _feeds.values) {
      feed.dispose();
    }
    _feeds.clear();
    _rankings.clear();
    _resumed.clear();
    _feed = null;
    _ranks = const {};
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _pulse?.cancel();
    _alignTimer?.cancel();
    store.removeListener(_storeChanged);
    repository.catalogUpdates.removeListener(_metadataChanged);
    _dropFeeds();
    for (final feeds in _stash.values) {
      for (final feed in feeds.values) {
        feed.dispose();
      }
    }
    _stash.clear();
    _stashRanks.clear();
    unawaited(repository.cancelCatalog());
    unawaited(repository.cancelRecommendations());
    super.dispose();
  }
}
