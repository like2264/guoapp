import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:native_liquid_glass/native_liquid_glass.dart';

import '../app_scope.dart';

/// 当前是否启用玻璃外观。
///
/// 直接用 [AppScope] 而不是 `AppScope.of`：这个判断会被很多基础组件用到，
/// 而它们有时会被放在 AppScope 之外（独立的对话框、测试里的裸 widget），
/// 那种情况下按「关」处理，不要抛空指针。
bool glassEnabled(BuildContext context) =>
    context.dependOnInheritedWidgetOfExactType<AppScope>()?.liquidGlass ??
    false;

/// Liquid Glass 的基础容器：背景模糊 + 极薄的高光层 + 细高光边。
///
/// 主题只能改颜色，模糊必须靠 [BackdropFilter]，所以玻璃效果统一走这个组件，
/// 需要“玻璃感”的地方直接包一层即可。默认几乎透明，让底下的封面/内容透出来；
/// 需要更实的底（例如深色页面上放正文）就把 [tint] 调大。
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.blur = 22,
    this.radius = 24,
    this.tint = 1,
    this.shade = 0,
    this.border = true,
    this.ring = true,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final double blur;
  final double radius;

  /// 底色浓度倍率：1 是默认的极薄高光，调到 2~3 会明显更「实」。
  final double tint;

  /// 压暗层。默认 0，只叠一层白光——适合压在深色页面上的底栏。
  /// 弹层这类「底下可能是亮封面、上面还要放白字」的场景把这里调到 0.5~0.65，
  /// 玻璃会变成烟熏色：后面的内容仍然看得见轮廓，字也压得住。
  final double shade;

  /// 是否描一圈高光边（贴边使用的底栏一般不要）。
  final bool border;

  /// 是否在贴边处画那根 0.8px 的深色细线。
  ///
  /// 它跟 [border] 是两回事：`border` 是玻璃内侧的白描边，这个是阴影里
  /// 一根零模糊的环。压在视频上的弹层用它会看起来像「玻璃外面又多了一个框」，
  /// 关掉之后只留下柔和投影。
  final bool ring;

  @override
  Widget build(BuildContext context) {
    // iOS 26+：整个 App 的玻璃容器统一换成系统原生 UIGlassEffect，
    // 和系统底栏同一套材质；手绘 BackdropFilter 留给旧系统与其他平台。
    // 这里只替换「玻璃底」，padding / child 原样保留，页面布局不变。
    if (NativeLiquidGlassUtils.supportsLiquidGlass) {
      final dark = Theme.of(context).brightness == Brightness.dark;
      return LiquidGlassContainer(
        config: LiquidGlassConfig(
          shape: LiquidGlassEffectShape.rect,
          cornerRadius: radius,
          // 给系统玻璃一层可控的底层颜色，滚动过亮/暗内容时不会来回反色。
          backgroundColor: Theme.of(context).colorScheme.surface.withValues(
                alpha: dark ? 0.42 : 0.62,
              ),
          border: border
              ? LiquidGlassBorder(
                  color: dark
                      ? Colors.white.withValues(alpha: 0.16)
                      : Colors.white.withValues(alpha: 0.85),
                  width: 1,
                )
              : null,
        ),
        child: Padding(padding: padding, child: child),
      );
    }
    final dark = Theme.of(context).brightness == Brightness.dark;
    final corners = BorderRadius.circular(radius);
    double alpha(double value) => (value * tint).clamp(0, 1).toDouble();
    // 一层玻璃色：先叠白光，需要压暗时再把黑压在上面，合成一个半透明色。
    // 浅色底上纯白玻璃几乎看不见，所以先垫一层很淡的中性灰当「雾面」，
    // 再把白光压上去——这样它在 #F4F6FB 的页面上才立得起来。
    Color layer(double value) {
      final base = dark
          ? Colors.white.withValues(alpha: alpha(value))
          : Color.alphaBlend(
              Colors.white.withValues(alpha: alpha(value)),
              // 2.0.0+137：雾面从 10% 加到 16%。用户反馈「浅色下玻璃看不出来」——
              // 白光叠在 #F4F6FB 上本来就只差几个色阶，靠这层灰才分出块面。
              const Color(0xFF9AA3B2).withValues(alpha: 0.16),
            );
      if (shade <= 0) return base;
      return Color.alphaBlend(
        base,
        Colors.black.withValues(alpha: shade.clamp(0, 1).toDouble()),
      );
    }

    return DecoratedBox(
      // 阴影和外描边必须画在裁剪外面，否则会被 ClipRRect 一起剪掉。
      // 浅色模式下这两样是玻璃「看得见」的关键：白色玻璃压在浅灰页面上，
      // 只靠内部的白色描边根本分不出边界，全靠这圈 6% 的黑和一层投影。
      decoration: BoxDecoration(
        borderRadius: corners,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: dark ? 0.32 : 0.08),
            blurRadius: 22,
            spreadRadius: -5,
            offset: const Offset(0, 9),
          ),
          if (ring)
            BoxShadow(
              color: Colors.black.withValues(alpha: dark ? 0.10 : 0.10),
              blurRadius: 0,
              spreadRadius: 0.8,
            ),
        ],
      ),
      child: ClipRRect(
        borderRadius: corners,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: DecoratedBox(
            decoration: BoxDecoration(
              // 描边比裁剪半径内缩半像素：不然 1px 的边有一半被 ClipRRect 剪掉，
              // 剩下的半像素和裁剪边缘叠在一起，看起来就是「玻璃外面多了一圈线」。
              borderRadius: BorderRadius.circular(radius - 0.5),
              border: border
                  ? Border.all(
                      color: dark
                          ? Colors.white.withValues(alpha: 0.16)
                          : Colors.white.withValues(alpha: 0.95),
                    )
                  : null,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: dark
                    ? [layer(0.09), layer(0.03)]
                    : [layer(0.64), layer(0.44)],
              ),
            ),
            child: Padding(padding: padding, child: child),
          ),
        ),
      ),
    );
  }
}

/// 卡片底：玻璃外观下是一块磨砂玻璃，关掉时还是原来那块实底 Material。
///
/// 用来替换满屏的 `Material(color: colors.surfaceContainer, ...)`——
/// 里面的 InkWell 水波纹照常，因为玻璃层下面仍然垫着一张透明 Material。
class GlassCard extends StatelessWidget {
  const GlassCard({
    super.key,
    required this.child,
    this.radius = 20,
    this.blur = 18,
    this.tint = 1.15,
    this.color,
    this.clip = true,
    this.border = true,
  });

  final Widget child;
  final double radius;
  final double blur;
  final double tint;

  /// 玻璃关掉时的实底颜色，默认 `surfaceContainer`。
  final Color? color;
  final bool clip;
  final bool border;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final corners = BorderRadius.circular(radius);
    final cut = clip ? Clip.antiAlias : Clip.none;
    if (!glassEnabled(context)) {
      return Material(
        color: color ?? colors.surfaceContainer,
        borderRadius: corners,
        clipBehavior: cut,
        child: child,
      );
    }
    return GlassPanel(
      radius: radius,
      blur: blur,
      tint: tint,
      border: border,
      padding: EdgeInsets.zero,
      child: Material(
        color: Colors.transparent,
        borderRadius: corners,
        clipBehavior: cut,
        child: child,
      ),
    );
  }
}
