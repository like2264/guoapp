package core

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"testing"
)

type probeBitWriter struct {
	bits []int
}

func (writer *probeBitWriter) put(value, width int) {
	for index := width - 1; index >= 0; index-- {
		writer.bits = append(writer.bits, (value>>index)&1)
	}
}

func (writer *probeBitWriter) ue(value int) {
	width := 0
	for (1<<(width+1))-1 <= value {
		width++
	}
	writer.put(0, width)
	writer.put(1, 1)
	writer.put(value-((1<<width)-1), width)
}

func (writer *probeBitWriter) bytes() []byte {
	out := make([]byte, (len(writer.bits)+7)/8)
	for index, bit := range writer.bits {
		if bit != 0 {
			out[index/8] |= 1 << (7 - uint(index%8))
		}
	}
	return out
}

// 造一条 baseline SPS：54x30 个宏块 = 864x480，右边裁掉 5 个 4:2:0 单元
// （10 像素），得到播放器日记里那类 854x480 的实际分辨率。
func probeSPSBytes() []byte {
	writer := &probeBitWriter{}
	writer.put(66, 8) // profile
	writer.put(0, 8)  // constraint flags
	writer.put(30, 8) // level
	writer.ue(0)      // sps id
	writer.ue(0)      // log2_max_frame_num_minus4
	writer.ue(0)      // pic_order_cnt_type
	writer.ue(0)      // log2_max_pic_order_cnt_lsb_minus4
	writer.ue(1)      // max_num_ref_frames
	writer.put(0, 1)  // gaps_in_frame_num_value_allowed_flag
	writer.ue(53)     // pic_width_in_mbs_minus1
	writer.ue(29)     // pic_height_in_map_units_minus1
	writer.put(1, 1)  // frame_mbs_only_flag
	writer.put(0, 1)  // direct_8x8_inference_flag
	writer.put(1, 1)  // frame_cropping_flag
	writer.ue(0)      // crop left
	writer.ue(0)      // crop top
	writer.ue(5)      // crop right
	writer.ue(0)      // crop bottom
	return append([]byte{0x67}, writer.bytes()...)
}

func TestH264SPSResolution(t *testing.T) {
	sps := probeSPSBytes()
	width, height := nativeParseH264SPS(sps)
	if width != 854 || height != 480 {
		t.Fatalf("SPS 宽高 = %dx%d，期望 854x480", width, height)
	}
	packet := append([]byte{0, 0, 1}, sps...)
	if width, height = nativeH264SPSResolution(append(packet, 0x00, 0x00, 0x01, 0x68)); width != 854 || height != 480 {
		t.Fatalf("TS 分片里解析宽高 = %dx%d，期望 854x480", width, height)
	}
}

func probeMP4Box(kind string, body []byte) []byte {
	out := make([]byte, 8+len(body))
	binary.BigEndian.PutUint32(out, uint32(len(out)))
	copy(out[4:8], kind)
	copy(out[8:], body)
	return out
}

func TestMP4Resolution(t *testing.T) {
	tkhd := make([]byte, 92)
	binary.BigEndian.PutUint32(tkhd[76:], 1280<<16)
	binary.BigEndian.PutUint32(tkhd[80:], 720<<16)
	moov := probeMP4Box("moov", probeMP4Box("trak", probeMP4Box("tkhd", tkhd)))
	width, height := nativeMP4Resolution(append(probeMP4Box("ftyp", []byte("isom")), moov...))
	if width != 1280 || height != 720 {
		t.Fatalf("MP4 宽高 = %dx%d，期望 1280x720", width, height)
	}
	// moov 在尾部时也要认得出来。
	if width, height = nativeMP4Resolution(append([]byte{0, 0, 0, 8, 'f', 'r', 'e', 'e'}, moov...)); width != 1280 || height != 720 {
		t.Fatalf("尾部 moov 宽高 = %dx%d，期望 1280x720", width, height)
	}
}

func TestProbeURLHint(t *testing.T) {
	cases := map[string]int64{
		"https://cdn.example.com/720p/seg1.ts":        720,
		"https://cdn.example.com/video.m3u8?q=1080":   1080,
		"https://cdn.example.com/abcdef123456/seg.ts": 0,
	}
	for address, want := range cases {
		if got := nativeURLQualityHint(address); got != want {
			t.Fatalf("%s 档位提示 = %d，期望 %d", address, got, want)
		}
	}
}

func TestPlaylistProbeSegmentPrefersMap(t *testing.T) {
	list := `#EXTM3U
#EXT-X-MAP:URI="init.mp4"
#EXTINF:10,
seg0.ts
#EXTINF:10,
seg1.ts
`
	if got := nativePlaylistProbeSegment(list, "https://cdn.example.com/hls/a.m3u8"); got != "https://cdn.example.com/hls/init.mp4" {
		t.Fatalf("探测目标 = %s，期望 fMP4 初始化段", got)
	}
}

func TestMasterPlaylistHeight(t *testing.T) {
	list := `#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=950000,RESOLUTION=854x480
a.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=1800000,RESOLUTION=1280x720
b.m3u8
`
	if got := nativeMasterPlaylistHeight(list); got != 720 {
		t.Fatalf("主列表最高档 = %d，期望 720", got)
	}
	// 竖屏按短边。
	vertical := "#EXTM3U\n#EXT-X-STREAM-INF:RESOLUTION=720x1280\na.m3u8\n"
	if got := nativeMasterPlaylistHeight(vertical); got != 720 {
		t.Fatalf("竖屏主列表档位 = %d，期望 720", got)
	}
	if got := nativeMasterPlaylistHeight("#EXTM3U\n#EXTINF:6,\nseg.ts\n"); got != 0 {
		t.Fatalf("单路列表不应有主档位，得到 %d", got)
	}
}

func TestPlaylistKey(t *testing.T) {
	list := `#EXTM3U
#EXT-X-KEY:METHOD=AES-128,URI="key.key",IV=0x87445e2c330d2d8b89bd052e088f6222
#EXTINF:6,
seg.ts
`
	info := nativePlaylistKey(list, "https://cdn.example.com/hls/index.m3u8")
	if info == nil {
		t.Fatal("没解析出 key")
	}
	if info.uri != "https://cdn.example.com/hls/key.key" {
		t.Fatalf("key URI = %s", info.uri)
	}
	if len(info.iv) != 16 || info.iv[0] != 0x87 || info.iv[15] != 0x22 {
		t.Fatalf("IV 不对：%x", info.iv)
	}
	// 绝对 URI 不会被 base 拼坏。
	list2 := "#EXT-X-KEY:METHOD=AES-128,URI=\"https://other.example/k.key\",IV=0x00000000000000000000000000000001\n"
	if info2 := nativePlaylistKey(list2, "https://cdn.example.com/hls/index.m3u8"); info2 == nil || info2.uri != "https://other.example/k.key" {
		t.Fatalf("绝对 key URI 解析错：%+v", info2)
	}
}

func TestDecryptSegment(t *testing.T) {
	// 造一段明文 TS，里面带 SPS。
	packet := append([]byte{0, 0, 1}, probeSPSBytes()...)
	packet = append(packet, 0x00, 0x00, 0x01, 0x68) // SPS 结束边界
	for len(packet)%16 != 0 {
		packet = append(packet, 0x47) // TS sync byte 填充到整块
	}
	key := []byte("0123456789abcdef")
	iv := []byte("fedcba9876543210")
	sealed := make([]byte, len(packet))
	block, _ := aes.NewCipher(key)
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(sealed, packet)
	plain := nativeDecryptSegment(sealed, key, iv)
	w, h := nativeH264SPSResolution(plain)
	t.Logf("解密后 SPS = %dx%d; mediaBytesHeight=%d; plain len=%d", w, h, nativeMediaBytesHeight(plain, "https://cdn/seg.ts"), len(plain))
	if h := nativeMediaBytesHeight(plain, "https://cdn/seg.ts"); h != 480 {
		t.Fatalf("解密后分辨率 = %d，期望 480", h)
	}
	// 仍用密文时解不出档位。
	if h := nativeMediaBytesHeight(sealed, "https://cdn/seg.ts"); h > 0 {
		t.Fatalf("密文不该解出分辨率，得到 %d", h)
	}
}
