import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../models.dart';
import '../app_scope.dart';
import '../theme/motion.dart';
import 'cover_image.dart';
import 'drama_actions.dart';
import 'focus_ring.dart';
import 'motion/motion_widgets.dart';

const _coverRadius = 12.0;

class _PosterButton extends StatefulWidget {
  const _PosterButton({
    required this.cover,
    required this.caption,
    required this.label,
    required this.onTap,
    this.onMore,
    this.actions,
    this.focusNode,
    this.autofocus = false,
    this.checked,
  });
  final Widget cover;
  final List<Widget> caption;
  final String label;
  final VoidCallback onTap;

  /// 长按的默认行为（多选页用它进入选择模式）。
  final VoidCallback? onMore;

  /// 长按后在**卡片封面内**浮出的操作（追剧 / 下载）。
  /// 有它时长按不再调 [onMore]。
  final List<DramaAction>? actions;
  final FocusNode? focusNode;
  final bool autofocus;
  final bool? checked;

  @override
  State<_PosterButton> createState() => _PosterButtonState();
}

class _PosterButtonState extends State<_PosterButton> {
  bool _focused = false;
  bool _hovered = false;
  bool _pressed = false;
  bool _actionsOpen = false;

  /// 全列表只允许一张卡片的操作浮层开着：长按第二张时第一张自动收。
  static _PosterButtonState? _openCard;

  /// 卡片所在的滚动位置。浮层开着的时候只要列表动了就把它收掉 ——
  /// 以前滚走之后浮层还挂在卡片上，滑回来才看见，很容易误点。
  ScrollPosition? _position;

  bool get _hasActions => widget.actions?.isNotEmpty ?? false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final position = Scrollable.maybeOf(context)?.position;
    if (identical(position, _position)) return;
    _position?.removeListener(_closeOnScroll);
    _position = position;
    _position?.addListener(_closeOnScroll);
  }

  @override
  void dispose() {
    _position?.removeListener(_closeOnScroll);
    if (identical(_openCard, this)) _openCard = null;
    super.dispose();
  }

  void _closeOnScroll() {
    if (!_actionsOpen) return;
    _closeActions();
  }

  void _toggleActions() {
    if (_actionsOpen) {
      _closeActions();
      return;
    }
    final other = _openCard;
    if (other != null && !identical(other, this)) other._closeActions();
    _openCard = this;
    setState(() => _actionsOpen = true);
  }

  void _closeActions() {
    if (!_actionsOpen) return;
    if (identical(_openCard, this)) _openCard = null;
    setState(() => _actionsOpen = false);
  }

  @override
  Widget build(BuildContext context) {
    final visible = focusVisible(_focused);
    final layer = _pressed ? 0.12 : (_hovered ? 0.08 : 0.0);
    final open = _actionsOpen && _hasActions;
    final button = InkWell(
      focusNode: widget.focusNode,
      autofocus: widget.autofocus,
      // 操作浮出来后，点封面任意位置只是把它收起来，不会顺手点进详情。
      onTap: open ? _closeActions : widget.onTap,
      onLongPress: _hasActions ? _toggleActions : widget.onMore,
      onSecondaryTap: _hasActions ? _toggleActions : widget.onMore,
      onFocusChange: (focused) => setState(() => _focused = focused),
      onHover: (hovered) => setState(() => _hovered = hovered),
      onHighlightChanged: (pressed) {
        // 长按会先触发 pressed 再弹操作：如果这时候按下的高亮还留着，
        // 收起遮罩后封面会灰一下。浮层打开时直接不吃这个高亮。
        if (open) return;
        setState(() => _pressed = pressed);
      },
      overlayColor: const WidgetStatePropertyAll(Colors.transparent),
      splashFactory: NoSplash.splashFactory,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          AspectRatio(
            aspectRatio: 2 / 3,
            child: FocusOutline(
              visible: visible,
              radius: _coverRadius,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  widget.cover,
                  IgnorePointer(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 120),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(_coverRadius),
                        color: Theme.of(
                          context,
                        ).colorScheme.onSurface.withValues(alpha: layer),
                      ),
                    ),
                  ),
                  if (open)
                    _CardActions(
                      actions: widget.actions!,
                      onDismiss: _closeActions,
                      onPick: (action) {
                        _closeActions();
                        action.onSelected(context);
                      },
                    ),
                ],
              ),
            ),
          ),
          ...widget.caption,
        ],
      ),
    );
    return Semantics(
      label: widget.label,
      checked: widget.checked,
      // 点卡片外面任何地方（另一张卡、导航栏、空白）都把浮层收掉。
      child: TapRegion(
        onTapOutside: (_) => _closeActions(),
        child: CallbackShortcuts(
          bindings: {
            const SingleActivator(LogicalKeyboardKey.contextMenu):
                ?widget.onMore,
          },
          child: AnimatedScale(
            scale: visible && AppScope.of(context).television ? 1.06 : 1,
            duration: const Duration(milliseconds: 120),
            child: button,
          ),
        ),
      ),
    );
  }
}

/// 卡片封面上的操作层：压一层暗色，中间竖排两枚胶囊按钮。
///
/// 尺寸很紧（手机上一张卡宽 100~120），所以字号只用 11.5，
/// 标签交给 FittedBox 缩，绝不换行 —— 换行会把按钮撑出封面。
class _CardActions extends StatelessWidget {
  const _CardActions({
    required this.actions,
    required this.onDismiss,
    required this.onPick,
  });
  final List<DramaAction> actions;
  final VoidCallback onDismiss;
  final ValueChanged<DramaAction> onPick;

  @override
  Widget build(BuildContext context) => GestureDetector(
    behavior: HitTestBehavior.opaque,
    onTap: onDismiss,
    child: DecoratedBox(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.52),
        borderRadius: BorderRadius.circular(_coverRadius),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 7),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final (index, action) in actions.indexed) ...[
                if (index > 0) const SizedBox(height: 6),
                _ActionChip(action: action, onTap: () => onPick(action)),
              ],
            ],
          ),
        ),
      ),
    ),
  );
}

class _ActionChip extends StatelessWidget {
  const _ActionChip({required this.action, required this.onTap});
  final DramaAction action;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.white.withValues(alpha: 0.18),
    borderRadius: BorderRadius.circular(9),
    child: InkWell(
      key: ValueKey('drama-action-${action.label}'),
      onTap: onTap,
      borderRadius: BorderRadius.circular(9),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: Colors.white.withValues(alpha: 0.28)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(action.icon, size: 13, color: Colors.white),
            const SizedBox(width: 4),
            Flexible(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  action.label,
                  maxLines: 1,
                  style: const TextStyle(
                    fontSize: 11.5,
                    height: 1.2,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

/// 把标题里命中的关键词切出来单独上色。
///
/// 只在「精确匹配」的卡片上用：搜索结果里一半条目只是标签/简介沾边，
/// 标题里根本没这个词，混在一起看不出哪几部是真对上了。
List<TextSpan> _markedSpans(
  String text,
  String keyword,
  TextStyle base,
  Color mark,
) {
  final needles = keyword
      .toLowerCase()
      .split(RegExp(r'\s+'))
      .where((word) => word.isNotEmpty)
      .toList();
  if (needles.isEmpty) return [TextSpan(text: text, style: base)];
  final haystack = text.toLowerCase();
  final spans = <TextSpan>[];
  var cursor = 0;
  while (cursor < text.length) {
    var best = -1;
    var length = 0;
    for (final needle in needles) {
      final hit = haystack.indexOf(needle, cursor);
      if (hit < 0) continue;
      if (best < 0 || hit < best || (hit == best && needle.length > length)) {
        best = hit;
        length = needle.length;
      }
    }
    if (best < 0) break;
    if (best > cursor) {
      spans.add(TextSpan(text: text.substring(cursor, best), style: base));
    }
    spans.add(
      TextSpan(
        text: text.substring(best, best + length),
        style: base.copyWith(color: mark, fontWeight: FontWeight.w800),
      ),
    );
    cursor = best + length;
  }
  if (spans.isEmpty) return [TextSpan(text: text, style: base)];
  if (cursor < text.length) {
    spans.add(TextSpan(text: text.substring(cursor), style: base));
  }
  return spans;
}

Widget _line(
  BuildContext context,
  String text,
  TextStyle style,
  int lines, {
  String? highlight,
}) => Padding(
  padding: const EdgeInsets.symmetric(horizontal: 2),
  child: SizedBox(
    height:
        MediaQuery.textScalerOf(context).scale(style.fontSize!) *
        style.height! *
        lines,
    child: highlight == null || highlight.trim().isEmpty
        ? Text(
            text,
            maxLines: lines,
            overflow: TextOverflow.ellipsis,
            style: style,
          )
        : Text.rich(
            TextSpan(
              children: _markedSpans(
                text,
                highlight,
                style,
                Theme.of(context).colorScheme.primary,
              ),
            ),
            maxLines: lines,
            overflow: TextOverflow.ellipsis,
            style: style,
          ),
  ),
);

class DramaTile extends StatelessWidget {
  const DramaTile({
    super.key,
    required this.drama,
    required this.onTap,
    this.subtitle,
    this.rank,
    this.ordinal,
    this.onMore,
    this.actions,
    this.focusNode,
    this.autofocus = false,
    this.heroScope,
    this.showScore = false,
    this.exploreBlur = false,
    this.highlight,
  });
  final Drama drama;
  final VoidCallback onTap;
  final String? heroScope;
  final bool showScore;
  final bool exploreBlur;
  final String? subtitle;
  final int? rank;

  /// 「全部」分类里的到达序号（1 起）。给了就在封面左上角写数字，
  /// 一路翻到底能直接对账「总共多少部」。
  final int? ordinal;
  final VoidCallback? onMore;

  /// 长按封面时在卡片内浮出的操作（发现页 / 搜索页）。
  final List<DramaAction>? actions;
  final FocusNode? focusNode;
  final bool autofocus;

  /// 搜索关键词。给了就只对「精确匹配」（标题命中，rank ≥ 3）的卡片生效：
  /// 标题里的关键词换成主题色加粗，封面左上角挂一枚「精准」角标。
  final String? highlight;

  static TextStyle titleStyle(BuildContext context) => TextStyle(
    fontSize: AppScope.of(context).television ? 15 : 14,
    fontWeight: FontWeight.w600,
    height: 1.3,
  );

  static TextStyle subtitleStyle(BuildContext context) => TextStyle(
    fontSize: AppScope.of(context).television ? 13 : 12,
    height: 1.3,
    color: Theme.of(context).colorScheme.onSurfaceVariant,
  );

  static double extentFor(BuildContext context, double width) {
    final scaler = MediaQuery.textScalerOf(context);
    final title = scaler.scale(titleStyle(context).fontSize!) * 1.3 * 2;
    final subtitle = scaler.scale(subtitleStyle(context).fontSize!) * 1.3;
    return (width * 1.5 + 9 + title + 4 + subtitle).ceilToDouble();
  }

  @override
  Widget build(BuildContext context) {
    final keyword = highlight;
    final exact =
        keyword != null && keyword.trim().isNotEmpty && drama.titleMatched;
    final cover = DramaCover(
      drama: drama,
      radius: _coverRadius,
      rank: rank,
      ordinal: ordinal,
      // 「精准」角标压在左上角，VIP 要让位到右上角。
      topLeftBadge: exact,
      showScore: showScore,
      exploreBlur: exploreBlur,
      heroScope: AppScope.of(context).television || !Visibility.of(context)
          ? null
          : heroScope,
    );
    return _PosterButton(
      cover: exact
          ? Stack(
              fit: StackFit.expand,
              children: [
                cover,
                const Positioned(top: 6, left: 6, child: _ExactBadge()),
              ],
            )
          : cover,
      label:
          '${ordinal == null ? '' : '第$ordinal部，'}'
          '${rank == null ? '' : '第$rank名，'}'
          '${exact ? '精确匹配，' : ''}'
          '${drama.title}，${drama.episodes}集${drama.vip ? '，VIP' : ''}'
          '${showScore && drama.score.isNotEmpty ? '，评分${drama.score}' : ''}',
      onTap: onTap,
      onMore: onMore,
      actions: actions,
      focusNode: focusNode,
      autofocus: autofocus,
      caption: [
        const SizedBox(height: 9),
        _line(
          context,
          drama.title,
          titleStyle(context),
          2,
          highlight: exact ? keyword : null,
        ),
        const SizedBox(height: 4),
        _line(context, subtitle ?? drama.category, subtitleStyle(context), 1),
      ],
    );
  }
}

/// 封面左上角的「精准」角标：搜索结果里标题真命中的那几部才挂。
class _ExactBadge extends StatelessWidget {
  const _ExactBadge();

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return IgnorePointer(
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: colors.primary,
          borderRadius: BorderRadius.circular(7),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.22),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
          child: Text(
            '精准',
            style: TextStyle(
              fontSize: 10,
              height: 1.1,
              fontWeight: FontWeight.w700,
              color: colors.onPrimary,
            ),
          ),
        ),
      ),
    );
  }
}

class ProgressPoster extends StatelessWidget {
  const ProgressPoster({
    super.key,
    required this.drama,
    required this.progress,
    required this.caption,
    required this.onTap,
    this.tag,
    this.onMore,
    this.focusNode,
    this.width = 100,
    this.selected,
    this.badge,
    this.heroScope,
  });
  final Drama drama;
  final String? heroScope;
  final double? progress;
  final String caption;
  final String? tag;
  final String? badge;
  final VoidCallback onTap;
  final VoidCallback? onMore;
  final FocusNode? focusNode;
  final double width;
  final bool? selected;

  static double extentFor(BuildContext context, double width) {
    final scaler = MediaQuery.textScalerOf(context);
    final television = AppScope.of(context).television;
    final title = scaler.scale(television ? 15 : 14) * 1.3;
    final caption = scaler.scale(television ? 13 : 12) * 1.3;
    return (width * 1.5 + 8 + title + 2 + caption).ceilToDouble();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final television = AppScope.of(context).television;
    return SizedBox(
      width: width,
      child: _PosterButton(
        cover: Stack(
          fit: StackFit.expand,
          children: [
            DramaCover(
              drama: drama,
              radius: _coverRadius,
              details: false,
              heroScope:
                  television || selected != null || !Visibility.of(context)
                  ? null
                  : heroScope,
            ),
            if (tag case final tag?)
              Positioned(
                left: 8,
                top: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 7,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.55),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    tag,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      height: 1.3,
                    ),
                  ),
                ),
              ),
            // 会员剧在列表卡片上也要有角标：以前只在详情页（details=true）
            // 才画，于是首页满屏会员剧一张标签都看不到。
            // 右上角优先给 badge（集数/状态），它占着就把 VIP 摆到下面一行。
            if (drama.vip)
              Positioned(
                right: 8,
                top: badge != null && selected == null ? 34 : 8,
                child: const IgnorePointer(child: VipBadge()),
              ),
            if (badge case final badge? when selected == null)
              Positioned(
                right: 8,
                top: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: colors.primary,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    badge,
                    style: TextStyle(
                      color: colors.onPrimary,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      height: 1.3,
                    ),
                  ),
                ),
              ),
            if (television)
              const IgnorePointer(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(_coverRadius),
                    ),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: [.55, 1],
                      colors: [Colors.transparent, Color(0xB3000000)],
                    ),
                  ),
                ),
              ),
            if (progress case final progress?)
              Positioned(
                left: television ? 8 : _coverRadius,
                right: television ? 8 : _coverRadius,
                bottom: television ? 8 : 0,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(television ? 2 : 1.5),
                  child: LinearProgressIndicator(
                    value: progress.clamp(0.0, 1.0),
                    minHeight: television ? 4 : 3,
                    color: colors.primaryFixedDim,
                    backgroundColor: Colors.white.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.zero,
                    stopIndicatorColor: Colors.transparent,
                  ),
                ),
              ),
            if (selected case final selected?) ...[
              IgnorePointer(
                child: AnimatedOpacity(
                  opacity: selected ? 1 : 0,
                  duration: Motion.of(context, Motion.short),
                  curve: Motion.standard,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(_coverRadius),
                      border: Border.all(color: colors.primary, width: 3),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 8,
                top: 8,
                child: AnimatedContainer(
                  duration: Motion.of(context, Motion.short),
                  curve: Motion.standard,
                  width: 26,
                  height: 26,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: selected
                        ? colors.primary
                        : Colors.black.withValues(alpha: 0.35),
                    border: selected
                        ? null
                        : Border.all(color: Colors.white, width: 2),
                  ),
                  child: ToggleIconSwitcher(
                    child: selected
                        ? Icon(
                            Icons.check_rounded,
                            key: const ValueKey(true),
                            size: 18,
                            color: colors.onPrimary,
                          )
                        : const SizedBox.shrink(key: ValueKey(false)),
                  ),
                ),
              ),
            ],
          ],
        ),
        label:
            '${drama.title}，${tag == null ? '' : '$tag，'}${badge == null ? '' : '$badge，'}$caption',
        checked: selected,
        onTap: onTap,
        onMore: onMore,
        focusNode: focusNode,
        caption: [
          const SizedBox(height: 8),
          _line(
            context,
            drama.title,
            TextStyle(
              fontSize: television ? 15 : 14,
              fontWeight: FontWeight.w600,
              height: 1.3,
            ),
            1,
          ),
          const SizedBox(height: 2),
          _line(
            context,
            caption,
            TextStyle(
              fontSize: television ? 13 : 12,
              height: 1.3,
              color: colors.onSurfaceVariant,
            ),
            1,
          ),
        ],
      ),
    );
  }
}
