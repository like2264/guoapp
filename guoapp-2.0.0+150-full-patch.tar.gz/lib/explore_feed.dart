import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import 'core_bridge.dart';
import 'drama_feed.dart';
import 'local_store.dart';
import 'models.dart';
import 'ranking_models.dart';
import 'source_catalog.dart';
import 'source_stats.dart';

const recommendTab = CatalogCategory('app:recommend', '推荐');

CatalogCategory rankingTab(RankingBoard board) =>
    CatalogCategory('app:rank:${board.id}', board.name);

class ExploreFeed extends ChangeNotifier {
  ExploreFeed(this.repository, this.store) {
    store.addListener(_storeChanged);
    repository.catalogUpdates.addListener(_metadataChanged);
    _pulse = Timer.periodic(_pulseInterval, (_) => unawaited(_pulseFacts()));
    _open();
  }
  final AppRepository repository;
  final LocalStore store;
  SourceCatalog? _catalog;
  CatalogCategory _tab = CatalogCategory.all;
  DramaFeed? _feed;
  Map<String, int> _ranks = const {};
  final _feeds = <String, DramaFeed>{};
  final _rankings = <String, Map<String, int>>{};

  /// 切走的站源在这里留一份列表缓存（最多 [_stashLimit] 个）。
  /// 原来换站源会把所有 feed 直接 dispose，来回切就得重新联网拉一遍，
  /// 表现就是"点完站源要等一小会儿"。留缓存后切回去是瞬间出内容。
  final _stash = <String, Map<String, DramaFeed>>{};
  final _stashRanks = <String, Map<String, Map<String, int>>>{};
  static const _stashLimit = 2;

  /// 从 [_stash] 接回来的 tab（`tab.id`）。
  ///
  /// 这些列表是切走前的内容，站点可能已经上新 —— 接回后第一次进入必须强制
  /// 重拉一遍，否则会出现「顶栏是新数字、列表还是旧作品」，三数对不上。
  final _resumed = <String>{};
  bool _disposed = false;

  /// 当前站源顶栏那行观测值。
  SourceFacts _facts = const SourceFacts();

  /// 每个站源「全部」分类里见过的作品 id。顶栏那句「已收录 N 部」就是它的长度：
  /// 只由「全部」目录喂，搜索、排行榜、单独切开的分类都不进来，
  /// 所以翻到哪就是哪，不会被别的入口撑大。
  final _seen = <String, Set<String>>{};

  /// 「全部」名单有新增、还没落盘的站源。翻页时只更新界面，等下一次
  /// 第一页 / 强制刷新才写存储，免得每翻一页都写一次。
  final _seenDirty = <String>{};

  /// 站源 id → 见过的作品 id。判「新上」用，落盘保存，跨进程有效。
  /// 早先靠「本地目录缓存里有没有这一条」来判断，但原生目录缓存会为新数据
  /// 回填旧值，站点给不出集数时那条记录的集数是 0，于是永远判不出「新上」。
  final _known = <String, Set<String>>{};

  /// 站源 id → 上次看到的「剧 id → 集数」。判「今日更新」用。
  /// 这份快照是我们自己记的，不依赖目录缓存怎么合并。
  final _episodes = <String, Map<String, int>>{};

  /// 站源 id → 今天变化过的作品 id（新的在前）。首页把这几部提到最前面。
  final _fresh = <String, List<String>>{};

  /// 当前统计属于哪一天。跨天就把「变化过的作品」清空，跟 updated/arrived 一起归零。
  String _factsDay = '';

  /// 站源 id → **本次会话**里翻到底实际列出的条数。
  ///
  /// 2.0.0+143~147 把它落盘了，结果「站点加了作品、App 顶栏纹丝不动」：
  /// 一次翻到底量到的旧条数会永远压过站点声明，站点涨了 8 部、9 部、20 部
  /// 都看不见（野果 / 黑桃 / 黄桃 全中）。现在只在内存里留着，切站源、刷新
  /// 都作废重算 —— 它代表「列表真正摆出来过多少部作品」，顶栏、底部、末位
  /// 卡片三个数都靠它统一。
  final _listed = <String, int>{};

  /// 最近一次**真的从站源拿到作品总量**的时间。
  ///
  /// 早先这里记的是「最近一次观测」（不管有没有拿到总量）：首屏那一页如果直接
  /// 命中本地目录缓存（缓存里 Total 还是 0），也会把它刷新成「刚刚观测过」，
  /// 切站源后的强制刷新就被跳过了 —— 表现就是顶栏一直显示「已收录 N 部」
  /// 而不是站点的「共 X 部」，而且随着往下翻越来越大。
  DateTime? _lastSiteTotalAt;

  /// 顶栏「今日更新 N 集」的定时探头：站点在我们停着不动的时候也会更新，
  /// 只在切源/翻页时统计的话，用户盯着同一页永远看不到数字涨。
  Timer? _pulse;
  static const _pulseInterval = Duration(seconds: 90);
  bool _pulsing = false;

  SourceSite? get source => _catalog?.source;
  SourceFacts get facts => _facts;

  /// 列表底部的「共 N 部」= 这一次一共加载过的作品数（跨页去重后）。
  ///
  /// 和顶栏、最后一张卡片的序号是**同一个数**（2.0.0+150 定死）：翻到底时
  /// 三处必然相等。以前这里报站点声明（夜社海外短剧 2,166），而列表实际只有
  /// 2,156 张卡、末位卡片是第 2,156 部 —— 三个数摆在同一屏上互相打脸。
  int get footerCount => _feed?.items.length ?? 0;

  DramaFeed? get feed => _feed;
  CatalogCategory get tab => _tab;
  bool get recommending => _tab.id == recommendTab.id;

  List<CatalogCategory> get tabs {
    final catalog = _catalog;
    if (catalog == null) return const [];
    final [all, ...genres] = catalog.categories;
    return [
      if (catalog.recommends) recommendTab,
      all,
      for (final board in catalog.boards) rankingTab(board),
      ...genres,
    ];
  }

  int? rankOf(Drama drama) => _ranks[drama.id];

  WatchEntry? get resume {
    final source = this.source;
    if (source == null || _tab.id != tabs.first.id) return null;
    return store.history
        .where((entry) => entry.drama.source == source.id)
        .firstOrNull;
  }

  Drama? get featured =>
      recommending && resume == null ? _feed?.items.firstOrNull : null;

  /// 「全部」网格里的条目。
  ///
  /// 2.0.0+147 起不再把头条作品 skip 掉：头条大卡片只是同一部作品的另一个入口，
  /// 把它从列表里摘出去会让网格少一部、序号整体错位（以前干脆整页不编号了）。
  /// 现在头条不占序号、列表从 1 号连续往下排，翻到底最后一张卡的序号就是「共 N 部」。
  List<Drama> get items => _feed?.items ?? const <Drama>[];

  void select(String id) {
    if (id == _tab.id) return;
    final tab = tabs.where((tab) => tab.id == id).firstOrNull;
    if (tab != null) _select(tab);
  }

  Future<void> refresh() async {
    final catalog = _catalog;
    if (catalog == null) return;
    // 站点可能上新了：本次会话实测出来的条数先作废，顶栏回到站点声明，
    // 这一轮重新翻到底之后再写回新的实测值（否则顶栏会一直挂着旧数）。
    _dropListed(catalog.source.id);
    if (catalog.categories.length == 1) {
      unawaited(_loadCategories(catalog, force: true));
    }
    await _feed?.reload(force: true);
  }

  /// 作废本次会话的实测条数，顶栏回到站点声明。
  ///
  /// 切站源、下拉刷新、站点自己报的总量变了，都要走这里 —— 否则一次翻到底
  /// 量到的旧条数会一直压着顶栏，站点上新了也看不见。
  void _dropListed(String source) {
    final dropped = _listed.remove(source);
    if (dropped == null || _facts.listed <= 0) return;
    _facts = SourceFacts(
      site: _facts.site,
      local: _facts.local,
      updated: _facts.updated,
      arrived: _facts.arrived,
      probed: _facts.probed,
    );
    _notify();
  }

  void _open() {
    final id = store.source;
    if (id == _catalog?.source.id) return;
    unawaited(repository.cancelCatalog());
    unawaited(repository.cancelRecommendations());
    _parkFeeds();
    // 探头的「刚拿到过总量」标记按站源算，换源必须清掉：不清的话切到新站源
    // 时 [_refreshFacts] 会以为已经拿过总量，直接跳过强制刷新，顶栏就一直挂着
    // 这个站上一次（甚至上一版 App）存下来的旧数字。
    _lastSiteTotalAt = null;
    if (id.isEmpty) {
      _catalog = null;
      _feed = null;
      _tab = CatalogCategory.all;
      _facts = const SourceFacts();
      return;
    }
    final catalog = _catalog = SourceCatalog(repository, SourceSite.byId(id));
    // 换站源时实测条数一律作废：站点在上一次停留期间可能已经上新，顶栏必须
    // 先回到站点声明，这一轮重新翻到底再写回新的实测值。不清的话切走再切回来，
    // 顶栏还是上一次的数（用户要求「切换站源后数字要随之更新」）。
    _listed.remove(id);
    final stored = readFacts(store.sourceStats, id);
    _facts = SourceFacts(
      site: stored.site,
      local: stored.local,
      updated: stored.updated,
      arrived: stored.arrived,
      probed: stored.probed,
    );
    // 切回来时接着上次的「全部」名单、集数快照和今日变化名单继续累计，不清零。
    _known[id] = readKnown(store.sourceStats, id).toSet();
    _episodes[id] = readEpisodes(store.sourceStats, id);
    _fresh[id] = readFresh(store.sourceStats, id).toList();
    _factsDay = factsDay(DateTime.now());
    final kept = readKnown(store.sourceStats, id);
    if (kept.isNotEmpty) {
      _seen[id] ??= kept.toSet();
    } else if (_facts.site <= 0 && _facts.local > 0) {
      // 旧版本存的是「本地目录缓存条数」，跟新的「全部分类已见数」不是一个口径，
      // 不能接着用。等这一轮把「全部」目录拉回来重新累计，别先显示一个假数字。
      _facts = SourceFacts(updated: _facts.updated, arrived: _facts.arrived);
    }
    final startedAt = DateTime.now();
    // 这个站源之前切走过，直接把列表接回来，不再重新请求。
    if (_stash.remove(id) case final kept?) {
      _feeds.addAll(kept);
      _resumed.addAll(kept.keys);
      _rankings.addAll(_stashRanks.remove(id) ?? const {});
      for (final feed in kept.values) {
        feed.addListener(_notify);
      }
    }
    _select(catalog.recommends ? recommendTab : CatalogCategory.all);
    unawaited(_loadCategories(catalog));
    // 先用本地剧库里存着的上次总量把顶栏填上（毫秒级），再去站源刷新。
    unawaited(_primeFacts(catalog));
    // 切一次源刷一次站源总量，不能只靠「用户往下翻页」时才收集。
    unawaited(_refreshFacts(catalog, startedAt));
  }

  /// 换站源前把当前站源的 feed 存进 [_stash]（而不是直接销毁）。
  void _parkFeeds() {
    final source = _catalog?.source.id;
    if (source == null || _feeds.isEmpty) {
      _dropFeeds();
      return;
    }
    for (final feed in _feeds.values) {
      feed.removeListener(_notify);
    }
    _stash[source] = Map.of(_feeds);
    _stashRanks[source] = Map.of(_rankings);
    _feeds.clear();
    _rankings.clear();
    _feed = null;
    _ranks = const {};
    while (_stash.length > _stashLimit) {
      final oldest = _stash.keys.first;
      _stashRanks.remove(oldest);
      for (final feed in _stash.remove(oldest)?.values ?? const <DramaFeed>[]) {
        feed.dispose();
      }
    }
  }

  Future<void> _loadCategories(
    SourceCatalog catalog, {
    bool force = false,
  }) async {
    try {
      await catalog.loadCategories(force: force);
    } catch (_) {}
    if (_disposed || catalog != _catalog) return;
    _notify();
  }

  void _select(CatalogCategory tab) {
    final catalog = _catalog!;
    if (recommending) unawaited(repository.cancelRecommendations());
    _tab = tab;
    if (_feeds[tab.id] case final kept?) {
      _feed = kept;
      _ranks = _rankings[tab.id] ?? const {};
      if (kept.items.isEmpty && !kept.loading) {
        unawaited(kept.reload());
      } else if (_resumed.remove(tab.id)) {
        // 这个列表是切走前留下的：强制重拉，让作品也跟着站点更新。
        unawaited(kept.reload(force: true));
      }
      _notify();
      return;
    }
    final board = catalog.boards
        .where((board) => rankingTab(board).id == tab.id)
        .firstOrNull;
    final ranks = _ranks = _rankings[tab.id] = <String, int>{};
    // 「全部」这个分类拿回来的是全站列表，才需要「更新优先」排序。
    final whole = tab.id.isEmpty;
    final feed = _feed = _feeds[tab.id] = tab.id == recommendTab.id
        ? DramaFeed(
            cumulative: true,
            load: (page, force) => _track(
              catalog,
              page,
              () => catalog.recommendations(more: page > 1, force: force),
            ),
          )
        : board != null
        ? DramaFeed(
            load: (page, force) => _track(
              catalog,
              page,
              () => _ranking(catalog, board, ranks, page, force),
            ),
          )
        : DramaFeed(
            cached: () => catalog.cached(tab),
            load: (page, force) => _track(
              catalog,
              page,
              () => catalog.fetch(tab, page: page, force: force),
              whole: whole,
            ),
          );
    feed.addListener(_notify);
    // 「全部」列表滚到底时把真实条数记下来：站点声明的总量普遍有水分
    // （分页型按「页数 × 每页」报，末页不满就算多了），顶栏那个数只有
    // 拿实测值兜住，才和列表底部报的一致。
    if (whole) _watchListed(catalog.source.id, feed);
    unawaited(feed.reload());
    _notify();
  }

  /// 盯住「全部」列表什么时候滚到底，记下那时一共列出多少部。
  void _watchListed(String source, DramaFeed feed) {
    void check() {
      if (feed.loading || feed.loadingMore || feed.hasMore) return;
      if (feed.error.isNotEmpty || feed.items.isEmpty) return;
      // 这个回调可能发生在 feed 自己 notifyListeners 的过程中，
      // 直接再 notify 一次会和「正在通知」的列表打架，挪到下一个微任务。
      unawaited(
        Future<void>.microtask(() => _noteListed(source, feed.items.length)),
      );
    }

    feed.addListener(check);
  }

  void _noteListed(String source, int listed) {
    if (_disposed || listed <= 0 || _facts.listed == listed) return;
    if (_catalog?.source.id != source) return;
    _listed[source] = listed;
    _facts = SourceFacts(
      site: _facts.site,
      local: _facts.local,
      updated: _facts.updated,
      arrived: _facts.arrived,
      listed: listed,
      probed: true,
    );
    _notify();
  }

  Future<CatalogPage> _ranking(
    SourceCatalog catalog,
    RankingBoard board,
    Map<String, int> ranks,
    int page,
    bool force,
  ) async {
    final result = await catalog.ranking(board, page: page, force: force);
    for (final item in result.items) {
      ranks[item.drama.id] = item.rank;
    }
    return CatalogPage(
      [for (final item in result.items) item.drama],
      hasMore: result.hasMore,
      warning: result.warning,
      page: result.page,
    );
  }

  /// 用本地剧库缓存里的总量先把顶栏填上，避免切换站源后空白一小会儿。
  /// 只读、不写盘：真正的数字由 [_refreshFacts] 从站源拿回来再落库。
  Future<void> _primeFacts(SourceCatalog catalog) async {
    final source = catalog.source.id;
    if (_facts.probed && _facts.site > 0) return;
    try {
      final page = await catalog.cached(CatalogCategory.all);
      if (_disposed || _catalog?.source.id != source) return;
      if (page.total <= 0 || page.total == _facts.site) return;
      // 缓存里的总量和内存里的不一样，说明缓存是上一版留下的：本次会话量到的
      // 实测条数同样作废，先按新的总量显示。
      _listed.remove(source);
      _facts = SourceFacts(
        site: page.total,
        local: _facts.local,
        updated: _facts.updated,
        arrived: _facts.arrived,
        probed: true,
      );
      _notify();
    } catch (_) {}
  }

  /// 切站源时刷新顶栏那行观测值。
  ///
  /// 首屏列表自己就会拉一页目录（[_track] 会把站源总量记下来），所以这里先
  /// 等 900ms：那一页已经带回总量就不重复请求站源；首屏完全走的本地缓存时
  /// 才补一次强制请求，保证「切过来看到的就是站点现在的数字」。
  Future<void> _refreshFacts(SourceCatalog catalog, DateTime startedAt) async {
    final source = catalog.source.id;
    await Future<void>.delayed(const Duration(milliseconds: 900));
    if (_disposed || _catalog?.source.id != source) return;
    final last = _lastSiteTotalAt;
    if (last != null && last.isAfter(startedAt)) return;
    try {
      final page = await catalog.fetch(
        CatalogCategory.all,
        page: 1,
        force: true,
        probe: true,
      );
      if (_disposed || _catalog?.source.id != source) return;
      _noteAll(source, page.items);
      await _observe(
        source,
        page.items,
        siteTotal: page.total,
        countArrivals: true,
      );
    } catch (_) {}
  }

  /// 定时重探「全部」第一页，把新长出来的集数并进「今日更新」。
  ///
  /// 只在应用前台跑：退到后台还每分钟拉一次目录纯属浪费流量和电。
  Future<void> _pulseFacts() async {
    if (_disposed || _pulsing) return;
    final catalog = _catalog;
    if (catalog == null) return;
    final lifecycle = WidgetsBinding.instance.lifecycleState;
    if (lifecycle != null && lifecycle != AppLifecycleState.resumed) return;
    final source = catalog.source.id;
    _pulsing = true;
    try {
      final page = await catalog.fetch(
        CatalogCategory.all,
        page: 1,
        force: true,
        probe: true,
      );
      if (_disposed || _catalog?.source.id != source) return;
      unawaited(store.refreshDramas(page.items).catchError((Object _) {}));
      _noteAll(source, page.items);
      await _observe(
        source,
        page.items,
        siteTotal: page.total,
        countArrivals: true,
      );
    } catch (_) {
      // 探头失败不打扰用户：下一轮再说。
    } finally {
      _pulsing = false;
    }
  }

  /// 取一页目录，顺便把结果记进本地（收藏/历史的剧信息刷新），
  /// 第一页还要更新顶栏那行观测值。
  ///
  /// 统计用的是我们自己记的集数快照（[_episodes]），不再读本地剧库 ——
  /// 原生目录缓存会把旧集数回填到新数据上（站点不给集数时是 0），
  /// 拿它当「旧值」就永远算不出增量。
  Future<CatalogPage> _track(
    SourceCatalog catalog,
    int page,
    Future<CatalogPage> Function() run, {
    bool whole = false,
  }) async {
    final source = catalog.source.id;
    final result = await run();
    unawaited(store.refreshDramas(result.items).catchError((Object _) {}));
    if (whole) _noteAll(source, result.items);
    if (page <= 1) {
      // 只有「全部」分类拿回来的是「全站总量」。分类页、榜单页的 total 是那个
      // 分类下的条数，拿来当总量会让顶栏数字随分类变来变去（+128 修的就是这个）。
      unawaited(
        _observe(
          source,
          result.items,
          siteTotal: whole ? result.total : 0,
          countArrivals: whole,
          // 命中本地目录缓存时 total 是上次存下来的，不能算「刚拿到」。
          freshPage: result.fresh,
        ),
      );
    }
    if (whole && page <= 1) {
      // 首屏的 total 已经由上面的 _observe 记下，这里什么都不用补。
    }
    // 列表顺序就是站源自己的顺序：2.0.0+144 把「新作品靠前」整个撤掉了 ——
    // 置顶会让第 1 页的序号与站点目录位置对不上，用户翻到底一对账就发现
    // 「第 3 张卡在站点上排第 90」，比看到新作品重要。
    return result;
  }

  /// 「全部」分类里又见到了这些剧，记下来（按 id 去重），顶栏的「已收录 N 部」
  /// 就是这个集合的长度。搜索、榜单、单独切开的分类都不进这个集合 ——
  /// 那样会把「站点到底有多少部」变成「我这一路看过多少条」。
  void _noteAll(String source, Iterable<Drama> items) {
    if (_disposed) return;
    final seen = _seen[source] ??= <String>{};
    if (seen.length >= factsSeenLimit) return;
    var added = false;
    for (final drama in items) {
      if (seen.length >= factsSeenLimit) break;
      if (drama.id.isEmpty) continue;
      if (seen.add(drama.id)) added = true;
    }
    if (!added || _catalog?.source.id != source) return;
    _seenDirty.add(source);
    _facts = SourceFacts(
      site: _facts.site,
      local: seen.length,
      updated: _facts.updated,
      arrived: _facts.arrived,
      listed: _listed[source] ?? 0,
      probed: true,
    );
    _notify();
  }

  /// 记录一次观测：站源总量 + 本地收录数 + 今天增加的集数。
  ///
  /// 集数用 [_episodes] 里我们自己记的快照比，新上用 [_known] 里的历史名单比 ——
  /// 两者都落盘，所以换进程、跨天、清缓存（只清目录缓存）都不影响判断。
  /// 第一次观测（还没有基线）只记基线不报数，不然一装上就是「新上 60 部」。
  Future<void> _observe(
    String source,
    List<Drama> fresh, {
    int siteTotal = 0,
    bool countArrivals = false,
    bool freshPage = true,
  }) async {
    if (_disposed) return;
    final today = factsDay(DateTime.now());
    if (_factsDay != today) {
      // 跨天：今日变化名单清空，updated/arrived 由 readFacts 自己归零。
      _factsDay = today;
      _fresh[source] = <String>[];
    }
    final known = _known[source] ??= <String>{};
    final episodes = _episodes[source] ??= <String, int>{};
    final changed = _fresh[source] ??= <String>[];
    var gained = 0;
    // 名单/今日变化名单本身有没有长出新条目。计数器没变但名单变了也要落盘，
    // 否则下次切回这个站源时读到的是旧名单，「新上」又被重新数一遍。
    var structure = false;
    final knownBefore = known.length;
    final changedBefore = changed.length;
    // 同一页里同一部可能出现两次（黄桃、柚子这类站源是多个栏目拼起来的），
    // 先按 id 取最大集数，再算增量，免得同一集更新被数两遍。
    final batch = <String, int>{};
    for (final drama in fresh) {
      if (drama.id.isEmpty) continue;
      final episodesNow = drama.episodes;
      final previous = batch[drama.id];
      batch[drama.id] = previous == null || episodesNow > previous
          ? episodesNow
          : previous;
    }
    for (final entry in batch.entries) {
      final id = entry.key;
      final now = entry.value;
      final old = episodes[id];
      if (old != null && old > 0 && now > old) {
        gained += now - old;
        _markChanged(changed, id);
      }
      // 「新上 N 部」这一行在 2.0.0+137 里删掉了：站点的「全部」第一页按更新
      // 时间排，每次刷新都有新作品挤上来，而落盘的 known 名单只留得住 1500 条，
      // 被裁掉的 id 再出现就会被重新数一遍 —— 于是数字每刷一次涨一次，能涨到 >「共 N 部」。
      //
      // 2.0.0+143 曾把「第一次见到的作品提到最前」搬回来，2.0.0+144 又撤了：
      // 置顶会让第 1 页的卡片序号和站点目录位置对不上，用户拿序号对账时
      // 「第 3 张卡在站点上排第 90」比「新作品在最前面」更让人困惑。
      if (!known.contains(id)) {
        structure = true;
      }
      known.add(id);
      if (now > 0 && (old == null || now > old)) episodes[id] = now;
    }
    // 内存里也别无限长：翻得越深这两份表越大，留够判断用的量就行。
    if (known.length > factsSeenLimit * 2) {
      final drop = known.length - factsSeenLimit;
      for (final id in known.take(drop).toList(growable: false)) {
        known.remove(id);
      }
    }
    if (episodes.length > factsEpisodeLimit * 2) {
      final drop = episodes.length - factsEpisodeLimit;
      for (final id in episodes.keys.take(drop).toList(growable: false)) {
        episodes.remove(id);
      }
    }
    // 站源给的量优先；站点给不出总量时用「全部」分类里见过的数兜底，
    // 不再用本地目录缓存的条数 —— 那个数被搜索和分类一起撑大，不是站点的量。
    final site = siteTotal > 0 ? siteTotal : _facts.site;
    // 只有真的从站源拿到过（不是本地缓存的旧 Total）才记「刚刚拿过总量」，
    // 否则切站源后的强制刷新会被这一笔挡掉，顶栏就一直停在旧数字上。
    if (siteTotal > 0 && freshPage) _lastSiteTotalAt = DateTime.now();
    // 站点自己报的总量变了，说明目录增删过：这次会话里翻到底量到的条数已经过期。
    if (siteTotal > 0 && _facts.site > 0 && siteTotal != _facts.site) {
      _listed.remove(source);
    }
    final local = _seen[source]?.length ?? _facts.local;
    if (_disposed || _catalog?.source.id != source) return;
    final saved = writeFacts(
      store.sourceStats,
      source,
      site: site,
      local: local,
      gained: gained,
      arrived: 0,
      known: known,
      episodes: episodes,
      fresh: changed,
      seeded: true,
    );
    final next = readFacts(saved, source);
    final dirty = _seenDirty.remove(source);
    structure =
        structure ||
        known.length != knownBefore ||
        changed.length != changedBefore;
    if (gained == 0 &&
        !dirty &&
        !structure &&
        next.site == _facts.site &&
        next.local == _facts.local &&
        next.updated == _facts.updated &&
        next.arrived == _facts.arrived) {
      // 没有变化就别写盘，也别让界面白重建一次。
      return;
    }
    // next 来自落盘的观测表，里面没有「翻到底实测条数」这一项（2.0.0+148 起
    // 不再落盘）。这里必须把内存里那份接回去，否则每观测一次就把顶栏的实测值
    // 洗成 0，顶栏又掉回站点声明 —— 三数立刻不等。
    _facts = SourceFacts(
      site: next.site,
      local: next.local,
      updated: next.updated,
      arrived: next.arrived,
      listed: _listed[source] ?? 0,
      probed: next.probed,
    );
    _notify();
    unawaited(store.setSourceStats(saved).catchError((Object _) {}));
  }

  void _markChanged(List<String> changed, String id) {
    if (changed.contains(id)) return;
    changed.insert(0, id);
    if (changed.length > factsFreshLimit) changed.removeLast();
  }

  void _storeChanged() {
    _open();
    _notify();
  }

  void _metadataChanged() {
    final drama = repository.catalogUpdates.latest;
    if (drama == null || drama.source != source?.id) return;
    _catalog?.remember([drama]);
    for (final feed in _feeds.values) {
      feed.update(drama);
    }
    unawaited(store.refreshDrama(drama).catchError((Object _) {}));
  }

  void _dropFeeds() {
    for (final feed in _feeds.values) {
      feed.dispose();
    }
    _feeds.clear();
    _rankings.clear();
    _resumed.clear();
    _feed = null;
    _ranks = const {};
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _pulse?.cancel();
    store.removeListener(_storeChanged);
    repository.catalogUpdates.removeListener(_metadataChanged);
    _dropFeeds();
    for (final feeds in _stash.values) {
      for (final feed in feeds.values) {
        feed.dispose();
      }
    }
    _stash.clear();
    _stashRanks.clear();
    unawaited(repository.cancelCatalog());
    unawaited(repository.cancelRecommendations());
    super.dispose();
  }
}
