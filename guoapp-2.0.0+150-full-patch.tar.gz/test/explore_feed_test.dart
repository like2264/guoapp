import 'package:duanju_app/explore_feed.dart';
import 'package:duanju_app/local_store.dart';
import 'package:duanju_app/ranking_models.dart';
import 'package:duanju_app/source_stats.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fakes.dart';
import 'support/source_fixture.dart';

Future<ExploreFeed> _open(
  FakeRepository repository, [
  Future<void> Function(LocalStore store)? prepare,
]) async {
  final store = await openStore();
  await prepare?.call(store);
  final explore = ExploreFeed(repository, store);
  addTearDown(explore.dispose);
  await pumpEventQueue();
  return explore;
}

List<String> _titles(ExploreFeed explore) => [
  for (final item in explore.items) item.title,
];

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('hongguo opens on picks with the first one featured', () async {
    final explore = await _open(FakeRepository());
    expect(explore.source?.id, 'hongguo');
    expect(
      [for (final tab in explore.tabs) tab.id],
      [recommendTab.id, '', 'short_play'],
    );
    expect(explore.recommending, isTrue);
    expect(explore.featured?.title, '推荐剧一');
    // 2.0.0+147 起头条作品不再从列表里摘出去：它就是列表第一项，
    // 大卡片只是同一部作品的另一个入口。这样网格序号能从 1 连续排到底。
    expect(_titles(explore), ['推荐剧一', '推荐剧二', '推荐剧三']);
    expect(explore.feed!.items.length, explore.items.length);
  });

  test('「全部」分类没有头条，序号与部数一一对应', () async {
    final explore = await _open(FakeRepository());
    explore.select('');
    await pumpEventQueue();
    expect(explore.recommending, isFalse);
    expect(explore.featured, isNull);
    // 序号第 i 张就是 i（numberFrom = 1），所以最后一张 = items.length，
    // 恰好等于顶栏与底部报的那个数。
    expect(explore.items.length, explore.feed!.items.length);
  });

  test('recent watching takes the lead on the first tab only', () async {
    final explore = await _open(
      FakeRepository(),
      (store) => store.saveWatch(watching(drama('w'), episode: 4)),
    );
    expect(explore.resume?.episode, 4);
    expect(explore.featured, isNull);
    expect(_titles(explore), ['推荐剧一', '推荐剧二', '推荐剧三']);

    explore.select('short_play');
    await pumpEventQueue();
    expect(explore.resume, isNull);
    expect(_titles(explore), ['分类short_play']);
  });

  test(
    'a visited tab comes back with its list, without asking again',
    () async {
      final repository = FakeRepository();
      final explore = await _open(repository);
      final picks = explore.feed;
      final requests = repository.recommendRequests.length;

      explore.select('short_play');
      await pumpEventQueue();
      expect(_titles(explore), ['分类short_play']);

      explore.select(recommendTab.id);
      expect(explore.feed, same(picks));
      expect(_titles(explore), ['推荐剧一', '推荐剧二', '推荐剧三']);
      await pumpEventQueue();
      expect(repository.recommendRequests.length, requests);
    },
  );

  test('refresh forces the current tab only', () async {
    final repository = FakeRepository();
    final explore = await _open(repository);
    await explore.refresh();
    expect(repository.recommendRequests.last, (more: false, force: true));

    explore.select('short_play');
    await pumpEventQueue();
    await explore.refresh();
    expect(repository.catalogRequests, [
      'hongguo|short_play||1',
      'hongguo|short_play||1!',
    ]);
  });

  test('ranking boards of this source follow all, with their ranks', () async {
    final repository = FakeRepository()
      ..boardList = const [
        RankingBoard(id: 'hongguo-hot', source: 'hongguo', name: '总热播榜'),
        RankingBoard(id: 'huangdou-all', source: 'huangdou', name: '总榜'),
      ];
    final explore = await _open(repository);
    final tabs = explore.tabs;
    expect([for (final tab in tabs) tab.name], ['推荐', '全部', '总热播榜', '真人剧']);
    expect(explore.resume, isNull);

    explore.select(tabs[2].id);
    await pumpEventQueue();
    expect(explore.featured, isNull);
    expect(_titles(explore), ['hongguo-hot第1名', 'hongguo-hot第2名']);
    await explore.feed!.loadMore();
    expect(
      [for (final item in explore.items) explore.rankOf(item)],
      [1, 2, 3, 4],
    );
    await explore.refresh();
    expect(repository.rankingRequests, [
      'hongguo-hot|1',
      'hongguo-hot|2',
      'hongguo-hot|1!',
    ]);

    explore.select('short_play');
    await pumpEventQueue();
    expect(explore.rankOf(explore.items.single), isNull);
  });

  test('turning the source off moves on, then back when it returns', () async {
    late LocalStore store;
    final explore = await _open(FakeRepository(), (value) async {
      store = value;
    });
    await store.setSourceEnabled('hongguo', false);
    await pumpEventQueue();
    expect(explore.source?.id, allSourcesEnabled ? 'hanxiaoquan' : null);
    expect(explore.feed == null, !allSourcesEnabled);

    await store.setSourceEnabled('hongguo', true);
    await pumpEventQueue();
    expect(explore.source?.id, 'hongguo');
    expect(explore.featured?.title, '推荐剧一');
  });

  test('loaded and updated dramas refresh saved records', () async {
    final repository = FakeRepository();
    late LocalStore store;
    final explore = await _open(repository, (value) async {
      store = value;
      await store.toggleFavorite(drama('r1', title: '旧名'));
    });
    expect(store.favorites.single.title, '推荐剧一');

    repository.catalogUpdates.publish(drama('r2', title: '新名'));
    await pumpEventQueue();
    expect(_titles(explore), ['推荐剧一', '新名', '推荐剧三']);
  });

  // 2.0.0+150 的三数规矩：顶栏 = 底部 = 末位卡片。站点声明只当「还没翻到底」
  // 时的预期值，一旦真的翻到底，一律报列表实际摆出来的独立作品数。
  test('翻到底后顶栏、底部、末位卡片是同一个数', () async {
    // 站点声明 3 部，但目录一页就到底、只给 1 部（catalogHasMore 默认 false）。
    final repository = FakeRepository()..catalogTotal = 3;
    final explore = await _open(repository);
    explore.select('');
    await pumpEventQueue();
    final loaded = explore.feed!.items.length;
    expect(loaded, 1);
    expect(explore.footerCount, loaded);
    expect(
      explore.facts.total,
      loaded,
      reason: '翻到底以后顶栏必须跟着列表走，不能再报站点声明的 3 部',
    );
  });

  // 站点部数变了以后顶栏必须跟着变。2.0.0+143~147 把「翻到底实测」的条数
  // 落盘了，结果它永远压过站点声明：站点涨了 8 部、9 部、20 部，App 顶栏一动
  // 不动（野果 / 黑桃 / 黄桃 都是这个症状）。现在实测值只在本次会话里生效，
  // 落盘的那份直接忽略；刷新时也会作废重算。
  test('落盘的实测条数不再生效，站点总量变了顶栏跟着变', () async {
    // hasMore 打开，否则一页到顶会被当成「翻到底」，把 listed 覆盖成一页的条数。
    final repository = FakeRepository()
      ..catalogTotal = 2000
      ..catalogHasMore = true;
    final explore = await _open(repository, (value) async {
      // 上一版 App 留下的旧记录：站点 2000、实测 1990。
      await value.setSourceStats({
        'hongguo': {
          'day': factsDay(DateTime.now()),
          'site': 2000,
          'local': 1900,
          'listed': 1990,
          'probed': true,
        },
      });
    });
    expect(explore.facts.site, 2000);
    expect(explore.facts.total, 2000, reason: '落盘的旧实测值必须被忽略');

    // 切到「全部」：只有它拿回来的 total 才是全站总量。
    explore.select('');
    await pumpEventQueue();
    repository.catalogTotal = 2100;
    await explore.refresh();
    await pumpEventQueue();
    expect(explore.facts.site, 2100);
    expect(explore.facts.total, 2100);
  });
}
