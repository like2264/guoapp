import 'dart:async';

import 'package:duanju_app/drama_feed.dart';
import 'package:duanju_app/models.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fakes.dart';

void main() {
  final a = drama('a'), b = drama('b'), c = drama('c');

  DramaFeed feedOf(DramaFeed feed) {
    addTearDown(feed.dispose);
    return feed;
  }

  test('stale cache shows first, then the first page replaces it', () async {
    final first = Completer<CatalogPage>();
    final feed = feedOf(
      DramaFeed(
        cached: () async => CatalogPage([a], page: 7, hasMore: true),
        load: (page, force) => first.future,
      ),
    );
    final reload = feed.reload();
    await pumpEventQueue();
    expect(feed.items, [a]);
    expect(feed.loading, isTrue);

    first.complete(CatalogPage([b], hasMore: true));
    await reload;
    expect(feed.items, [b]);
    expect(feed.loading, isFalse);
  });

  test('fresh cache skips the network and continues its page', () async {
    final pages = <int>[];
    final feed = feedOf(
      DramaFeed(
        cached: () async =>
            CatalogPage([a], page: 7, hasMore: true, fresh: true),
        load: (page, force) async {
          pages.add(page);
          return CatalogPage([b], page: page);
        },
      ),
    );
    await feed.reload();
    expect(pages, isEmpty);
    await feed.loadMore();
    expect(pages, [8]);
    expect(feed.items, [a, b]);
    expect(feed.hasMore, isFalse);
  });

  test('forced reloads skip the cache', () async {
    final forced = <bool>[];
    final feed = feedOf(
      DramaFeed(
        cached: () async => CatalogPage([a], fresh: true),
        load: (page, force) async {
          forced.add(force);
          return CatalogPage([b]);
        },
      ),
    );
    await feed.reload(force: true);
    expect(forced, [true]);
    expect(feed.items, [b]);
  });

  test('一页部分失败但拿到了作品：不甩错误、不挡后续翻页', () async {
    final pages = <int>[];
    final feed = feedOf(
      DramaFeed(
        load: (page, force) async {
          pages.add(page);
          return page == 1
              ? CatalogPage([a, b], hasMore: true)
              : CatalogPage(
                  [b, c],
                  page: page,
                  warning: '部分失败',
                  hasMore: true,
                );
        },
      ),
    );
    await feed.reload();
    await feed.loadMore();
    expect(feed.items, [a, b, c]);
    // 这一页拿到了数据，只是有告警。以前把它当成「翻页失败」：底部立刻
    // 换成错误 + 重试、canLoadMore 变假，列表就停在半路（夜社停在 480 附近、
    // 野果停在 1,388 都是这么来的）。
    expect(feed.error, isEmpty);
    expect(feed.canLoadMore, isTrue);
    await feed.loadMore();
    expect(pages, [1, 2, 3], reason: '接着翻下一页，不回头重试已经拿到数据的那页');
  });

  test('cumulative feeds replace their items with each answer', () async {
    final feed = feedOf(
      DramaFeed(
        cumulative: true,
        load: (page, force) async =>
            CatalogPage(page == 1 ? [a] : [a, b], hasMore: page == 1),
      ),
    );
    await feed.reload();
    await feed.loadMore();
    expect(feed.items, [a, b]);
  });

  test('an older answer never overwrites a newer reload', () async {
    final answers = <Completer<CatalogPage>>[];
    final feed = feedOf(
      DramaFeed(
        load: (page, force) {
          answers.add(Completer());
          return answers.last.future;
        },
      ),
    );
    final older = feed.reload();
    final newer = feed.reload();
    answers[1].complete(CatalogPage([b]));
    await newer;
    answers[0].complete(CatalogPage([a]));
    await older;
    expect(feed.items, [b]);
  });

  test('跨页重复的作品藏掉，序号连续排', () async {
    final feed = feedOf(
      DramaFeed(
        load: (page, force) async => page == 1
            ? CatalogPage([a, b], hasMore: true)
            : CatalogPage([b, c], page: 2, hasMore: false),
      ),
    );
    await feed.reload();
    await feed.loadMore();
    // b 在第二页又出现一次（站点分页本身会重复吐），卡片藏掉。序号按加载
    // 出来的作品连续排，末位卡片是第 3 部 —— 和列表底部、顶栏报的「共 3 部」
    // 是同一个数（+150 的三数规矩）。
    expect(feed.items, [a, b, c]);
    expect(feed.items.length, 3);
  });

  test('翻页连续失败只暂停自动翻页，不宣布到底、不丢已加载的作品', () async {
    var calls = 0;
    final feed = feedOf(
      DramaFeed(
        load: (page, force) async {
          if (page == 1) return CatalogPage([a], hasMore: true);
          calls++;
          throw StateError('context canceled');
        },
      ),
    );
    await feed.reload();
    expect(feed.hasMore, isTrue);
    await feed.loadMore();
    expect(feed.hasMore, isTrue, reason: '第一次失败还允许再试');
    await feed.loadMore();
    await feed.loadMore();
    expect(
      feed.hasMore,
      isTrue,
      reason: '失败不能让列表宣布到底 —— 一宣布，顶栏/底部/末位卡片就再也对不上',
    );
    expect(feed.canLoadMore, isFalse, reason: '连错三次暂停自动翻页');
    expect(feed.stalled, isTrue);
    expect(feed.items, [a], reason: '已经加载的作品不能丢');
    expect(feed.error, '翻页超时，稍后再试');
    expect(calls, 3);
  });

  test('点重试后接着拉失败的那一页，成功后三数自然相等', () async {
    var fail = true;
    var calls = 0;
    final feed = feedOf(
      DramaFeed(
        load: (page, force) async {
          if (page == 1) return CatalogPage([a], hasMore: true);
          calls++;
          if (fail) throw StateError('context canceled');
          return CatalogPage([b], page: 2, hasMore: false);
        },
      ),
    );
    await feed.reload();
    await feed.loadMore();
    expect(feed.error, isNotEmpty);
    fail = false;
    await feed.retry();
    expect(feed.items, [a, b], reason: '重试的是失败的那页，不跳页');
    expect(feed.error, isEmpty);
    expect(feed.hasMore, isFalse);
    expect(calls, 2);
  });

  test('a failure is shown until the next reload succeeds', () async {
    var fail = true;
    final feed = feedOf(
      DramaFeed(
        load: (page, force) async =>
            fail ? throw StateError('网络错误') : CatalogPage([a]),
      ),
    );
    await feed.reload();
    expect(feed.items, isEmpty);
    expect(feed.error, contains('网络错误'));

    fail = false;
    await feed.reload(force: true);
    expect(feed.error, isEmpty);
    expect(feed.items, [a]);
  });
}
