import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:duanju_app/catalog_updates.dart';
import 'package:duanju_app/core_bridge.dart';
import 'package:duanju_app/models.dart';
import 'package:duanju_app/ui/app_scope.dart';
import 'package:duanju_app/ui/widgets/cover_image.dart';
import 'package:duanju_app/ui/widgets/drama_actions.dart';
import 'package:duanju_app/ui/widgets/drama_tile.dart';

class _FakeRepository implements AppRepository {
  @override
  final CatalogUpdates catalogUpdates = CatalogUpdates();

  /// 封面组件会问 `coverPath`（本地缓存路径，没下载过就是 null），
  /// 其余调用在只画卡片的用例里不该出现，一律当作「没有」。
  @override
  dynamic noSuchMethod(Invocation invocation) {
    if (invocation.memberName == #coverCached) return false;
    // 封面下载在这里没有意义：给一个永远完成的空地址，卡片会画占位块。
    if (invocation.memberName == #cover) return Future<String>.value('');
    return null;
  }
}

/// 2.0.0+144：长按卡片不再从底部滑一块面板上来，
/// 两枚按钮直接浮在封面中央 —— 用户要的是「就在这张卡上操作」。
void main() {
  testWidgets('长按在封面上浮出操作，点一下执行并收起', (tester) async {
    var followed = 0;
    var downloaded = 0;
    final drama = const Drama(
      id: 'demo:1',
      source: 'demo',
      title: '测试剧',
      episodes: 12,
    );
    await tester.pumpWidget(
      AppScope(
        repository: _FakeRepository(),
        formFactor: FormFactor.phone,
        child: MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 120,
                child: DramaTile(
                  drama: drama,
                  onTap: () {},
                  actions: [
                    DramaAction(
                      label: '追剧',
                      icon: Icons.bookmark_add_outlined,
                      onSelected: (_) => followed++,
                    ),
                    DramaAction(
                      label: '下载',
                      icon: Icons.download_rounded,
                      onSelected: (_) => downloaded++,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('下载'), findsNothing, reason: '没长按就显示操作了');

    await tester.longPress(find.byType(DramaTile));
    await tester.pumpAndSettle();
    expect(find.text('追剧'), findsOneWidget);
    expect(find.text('下载'), findsOneWidget);

    // 按钮必须落在封面范围内，而不是另起一块浮层。
    final cover = tester.getRect(find.byType(DramaCover).first);
    for (final label in ['追剧', '下载']) {
      final chip = tester.getRect(find.text(label));
      expect(cover.contains(chip.center), isTrue, reason: '$label 跑到封面外面了');
    }

    await tester.tap(find.text('下载'));
    await tester.pumpAndSettle();
    expect(downloaded, 1);
    expect(followed, 0);
    expect(find.text('下载'), findsNothing, reason: '选完没有收起');
  });
}
