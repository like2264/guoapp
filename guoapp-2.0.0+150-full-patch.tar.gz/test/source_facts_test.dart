import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:duanju_app/drama_feed.dart';
import 'package:duanju_app/models.dart';
import 'package:duanju_app/source_stats.dart';
import 'package:duanju_app/ui/widgets/drama_grid.dart';

/// 部数口径（2.0.0+150 定死）：顶栏 = 底部 = 末位卡片，三处是同一个数。
///
/// - 顶栏：站点所有作品数（各分类相加、去重）
/// - 底部：拉到底时一共加载过的作品数
/// - 末位卡片：作品总数（连续序号）
///
/// 所以「翻到底实测出来的独立条数」（[SourceFacts.listed]）优先，站点声明只在
/// 还没翻到底时当预期值。历史上这里反着来过两次：
/// - 顶栏报声明、底部报实际条数，差几十上百部（+143 之前）；
/// - +149 一律信声明，结果顶栏 1,401 / 末位卡片 1,388、夜社末位卡片不到 500。
void main() {
  test('翻到底实测的独立条数优先，顶栏跟着末位卡片走', () {
    const facts = SourceFacts(site: 1401, listed: 1388, probed: true);
    expect(facts.total, 1388, reason: '顶栏必须等于列表真正摆出来的作品数');
    expect(facts.headline, '共 1,388 部');
  });

  test('还没翻到底就用站点声明当预期值', () {
    const facts = SourceFacts(site: 2056, probed: true);
    expect(facts.total, 2056);
    expect(facts.headline, '共 2,056 部');
  });

  test('实测比声明多也以实测为准（页面真的摆出来这么多）', () {
    const facts = SourceFacts(site: 1900, listed: 1951, probed: true);
    expect(facts.total, 1951);
    expect(facts.headline, '共 1,951 部');
  });

  test('只有实测值（站点给不出总量）也报「共 N 部」', () {
    const facts = SourceFacts(listed: 843, probed: true);
    expect(facts.total, 843);
    expect(facts.headline, '共 843 部');
  });

  // 2.0.0+148：实测条数不落盘了。留在存储里的旧值一律不认 —— 它会永远压过
  // 站点声明，站点加了作品顶栏也不动（野果 1388/1396、黑桃 1527/1536 就是）。
  test('落盘的实测条数读出来也是 0', () {
    final raw = <String, Object?>{
      'huangtao': {
        'day': factsDay(DateTime.now()),
        'site': 2056,
        'local': 300,
        'updated': 12,
        'listed': 1951,
        'probed': true,
        'all': ['huangtao:1'],
      },
    };
    final facts = readFacts(raw, 'huangtao');
    expect(facts.listed, 0);
    expect(facts.probed, isTrue);
    expect(facts.total, 2056, reason: '顶栏必须回到站点声明');
    expect(facts.site, 2056);
    expect(facts.updated, 12);
    expect(readKnown(raw, 'huangtao'), ['huangtao:1']);
  });

  test('writeFacts 重写整行时不再写实测值，其它观测值照旧', () {
    final raw = <String, Object?>{
      'huangtao': {
        'day': factsDay(DateTime.now()),
        'site': 2056,
        'local': 300,
        'updated': 3,
        'listed': 1951,
        'probed': true,
      },
    };
    final saved = writeFacts(raw, 'huangtao', site: 2060, local: 301, gained: 2);
    final facts = readFacts(saved, 'huangtao');
    expect(facts.listed, 0);
    expect(facts.site, 2060);
    expect(facts.updated, 5);
    expect((saved['huangtao'] as Map).containsKey('listed'), isFalse);
  });

  testWidgets('底栏滚到底只报一个数字', (tester) async {
    final feed = DramaFeed(
      load: (page, force) async => CatalogPage(const [], hasMore: false),
    );
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(body: FeedFooter(feed: feed, count: 1951)),
      ),
    );
    expect(find.text('已经到底了 · 共 1,951 部'), findsOneWidget);
    expect(find.textContaining('顶栏'), findsNothing);
    feed.dispose();
  });
}
