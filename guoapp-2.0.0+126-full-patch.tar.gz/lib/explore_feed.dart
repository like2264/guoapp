import 'dart:async';

import 'package:flutter/foundation.dart';

import 'core_bridge.dart';
import 'drama_feed.dart';
import 'local_store.dart';
import 'models.dart';
import 'ranking_models.dart';
import 'source_catalog.dart';
import 'source_stats.dart';

const recommendTab = CatalogCategory('app:recommend', '推荐');

CatalogCategory rankingTab(RankingBoard board) =>
    CatalogCategory('app:rank:${board.id}', board.name);

class ExploreFeed extends ChangeNotifier {
  ExploreFeed(this.repository, this.store) {
    store.addListener(_storeChanged);
    repository.catalogUpdates.addListener(_metadataChanged);
    _open();
  }
  final AppRepository repository;
  final LocalStore store;
  SourceCatalog? _catalog;
  CatalogCategory _tab = CatalogCategory.all;
  DramaFeed? _feed;
  Map<String, int> _ranks = const {};
  final _feeds = <String, DramaFeed>{};
  final _rankings = <String, Map<String, int>>{};

  /// 切走的站源在这里留一份列表缓存（最多 [_stashLimit] 个）。
  /// 原来换站源会把所有 feed 直接 dispose，来回切就得重新联网拉一遍，
  /// 表现就是"点完站源要等一小会儿"。留缓存后切回去是瞬间出内容。
  final _stash = <String, Map<String, DramaFeed>>{};
  final _stashRanks = <String, Map<String, Map<String, int>>>{};
  static const _stashLimit = 2;
  bool _disposed = false;

  /// 当前站源顶栏那行观测值。
  SourceFacts _facts = const SourceFacts();

  /// 每个站源「全部」分类里见过的作品 id。顶栏那句「已收录 N 部」就是它的长度：
  /// 只由「全部」目录喂，搜索、排行榜、单独切开的分类都不进来，
  /// 所以翻到哪就是哪，不会被别的入口撑大。
  final _seen = <String, Set<String>>{};

  /// 「全部」名单有新增、还没落盘的站源。翻页时只更新界面，等下一次
  /// 第一页 / 强制刷新才写存储，免得每翻一页都写一次。
  final _seenDirty = <String>{};

  /// 最近一次从站源真实拿到一页目录（含站源总量）的时间。
  /// 切站源后用它判断「首屏那一页是不是已经刷过统计了」，避免同一轮打两次站源。
  DateTime? _lastObserve;

  SourceSite? get source => _catalog?.source;
  SourceFacts get facts => _facts;
  DramaFeed? get feed => _feed;
  CatalogCategory get tab => _tab;
  bool get recommending => _tab.id == recommendTab.id;

  List<CatalogCategory> get tabs {
    final catalog = _catalog;
    if (catalog == null) return const [];
    final [all, ...genres] = catalog.categories;
    return [
      if (catalog.recommends) recommendTab,
      all,
      for (final board in catalog.boards) rankingTab(board),
      ...genres,
    ];
  }

  int? rankOf(Drama drama) => _ranks[drama.id];

  WatchEntry? get resume {
    final source = this.source;
    if (source == null || _tab.id != tabs.first.id) return null;
    return store.history
        .where((entry) => entry.drama.source == source.id)
        .firstOrNull;
  }

  Drama? get featured =>
      recommending && resume == null ? _feed?.items.firstOrNull : null;

  List<Drama> get items {
    final items = _feed?.items ?? const <Drama>[];
    return featured == null ? items : items.skip(1).toList();
  }

  void select(String id) {
    if (id == _tab.id) return;
    final tab = tabs.where((tab) => tab.id == id).firstOrNull;
    if (tab != null) _select(tab);
  }

  Future<void> refresh() async {
    final catalog = _catalog;
    if (catalog == null) return;
    if (catalog.categories.length == 1) {
      unawaited(_loadCategories(catalog, force: true));
    }
    await _feed?.reload(force: true);
  }

  void _open() {
    final id = store.source;
    if (id == _catalog?.source.id) return;
    unawaited(repository.cancelCatalog());
    unawaited(repository.cancelRecommendations());
    _parkFeeds();
    if (id.isEmpty) {
      _catalog = null;
      _feed = null;
      _tab = CatalogCategory.all;
      _facts = const SourceFacts();
      return;
    }
    final catalog = _catalog = SourceCatalog(repository, SourceSite.byId(id));
    _facts = readFacts(store.sourceStats, id);
    // 切回来时接着上次的「全部」名单往下累计，不清零。
    final kept = readSeen(store.sourceStats, id);
    if (kept.isNotEmpty) {
      _seen[id] ??= kept.toSet();
    } else if (_facts.site <= 0 && _facts.local > 0) {
      // 旧版本存的是「本地目录缓存条数」，跟新的「全部分类已见数」不是一个口径，
      // 不能接着用。等这一轮把「全部」目录拉回来重新累计，别先显示一个假数字。
      _facts = SourceFacts(updated: _facts.updated);
    }
    final startedAt = DateTime.now();
    // 这个站源之前切走过，直接把列表接回来，不再重新请求。
    if (_stash.remove(id) case final kept?) {
      _feeds.addAll(kept);
      _rankings.addAll(_stashRanks.remove(id) ?? const {});
      for (final feed in kept.values) {
        feed.addListener(_notify);
      }
    }
    _select(catalog.recommends ? recommendTab : CatalogCategory.all);
    unawaited(_loadCategories(catalog));
    // 先用本地剧库里存着的上次总量把顶栏填上（毫秒级），再去站源刷新。
    unawaited(_primeFacts(catalog));
    // 切一次源刷一次站源总量，不能只靠「用户往下翻页」时才收集。
    unawaited(_refreshFacts(catalog, startedAt));
  }

  /// 换站源前把当前站源的 feed 存进 [_stash]（而不是直接销毁）。
  void _parkFeeds() {
    final source = _catalog?.source.id;
    if (source == null || _feeds.isEmpty) {
      _dropFeeds();
      return;
    }
    for (final feed in _feeds.values) {
      feed.removeListener(_notify);
    }
    _stash[source] = Map.of(_feeds);
    _stashRanks[source] = Map.of(_rankings);
    _feeds.clear();
    _rankings.clear();
    _feed = null;
    _ranks = const {};
    while (_stash.length > _stashLimit) {
      final oldest = _stash.keys.first;
      _stashRanks.remove(oldest);
      for (final feed in _stash.remove(oldest)?.values ??
          const <DramaFeed>[]) {
        feed.dispose();
      }
    }
  }

  Future<void> _loadCategories(
    SourceCatalog catalog, {
    bool force = false,
  }) async {
    try {
      await catalog.loadCategories(force: force);
    } catch (_) {}
    if (_disposed || catalog != _catalog) return;
    _notify();
  }

  void _select(CatalogCategory tab) {
    final catalog = _catalog!;
    if (recommending) unawaited(repository.cancelRecommendations());
    _tab = tab;
    if (_feeds[tab.id] case final kept?) {
      _feed = kept;
      _ranks = _rankings[tab.id] ?? const {};
      if (kept.items.isEmpty && !kept.loading) unawaited(kept.reload());
      _notify();
      return;
    }
    final board = catalog.boards
        .where((board) => rankingTab(board).id == tab.id)
        .firstOrNull;
    final ranks = _ranks = _rankings[tab.id] = <String, int>{};
    final feed = _feed = _feeds[tab.id] = tab.id == recommendTab.id
        ? DramaFeed(
            cumulative: true,
            load: (page, force) => _track(
              catalog,
              page,
              () => catalog.recommendations(more: page > 1, force: force),
            ),
          )
        : board != null
        ? DramaFeed(
            load: (page, force) => _track(
              catalog,
              page,
              () => _ranking(catalog, board, ranks, page, force),
            ),
          )
        : DramaFeed(
            cached: () => catalog.cached(tab),
            load: (page, force) => _track(
              catalog,
              page,
              () => catalog.fetch(tab, page: page, force: force),
              whole: tab.id.isEmpty,
            ),
          );
    feed.addListener(_notify);
    unawaited(feed.reload());
    _notify();
  }

  Future<CatalogPage> _ranking(
    SourceCatalog catalog,
    RankingBoard board,
    Map<String, int> ranks,
    int page,
    bool force,
  ) async {
    final result = await catalog.ranking(board, page: page, force: force);
    for (final item in result.items) {
      ranks[item.drama.id] = item.rank;
    }
    return CatalogPage(
      [for (final item in result.items) item.drama],
      hasMore: result.hasMore,
      warning: result.warning,
      page: result.page,
    );
  }

  /// 用本地剧库缓存里的总量先把顶栏填上，避免切换站源后空白一小会儿。
  /// 只读、不写盘：真正的数字由 [_refreshFacts] 从站源拿回来再落库。
  Future<void> _primeFacts(SourceCatalog catalog) async {
    final source = catalog.source.id;
    if (_facts.probed && _facts.site > 0) return;
    try {
      final page = await catalog.cached(CatalogCategory.all);
      if (_disposed || _catalog?.source.id != source) return;
      if (page.total <= 0 || page.total == _facts.site) return;
      _facts = SourceFacts(
        site: page.total,
        local: _facts.local,
        updated: _facts.updated,
        probed: true,
      );
      _notify();
    } catch (_) {}
  }

  /// 切站源时刷新顶栏那行观测值。
  ///
  /// 首屏列表自己就会拉一页目录（[_track] 会把站源总量记下来），所以这里先
  /// 等 900ms：那一页已经带回总量就不重复请求站源；首屏完全走的本地缓存时
  /// 才补一次强制请求，保证「切过来看到的就是站点现在的数字」。
  Future<void> _refreshFacts(SourceCatalog catalog, DateTime startedAt) async {
    final source = catalog.source.id;
    await Future<void>.delayed(const Duration(milliseconds: 900));
    if (_disposed || _catalog?.source.id != source) return;
    final last = _lastObserve;
    if (last != null && last.isAfter(startedAt)) return;
    final before = await _episodeSnapshot(source);
    try {
      final page = await catalog.fetch(
        CatalogCategory.all,
        page: 1,
        force: true,
      );
      if (_disposed || _catalog?.source.id != source) return;
      _lastObserve = DateTime.now();
      _noteAll(source, page.items);
      await _observe(source, before, page.items, siteTotal: page.total);
    } catch (_) {}
  }

  /// 取一页目录，顺便把结果记进本地（收藏/历史的剧信息刷新），
  /// 第一页还要更新顶栏那行观测值。
  ///
  /// 统计必须在请求**之前**拍一张快照：native 侧在返回结果时已经把新数据
  /// 并进本地剧库了，事后再读「旧值」就永远相等，今日更新永远是 0。
  Future<CatalogPage> _track(
    SourceCatalog catalog,
    int page,
    Future<CatalogPage> Function() run, {
    bool whole = false,
  }) async {
    final source = catalog.source.id;
    final before = page <= 1 ? await _episodeSnapshot(source) : null;
    final result = await run();
    unawaited(store.refreshDramas(result.items).catchError((Object _) {}));
    if (whole) _noteAll(source, result.items);
    if (page <= 1) {
      _lastObserve = DateTime.now();
      unawaited(_observe(source, before, result.items, siteTotal: result.total));
    }
    return result;
  }

  /// 「全部」分类里又见到了这些剧，记下来（按 id 去重），顶栏的「已收录 N 部」
  /// 就是这个集合的长度。搜索、榜单、单独切开的分类都不进这个集合 ——
  /// 那样会把「站点到底有多少部」变成「我这一路看过多少条」。
  void _noteAll(String source, Iterable<Drama> items) {
    if (_disposed) return;
    final seen = _seen[source] ??= <String>{};
    if (seen.length >= factsSeenLimit) return;
    var added = false;
    for (final drama in items) {
      if (seen.length >= factsSeenLimit) break;
      if (drama.id.isEmpty) continue;
      if (seen.add(drama.id)) added = true;
    }
    if (!added || _catalog?.source.id != source) return;
    _seenDirty.add(source);
    _facts = SourceFacts(
      site: _facts.site,
      local: seen.length,
      updated: _facts.updated,
      probed: true,
    );
    _notify();
  }

  /// 本地剧库里该站源「剧 id → 当前集数」。
  Future<Map<String, int>?> _episodeSnapshot(String source) async {
    try {
      final cached = await repository.cached(source);
      return {for (final drama in cached.items) drama.id: drama.episodes};
    } catch (_) {
      return null;
    }
  }

  /// 记录一次观测：站源总量 + 本地收录数 + 今天增加的集数（只算库里原有的剧）。
  Future<void> _observe(
    String source,
    Map<String, int>? before,
    List<Drama> fresh, {
    int siteTotal = 0,
  }) async {
    if (_disposed) return;
    var gained = 0;
    if (before != null && before.isNotEmpty) {
      for (final drama in fresh) {
        final old = before[drama.id];
        if (old == null || old <= 0) continue;
        final delta = drama.episodes - old;
        if (delta > 0) gained += delta;
      }
    }
    // 站源给的量优先；站点给不出总量时用「全部」分类里见过的数兜底，
    // 不再用本地目录缓存的条数 —— 那个数被搜索和分类一起撑大，不是站点的量。
    final site = siteTotal > 0 ? siteTotal : _facts.site;
    final local = _seen[source]?.length ?? _facts.local;
    if (_disposed || _catalog?.source.id != source) return;
    final saved = writeFacts(
      store.sourceStats,
      source,
      site: site,
      local: local,
      gained: gained,
      seen: _seen[source],
    );
    final next = readFacts(saved, source);
    final dirty = _seenDirty.remove(source);
    if (gained == 0 &&
        !dirty &&
        next.site == _facts.site &&
        next.local == _facts.local &&
        next.updated == _facts.updated) {
      // 没有变化就别写盘，也别让界面白重建一次。
      return;
    }
    _facts = next;
    _notify();
    unawaited(store.setSourceStats(saved).catchError((Object _) {}));
  }

  void _storeChanged() {
    _open();
    _notify();
  }

  void _metadataChanged() {
    final drama = repository.catalogUpdates.latest;
    if (drama == null || drama.source != source?.id) return;
    _catalog?.remember([drama]);
    for (final feed in _feeds.values) {
      feed.update(drama);
    }
    unawaited(store.refreshDrama(drama).catchError((Object _) {}));
  }

  void _dropFeeds() {
    for (final feed in _feeds.values) {
      feed.dispose();
    }
    _feeds.clear();
    _rankings.clear();
    _feed = null;
    _ranks = const {};
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    store.removeListener(_storeChanged);
    repository.catalogUpdates.removeListener(_metadataChanged);
    _dropFeeds();
    for (final feeds in _stash.values) {
      for (final feed in feeds.values) {
        feed.dispose();
      }
    }
    _stash.clear();
    _stashRanks.clear();
    unawaited(repository.cancelCatalog());
    unawaited(repository.cancelRecommendations());
    super.dispose();
  }
}
