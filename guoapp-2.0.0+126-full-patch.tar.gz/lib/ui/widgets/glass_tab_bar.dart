import 'dart:ui';

import 'package:flutter/material.dart';

/// 浮动玻璃标签栏：半透明胶囊 + 极轻的背景模糊 + 细高光边。
///
/// 参考效果（腾讯视频的 Liquid Glass 底栏）：底下的封面、标题要**能看清**，
/// 所以模糊只能很轻（sigma 0.8，几乎只是把边缘揉软一点），白光只剩薄薄一层。
/// 模糊一旦开到 8 以上，底下就只剩一团色块，用户会觉得「挡住的东西完全看不到」。
///
/// 选中项是一整格的亮胶囊：图标和文字都落在胶囊里，胶囊用主题色淡淡一层
/// 填充 + 白描边 + 主题色微光。
class GlassTabBar extends StatelessWidget {
  const GlassTabBar({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
    required this.destinations,
    this.onSwipe,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final List<GlassTabDestination> destinations;

  /// 在底栏上左右滑时回调：-1 = 上一栏，+1 = 下一栏。
  /// 手势只挂在底栏这一条上，页面本身不响应横滑。
  final ValueChanged<int>? onSwipe;

  /// 胶囊本体高度（不含底部安全区）。
  static const barHeight = 62.0;

  /// 底栏上下的留白。内容要躲开底栏时，用 [reservedHeight]。
  static const horizontalInset = 14.0;
  static const bottomGap = 10.0;

  static const _radius = barHeight / 2;

  /// 底栏实际占用的总高度（胶囊 + 上下留白 + 安全区）。
  /// 页面底部留白按它算，内容就不会被浮起来的玻璃条盖住。
  static double reservedHeight(BuildContext context) =>
      barHeight +
      bottomGap +
      MediaQuery.viewPaddingOf(context).bottom +
      8;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors = Theme.of(context).colorScheme;
    final inset = MediaQuery.viewPaddingOf(context).bottom;
    final radius = BorderRadius.circular(_radius);
    final bar = Padding(
      padding: EdgeInsets.fromLTRB(
        horizontalInset,
        0,
        horizontalInset,
        bottomGap + inset,
      ),
      // 阴影放在裁剪外面，否则会被 ClipRRect 一起剪掉。
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: radius,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: dark ? 0.18 : 0.08),
              blurRadius: 22,
              spreadRadius: -6,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: radius,
          child: BackdropFilter(
            // 几乎不糊：底下的封面和标题要一眼能读出来，玻璃感交给
            // 描边和顶部高光去表达。
            filter: ImageFilter.blur(
              sigmaX: 0.8,
              sigmaY: 0.8,
              tileMode: TileMode.clamp,
            ),
            // 高光放在内边距外面，才能贴住胶囊真正的上沿。
            child: SizedBox(
              height: barHeight,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        borderRadius: radius,
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: dark
                              ? [
                                  Colors.white.withValues(alpha: 0.055),
                                  Colors.white.withValues(alpha: 0.022),
                                ]
                              : [
                                  Colors.white.withValues(alpha: 0.26),
                                  Colors.white.withValues(alpha: 0.12),
                                ],
                        ),
                        border: Border.all(
                          color: dark
                              ? Colors.white.withValues(alpha: 0.30)
                              : Colors.white.withValues(alpha: 0.75),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          for (
                            var index = 0;
                            index < destinations.length;
                            index++
                          )
                            Expanded(
                              child: _item(context, index, dark, colors),
                            ),
                        ],
                      ),
                    ),
                  ),
                  // 顶部一条细高光，玻璃感主要靠它。
                  Positioned(
                    left: _radius * 0.6,
                    right: _radius * 0.6,
                    top: 0,
                    child: IgnorePointer(
                      child: Container(
                        height: 1,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.white.withValues(alpha: 0),
                              Colors.white.withValues(alpha: dark ? 0.45 : 0.9),
                              Colors.white.withValues(alpha: 0),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    final swipe = onSwipe;
    if (swipe == null) return bar;
    return _SwipeDetector(onSwipe: swipe, child: bar);
  }

  Widget _item(
    BuildContext context,
    int index,
    bool dark,
    ColorScheme colors,
  ) {
    final destination = destinations[index];
    final selected = index == selectedIndex;
    final idle = dark
        ? Colors.white.withValues(alpha: 0.92)
        : Colors.black.withValues(alpha: 0.78);
    // 背景很透，内容可能很亮也可能很暗，给字加一圈很轻的影子保证可读。
    final legibility = <Shadow>[
      Shadow(
        offset: const Offset(0, 1),
        blurRadius: 2,
        color: dark
            ? Colors.black.withValues(alpha: 0.65)
            : Colors.white.withValues(alpha: 0.85),
      ),
    ];
    return Semantics(
      button: true,
      selected: selected,
      label: destination.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => onSelected(index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 240),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            // 整格胶囊：主题色淡淡一层填充，白描边勾出边界，再用同色微光
            // 托一下，看起来像浮在玻璃上的一小块色片。
            color: selected
                ? colors.primary.withValues(alpha: dark ? 0.22 : 0.14)
                : Colors.transparent,
            border: selected
                ? Border.all(
                    color: dark
                        ? Colors.white.withValues(alpha: 0.34)
                        : Colors.white.withValues(alpha: 0.92),
                  )
                : null,
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: colors.primary.withValues(
                        alpha: dark ? 0.22 : 0.16,
                      ),
                      blurRadius: 14,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconTheme.merge(
                data: IconThemeData(
                  size: 22,
                  color: selected ? colors.primary : idle,
                ),
                child: selected ? destination.selectedIcon : destination.icon,
              ),
              const SizedBox(height: 2),
              Text(
                destination.label,
                maxLines: 1,
                overflow: TextOverflow.fade,
                softWrap: false,
                style: TextStyle(
                  fontSize: 11,
                  height: 1.1,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  color: selected ? colors.primary : idle,
                  shadows: legibility,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GlassTabDestination {
  const GlassTabDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
  });

  final String label;
  final Widget icon;
  final Widget selectedIcon;
}

/// 底栏上的横滑识别：直接读指针事件 + 手势拖动双保险。
///
/// 一次连续拖动只切一栏：触发之后把起点挪到当前位置，避免手指没抬起就
/// 连续跳两三个 tab；抬手指时的甩动（fling）也认。
class _SwipeDetector extends StatefulWidget {
  const _SwipeDetector({required this.onSwipe, required this.child});

  final ValueChanged<int> onSwipe;
  final Widget child;

  @override
  State<_SwipeDetector> createState() => _SwipeDetectorState();
}

class _SwipeDetectorState extends State<_SwipeDetector> {
  int? _pointer;
  double _startX = 0;
  double _startY = 0;
  double _lastX = 0;
  double _drag = 0;

  static const _threshold = 14.0;

  bool _busy = false;

  bool _fire(double dx, double dy) {
    if (_busy || dx.abs() < _threshold || dx.abs() <= dy.abs()) return false;
    _busy = true;
    widget.onSwipe(dx < 0 ? 1 : -1);
    return true;
  }

  @override
  Widget build(BuildContext context) => Listener(
    behavior: HitTestBehavior.opaque,
    onPointerDown: (event) {
      if (_pointer != null) return;
      _pointer = event.pointer;
      _startX = _lastX = event.localPosition.dx;
      _startY = event.localPosition.dy;
      _busy = false;
    },
    onPointerMove: (event) {
      if (event.pointer != _pointer) return;
      _lastX = event.localPosition.dx;
      _fire(_lastX - _startX, (event.localPosition.dy - _startY).abs());
    },
    onPointerUp: (event) {
      if (event.pointer != _pointer) return;
      _fire(_lastX - _startX, (event.localPosition.dy - _startY).abs());
      _pointer = null;
    },
    onPointerCancel: (event) {
      if (event.pointer == _pointer) _pointer = null;
    },
    child: GestureDetector(
      behavior: HitTestBehavior.opaque,
      onHorizontalDragStart: (_) => _drag = 0,
      onHorizontalDragUpdate: (details) {
        _drag += details.delta.dx;
        if (_fire(_drag, 0)) _drag = 0;
      },
      onHorizontalDragEnd: (details) {
        final velocity = details.primaryVelocity ?? 0;
        if (velocity.abs() >= 80) _fire(velocity / 8, 0);
        _drag = 0;
      },
      child: widget.child,
    ),
  );
}
