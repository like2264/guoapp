import 'package:flutter/material.dart';

import '../theme/glass.dart';

/// 页面顶栏。
///
/// Liquid Glass 打开时它是一条浮起来的玻璃条（左右留白、四角圆掉、背景模糊），
/// 关掉时退回原来的「纯文字 + 右侧按钮」。两种情况下内容高度基本一致，
/// 各页面不用改布局。
class PageHeader extends StatelessWidget {
  const PageHeader({
    super.key,
    required this.title,
    this.subtitle = '',
    this.subtitleLines = const [],
    this.actions = const [],
  });
  final String title;

  /// 紧跟标题的一行小字（发现页用来放站源的作品数与今日更新集数）。
  /// 放不下就省略号，不换行、不撑高。
  final String subtitle;

  /// 同样的副标题，但按行分开排（最多两行，10.5 号字）。
  /// 发现页顶栏一行放不下「共 4,379 部 · 今日更新 56 集」，会截成
  /// 「已收录 2,051 部 · 今日…」，所以拆成上下两行各说一件事。
  final List<String> subtitleLines;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    final row = _row(context);
    if (!glassEnabled(context)) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 8, 0),
        child: SizedBox(height: 64, child: row),
      );
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 0),
      child: GlassPanel(
        radius: 24,
        blur: 18,
        tint: 1.05,
        padding: const EdgeInsets.fromLTRB(14, 0, 2, 0),
        child: SizedBox(height: 58, child: row),
      ),
    );
  }

  Widget _row(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final style = Theme.of(context).textTheme.headlineMedium?.copyWith(
      fontSize: 28,
      fontWeight: FontWeight.w800,
    );
    final note = TextStyle(
      fontSize: 10.5,
      height: 1.2,
      fontWeight: FontWeight.w500,
      color: colors.onSurfaceVariant.withValues(alpha: 0.85),
    );
    return Row(
      children: [
        Expanded(
          child: Row(
            children: [
              Flexible(
                child: Semantics(
                  header: true,
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: style,
                  ),
                ),
              ),
              if (subtitleLines.isNotEmpty) ...[
                const SizedBox(width: 8),
                Flexible(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (final line in subtitleLines.take(2))
                        Text(
                          line,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: note,
                        ),
                    ],
                  ),
                ),
              ] else if (subtitle.isNotEmpty) ...[
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: note,
                  ),
                ),
              ],
            ],
          ),
        ),
        ...actions,
      ],
    );
  }
}
