import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// 浮动玻璃标签栏：半透明胶囊 + 极轻的背景模糊 + 细高光边。
///
/// 参考效果（腾讯视频的 Liquid Glass 底栏）：底下的封面、标题要**能看清**，
/// 所以模糊只能很轻（sigma 0.8，几乎只是把边缘揉软一点），白光只剩薄薄一层。
/// 模糊一旦开到 8 以上，底下就只剩一团色块，用户会觉得「挡住的东西完全看不到」。
///
/// 选中项是一整格的亮胶囊。胶囊是**独立的一层**，可以在栏目之间拖着走：
/// 按住底栏左右拖，胶囊跟着手指走，松手落到最近的一格并切过去。
class GlassTabBar extends StatefulWidget {
  const GlassTabBar({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
    required this.destinations,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final List<GlassTabDestination> destinations;

  /// 胶囊本体高度（不含底部安全区）。
  static const barHeight = 62.0;

  /// 底栏上下的留白。内容要躲开底栏时，用 [reservedHeight]。
  static const horizontalInset = 14.0;
  static const bottomGap = 10.0;

  static const _radius = barHeight / 2;

  /// 玻璃条内边距：胶囊在这里面移动。
  static const _pad = 6.0;

  /// 底栏实际占用的总高度（胶囊 + 上下留白 + 安全区）。
  /// 页面底部留白按它算，内容就不会被浮起来的玻璃条盖住。
  static double reservedHeight(BuildContext context) =>
      barHeight +
      bottomGap +
      MediaQuery.viewPaddingOf(context).bottom +
      8;

  @override
  State<GlassTabBar> createState() => _GlassTabBarState();
}

class _GlassTabBarState extends State<GlassTabBar> {
  /// 拖胶囊时相对「选中格左边缘」的偏移。
  double _drag = 0;
  bool _dragging = false;

  /// 拖动过程中已经掠过（并震动过）的格子，避免同一格反复震。
  int? _hovered;

  static const _snap = Duration(milliseconds: 240);

  void _dragStart(DragStartDetails details) {
    HapticFeedback.selectionClick();
    setState(() {
      _dragging = true;
      _drag = 0;
      _hovered = widget.selectedIndex;
    });
  }

  void _dragUpdate(DragUpdateDetails details, double cell) {
    setState(() {
      _drag += details.delta.dx;
      // 胶囊最多移到首尾两格，再往外拖没有意义。
      final travel = cell * (widget.destinations.length - 1);
      _drag = _drag.clamp(-widget.selectedIndex * cell, travel - widget.selectedIndex * cell);
      final index = widget.selectedIndex + (_drag / cell).round();
      if (index != _hovered) {
        _hovered = index;
        HapticFeedback.selectionClick();
      }
    });
  }

  void _dragEnd(double cell) {
    final index = (widget.selectedIndex + (_drag / cell).round()).clamp(
      0,
      widget.destinations.length - 1,
    );
    setState(() {
      _dragging = false;
      _drag = 0;
      _hovered = null;
    });
    if (index != widget.selectedIndex) widget.onSelected(index);
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors = Theme.of(context).colorScheme;
    final inset = MediaQuery.viewPaddingOf(context).bottom;
    final radius = BorderRadius.circular(GlassTabBar._radius);
    return Padding(
      padding: EdgeInsets.fromLTRB(
        GlassTabBar.horizontalInset,
        0,
        GlassTabBar.horizontalInset,
        GlassTabBar.bottomGap + inset,
      ),
      // 阴影放在裁剪外面，否则会被 ClipRRect 一起剪掉。
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: radius,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: dark ? 0.18 : 0.08),
              blurRadius: 22,
              spreadRadius: -6,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: radius,
          child: BackdropFilter(
            // 几乎不糊：底下的封面和标题要一眼能读出来，玻璃感交给
            // 描边和顶部高光去表达。
            filter: ImageFilter.blur(
              sigmaX: 0.8,
              sigmaY: 0.8,
              tileMode: TileMode.clamp,
            ),
            // 高光放在内边距外面，才能贴住胶囊真正的上沿。
            child: SizedBox(
              height: GlassTabBar.barHeight,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final inner =
                      constraints.maxWidth - GlassTabBar._pad * 2;
                  final cell = inner / widget.destinations.length;
                  final left =
                      GlassTabBar._pad +
                      widget.selectedIndex * cell +
                      _drag;
                  return Stack(
                    children: [
                      Positioned.fill(
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            borderRadius: radius,
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: dark
                                  ? [
                                      Colors.white.withValues(alpha: 0.055),
                                      Colors.white.withValues(alpha: 0.022),
                                    ]
                                  : [
                                      Colors.white.withValues(alpha: 0.26),
                                      Colors.white.withValues(alpha: 0.12),
                                    ],
                            ),
                            border: Border.all(
                              color: dark
                                  ? Colors.white.withValues(alpha: 0.30)
                                  : Colors.white.withValues(alpha: 0.75),
                              width: 1,
                            ),
                          ),
                        ),
                      ),
                      // 选中胶囊。拖动时零延时跟手，松手后回到 240ms 的缓动。
                      AnimatedPositioned(
                        duration: _dragging ? Duration.zero : _snap,
                        curve: Curves.easeOutCubic,
                        left: left + 2,
                        width: cell - 4,
                        top: GlassTabBar._pad,
                        height: GlassTabBar.barHeight - GlassTabBar._pad * 2,
                        child: IgnorePointer(
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(26),
                              // 整格胶囊：主题色淡淡一层填充，白描边勾出边界，
                              // 再用同色微光托一下，看起来像浮在玻璃上的一小块色片。
                              color: colors.primary.withValues(
                                alpha: dark ? 0.22 : 0.14,
                              ),
                              border: Border.all(
                                color: dark
                                    ? Colors.white.withValues(alpha: 0.34)
                                    : Colors.white.withValues(alpha: 0.92),
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: colors.primary.withValues(
                                    alpha: dark ? 0.22 : 0.16,
                                  ),
                                  blurRadius: 14,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Positioned.fill(
                        child: Padding(
                          padding: const EdgeInsets.all(GlassTabBar._pad),
                          child: GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onHorizontalDragStart: _dragStart,
                            onHorizontalDragUpdate: (details) =>
                                _dragUpdate(details, cell),
                            onHorizontalDragEnd: (_) => _dragEnd(cell),
                            onHorizontalDragCancel: () => _dragEnd(cell),
                            child: Row(
                              children: [
                                for (
                                  var index = 0;
                                  index < widget.destinations.length;
                                  index++
                                )
                                  Expanded(
                                    child: _item(context, index, dark, colors),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      // 顶部一条细高光，玻璃感主要靠它。
                      Positioned(
                        left: GlassTabBar._radius * 0.6,
                        right: GlassTabBar._radius * 0.6,
                        top: 0,
                        child: IgnorePointer(
                          child: Container(
                            height: 1,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.white.withValues(alpha: 0),
                                  Colors.white.withValues(
                                    alpha: dark ? 0.45 : 0.9,
                                  ),
                                  Colors.white.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _item(
    BuildContext context,
    int index,
    bool dark,
    ColorScheme colors,
  ) {
    final destination = widget.destinations[index];
    final selected = index == widget.selectedIndex;
    final idle = dark
        ? Colors.white.withValues(alpha: 0.92)
        : Colors.black.withValues(alpha: 0.78);
    // 背景很透，内容可能很亮也可能很暗，给字加一圈很轻的影子保证可读。
    final legibility = <Shadow>[
      Shadow(
        offset: const Offset(0, 1),
        blurRadius: 2,
        color: dark
            ? Colors.black.withValues(alpha: 0.65)
            : Colors.white.withValues(alpha: 0.85),
      ),
    ];
    return Semantics(
      button: true,
      selected: selected,
      label: destination.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => widget.onSelected(index),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconTheme.merge(
              data: IconThemeData(
                size: 22,
                color: selected ? colors.primary : idle,
              ),
              child: selected ? destination.selectedIcon : destination.icon,
            ),
            const SizedBox(height: 2),
            Text(
              destination.label,
              maxLines: 1,
              overflow: TextOverflow.fade,
              softWrap: false,
              style: TextStyle(
                fontSize: 11,
                height: 1.1,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected ? colors.primary : idle,
                shadows: legibility,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class GlassTabDestination {
  const GlassTabDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
  });

  final String label;
  final Widget icon;
  final Widget selectedIcon;
}
