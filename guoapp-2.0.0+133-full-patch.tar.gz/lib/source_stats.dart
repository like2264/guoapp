/// 站源观测量：顶栏标题旁边那行「共 4,379 部 · 今日更新 56 集」。
///
/// - `site`：站源目录的**作品总量**，来自站源目录首页自己给的数字
///   （黄桃/91短剧/柚子/X短剧/夜社 = 总页数 × 每页条数，剧果/野果 = 站点 total，
///   黄果视频 = 列表页页眉，黄果AI = 各分类 total 之和，禁果 = 一次拉回的全量，
///   黑桃 = 总页数 × 每页条数 + 末页）。站源给不出时是 0，这时退回本地已见数。
/// - `local`：**「全部」分类里见过的作品数**（按 id 去重）。
///   它只累计「全部」目录里出现过的剧，搜索、排行榜、单独切开的分类都不计入，
///   所以往下翻多少就是多少，不会被别的入口撑大。站源给不出总量时才用它。
/// - `updated`：今天观察到「本来就在库里、集数变多了」的增量之和。
///   今天才第一次翻到的剧不算更新（否则往下翻几页就虚增几百集），跨天归零。
/// - `arrived`：今天「全部」第一页里第一次见到的作品数。
///   有些站源的目录列表压根不给集数（野果、91短剧的 JSON 接口），
///   `updated` 对它们永远是 0；这一项是给「顶栏看得出来有没有新东西」兜底的。
///   只统计第一页刷新，翻页、搜索、分类都不计入。
class SourceFacts {
  const SourceFacts({
    this.site = 0,
    this.local = 0,
    this.updated = 0,
    this.arrived = 0,
    this.probed = false,
  });

  final int site;
  final int local;
  final int updated;
  final int arrived;

  /// 这个站源有没有成功观测过（至少拉回来过一页目录）。
  /// 没观测过时不显示任何数字——否则会先闪一下「已收录 24 部」再跳到「共 2,040 部」。
  final bool probed;

  bool get known => site > 0 || local > 0;

  /// 4,379 —— 数量上千后加千分位，扫一眼就知道是「几千部」还是「几十部」。
  static String count(int value) => '$value'.replaceAllMapped(
    RegExp(r'(\d)(?=(\d{3})+$)'),
    (match) => '${match[1]},',
  );

  /// 顶栏第一行：「共 4,379 部」或「已收录 2,051 部」。没数据时返回空串。
  String get headline {
    if (!probed) return '';
    final total = site > 0 ? site : local;
    if (total <= 0) return '';
    return site > 0 ? '共 ${count(total)} 部' : '已收录 ${count(total)} 部';
  }

  /// 顶栏第二行：「今日更新 56 集」「今日更新 12 集 · 新上 4 部」。
  /// 观测过就一直显示，0 也照实说。
  String get detail {
    if (!probed) return '';
    final parts = [
      if (updated > 0) '今日更新 ${count(updated)} 集',
      if (arrived > 0) '新上 ${count(arrived)} 部',
    ];
    if (parts.isEmpty) return '今日更新 0 集';
    return parts.join(' · ');
  }

  /// 单行版本（电视顶栏、无障碍播报用）。
  String get label => [headline, detail].where((part) => part.isNotEmpty).join(' · ');
}

String factsDay(DateTime time) {
  String two(int value) => value.toString().padLeft(2, '0');
  return '${time.year}-${two(time.month)}-${two(time.day)}';
}

/// 「全部」分类里最多记多少个 id。和原生目录缓存的上限一致，
/// 超过就不再往上加，避免第三方站源无限长。
const factsSeenLimit = 5000;

int? _int(Object? value) => value is num ? value.toInt() : null;

/// 某个站源「全部」分类里见过的作品 id，用来接着往下累计。
/// 站源自己给得出总量（`site > 0`）时不存这份名单，省得白占地方。
List<String> readSeen(Map<String, Object?> raw, String source) {
  final row = raw[source];
  if (row is! Map) return const [];
  final list = row['all'];
  if (list is! List) return const [];
  return [
    for (final id in list)
      if (id is String && id.isNotEmpty) id,
  ];
}

/// 从存储的原始表里读某个站源的观测值；跨天自动把「今日更新」归零。
SourceFacts readFacts(
  Map<String, Object?> raw,
  String source, {
  DateTime? now,
}) {
  final row = raw[source];
  if (row is! Map) return const SourceFacts();
  // 2.0.0+123 之前只存了 total（当时等于本地收录数），旧值按 local 读。
  final site = _int(row['site']) ?? 0;
  final local = _int(row['local']) ?? _int(row['total']) ?? 0;
  final updated = row['day'] == factsDay(now ?? DateTime.now())
      ? _int(row['updated']) ?? 0
      : 0;
  final arrived = row['day'] == factsDay(now ?? DateTime.now())
      ? _int(row['arrived']) ?? 0
      : 0;
  return SourceFacts(
    site: site < 0 ? 0 : site,
    local: local < 0 ? 0 : local,
    updated: updated < 0 ? 0 : updated,
    arrived: arrived < 0 ? 0 : arrived,
    // 老数据（2.0.0+123 之前）没有这个标记，但有数字就说明观测过。
    probed: row['probed'] == true || site > 0,
  );
}

/// 把一次观测写回原始表。返回新的表，调用方负责持久化。
///
/// `seen` 是「全部」分类里见过的作品 id；站源自己给得出总量（`site > 0`）时
/// 不存这份名单，因为那时顶栏显示的是站点数字，本地已见数用不上。
Map<String, Object?> writeFacts(
  Map<String, Object?> raw,
  String source, {
  required int site,
  required int local,
  int gained = 0,
  int arrived = 0,
  Iterable<String>? seen,
  DateTime? now,
}) {
  final clock = now ?? DateTime.now();
  final day = factsDay(clock);
  final row = raw[source];
  // 同一天才累加，跨天从 0 重新开始。
  final sameDay = row is Map && row['day'] == day;
  final carried = sameDay ? _int(row['updated']) ?? 0 : 0;
  final updated = carried + (gained > 0 ? gained : 0);
  final carriedArrived = sameDay ? _int(row['arrived']) ?? 0 : 0;
  final arrivedTotal = carriedArrived + (arrived > 0 ? arrived : 0);
  final ids = site > 0 || seen == null
      ? const <String>[]
      : seen.take(factsSeenLimit).toList(growable: false);
  return {
    ...raw,
    source: {
      'day': day,
      'updated': updated < 0 ? 0 : updated,
      'arrived': arrivedTotal < 0 ? 0 : arrivedTotal,
      'site': site < 0 ? 0 : site,
      'local': local < 0 ? 0 : local,
      'probed': true,
      if (ids.isNotEmpty) 'all': ids,
    },
  };
}
