import 'dart:async';
import 'dart:math';

import 'core_bridge.dart';
import 'follow_state.dart';
import 'local_store.dart';
import 'models.dart';

class FollowUpdater {
  FollowUpdater(
    this.repository,
    this.store, {
    this.startDelay = const Duration(seconds: 30),
    this.interval = const Duration(minutes: 30),
    this.recheck = const Duration(hours: 6),
    this.limit = 10,
    DateTime Function()? clock,
  }) : _epoch = store.profileEpoch,
       _clock = clock ?? DateTime.now;

  static const _maxBackoffShift = 3;

  final AppRepository repository;
  final LocalStore store;
  final Duration startDelay;
  final Duration interval;
  final Duration recheck;
  final int limit;
  final DateTime Function() _clock;
  final int _epoch;
  Timer? _timer;
  bool _running = false;
  bool _disposed = false;

  bool get _valid =>
      !_disposed && !store.locked && _epoch == store.profileEpoch;

  /// 已经有一轮核对自己在跑（定时任务或上一次下拉）。界面上别再叠一次。
  bool get running => _running;

  /// 最近一次核对的时间；一部都没核对过返回 null。
  DateTime? get lastCheckedAt {
    DateTime? newest;
    for (final check in store.followChecks.values) {
      if (newest == null || check.checkedAt.isAfter(newest)) {
        newest = check.checkedAt;
      }
    }
    return newest;
  }

  void start() {
    if (_timer != null || !repository.supportsSourceManagement || !_valid) {
      return;
    }
    _timer = Timer(startDelay, () {
      _timer = Timer.periodic(interval, (_) => _tick());
      _tick();
    });
  }

  void _tick() => unawaited(run().catchError((Object _) {}));

  List<Drama> _due(Map<String, FollowCheck> checks) {
    final now = _clock();
    final never = DateTime.fromMillisecondsSinceEpoch(0);
    final items = store.favorites.where((drama) {
      if (const {'finished', 'completed'}.contains(drama.releaseStatus)) {
        return false;
      }
      final check = checks[drama.id];
      return check == null ||
          !now.isBefore(
            check.checkedAt.add(
              recheck * (1 << min(check.failures, _maxBackoffShift)),
            ),
          );
    }).toList();
    items.sort(
      (a, b) => (checks[a.id]?.checkedAt ?? never).compareTo(
        checks[b.id]?.checkedAt ?? never,
      ),
    );
    return items.take(limit).toList();
  }

  Future<void> run() async {
    if (_running || !_valid) return;
    _running = true;
    try {
      final checks = store.followChecks;
      final updates = <Drama>[];
      for (final drama in _due(checks)) {
        if (!_valid) return;
        try {
          updates.add(await repository.followCheck(drama));
          checks[drama.id] = FollowCheck(_clock());
        } catch (_) {
          checks[drama.id] = FollowCheck(
            _clock(),
            failures: (checks[drama.id]?.failures ?? 0) + 1,
          );
        }
      }
      if (!_valid) return;
      if (updates.isNotEmpty) await store.refreshDramas(updates);
      await store.saveFollowChecks(checks, epoch: _epoch);
    } finally {
      _running = false;
    }
  }

  /// 用户在追剧页下拉刷新：不等 6 小时的复查间隔，把追剧逐部重新核对一遍。
  ///
  /// 一部一部来（站源详情接口本来就慢），超过 [budget] 就收手，剩下的交给
  /// 定时任务。返回 true 表示这一轮至少成功核对了一部，界面据此决定要不要
  /// 提示「没刷到」。
  ///
  /// [force] 为假时用于「切换到底栏追剧」这种顺手动作：刚核对过 [staleAfter]
  /// 以内就什么都不做，免得来回切栏目把站源全打一遍。
  Future<bool> refresh({
    Duration budget = const Duration(seconds: 25),
    bool force = true,
    Duration staleAfter = const Duration(minutes: 5),
  }) async {
    // 已经有一轮在跑：不是失败，别让界面弹「没核对成功」。
    if (_running) return true;
    if (!_valid) return false;
    final items = store.favorites.toList();
    if (items.isEmpty) return true;
    if (!force) {
      final last = lastCheckedAt;
      if (last != null && _clock().difference(last) < staleAfter) return true;
    }
    _running = true;
    var checked = 0;
    try {
      final checks = store.followChecks;
      final updates = <Drama>[];
      final deadline = _clock().add(budget);
      for (final drama in items) {
        if (!_valid || _clock().isAfter(deadline)) break;
        try {
          updates.add(await repository.followCheck(drama));
          checks[drama.id] = FollowCheck(_clock());
          checked++;
        } catch (_) {
          checks[drama.id] = FollowCheck(
            _clock(),
            failures: (checks[drama.id]?.failures ?? 0) + 1,
          );
        }
      }
      if (!_valid) return false;
      if (updates.isNotEmpty) await store.refreshDramas(updates);
      await store.saveFollowChecks(checks, epoch: _epoch);
    } finally {
      _running = false;
    }
    return checked > 0;
  }

  void dispose() {
    _disposed = true;
    _timer?.cancel();
  }
}
