import 'dart:async';

import 'package:flutter/foundation.dart';

import 'core_bridge.dart';
import 'background_keepalive.dart';
import 'local_store.dart';
import 'models.dart';

/// 底栏「我的」胶囊上写什么。
///
/// 失败集最要紧，一律用感叹号盖过「还有几集在下载」的数字；没有失败时回到
/// 原来的在下载计数，两边都没有就不显示徽标（2.0.0+159 反馈）。
String? downloadBadgeLabel({required int failed, required int active}) {
  if (failed > 0) return '!';
  if (active > 0) return active > 99 ? '99+' : '$active';
  return null;
}

class DownloadOverview extends ChangeNotifier {
  DownloadOverview(this.repository, this.store, {this.interval = _interval}) {
    store.addListener(_sync);
    _sync();
  }

  static const _interval = Duration(seconds: 2);
  final AppRepository repository;
  final LocalStore store;
  final Duration interval;
  Timer? _timer;
  int? _epoch;
  int _request = 0;
  bool _loading = false;
  bool _disposed = false;
  List<DownloadJob> _jobs = const [];

  bool get available => store.canDownload && repository.supportsDownloads;
  List<DownloadJob> get jobs => _jobs;
  int get active => _jobs.where((job) => job.active || job.converting).length;
  int get completed => _jobs.where((job) => job.completed).length;

  /// 失败集数：底栏「我的」胶囊有失败时改用感叹号提醒（2.0.0+159 反馈）。
  int get failed => _jobs.where((job) => job.state == 'failed').length;
  int get completedBytes => _jobs
      .where((job) => job.completed)
      .fold(0, (total, job) => total + job.bytes);

  /// 正在下载 / 处理的任务一共写了多少字节。
  int get activeBytes => _jobs
      .where((job) => job.active || job.converting)
      .fold(0, (total, job) => total + job.bytes);

  /// 当前下载速度（字节/秒），平滑过的。
  ///
  /// 原生只给「已下载多少字节」，没有速度字段：这里用两次轮询之间
  /// [activeBytes] 的增量除以真实间隔算瞬时值，再用 EMA 抹平 —— 直接用瞬时值
  /// 会随着分片落盘一跳一跳的，看着像心电图。
  double get speed => _speed;
  double _speed = 0;

  /// 每个任务自己的速度（字节/秒），键是任务 id。下载页把它显示在卡片上
  /// （2.0.0+156 按反馈从标题行挪到卡片）。同样用轮询增量 + EMA。
  double speedOf(DownloadJob job) => _jobSpeeds[job.id] ?? 0;
  final _jobSpeeds = <String, double>{};
  final _sampleJobBytes = <String, int>{};

  int _sampleBytes = 0;
  DateTime? _sampleAt;

  void _measure() {
    final now = DateTime.now();
    final at = _sampleAt;
    final seconds = at == null
        ? 0.0
        : now.difference(at).inMilliseconds / 1000;
    _sampleAt = now;
    // 只统计「正在下载」的：排队中的不动，处理中的（转码）也不该算网速。
    final running = [
      for (final job in _jobs)
        if (job.state == 'downloading') job,
    ];
    if (at == null || seconds <= 0) {
      _sampleBytes = activeBytes;
      for (final job in running) {
        _sampleJobBytes[job.id] = job.bytes;
      }
      return;
    }
    var total = 0.0;
    final next = <String, double>{};
    for (final job in running) {
      final before = _sampleJobBytes[job.id];
      final delta = before == null ? 0 : job.bytes - before;
      // 没有增长（暂停、刚好都在等响应）就归零，不显示一个假速度。
      final instant = delta > 0 ? delta / seconds : 0.0;
      final previous = _jobSpeeds[job.id] ?? 0;
      final value = instant <= 0
          ? 0.0
          : previous <= 0
          ? instant
          : previous * 0.6 + instant * 0.4;
      next[job.id] = value;
      total += value;
    }
    _sampleJobBytes
      ..clear()
      ..addAll({for (final job in running) job.id: job.bytes});
    _jobSpeeds
      ..clear()
      ..addAll(next);
    _speed = total;
    _sampleBytes = activeBytes;
  }

  /// 速度的指纹：卡片上显示的是取整后的值，按显示精度比较，避免每 2 秒白重建。
  String _speedKey() => [
    for (final entry in _jobSpeeds.entries)
      if (entry.value > 0) '${entry.key}:${(entry.value / 1024).round()}',
  ].join(',');

  DownloadJob? get current =>
      _jobs.where((job) => job.state == 'downloading').firstOrNull ??
      _jobs.where((job) => job.active).firstOrNull;

  void _sync() {
    if (!available) {
      _stop();
      return;
    }
    if (_epoch != store.profileEpoch) {
      _epoch = store.profileEpoch;
      _request++;
      _loading = false;
      _replace(const []);
    }
    if (_timer == null) {
      _timer = Timer.periodic(interval, (_) => refresh());
      refresh();
    }
  }

  void _stop() {
    _timer?.cancel();
    _timer = null;
    _epoch = null;
    _request++;
    _loading = false;
    _resetSpeed();
    _replace(const []);
  }

  void _resetSpeed() {
    _speed = 0;
    _jobSpeeds.clear();
    _sampleJobBytes.clear();
    _sampleBytes = 0;
    _sampleAt = null;
  }

  static String _signature(List<DownloadJob> jobs) => [
    for (final job in jobs)
      '${job.id}|${job.state}|${job.progress}|${job.bytes}|${job.total}|'
          '${job.actualQuality}|${job.error}|${job.drama.title}',
  ].join('\n');

  void _replace(List<DownloadJob> jobs) {
    if (identical(jobs, _jobs) || _signature(jobs) == _signature(_jobs)) {
      return;
    }
    _jobs = jobs;
    // iOS：有下载/处理在跑就向系统要后台时间，跑完立刻还回去（见
    // background_keepalive.dart）。以前这里只能提示用户保持前台。
    if (jobs.any((job) => job.active || job.converting)) {
      unawaited(BackgroundKeepAlive.hold());
    } else {
      unawaited(BackgroundKeepAlive.release());
    }
    if (!_disposed) notifyListeners();
  }

  Future<void> refresh() async {
    if (_loading || !available) return;
    _loading = true;
    final request = _request;
    try {
      final jobs = await repository.downloads();
      if (!_disposed && request == _request) {
        final before = _speedKey();
        _replace(jobs);
        // 速度要每次轮询都算（字节没变就归零），不能只在数据变化时才采样。
        _measure();
        // 只有速度真的变了才通知：任务没动的时候别让界面每 2 秒白重建一次。
        if (!_disposed && _speedKey() != before) notifyListeners();
      }
    } catch (_) {
    } finally {
      if (request == _request) _loading = false;
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    store.removeListener(_sync);
    super.dispose();
  }
}
