import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:window_manager/window_manager.dart';

import 'app_device.dart';
import 'core_bridge.dart';
import 'diary_service.dart';
import 'local_files.dart';
import 'local_store.dart';
import 'picture_in_picture.dart';
import 'portable_data.dart';
import 'ui/app.dart';
import 'ui/theme/app_theme.dart';
import 'window_frame.dart';
import 'window_on_top.dart';
import 'windows_data_migration.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isAndroid) {
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setSystemUIOverlayStyle(AppTheme.systemBars(Brightness.dark));
  }
  if (Platform.isWindows) {
    enablePortableData();
    if (portableDataPath == null) await migrateWindowsData();
    await windowManager.ensureInitialized();
    await rememberWindowFrame();
  }
  if (Platform.isMacOS) {
    await windowManager.ensureInitialized();
    try {
      await windowManager.waitUntilReadyToShow(
        const WindowOptions(
          size: Size(1280, 800),
          minimumSize: desktopMinimumSize,
          center: true,
        ),
        () async {
          await rememberWindowFrame();
          await windowManager.show();
        },
      );
    } catch (_) {}
  }
  if (Platform.isWindows || Platform.isMacOS) await restoreWindowOnTop();
  MediaKit.ensureInitialized();
  final device = await AppDevice.detect();
  final rendering = Platform.isAndroid
      ? ', 渲染: ${await AppDevice.compatibleRendering() ? 'skia' : 'impeller'}'
      : '';
  DiaryService.add(
    '[App] 应用启动，版本: ${device.version}, '
    '平台: ${Platform.operatingSystem}$rendering',
  );
  runApp(AppBootstrap(device: device));
}

class AppBootstrap extends StatefulWidget {
  const AppBootstrap({super.key, this.device = const AppDevice()});
  final AppDevice device;
  @override
  State<AppBootstrap> createState() => _AppBootstrapState();
}

class _AppBootstrapState extends State<AppBootstrap>
    with WidgetsBindingObserver {
  final repository = NativeRepository();
  LocalStore? store;
  Object? error;
  late AppDevice device = widget.device;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initialize();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    store?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    DiaryService.add('[App] 生命周期：${state.name}');
    if (state == AppLifecycleState.resumed && Platform.isAndroid) {
      unawaited(_refreshDevice());
    }
    if (!Platform.isIOS) return;
    // 切后台（paused）不再暂停下载：静音保活的目的就是让下载在后台继续跑，
    // 这里再 pauseAll 等于自己把保活成果废掉，回前台又没有任何 resume，
    // 用户看到的就是「切到后台再回来，下载还是暂停」（+161 反馈）。
    // 只有 detached（App 被划掉/终止）才暂停——iOS 不允许绕过系统终止，
    // 此时暂停并写回断点，下次进来可续。
    if (state == AppLifecycleState.detached) {
      unawaited(
        NativeRepository(
          background: true,
        ).controlDownloads('pauseAll').catchError((Object error) {
          DiaryService.add('[App] 退出时暂停下载失败：$error');
        }),
      );
    }
  }

  Future<void> _refreshDevice() async {
    final detected = await AppDevice.detect(fallback: device);
    if (!mounted ||
        (device.television == detected.television &&
            device.version == detected.version)) {
      return;
    }
    setState(() => device = detected);
  }

  Future<void> _initialize() async {
    setState(() => error = null);
    try {
      final preferences = await SharedPreferences.getInstance();
      await _refreshDevice();
      await repository.initialize();
      final support = await getApplicationSupportDirectory();
      final local = await LocalStore.open(
        preferences,
        LocalFiles(Directory(path.join(support.path, 'store'))),
      );
      if (!mounted) return;
      setState(() {
        store = local;
        repository.access = local;
      });
    } catch (failure) {
      if (mounted) setState(() => error = failure);
    }
  }

  @override
  Widget build(BuildContext context) => DuanjuApp(
    repository: repository,
    store: store,
    bootstrapError: error?.toString(),
    onRetry: _initialize,
    television: device.television,
    version: device.version,
  );
}
