/// 站源观测量：顶栏标题旁边那行「共 4,379 部」+ 下面一行「今日更新 56 集」。
///
/// - `site`：站源目录的**作品总量**，来自站源目录首页自己给的数字
///   （黄桃/91短剧/柚子/X短剧/夜社 = 总页数 × 每页条数，剧果/野果 = 站点 total，
///   黄果视频 = 列表页页眉，黄果AI = 各分类 total 之和，禁果 = 一次拉回的全量，
///   黑桃 = 总页数 × 每页条数 + 末页）。站源给不出时是 0，这时退回本地已见数。
/// - `local`：**「全部」分类里见过的作品数**（按 id 去重）。
///   它只累计「全部」目录里出现过的剧，搜索、排行榜、单独切开的分类都不计入，
///   所以往下翻多少就是多少，不会被别的入口撑大。站源给不出总量时才用它。
/// - `updated`：今天观察到「本来就在库里、集数变多了」的增量之和。
///   今天才第一次翻到的剧不算更新（否则往下翻几页就虚增几百集），跨天归零。
/// - `listed`：**翻到底那一次实际列出了多少部独立作品**。
///   站源声明的总量普遍有水分：分页型站源按「总页数 × 每页条数」报，
///   末页不满就被多算；另一些站源把已下架的作品也算在里面。
///   翻到底时用真实条数把顶栏和列表底部对齐。
///
///   2.0.0+148 一度不落盘（怕旧值永远压过站点声明）；2.0.0+154 按反馈改成
///   **落盘但一定会重测**：进站先显示上次实测值（X短剧 2,180 → 2,169 这种
///   声明虚高的站源，一进站就该看到真实数字），随后
///   - 没测过 / 距上次超过 [listedFreshFor] / 站点声明变了 → 后台重测一遍；
///   - 「全部」翻到底时把分类里藏着的作品并进来，重测的就是补齐后的部数。
///   所以它不会再像 +148 那样「永远不动」。
/// - `arrived`：**已废弃，恒为 0**。原来记「今天第一次见到的作品数」，用来在
///   顶栏显示「新上 N 部」；但站点第一页每次都换新作品、落盘名单又只能留 1500 条，
///   数字每刷一次涨一次（真机上能涨到 26 万，大过「共 N 部」），2.0.0+137 删掉了。
///
/// 第二行的口径对所有站源统一：永远是「今日更新 N 集」，没有就写 0，
/// 不再出现「黄果视频两项、黄桃只有一项」这种不一致。
class SourceFacts {
  const SourceFacts({
    this.site = 0,
    this.local = 0,
    this.updated = 0,
    this.arrived = 0,
    this.listed = 0,
    this.probed = false,
  });

  final int site;
  final int local;
  final int updated;
  final int arrived;

  /// 翻到底时实际列出的条数（0 = 还没测过）。
  final int listed;

  /// 这个站源有没有成功观测过（至少拉回来过一页目录）。
  /// 没观测过时不显示任何数字——否则会先闪一下「已收录 24 部」再跳到「共 2,040 部」。
  final bool probed;

  bool get known => site > 0 || local > 0 || listed > 0;

  /// 只改其中几项，其余原样带过来。
  ///
  /// 顶栏那一行有 6 个字段、更新点有七八处，早先每处都手写一遍构造：
  /// 谁忘了带 `listed`，顶栏就会莫名其妙退回站点声明（+148/+150 都栽过）。
  SourceFacts copyWith({
    int? site,
    int? local,
    int? updated,
    int? arrived,
    int? listed,
    bool? probed,
  }) => SourceFacts(
    site: site ?? this.site,
    local: local ?? this.local,
    updated: updated ?? this.updated,
    arrived: arrived ?? this.arrived,
    listed: listed ?? this.listed,
    probed: probed ?? this.probed,
  );

  /// 顶栏那行「共 N 部」。口径 = **独立作品数**（2.0.0+150 重新定死）：
  ///
  /// | 位置 | 含义 |
  /// |---|---|
  /// | 顶栏 | 站点所有作品数（各分类相加、去重，不含重复作品） |
  /// | 列表底部 | 拉到底时一共加载过的作品数 |
  /// | 末位卡片 | 作品总数（连续序号，与上面两个同一个数） |
  ///
  /// 三者必须相等，而且数字要跟真正摆出来的作品对得上。
  ///
  /// 所以 [listed]（翻到底实际列出的独立条数）优先。它只在本次会话里有效
  /// （见 ExploreFeed 的 `_listed`），切站源或刷新就作废重算，站点上新作品
  /// 之后这个数才跟着涨。
  ///
  /// 没翻到底才用站点声明 [site] 当预期值。**绝不能反过来让声明压过实测**：
  /// 站点声明的口径常常是「页数 × 每页」（野果声明 1,401，实际最后一张卡是
  /// 第 1,401 部；少一页就变成「顶栏 1,401、末位卡片 1,388」），或者把重复
  /// 作品算两遍（夜社·海外短剧声明 2,166，独立作品只有 2,156）。+149 试过
  /// 一律信声明，结果三数大乱。
  int get total {
    if (listed > 0) return listed;
    if (site > 0) return site;
    return local;
  }

  /// 4,379 —— 数量上千后加千分位，扫一眼就知道是「几千部」还是「几十部」。
  static String count(int value) => '$value'.replaceAllMapped(
    RegExp(r'(\d)(?=(\d{3})+$)'),
    (match) => '${match[1]},',
  );

  /// 顶栏第一行：「共 4,379 部」或「已收录 2,051 部」。没数据时返回空串。
  String get headline {
    if (!probed) return '';
    final value = total;
    if (value <= 0) return '';
    return site > 0 || listed > 0
        ? '共 ${count(value)} 部'
        : '已收录 ${count(value)} 部';
  }

  /// 顶栏第二行：只留「今日更新 N 集」。
  ///
  /// 「新上 N 部」在 2.0.0+137 删掉了：站点第一页按更新时间排，每刷一次就有新作品
  /// 挤上来，落盘的名单又只留得住 1500 条，数字于是越刷越大，最后能大过「共 N 部」。
  /// 显示不出来就别显示，也不再用它给首页排序。
  String get detail {
    if (!probed) return '';
    return '今日更新 ${count(updated)} 集';
  }

  String get updatesLabel => probed ? '今日更新 ${count(updated)} 集' : '';

  /// 单行版本（电视顶栏、无障碍播报用）。
  String get label => [headline, detail].where((part) => part.isNotEmpty).join(' · ');
}

String factsDay(DateTime time) {
  String two(int value) => value.toString().padLeft(2, '0');
  return '${time.year}-${two(time.month)}-${two(time.day)}';
}

/// 每个站源记多少个「见过的作品 id」。只用来判断「这一部我今天以前见过没有」，
/// 记第一页到前几十页足够，记太多会把偏好存储撑肿。
const factsSeenLimit = 1500;

/// 每个站源记多少部剧的集数快照（用来算「今日更新」）。
/// 目录第一页每部都记，一千多部足够覆盖常用的几个分类入口。
const factsEpisodeLimit = 1200;

/// 今天优先显示的作品 id 记多少个。
const factsFreshLimit = 240;

int? _int(Object? value) => value is num ? value.toInt() : null;

/// 某个站源「全部」分类里见过的作品 id，用来接着往下累计。
List<String> readKnown(Map<String, Object?> raw, String source) =>
    _stringList(raw, source, 'all');

List<String> readFresh(Map<String, Object?> raw, String source, {DateTime? now}) {
  final row = raw[source];
  if (row is! Map) return const [];
  if (row['day'] != factsDay(now ?? DateTime.now())) return const [];
  return _stringList(raw, source, 'fresh');
}

List<String> _stringList(Map<String, Object?> raw, String source, String key) {
  final row = raw[source];
  if (row is! Map) return const [];
  final list = row[key];
  if (list is! List) return const [];
  return [
    for (final id in list)
      if (id is String && id.isNotEmpty) id,
  ];
}

/// 某个站源上次看到的「剧 id → 集数」。只记集数大于 0 的条目：
/// 站点不给集数的剧本来就无法比较，记下来只会白占地方。
Map<String, int> readEpisodes(Map<String, Object?> raw, String source) {
  final row = raw[source];
  if (row is! Map) return <String, int>{};
  final map = row['ep'];
  if (map is! Map) return <String, int>{};
  final out = <String, int>{};
  for (final entry in map.entries) {
    final key = entry.key;
    final value = _int(entry.value);
    if (key is String && key.isNotEmpty && value != null && value > 0) {
      out[key] = value;
    }
  }
  return out;
}

/// 这个站源有没有做过第一次基线观测。没做过时第一页整页都会被当成「新上」，
/// 得先安静地把名单和集数存下来，下次开始才算增量。
bool readSeeded(Map<String, Object?> raw, String source) {
  final row = raw[source];
  return row is Map && row['seeded'] == true;
}

/// 实测条数在多长时间内算「刚测过」。超过就重新量一遍。
const listedFreshFor = Duration(minutes: 30);

/// 分类补齐扫过一遍之后，多久之内不重复扫（X短剧这种声明虚高、
/// 分类里其实没藏东西的站源，别每次刷新都白扫一百多页）。
const sweptFreshFor = Duration(hours: 12);

/// 上次实测的结果：部数、什么时候测的、上次扫完分类是什么时候。
typedef ListedStats = ({int listed, DateTime? at, DateTime? swept});

ListedStats readListedStats(Map<String, Object?> raw, String source) {
  final row = raw[source];
  if (row is! Map) return (listed: 0, at: null, swept: null);
  DateTime? time(Object? value) {
    final ms = _int(value);
    return ms == null || ms <= 0
        ? null
        : DateTime.fromMillisecondsSinceEpoch(ms);
  }

  final listed = _int(row['listed']) ?? 0;
  return (
    listed: listed < 0 ? 0 : listed,
    at: time(row['listedAt']),
    swept: time(row['swept']),
  );
}

/// 把实测结果写回原始表（只动这三个键，别的观测值原样保留）。
Map<String, Object?> writeListedStats(
  Map<String, Object?> raw,
  String source, {
  required int listed,
  DateTime? swept,
  DateTime? now,
  int? keepSwept,
}) {
  final clock = now ?? DateTime.now();
  final row = raw[source];
  final base = row is Map
      ? Map<String, Object?>.from(row)
      : <String, Object?>{};
  final previous = _int(base['swept']) ?? 0;
  return {
    ...raw,
    source: {
      ...base,
      'listed': listed < 0 ? 0 : listed,
      'listedAt': clock.millisecondsSinceEpoch,
      if (swept != null)
        'swept': swept.millisecondsSinceEpoch
      else if (keepSwept == null && previous > 0)
        'swept': previous,
    },
  };
}

/// 从存储的原始表里读某个站源的观测值；跨天自动把「今日更新 / 新上」归零。
SourceFacts readFacts(
  Map<String, Object?> raw,
  String source, {
  DateTime? now,
}) {
  final row = raw[source];
  if (row is! Map) return const SourceFacts();
  // 2.0.0+123 之前只存了 total（当时等于本地收录数），旧值按 local 读。
  final site = _int(row['site']) ?? 0;
  final local = _int(row['local']) ?? _int(row['total']) ?? 0;
  final today = row['day'] == factsDay(now ?? DateTime.now());
  final updated = today ? _int(row['updated']) ?? 0 : 0;
  final arrived = today ? _int(row['arrived']) ?? 0 : 0;
  final listed = _int(row['listed']) ?? 0;
  return SourceFacts(
    site: site < 0 ? 0 : site,
    local: local < 0 ? 0 : local,
    updated: updated < 0 ? 0 : updated,
    arrived: arrived < 0 ? 0 : arrived,
    // 2.0.0+154 起重新认这个数：它只是「进站先显示的数字」，随后一定会重测。
    listed: listed < 0 ? 0 : listed,
    // 老数据（2.0.0+123 之前）没有这个标记，但有数字就说明观测过。
    probed: row['probed'] == true || site > 0 || _int(row['listed']) != null,
  );
}

/// 把一次观测写回原始表。返回新的表，调用方负责持久化。
///
/// `known` 是「全部」里见过的作品 id（判「新上」用），`episodes` 是上次看到的
/// 集数（判「今日更新」用），`fresh` 是今天变化过的作品 id（首页优先显示用）。
/// 这三份都由上层维护，这里只负责裁剪长度后落盘。
Map<String, Object?> writeFacts(
  Map<String, Object?> raw,
  String source, {
  required int site,
  required int local,
  int gained = 0,
  int arrived = 0,
  Iterable<String>? known,
  Map<String, int>? episodes,
  Iterable<String>? fresh,
  bool seeded = true,
  DateTime? now,
}) {
  final clock = now ?? DateTime.now();
  final day = factsDay(clock);
  final row = raw[source];
  // 同一天才累加，跨天从 0 重新开始。
  final sameDay = row is Map && row['day'] == day;
  final carried = sameDay ? _int(row['updated']) ?? 0 : 0;
  final updated = carried + (gained > 0 ? gained : 0);
  // 「新上」已经不再统计（顶栏那一行删了），这里一律写 0，
  // 顺手把历史遗留的大数字（有的站存过 26 万）一并清掉。
  final arrivedTotal = 0;
  final ids = _tail(known, factsSeenLimit);
  final freshIds = _tail(fresh, factsFreshLimit);
  final snapshot = <String, int>{};
  if (episodes != null) {
    // 只保留最后写进来的若干条：Map 保持插入顺序，越靠前越旧。
    final keys = episodes.keys.toList(growable: false);
    final start = keys.length > factsEpisodeLimit ? keys.length - factsEpisodeLimit : 0;
    for (var index = start; index < keys.length; index++) {
      final key = keys[index];
      final value = episodes[key];
      if (value != null && value > 0) snapshot[key] = value;
    }
  }
  return {
    ...raw,
    source: {
      'day': day,
      'updated': updated < 0 ? 0 : updated,
      'arrived': arrivedTotal < 0 ? 0 : arrivedTotal,
      'site': site < 0 ? 0 : site,
      'local': local < 0 ? 0 : local,
      'probed': true,
      // 实测条数 / 上次扫分类的时间由 [writeListedStats] 维护，这里必须原样带回来：
      // 整行是重建的，漏带就等于每次观测都把顶栏的实测值洗掉（+148 的「顶栏
      // 又掉回站点声明」就是这么来的）。
      if (_int(row is Map ? row['listed'] : null) case final value?
          when value > 0)
        'listed': value,
      if (_int(row is Map ? row['listedAt'] : null) case final value?
          when value > 0)
        'listedAt': value,
      if (_int(row is Map ? row['swept'] : null) case final value? when value > 0)
        'swept': value,
      if (seeded) 'seeded': true,
      if (ids.isNotEmpty) 'all': ids,
      if (snapshot.isNotEmpty) 'ep': snapshot,
      if (freshIds.isNotEmpty) 'fresh': freshIds,
    },
  };
}

List<String> _tail(Iterable<String>? values, int limit) {
  if (values == null) return const [];
  final list = [
    for (final value in values)
      if (value.isNotEmpty) value,
  ];
  if (list.length <= limit) return list;
  return list.sublist(list.length - limit);
}
