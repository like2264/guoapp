import 'dart:async';

import 'package:flutter/material.dart';

import 'core_bridge.dart';
import 'models.dart';

/// 选集面板上的「本剧总时长」：把每一集的时长加起来。
///
/// 站点的详情接口几乎都不带每集时长，只能按集解析一次播放列表（HLS 的
/// #EXTINF 求和，或者模块自己给的 durationMs）。因此这里分批向原生要，
/// 边拿边报进度；原生侧按「剧 → 分集」落盘缓存，第二次打开详情页直接读
/// 缓存，不再联网。
///
/// 集数变了（站点上新）会重新统计一遍：已经缓存的集直接命中，只补新增的。
class EpisodeDurations extends ChangeNotifier {
  EpisodeDurations(this.repository, this.drama);

  final AppRepository repository;
  final Drama drama;

  /// 一批问多少集：太小会把一次统计拆成太多次往返，太大则单次等待变长、
  /// 进度条一次跳一大截。十来集一批，手机上大约两三秒一跳。
  static const _batchSize = 12;

  final Map<String, int> _durations = {};
  List<Episode> _episodes = const [];
  String _signature = '';
  int _known = 0;
  int _generation = 0;
  bool _running = false;
  bool _stalled = false;
  int _emptyBatches = 0;
  bool _disposed = false;

  /// 当前统计的分集数。
  int get episodes => _episodes.length;

  /// 已经有常长的集数。
  int get known => _known;

  /// 还在统计中。
  bool get running => _running;

  /// 一集都还没量到、正在挨集问站点 —— 选集面板右上角要转圈的那种状态。
  bool get counting => _running && _known == 0 && !_stalled;

  /// 拿到的所有集时长之和（毫秒）。
  int get totalMs {
    var total = 0;
    for (final episode in _episodes) {
      total += _durations[episode.id] ?? 0;
    }
    return total;
  }

  /// 选集面板右上角那一行字；还没拿到任何一集时长时返回 null（不占位）。
  String? get summary {
    if (_episodes.isEmpty) return null;
    // +173：一批解析失败（站点偶发 403）不该让已经显示的「统计中」整块消失——
    // 用户反馈「显示出统计中又很快没了，回头再进又有」。保留文案，直到确实
    // 统计到至少一集、或这一轮被新列表取代。
    if (_known == 0) return '总时长 统计中…';
    final text = '总时长 ${formatDuration(totalMs)}';
    if (_known >= _episodes.length) return text;
    // 有集拿不到时长（站点没给、或这一集解析失败）：把「统计了几集」摆出来，
    // 免得用户把这个偏小的数当成作品本身的总时长。
    return '$text（$_known/${_episodes.length} 集）';
  }

  /// 分集列表变了才重新统计；同一份列表反复 sync 不重复发请求。
  void sync(List<Episode> episodes) {
    // 没有分集 ID 的集没法按集取时长（也认不出是哪一集），直接不参与统计。
    final usable = [
      for (final episode in episodes)
        if (episode.id.isNotEmpty) episode,
    ];
    final signature = usable.isEmpty
        ? '0'
        : '${usable.length}:${usable.first.id}:${usable.last.id}';
    if (signature == _signature) return;
    _signature = signature;
    _episodes = List<Episode>.unmodifiable(usable);
    _known = _episodes.where((episode) => _has(episode)).length;
    _stalled = false;
    _emptyBatches = 0;
    final generation = ++_generation;
    _notify();
    if (_episodes.isEmpty) {
      _running = false;
      return;
    }
    if (_known >= _episodes.length) {
      _running = false;
      return;
    }
    unawaited(_probe(generation));
  }

  bool _has(Episode episode) => (_durations[episode.id] ?? 0) > 0;

  Future<void> _probe(int generation) async {
    _running = true;
    _notify();
    final queue = [
      for (final episode in _episodes)
        if (!_has(episode)) episode,
    ];
    while (queue.isNotEmpty && _alive(generation)) {
      final batch = queue.take(_batchSize).toList();
      Map<String, int> got = const {};
      try {
        got = await repository.chapterDurations(drama, batch);
      } catch (_) {
        got = const {};
      }
      if (!_alive(generation)) return;
      queue.removeRange(0, batch.length);
      var found = 0;
      for (final episode in batch) {
        final duration = got[episode.id] ?? 0;
        if (duration > 0) {
          _durations[episode.id] = duration;
          found++;
        }
      }
      _known = _episodes.where(_has).length;
      // +173：站点偶发 403/超时会让某一批全 0，原先直接 stall 并熄掉「统计中」，
      // 过一阵再进才恢复。改成连续两批全 0 才判定站点不通，单批失败继续往下试，
      // 显著提升一次打开就统计完的概率；真不通时仍会在第二批后停下，不死磕。
      if (found == 0 && queue.isNotEmpty) {
        _emptyBatches++;
        if (_emptyBatches >= 2) {
          _stalled = true;
          break;
        }
      } else {
        _emptyBatches = 0;
      }
      _notify();
    }
    // 期间如果又 sync 了一份新列表，收尾交给新的那一轮，别把它的「统计中」熄掉。
    if (!_alive(generation)) return;
    _running = false;
    _notify();
  }

  bool _alive(int generation) => !_disposed && generation == _generation;

  void _notify() {
    if (_disposed) return;
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _generation++;
    super.dispose();
  }
}

/// 时长按用户要的口径写成「125 mins 30 s」。
String formatDuration(int milliseconds) {
  final seconds = (milliseconds / 1000).round();
  return '${seconds ~/ 60} mins ${seconds % 60} s';
}

/// 选集栏上那一行「总时长 …」。
///
/// 2.0.0+156 按反馈改回 +151 的样子：标题下面单独一行，纯文字，没有转圈。
/// 统计中显示「统计中…」，全部集数都拿到就只留最终数字；一集都拿不到时整块不占位，
/// 免得给用户一个「0 mins 0 s」的假数字。
class EpisodeDurationLabel extends StatelessWidget {
  const EpisodeDurationLabel({super.key, required this.stats, this.fontSize});

  final EpisodeDurations stats;
  final double? fontSize;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: stats,
    builder: (context, _) {
      final text = stats.summary;
      if (text == null) return const SizedBox.shrink();
      return Text(
        text,
        style: TextStyle(
          fontSize: fontSize,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      );
    },
  );
}
