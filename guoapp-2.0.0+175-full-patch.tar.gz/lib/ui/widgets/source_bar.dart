import 'package:flutter/material.dart';

import '../../source_color.dart';
import '../app_scope.dart';
import 'bar_button.dart';
import 'page_header.dart';
import 'search_field.dart';

class SourceBar extends StatelessWidget {
  const SourceBar({
    super.key,
    required this.source,
    required this.onSwitchSource,
    required this.onOpenSearch,
    required this.onSearchSubmitted,
    this.subtitle = '',
    this.subtitleLines = const [],
    this.note = '',
    this.searchController,
    this.televisionLeading,
    this.leading = const [],
    this.actions = const [],
    this.stretch = false,
    this.noteColor,
  });
  final List<Widget> leading;
  final String source;

  /// 站源名旁边那行小字：已收录多少部、今天更新多少集。
  final String subtitle;

  /// 同样的信息拆成两行（上「共 N 部」、下「今日更新 M 集」）。
  /// 手机和平板顶栏宽度有限，一行放不下会被截断。
  final List<String> subtitleLines;

  /// 标题行右侧的补充（「共 4,379 部」）。
  final String note;
  final void Function(BuildContext anchor) onSwitchSource;
  final VoidCallback onOpenSearch;
  final ValueChanged<String> onSearchSubmitted;
  final TextEditingController? searchController;
  final Widget? televisionLeading;
  final List<Widget> actions;

  /// 玻璃拉成长条，把右侧按钮一起装进去（发现页用）。
  final bool stretch;

  /// 「共 N 部」的颜色。
  final Color? noteColor;

  @override
  Widget build(BuildContext context) {
    final form = AppScope.formFactorOf(context);
    final titleColor = sourceColor(context, source);
    final hint = '在 $source 中搜索';
    // 电视只有一行位置，把两行合成「共 N 部 · 今日更新 M 集」。
    final tvNote = subtitleLines.isEmpty
        ? subtitle
        : subtitleLines.where((line) => line.isNotEmpty).join(' · ');
    final switcher = Builder(
      builder: (anchor) => BarButton(
        icon: Icons.public_rounded,
        tooltip: '切换站源',
        onPressed: () => onSwitchSource(anchor),
      ),
    );
    final search = BarButton(
      icon: Icons.search_rounded,
      tooltip: hint,
      onPressed: onOpenSearch,
    );
    return switch (form) {
      FormFactor.phone => PageHeader(
        title: source,
        titleColor: titleColor,
        subtitle: subtitle,
        subtitleLines: subtitleLines,
        note: note,
        stretch: stretch,
        noteColor: noteColor,
        actions: [...leading, switcher, search, ...actions],
      ),
      FormFactor.pad || FormFactor.window => PageHeader(
        title: source,
        titleColor: titleColor,
        subtitle: subtitle,
        subtitleLines: subtitleLines,
        note: note,
        stretch: stretch,
        noteColor: noteColor,
        actions: [
          ...leading,
          switcher,
          const SizedBox(width: 4),
          SizedBox(
            width: MediaQuery.sizeOf(context).width >= 900 ? 320 : 240,
            child: SearchField(
              hint: hint,
              controller: searchController,
              onSubmitted: onSearchSubmitted,
            ),
          ),
          const SizedBox(width: 4),
          ...actions,
        ],
      ),
      FormFactor.television => SizedBox(
        height: 48,
        child: Row(
          spacing: 10,
          children: [
            ?televisionLeading,
            const Spacer(),
            Text(
              source,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: titleColor,
              ),
            ),
            if (tvNote.isNotEmpty)
              Text(
                tvNote,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 11,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),            switcher,
            search,
            ...actions,
          ],
        ),
      ),
    };
  }
}
