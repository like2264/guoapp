import 'package:flutter/material.dart';

import '../../local_store.dart';
import '../../models.dart';
import '../app_scope.dart';
import '../downloads/download_picker_page.dart';
import '../shell/app_shell.dart';
import '../theme/glass.dart';
import 'follow_button.dart';

/// 卡片上的一枚操作（长按封面后在卡片内部浮出来）。
///
/// 2.0.0+143 是弹一块底部玻璃面板；2.0.0+144 改成**直接在卡片上**显示，
/// 少一次「面板从底部滑上来、再滑回去」的等待，也不会挡住列表其他内容。
class DramaAction {
  const DramaAction({
    required this.label,
    required this.icon,
    required this.onSelected,
  });
  final String label;
  final IconData icon;
  final void Function(BuildContext context) onSelected;
}

/// 长按作品卡片时，这张卡可以做的两件事：追剧 / 下载。
///
/// 只给发现页、搜索页用：追剧页与历史页的长按是「进入多选」，
/// 那里不传这个，保持原来的行为。
List<DramaAction> dramaActions(
  BuildContext context,
  LocalStore store,
  Drama drama,
) {
  final followed = store.isFavorite(drama.id);
  return [
    DramaAction(
      label: followed ? '取消追剧' : '追剧',
      icon: followed ? Icons.bookmark_remove_rounded : Icons.bookmark_add_outlined,
      onSelected: (context) => quickFollow(context, store, drama),
    ),
    DramaAction(
      label: '下载',
      icon: Icons.download_rounded,
      onSelected: (context) => _download(context, store, drama),
    ),
  ];
}

/// 先拉一次详情页（要拿选集列表），再进「下载选集」。
/// 这中间可能要等一两秒，所以给一个不可取消的转圈，别让用户以为没点到。
Future<void> _download(
  BuildContext context,
  LocalStore store,
  Drama drama,
) async {
  final repository = AppScope.of(context).repository;
  final messenger = ScaffoldMessenger.of(context);
  final navigator = Navigator.of(context, rootNavigator: true);
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => const _Busy(),
  );
  try {
    final detail = await repository.detail(drama);
    if (!navigator.mounted) return;
    navigator.pop();
    if (!context.mounted) return;
    await openPage<void>(
      context,
      (_) => DownloadPickerPage(store: store, detail: detail),
    );
  } catch (failure) {
    if (navigator.mounted) navigator.pop();
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text('读取选集失败：$failure')));
  }
}

class _Busy extends StatelessWidget {
  const _Busy();

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: false,
    child: Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: GlassPanel(
        radius: 22,
        blur: 14,
        tint: 1.5,
        shade: Theme.of(context).brightness == Brightness.dark ? 0.6 : 0,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox.square(
              dimension: 20,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            ),
            const SizedBox(width: 14),
            Text(
              '正在读取选集…',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    ),
  );
}
