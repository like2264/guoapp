import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';

import '../../core_bridge.dart';
import '../../cover_loader.dart';
import '../../models.dart';
import '../app_scope.dart';
import '../cover_blur.dart';
import 'motion/motion_widgets.dart';

const vipGold = Color(0xFFF6C86B);
const onVipGold = Color(0xFF40300D);

class VipBadge extends StatelessWidget {
  const VipBadge({super.key});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
    decoration: BoxDecoration(
      color: vipGold,
      borderRadius: BorderRadius.circular(6),
    ),
    child: const Text(
      'VIP',
      style: TextStyle(
        color: onVipGold,
        fontSize: 11,
        fontWeight: FontWeight.w800,
        height: 1.2,
      ),
    ),
  );
}

class DramaCover extends StatelessWidget {
  const DramaCover({
    super.key,
    required this.drama,
    this.radius = 12,
    this.details = true,
    this.rank,
    this.ordinal,
    this.topLeftBadge = false,
    this.heroScope,
    this.showScore = false,
    this.exploreBlur = false,
  });
  final Drama drama;
  final double radius;
  final bool details;
  final bool exploreBlur;
  final bool showScore;
  final int? rank;

  /// 「全部」分类的到达序号（从 1 开始）。给了就在封面左上角写大号数字，
  /// 方便一路翻到底核对「到底有多少部」。
  final int? ordinal;

  /// 调用方自己要在左上角叠一枚角标（搜索结果里的「精准」）时置真，
  /// VIP 角标就让到右上角，免得两个叠在一起看不清。
  final bool topLeftBadge;
  final String? heroScope;
  static const imagesDisabled = bool.fromEnvironment('DISABLE_REMOTE_IMAGES');

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final placeholder = ColoredBox(
      color: colors.surfaceContainerHighest,
      child: Center(
        child: Icon(
          Icons.movie_creation_outlined,
          size: 36,
          color: colors.onSurfaceVariant,
        ),
      ),
    );
    Widget image = Stack(
      fit: StackFit.expand,
      children: [
        placeholder,
        if (!imagesDisabled && drama.id.isNotEmpty)
          CoverImage(
            key: ValueKey('${drama.id}\u0000${drama.cover}'),
            drama: drama,
            repository: AppScope.of(context).repository,
            placeholder: placeholder,
          ),
      ],
    );
    // 2.0.3+115 起不再做「封面从卡片飞进详情页」：详情页就地展开，
    // 卡片封面留在原地。heroScope 参数继续留着，各列表页不用跟着改。
    final blurred =
        CoverBlurScope.of(context)?.blurs(drama, explore: exploreBlur) ?? false;
    image = ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: ImageFiltered(
        enabled: blurred,
        imageFilter: ImageFilter.blur(
          sigmaX: 16,
          sigmaY: 16,
          tileMode: TileMode.clamp,
        ),
        child: image,
      ),
    );
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Stack(
        fit: StackFit.expand,
        children: [
          image,
          if (details)
            const IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.center,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xC7000000)],
                  ),
                ),
              ),
            ),
          if (details && (drama.badge.isNotEmpty || drama.episodes > 0))
            Positioned(
              left: 9,
              bottom: 9,
              child: Text(
                drama.badge.isNotEmpty ? drama.badge : '共 ${drama.episodes} 集',
                style: const TextStyle(color: Colors.white, fontSize: 12),
              ),
            ),
          if (details && showScore && drama.score.isNotEmpty)
            Positioned(
              right: 9,
              bottom: 9,
              child: Text(
                drama.score,
                style: const TextStyle(
                  color: Color(0xFFFFC542),
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          if (details && drama.vip)
            Positioned(
              // 左上角被排行榜角标、序号或「精准」占了就让到右上角，
              // 别两个叠在一起。
              left: rank == null && ordinal == null && !topLeftBadge ? 8 : null,
              right: rank == null && ordinal == null && !topLeftBadge
                  ? null
                  : 8,
              top: 8,
              child: const VipBadge(),
            ),
          if (rank case final rank?)
            Positioned(left: 0, top: 0, child: RankBadge(rank: rank)),
          if (ordinal case final ordinal?)
            Positioned(left: 0, top: 0, child: OrdinalBadge(value: ordinal)),
        ],
      ),
    );
  }
}

class RankBadge extends StatelessWidget {
  const RankBadge({super.key, required this.rank});
  final int rank;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final top = rank <= 3;
    return Container(
      constraints: const BoxConstraints(minWidth: 28),
      height: 26,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: !top
            ? const Color(0x8C000000)
            : theme.brightness == Brightness.dark
            ? theme.colorScheme.inversePrimary
            : theme.colorScheme.primary,
        borderRadius: const BorderRadius.only(bottomRight: Radius.circular(10)),
      ),
      child: Text(
        '$rank',
        style: TextStyle(
          color: Colors.white,
          fontSize: top ? 15 : 13,
          fontWeight: FontWeight.w800,
          height: 1,
        ),
      ),
    );
  }
}

/// 「全部」分类封面左上角的到达序号。
///
/// 参照主流短剧 App 的写法：纯白大号数字 + 黑色描边阴影，不铺底色块，
/// 尽量不挡海报。手机屏三列时卡片宽约 110，四位数的总量也放得下。
class OrdinalBadge extends StatelessWidget {
  const OrdinalBadge({super.key, required this.value});
  final int value;

  @override
  Widget build(BuildContext context) {
    final text = '$value';
    return IgnorePointer(
      child: Padding(
        padding: const EdgeInsets.only(left: 8, top: 2),
        child: Text(
          text,
          maxLines: 1,
          softWrap: false,
          style: TextStyle(
            color: Colors.white,
            fontSize: text.length >= 4 ? 20 : 24,
            height: 1.06,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.8,
            fontFeatures: const [FontFeature.tabularFigures()],
            shadows: const [
              // 两层阴影叠出描边感：近处压实、远处化开，任何底色上都看得清。
              Shadow(
                color: Color(0xE6000000),
                blurRadius: 4,
                offset: Offset(0, 1),
              ),
              Shadow(
                color: Color(0x99000000),
                blurRadius: 10,
                offset: Offset(0, 2),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CoverImage extends StatefulWidget {
  const CoverImage({
    super.key,
    required this.drama,
    required this.repository,
    required this.placeholder,
    this.retryable = true,
  });
  final Drama drama;
  final AppRepository repository;
  final Widget placeholder;
  final bool retryable;

  @override
  State<CoverImage> createState() => _CoverImageState();
}

class _CoverImageState extends State<CoverImage> {
  static const _decodeWidth = 440;
  CoverRequest? _request;
  Future<String>? _file;
  int _revision = 0;
  bool _failed = false;
  bool _retryOnFailure = false;
  bool _retryQueued = false;
  String? _failedPath;

  /// 本地已经有这个封面文件时第一帧就直出，不等 Future 走完。
  /// 之前每张卡片都要先渲染一帧占位图、再淡入图片，滚动和返回列表时
  /// 整屏都在闪。
  String? _readyPath;

  @override
  void initState() {
    super.initState();
    _revision = widget.repository.catalogUpdates.coverRevision(widget.drama.id);
    widget.repository.catalogUpdates.addListener(_metadataChanged);
    _load();
  }

  @override
  void didUpdateWidget(covariant CoverImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.repository != widget.repository) {
      oldWidget.repository.catalogUpdates.removeListener(_metadataChanged);
      widget.repository.catalogUpdates.addListener(_metadataChanged);
    }
    if (oldWidget.repository != widget.repository ||
        oldWidget.drama.source != widget.drama.source) {
      _failed = _retryOnFailure = false;
      _failedPath = null;
      _revision = widget.repository.catalogUpdates.coverRevision(
        widget.drama.id,
      );
      _load();
    }
  }

  @override
  void dispose() {
    _request?.cancel();
    widget.repository.catalogUpdates.removeListener(_metadataChanged);
    super.dispose();
  }

  void _load() {
    _request?.cancel();
    _request = null;
    _failed = false;
    _failedPath = null;
    final ready = widget.repository.coverPath(widget.drama);
    if (ready != null) {
      // 文件路径已知：直接交给 Image.file，第一帧就是图。
      _readyPath = ready;
      _file = Future<String>.value(ready);
      return;
    }
    _readyPath = null;
    _file = CoverLoader.cached(widget.repository, widget.drama);
    if (_file != null) return;
    final request = _request = CoverLoader.request(
      widget.repository,
      widget.drama,
    );
    _file = request.file;
  }

  void _metadataChanged() {
    final revision = widget.repository.catalogUpdates.coverRevision(
      widget.drama.id,
    );
    if (revision == _revision) return;
    _revision = revision;
    _retryOnFailure = true;
    if (_failed) _queueRetry();
  }

  void _queueRetry() {
    if (_retryQueued || !_retryOnFailure) return;
    _retryQueued = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _retryQueued = false;
      if (!mounted || !_retryOnFailure) return;
      _retryOnFailure = false;
      _retry(_failedPath);
    });
    WidgetsBinding.instance.ensureVisualUpdate();
  }

  Future<void> _retry(String? path) async {
    if (path != null) {
      await ResizeImage.resizeIfNeeded(
        _decodeWidth,
        null,
        FileImage(File(path)),
      ).evict();
    }
    if (!mounted) return;
    _request?.cancel();
    setState(() {
      _request = null;
      _failed = _retryOnFailure = false;
      _failedPath = null;
      _readyPath = null;
      _file = widget.repository.cover(
        widget.repository.catalogUpdates.current(widget.drama),
        force: true,
      );
    });
  }

  Widget _failure(String? path) {
    _failed = true;
    _failedPath = path;
    if (_retryOnFailure) _queueRetry();
    if (!widget.retryable) return widget.placeholder;
    return Center(
      child: IconButton(
        tooltip: '重试海报',
        onPressed: () => _retry(path),
        icon: Icon(
          Icons.refresh_rounded,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ready = _readyPath;
    if (ready != null && !_failed) {
      // 已经解过的图：不占位、不淡入，避免列表滚动和返回时整屏闪一下。
      return Image.file(
        File(ready),
        fit: BoxFit.cover,
        cacheWidth: _decodeWidth,
        excludeFromSemantics: true,
        gaplessPlayback: true,
        errorBuilder: (_, _, _) => _failure(ready),
      );
    }
    return FutureBuilder<String>(
      future: _file,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return widget.placeholder;
        }
        if (snapshot.hasError || !snapshot.hasData) return _failure(null);
        _readyPath = snapshot.data;
        return Image.file(
          File(snapshot.data!),
          fit: BoxFit.cover,
          cacheWidth: _decodeWidth,
          excludeFromSemantics: true,
          gaplessPlayback: true,
          frameBuilder: fadeInFrameBuilder,
          errorBuilder: (_, _, _) => _failure(snapshot.data),
        );
      },
    );
  }
}
