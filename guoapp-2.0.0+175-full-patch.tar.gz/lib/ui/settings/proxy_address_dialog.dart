import 'package:flutter/material.dart';

import '../widgets/focus_ring.dart';
import '../widgets/form_text_field.dart';

/// 代理地址输入框。设置 › 代理 的全局地址和「按站源设置」里的手动代理共用。
Future<String?> showProxyAddressDialog(
  BuildContext context, {
  String initial = '',
}) => showDialog<String>(
  context: context,
  builder: (_) => _ProxyAddressDialog(initial: initial),
);

class _ProxyAddressDialog extends StatefulWidget {
  const _ProxyAddressDialog({required this.initial});
  final String initial;

  @override
  State<_ProxyAddressDialog> createState() => _ProxyAddressDialogState();
}

class _ProxyAddressDialogState extends State<_ProxyAddressDialog> {
  late final _address = TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _address.dispose();
    super.dispose();
  }

  void _submit() {
    final address = _address.text.trim();
    if (address.isNotEmpty) Navigator.pop(context, address);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('代理地址'),
    content: SizedBox(
      width: 420,
      child: FormTextField(
        controller: _address,
        autofocus: true,
        url: true,
        onSubmitted: (_) => _submit(),
        decoration: const InputDecoration(
          hintText: 'http://127.0.0.1:7890',
          helperText: '支持 HTTP、HTTPS、SOCKS5',
        ),
      ),
    ),
    actions: [
      FocusRing(
        radius: 20,
        child: TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('取消'),
        ),
      ),
      FocusRing(
        radius: 20,
        child: FilledButton(onPressed: _submit, child: const Text('保存')),
      ),
    ],
  );
}
