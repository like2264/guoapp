import 'dart:io';

import 'package:flutter/services.dart';

/// iOS 后台下载的「续命」通道。
///
/// iOS 不会让普通 App 一直在后台跑：切到后台几秒后进程就被挂起，下载和
/// ffmpeg 处理会一起停住（以前只能提示用户「请保持应用在前台」）。这里通过
/// 原生向系统要时间，两条腿一起走：
///
/// 1. **UIApplication.beginBackgroundTask**：切到后台那一刻申请的临时额度，
///    通常能再跑几十秒，够把正在写的那几集收个尾；
/// 2. **BGProcessingTask**（Info.plist 里登记了 `processing` 后台模式）：
///    系统在设备空闲、有网的时候会批一段更长的运行时间，用来把剩下的集数
///    继续下完。不是「想跑就能跑」，但比什么都不做多出几分钟到几十分钟。
///
/// 两条都是用一点少一点，所以下载/处理全部结束就立刻 [release]，别白占额度；
/// 回到前台时原生侧会主动归还，Dart 这边不需要额外做什么。
class BackgroundKeepAlive {
  const BackgroundKeepAlive._();

  static const channel = MethodChannel('duanju/background');

  static bool _holding = false;

  /// 只有 iOS 需要这套；Android 走前台服务，桌面端本来就不会被挂起。
  static bool get supported => Platform.isIOS;

  /// 当前有没有占着后台额度（调试与单测用）。
  static bool get holding => _holding;

  /// 还有下载或媒体处理在跑时叫它：告诉系统「别急着挂起我」。
  ///
  /// 只发一次，重复调用不会叠加额度。
  static Future<void> hold() async {
    if (!supported || _holding) return;
    _holding = true;
    try {
      await channel.invokeMethod<Object?>('begin').timeout(
        const Duration(seconds: 2),
      );
    } catch (_) {
      // 系统不给时间也不影响前台下载，静默即可。
    }
  }

  /// 下载和处理都结束了：立刻把后台额度还回去。
  static Future<void> release() async {
    if (!supported || !_holding) return;
    _holding = false;
    try {
      await channel
          .invokeMethod<Object?>('end')
          .timeout(const Duration(seconds: 2));
    } catch (_) {}
  }
}
