// 黄桃（aihuangdou.com）：SSR 列表页 + 同源 JSON 接口，所有 /api/* 走站点 edge 桥。
//
// 列表：/ai-duanju/、/tag/{slug}/，翻页走路径 /{path}/{n}/，每页 22 部，页脚「第 X/Y 页」。
// 搜索：edge GET /api/search?q=&page=&size=20 -> data.items + data.pagination.pages
// 详情：edge GET /api/videos/{id}；分集直连 /videos/{id}/episodes（不带 /api 前缀，也不走 edge）
// 播放：edge POST /api/videos/{id}/episodes/{n}/playback，body {} -> data.streams.main
//
// edge 桥：POST /api/edge/request，信封 {method, path, body(base64), content_type}。

var SITE = "https://aihuangdou.com";
var UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
var CHANNEL = "黄桃";
var DEFAULT_CHANNEL = "ai-duanju";
var SEARCH_PAGE_SIZE = 20;
// 目录每页 22 部（站点实测：56/8/35/35 页，只有末页不满）。
var PAGE_SIZE = 22;
var MAX_PAGE = 500;
var MAX_EPISODES = 2000;

var CHANNELS = [
  { id: "c:ai-duanju", name: "AI 短剧" },
  { id: "c:ai-manju", name: "AI 漫剧" },
  { id: "c:ai-mogai", name: "AI 魔改" },
  { id: "c:ai-meinv", name: "AI 美女" },
];

var RE_CARD = /<article class="drama-card"[^>]*>([\s\S]*?)<\/article>/gi;
var RE_CARD_ID = /href="\/drama\/(\d+)\/"/i;
var RE_CARD_NAME = /data-track-item-name="([^"]*)"/i;
var RE_CARD_ALT = /<img[^>]+alt="《([^》]*)》封面"/i;
var RE_CARD_COVER = /data-src="([^"]+)"/i;
var RE_CARD_SCORE = /<em class="card-score">([\s\S]*?)<\/em>/i;
var RE_CARD_FLAG = /<span class="eps-flag">([\s\S]*?)<\/span>/i;
// 角标里的集数：「更新中 · 3集」「全 23 集」「更新至第 11 集」。
// 以前 remark 只当文案用，列表条目的集数字段一直是 0；而顶栏「今日更新」
// 只有在「库里原有的剧集数变大」时才算增量，列表不给集数就永远显示 0 集。
var RE_FLAG_EPISODES = /(?:更新至|更新中|全|共|第)?\s*(\d{1,5})\s*(?:集|话|期)/;
function flagEpisodes(text) {
  var match = RE_FLAG_EPISODES.exec(String(text || ""));
  if (!match) return 0;
  var count = asNumber(match[1], 0);
  return count > 0 && count <= 100000 ? count : 0;
}
var RE_CARD_TITLE = /<h3[^>]*>([\s\S]*?)<\/h3>/i;
var RE_CARD_DESC = /<p class="card-desc">([\s\S]*?)<\/p>/i;
var RE_CARD_META = /<\/h3><\/a>\s*<p>([\s\S]*?)<\/p>/i;
var RE_PAGE_TOTAL = /第\s*\d+\s*\/\s*(\d+)\s*页/;
var RE_PLAY_DATA = /<script id="ninePlayData" type="application\/json">([\s\S]*?)<\/script>/i;
var RE_HTML_TAG = /<[^>]+>/g;
var RE_ID = /^[1-9][0-9]{0,15}$/;
var RE_SLUG = /^[a-z0-9][a-z0-9\-]{0,63}$/;
var RE_HEAT = /[0-9]+(?:\.[0-9]+)?\s*[wW万]?/;

function unescapeHtml(text) {
  return String(text)
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&#(\d+);/g, function (_, code) {
      return String.fromCharCode(parseInt(code, 10));
    });
}

function clean(text) {
  if (text === null || text === undefined) return "";
  var raw = unescapeHtml(String(text).replace(RE_HTML_TAG, " "));
  raw = raw.replace(/\u3000/g, " ");
  return raw.replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
}

function clip(text, limit) {
  var value = String(text === null || text === undefined ? "" : text);
  return value.length > limit ? value.slice(0, limit) : value;
}

function absUrl(raw) {
  var value = String(raw || "").replace(/^\s+|\s+$/g, "");
  if (value === "") return "";
  if (value.indexOf("//") === 0) return "https:" + value;
  if (/^https?:\/\//i.test(value)) return value;
  if (value.charAt(0) === "/") return SITE + value;
  return SITE + "/" + value;
}

function asNumber(value, fallback) {
  var parsed = parseInt(String(value), 10);
  return isNaN(parsed) ? fallback : parsed;
}

function validId(id) {
  return RE_ID.test(String(id || "").replace(/^\s+|\s+$/g, ""));
}

function categoryParts(category) {
  var value = String(category || "").replace(/^\s+|\s+$/g, "");
  if (value === "") return { kind: "default", value: "" };
  if (value.indexOf("c:") === 0) {
    for (var index = 0; index < CHANNELS.length; index++) {
      if (CHANNELS[index].id === value) return { kind: "channel", value: value.slice(2) };
    }
    return null;
  }
  if (value.indexOf("t:") === 0) {
    var slug = value.slice(2);
    if (RE_SLUG.test(slug)) return { kind: "tag", value: slug };
    return null;
  }
  return null;
}

function validCategory(category) {
  return categoryParts(category) !== null;
}

function listPath(category, page) {
  var parts = categoryParts(category) || { kind: "default", value: "" };
  var base = "/" + DEFAULT_CHANNEL + "/";
  if (parts.kind === "channel") base = "/" + parts.value + "/";
  else if (parts.kind === "tag") base = "/tag/" + parts.value + "/";
  if (page > 1) return base + page + "/";
  return base;
}

function textGet(path) {
  var address = path.indexOf("http") === 0 ? path : SITE + path;
  var response = host.fetchText({ url: address, referer: SITE + "/", userAgent: UA });
  return response && response.body ? response.body : "";
}

function edge(method, path, payload) {
  var target = path.charAt(0) === "/" ? path : "/" + path;
  var envelope = { method: method, path: target, body: "", content_type: "" };
  if (payload !== null && payload !== undefined) {
    envelope.body = host.base64Encode(JSON.stringify(payload));
    envelope.content_type = "application/json";
  }
  var response = host.fetch({
    method: "POST",
    url: SITE + "/api/edge/request",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json, text/plain, */*",
      Origin: SITE,
      Referer: SITE + "/",
      "User-Agent": UA,
    },
    body: JSON.stringify(envelope),
    timeoutMs: 30000,
  });
  var reply = null;
  try {
    reply = JSON.parse(response && response.body ? response.body : "");
  } catch (error) {
    throw new Error("黄桃接口返回格式无效");
  }
  if (!reply) throw new Error("黄桃接口返回格式无效");
  if (reply.status !== 1) throw new Error("黄桃接口返回失败：" + (clean(reply.msg) || "未知错误"));
  return reply.data;
}

function heatOf(meta) {
  var value = String(meta || "").replace(/^\s+|\s+$/g, "");
  if (value === "") return "";
  var index = value.indexOf("热度");
  if (index < 0) return "";
  var segment = value.slice(0, index);
  var cut = segment.lastIndexOf("·");
  if (cut >= 0) segment = segment.slice(cut + 1);
  var match = RE_HEAT.exec(segment);
  return match ? String(match[0]).replace(/^\s+|\s+$/g, "") : "";
}

function makeDrama(sourceId, title, cover, extra) {
  var drama = {
    id: host.dramaId(sourceId),
    source: host.source,
    sourceId: sourceId,
    title: title,
    name: title,
    channelName: CHANNEL,
  };
  if (cover) {
    drama.cover = cover;
    drama.coverUrl = cover;
  }
  if (extra) {
    for (var key in extra) {
      if (Object.prototype.hasOwnProperty.call(extra, key) && extra[key] !== "" && extra[key] !== null) {
        drama[key] = extra[key];
      }
    }
  }
  if (!drama.categoryName) drama.categoryName = "AI 短剧";
  return drama;
}

function parseCards(body) {
  var items = [];
  var seen = {};
  RE_CARD.lastIndex = 0;
  var match;
  while ((match = RE_CARD.exec(body)) !== null) {
    var chunk = match[1];
    var idMatch = RE_CARD_ID.exec(chunk);
    if (!idMatch || !validId(idMatch[1]) || seen[idMatch[1]]) continue;
    var sourceId = idMatch[1];
    var title = "";
    var nameMatch = RE_CARD_NAME.exec(chunk);
    if (nameMatch) title = clean(nameMatch[1]);
    if (title === "") {
      var titleMatch = RE_CARD_TITLE.exec(chunk);
      if (titleMatch) title = clean(titleMatch[1]);
    }
    if (title === "") {
      var altMatch = RE_CARD_ALT.exec(chunk);
      if (altMatch) title = clean(altMatch[1]);
    }
    if (title === "") continue;
    seen[sourceId] = true;
    var coverMatch = RE_CARD_COVER.exec(chunk);
    var remark = "";
    var flagMatch = RE_CARD_FLAG.exec(chunk);
    if (flagMatch) remark = clip(clean(flagMatch[1]), 64);
    var episodes = flagEpisodes(remark);
    var score = "";
    var scoreMatch = RE_CARD_SCORE.exec(chunk);
    if (scoreMatch) score = clip(clean(scoreMatch[1]).replace(/\s+分/g, "分"), 16);
    var meta = "";
    var metaMatch = RE_CARD_META.exec(chunk);
    if (metaMatch) meta = clean(metaMatch[1]);
    var description = "";
    var descMatch = RE_CARD_DESC.exec(chunk);
    if (descMatch) description = clip(clean(descMatch[1]), 4000);
    var categoryName = "AI 短剧";
    if (meta !== "") {
      var segments = meta.split("·");
      for (var index = segments.length - 1; index >= 0; index--) {
        var segment = String(segments[index]).replace(/^\s+|\s+$/g, "");
        if (segment === "" || segment.indexOf("热度") >= 0 || segment.indexOf("AI") === 0) continue;
        categoryName = clip(segment, 24);
        break;
      }
    }
    var extra = {
      desc: description,
      intro: description,
      categoryName: categoryName,
      remark: remark,
      score: score,
      heat: heatOf(meta),
    };
    if (episodes > 0) {
      extra.episodeCount = episodes;
      extra.totalEpisode = episodes;
    }
    items.push(
      makeDrama(sourceId, clip(title, 512), coverMatch ? absUrl(coverMatch[1]) : "", extra)
    );
    if (items.length >= 200) break;
  }
  return items;
}

// 全站作品总量 = 四个频道页各自写的「共收录 N 部」相加。
//
// 站内搜索页页眉那句「站内共有 <b>N</b> 部作品」是虚高的旧数字：2026-11-22
// 实测搜索页写 2,952，而四个频道分别是 1,220 / 155 / 775 / 777 = 2,927，
// 真正按页翻出来也正好 2,927 张卡（136 页）。用户拿站点上的数字一比就是
// 「App 比站点少 25 部」。所以优先按频道相加，抓不到才退回页眉那句。
var totalCache = { at: 0, value: 0 };

function channelTotal(slug) {
  try {
    var body = textGet("/" + slug + "/");
    var match = /共收录\s*([\d,]+)\s*部/.exec(body);
    if (!match) return 0;
    var value = asNumber(String(match[1]).replace(/,/g, ""), 0);
    return value > 0 && value <= 1000000 ? value : 0;
  } catch (error) {
    return 0;
  }
}

function catalogTotal() {
  var now = Date.now();
  if (totalCache.value > 0 && now - totalCache.at < 15 * 60 * 1000) {
    return totalCache.value;
  }
  var summed = 0;
  for (var i = 0; i < SECTIONS.length; i++) {
    var slug = String(SECTIONS[i]).replace(/^c:/, "");
    var each = channelTotal(slug);
    if (each <= 0) {
      summed = 0;
      break;
    }
    summed += each;
  }
  if (summed > 0) {
    totalCache = { at: now, value: summed };
    return summed;
  }
  // 频道页都抓不到：退回搜索页页眉（那个数可能虚高，但好过没有）。
  try {
    var body = textGet("/search");
    var match = /站内共有\s*<b>\s*([\d,]+)\s*<\/b>\s*部作品/.exec(body);
    if (!match) return 0;
    var value = asNumber(String(match[1]).replace(/,/g, ""), 0);
    if (value <= 0 || value > 1000000) return 0;
    totalCache = { at: now, value: value };
    return value;
  } catch (error) {
    return 0;
  }
}

function totalPages(body) {
  var match = RE_PAGE_TOTAL.exec(body);
  if (!match) return 0;
  var total = asNumber(match[1], 0);
  return total >= 0 && total <= MAX_PAGE ? total : 0;
}

function chapterOf(sourceId, number) {
  var episode = String(number);
  return {
    id: host.chapterId(sourceId, episode),
    source: host.source,
    title: "第" + number + "集",
    currentEpisode: number,
    videoUrl: "huangtao-play://" + episode,
    pageUrl: SITE + "/video/" + sourceId + "/" + episode + "/",
    referer: SITE + "/",
  };
}

function buildChapters(eps, total, sourceId) {
  var chapters = [];
  for (var index = 0; index < eps.length; index++) {
    var episode = eps[index] || {};
    var number = asNumber(episode.n, 0);
    if (number < 1 || number > MAX_EPISODES) number = index + 1;
    var title = clip(clean(episode.title || episode.fact || episode.heading), 128);
    var chapter = chapterOf(sourceId, number);
    if (title !== "") chapter.title = title;
    chapters.push(chapter);
  }
  if (chapters.length === 0 && total > 0 && total <= MAX_EPISODES) {
    for (var number = 1; number <= total; number++) chapters.push(chapterOf(sourceId, number));
  }
  chapters.sort(function (left, right) {
    return left.currentEpisode - right.currentEpisode;
  });
  return chapters;
}

function pageEpisodes(sourceId) {
  var body = textGet("/video/" + encodeURIComponent(sourceId) + "/");
  var match = RE_PLAY_DATA.exec(body);
  if (!match) return null;
  var data = null;
  try {
    data = JSON.parse(unescapeHtml(match[1]));
  } catch (error) {
    return null;
  }
  if (!data || !(data.eps instanceof Array) || data.eps.length === 0) return null;
  var chapters = buildChapters(data.eps, asNumber(data.epTotal, 0), sourceId);
  if (chapters.length === 0) return null;
  return { total: Math.max(asNumber(data.epTotal, 0), chapters.length), chapters: chapters };
}

function fetchEpisodes(sourceId) {
  var total = 0;
  var eps = [];
  try {
    var body = textGet("/videos/" + encodeURIComponent(sourceId) + "/episodes");
    var envelope = JSON.parse(body);
    if (envelope && envelope.data) {
      total = asNumber(envelope.data.epTotal, 0);
      if (envelope.data.eps instanceof Array) eps = envelope.data.eps;
    }
  } catch (error) {}
  var chapters = buildChapters(eps, total, sourceId);
  if (chapters.length === 0) {
    var fallback = pageEpisodes(sourceId);
    if (fallback) return fallback;
    return null;
  }
  return { total: Math.max(total, chapters.length), chapters: chapters };
}

// 搜索结果补简介。
//
// 站点的搜索接口只返回标题和标签，简介只在详情接口里。但搜索本身是按全文做
// 字符匹配的（搜「孟晓涵」能带出简介里出现过这三个字的剧），所以结果集里确实
// 混着「只有简介沾边」的作品。缺简介时 native 的相关度分级判不到第 7 档，
// 这些条目会被当成无关直接丢掉——用户看到的就是「明明简介里有，却搜不到」。
// 这里对「标题和标签都没命中」的条目按需补一次简介，按 id 缓存 7 天。
var INTRO_TTL_MS = 7 * 24 * 60 * 60 * 1000;
var INTRO_PAGE_BUDGET = 12;
var INTRO_PAGE_BUDGET_MS = 4000;
// 第二页往后每页少补一点：只补第一页的话，用户往下翻到的那些「只有简介
// 沾边」的作品会被 native 当无关丢掉，看起来就是搜不全。
var INTRO_LATER_BUDGET = 6;
var INTRO_LATER_BUDGET_MS = 2500;

function introUnknown(drama, keyword, words) {
  var title = String(drama.title || drama.name || "").toLowerCase();
  if (title.indexOf(keyword) >= 0) return false;
  for (var index = 0; index < words.length; index++) {
    if (title.indexOf(words[index]) >= 0) return false;
  }
  var meta = [String(drama.categoryName || drama.category || "")].concat(drama.tags || []);
  for (var position = 0; position < meta.length; position++) {
    var value = String(meta[position]).toLowerCase();
    if (value === "") continue;
    if (value.indexOf(keyword) >= 0) return false;
    for (var word = 0; word < words.length; word++) {
      if (value.indexOf(words[word]) >= 0) return false;
    }
  }
  return true;
}

function attachIntros(items, keyword, page) {
  // 首屏补得多一点，后面几页补得少一点：只补第一页的话，用户往下翻到的
  // 那些「只有简介沾边」的作品会被 native 当无关丢掉，看起来就是搜不全。
  var budget = page === 1 ? INTRO_PAGE_BUDGET : INTRO_LATER_BUDGET;
  var budgetMs = page === 1 ? INTRO_PAGE_BUDGET_MS : INTRO_LATER_BUDGET_MS;
  var lowered = String(keyword || "").toLowerCase();
  if (lowered === "") return;
  var words = lowered.split(/\s+/).filter(function (word) {
    return word !== "";
  });
  var started = Date.now();
  var filled = 0;
  for (var index = 0; index < items.length; index++) {
    if (filled >= budget || Date.now() - started > budgetMs) return;
    var drama = items[index];
    if (drama.desc || drama.intro) continue;
    if (!introUnknown(drama, lowered, words)) continue;
    var id = String(drama.sourceId || "");
    if (id === "") continue;
    var cached = null;
    try {
      cached = host.cacheGet("intro:" + id);
    } catch (error) {
      cached = null;
    }
    if (cached !== null && cached !== "") {
      drama.desc = cached;
      drama.intro = cached;
      continue;
    }
    var intro = "";
    try {
      intro = fetchIntro(id);
    } catch (error) {
      intro = "";
    }
    if (intro === "") continue;
    drama.desc = intro;
    drama.intro = intro;
    try {
      host.cacheSet("intro:" + id, intro, INTRO_TTL_MS);
    } catch (error) {}
    filled++;
  }
}

function fetchIntro(sourceId) {
  var row = edge("GET", "/api/videos/" + encodeURIComponent(sourceId), null) || {};
  return clip(clean(row.description || row.intro), 4000);
}

// ---- 「全部」= 各频道拼接 ----------------------------------------------------
//
// 黄桃有四个并列频道（AI 短剧 / AI 漫剧 / AI 魔改 / AI 美女），站点只在首页把
// 它们混在一起展示，没有跨频道的分页列表。/ai-duanju/ 是「成人短剧」这一栏，
// 标签栏却把它当默认入口，所以老写法拿它当「全部」。
//
// 这里把四个频道按页接成一个虚拟列表。每个频道的总页数从它自己那页的
// 「第 1/N 页」学到并缓存一天；没学到之前用实测值兜底，保证冷启动就能给出
// 正确的总量，不必为了一个数字先发四个请求。
var SECTIONS = ["c:ai-duanju", "c:ai-manju", "c:ai-mogai", "c:ai-meinv"];
var SECTION_PAGES_KEY = "sections:pages";
var SECTION_PAGES_TTL_MS = 24 * 60 * 60 * 1000;
var SECTION_PAGES_DEFAULT = {
  "c:ai-duanju": 52,
  "c:ai-manju": 7,
  "c:ai-mogai": 33,
  "c:ai-meinv": 34,
};

function sectionPages() {
  var stored = null;
  try {
    stored = host.cacheGet(SECTION_PAGES_KEY);
  } catch (error) {
    stored = null;
  }
  var pages = {};
  var key;
  // host.cacheSet 只存字符串（传对象会被写成 "[object Object]"），所以这里
  // 先试着解析 JSON。老版本正是栽在这上面：学到的页数一次都没进过缓存，
  // 「全部」永远按默认页数收尾，尾页作品翻不到。
  if (typeof stored === "string" && stored !== "") {
    try {
      stored = JSON.parse(stored);
    } catch (error) {
      stored = null;
    }
  }
  if (stored && typeof stored === "object") {
    for (key in stored) {
      if (Object.prototype.hasOwnProperty.call(stored, key)) {
        pages[key] = asNumber(stored[key], 0);
      }
    }
  }
  for (key in SECTION_PAGES_DEFAULT) {
    if (!pages[key] || pages[key] <= 0) pages[key] = SECTION_PAGES_DEFAULT[key];
  }
  return pages;
}

function rememberSectionPages(category, count) {
  if (!count || count <= 0) return;
  var pages = sectionPages();
  if (pages[category] === count) return;
  pages[category] = count;
  try {
    host.cacheSet(SECTION_PAGES_KEY, JSON.stringify(pages), SECTION_PAGES_TTL_MS);
  } catch (error) {}
}

// 拉某个频道的一页，顺手把它真实的总页数记下来（不用额外请求）。
function loadSection(category, page) {
  var body = textGet(listPath(category, page));
  var items = parseCards(body);
  var pages = totalPages(body);
  if (pages > 0) rememberSectionPages(category, pages);
  return {
    items: items,
    pages: pages > 0 ? pages : sectionPages()[category],
  };
}


// 缓存里四（三/两）栏的页数是否都学到了。上一次写缓存坏在传对象上，
// 用户机上一直只有默认值；只要发现缺任何一栏，开局就把各栏第一页拉一遍。
function sectionsKnown() {
  var stored = null;
  try {
    stored = host.cacheGet(SECTION_PAGES_KEY);
  } catch (error) {
    stored = null;
  }
  if (typeof stored === "string" && stored !== "") {
    try {
      stored = JSON.parse(stored);
    } catch (error) {
      stored = null;
    }
  }
  if (!stored || typeof stored !== "object") return false;
  for (var i = 0; i < SECTIONS.length; i++) {
    if (!(asNumber(stored[SECTIONS[i]], 0) > 0)) return false;
  }
  return true;
}


function sumPages(pages) {
  var total = 0;
  for (var i = 0; i < SECTIONS.length; i++) total += pages[SECTIONS[i]];
  return total;
}

// 现场把四个频道的第一页各拉一遍，学到真实页数（缓存过期或页码越界时才走）。
function refreshSectionPages() {
  for (var i = 0; i < SECTIONS.length; i++) {
    try {
      loadSection(SECTIONS[i], 1);
    } catch (error) {}
  }
  return sectionPages();
}

// 「全部」第 index 页落在哪个频道的第几页；越界返回 null。
function serveAll(pages, index) {
  var remaining = index;
  for (var slot = 0; slot < SECTIONS.length; slot++) {
    var span = pages[SECTIONS[slot]];
    if (remaining > span) {
      remaining -= span;
      continue;
    }
    var section = loadSection(SECTIONS[slot], remaining);
    var learned = sectionPages();
    var totalPages = sumPages(learned);
    // 声明是末页却还满页：站点常把页数标少一页，探一页。
    if (section.items.length >= PAGE_SIZE && index >= totalPages) {
      learned[SECTIONS[slot]] = learned[SECTIONS[slot]] + 1;
      rememberSectionPages(SECTIONS[slot], learned[SECTIONS[slot]]);
      totalPages = sumPages(sectionPages());
    }
    return { items: section.items, hasMore: index < totalPages, total: catalogTotal() || totalPages * PAGE_SIZE };
  }
  return null;
}

module.exports = {
  validCategory: validCategory,

  categories: function () {
    var data = edge("GET", "/api/tags", null);
    var categories = CHANNELS.slice();
    var tags = 0;
    var groups = data && data.categories instanceof Array ? data.categories : [];
    for (var index = 0; index < groups.length; index++) {
      var group = groups[index] || {};
      var entries = group.tags instanceof Array ? group.tags : [];
      for (var inner = 0; inner < entries.length; inner++) {
        var tag = entries[inner] || {};
        var slug = String(tag.slug || "").replace(/^\s+|\s+$/g, "");
        if (!RE_SLUG.test(slug)) continue;
        var name = String(tag.name || "").replace(/^\s+|\s+$/g, "");
        var groupName = String(group.name || "").replace(/^\s+|\s+$/g, "");
        if (groupName !== "" && name !== "") name = groupName + " · " + name;
        if (name === "") name = slug;
        categories.push({ id: "t:" + slug, name: clip(name, 24) });
        tags++;
        if (categories.length >= 96) break;
      }
      if (categories.length >= 96) break;
    }
    if (tags === 0 && groups.length === 0) throw new Error("黄桃暂未返回内容分类");
    return categories;
  },

  catalogPage: function (page, category) {
    var index = asNumber(page, 0);
    if (index < 1 || index > MAX_PAGE) throw new Error("黄桃目录页码无效");
    if (!validCategory(category)) throw new Error("黄桃内容分类无效");
    var value = String(category || "").replace(/^\s+|\s+$/g, "");
    if (value !== "") {
      var single = loadSection(value, index);
      if (single.items.length === 0) return { items: [], hasMore: false };
      return {
        items: single.items,
        hasMore: index < single.pages,
        total: 0,
      };
    }
    // 「全部」= AI 短剧 / AI 漫剧 / AI 魔改 / AI 美女 四个频道按页接起来。
    // 站点没有跨频道的总列表：老写法直接抓 /ai-duanju/，只有 1129 部，而站内
    // 首页写着 2750 部——另外 1621 部（漫剧 141、魔改 725、美女 727）一条都
    // 翻不到。顶栏挂着 2750、列表只能翻 52 页，就是这个原因。
    var pages0 = sectionPages();
    // 页数缓存不完整（第一次装、缓存过期、旧版本写坏过）就先补齐，
    // 否则默认值会把每栏的尾页截掉。
    if (!sectionsKnown()) pages0 = refreshSectionPages();
    var served = serveAll(pages0, index);
    if (served) return served;
    // 页码越界：缓存里的页数可能旧了，现场刷新一次再算。
    var pages = refreshSectionPages();
    var retried = serveAll(pages, index);
    if (retried) return retried;
    return { items: [], hasMore: false, total: catalogTotal() || sumPages(pages) * PAGE_SIZE };
  },

  search: function (page, query) {
    var index = asNumber(page, 0);
    var keyword = String(query || "").replace(/^\s+|\s+$/g, "");
    if (keyword === "") return { items: [], hasMore: false };
    if (index < 1 || index > MAX_PAGE) throw new Error("黄桃搜索页码无效");
    if (keyword.length > 64) throw new Error("黄桃搜索关键词无效");
    var data = edge(
      "GET",
      "/api/search?q=" + encodeURIComponent(keyword) + "&page=" + index + "&size=" + SEARCH_PAGE_SIZE,
      null
    );
    var rows = data && data.items instanceof Array ? data.items : [];
    var items = [];
    var seen = {};
    for (var row = 0; row < rows.length; row++) {
      var entry = rows[row] || {};
      var sourceId = String(entry.id !== undefined && entry.id !== null ? entry.id : entry.video_id || "")
        .replace(/^\s+|\s+$/g, "");
      if (!validId(sourceId) || seen[sourceId]) continue;
      var title = clip(clean(entry.title || entry.name), 512);
      if (title === "") continue;
      seen[sourceId] = true;
      var description = clip(clean(entry.description || entry.intro), 4000);
      var onlineDate = "";
      var created = String(entry.created_at || "").replace(/^\s+|\s+$/g, "");
      if (created.length >= 10) onlineDate = created.slice(0, 10);
      var tags = entry.tags instanceof Array ? entry.tags : [];
      var extra = {
        desc: description,
        intro: description,
        categoryName: "AI 短剧",
        heat: String(entry.hot === undefined || entry.hot === null ? "" : entry.hot),
        views: String(entry.play_count === undefined || entry.play_count === null ? "" : entry.play_count),
        onlineDate: onlineDate,
      };
      if (tags.length > 0) extra.tags = tags;
      items.push(makeDrama(sourceId, title, absUrl(entry.cover || entry.poster), extra));
    }
    var pages = data && data.pagination ? asNumber(data.pagination.pages, 0) : 0;
    attachIntros(items, keyword, index);
    return { items: items, hasMore: pages > 0 ? index < pages : false };
  },

  detail: function (sourceId) {
    var id = String(sourceId || "").replace(/^\s+|\s+$/g, "");
    if (!validId(id)) throw new Error("黄桃剧集标识无效");
    var row = edge("GET", "/api/videos/" + encodeURIComponent(id), null) || {};
    var returned = String(row.id === undefined || row.id === null ? "" : row.id).replace(/^\s+|\s+$/g, "");
    if (returned !== "" && returned !== id) throw new Error("黄桃详情与请求剧集不符");

    var title = clip(clean(row.title || row.name), 512);
    if (title === "") throw new Error("黄桃详情缺少剧集名称");
    var description = clip(clean(row.description || row.intro), 12000);
    var cover = absUrl(row.cover || row.poster);
    var label = "AI 短剧";
    if (row.breadcrumb instanceof Array && row.breadcrumb.length > 0) {
      var crumb = clip(clean((row.breadcrumb[0] || {}).name), 32);
      if (crumb !== "") label = crumb;
    }

    var episodes = fetchEpisodes(id);
    if (!episodes) throw new Error("黄桃该剧暂无可播放分集");

    var extra = {
      desc: description,
      intro: description,
      categoryName: label,
      episodeCount: episodes.total,
      totalEpisode: episodes.total,
      remark: "全 " + episodes.total + " 集",
    };
    var tags = row.tags instanceof Array ? row.tags : [];
    if (tags.length > 0) extra.tags = tags;
    var created = String(row.created_at || "").replace(/^\s+|\s+$/g, "");
    if (created.length >= 10) extra.onlineDate = created.slice(0, 10);
    if (row.counts && typeof row.counts === "object") {
      if (row.counts.hot !== undefined && row.counts.hot !== null) extra.heat = String(row.counts.hot);
      var views = row.counts.play !== undefined && row.counts.play !== null ? row.counts.play : row.counts.view;
      if (views === undefined || views === null) views = row.counts.hot;
      if (views !== undefined && views !== null) extra.views = String(views);
    }
    return { drama: makeDrama(id, title, cover, extra), chapters: episodes.chapters };
  },

  resolveMedia: function (task) {
    var chapter = task && task.chapter ? task.chapter : {};
    var dramaId = String((task && task.dramaId) || host.source + ":");
    var prefix = host.source + ":";
    var rest = dramaId.indexOf(prefix) === 0 ? dramaId.slice(prefix.length) : "";
    var sourceId = rest;
    var number = 0;
    var separator = rest.indexOf(":");
    if (separator > 0) {
      sourceId = rest.slice(0, separator);
      number = asNumber(rest.slice(separator + 1), 0);
    } else if (chapter.id) {
      var chapterId = String(chapter.id);
      var cut = chapterId.lastIndexOf(":");
      if (cut > 0) number = asNumber(chapterId.slice(cut + 1), 0);
    }
    if (!validId(sourceId)) throw new Error("黄桃播放信息无效，请刷新详情");
    if (number < 1 || number > MAX_EPISODES) throw new Error("黄桃播放分集信息无效，请刷新详情");

    var data =
      edge(
        "POST",
        "/api/videos/" + encodeURIComponent(sourceId) + "/episodes/" + number + "/playback",
        {}
      ) || {};
    var method = String(data.manifest_method || "").replace(/^\s+|\s+$/g, "");
    if (method !== "" && method.toUpperCase() !== "GET") throw new Error("黄桃播放接口返回了不支持的播放方式");
    var streams = data.streams || {};
    var pageUrl = SITE + "/video/" + sourceId + "/" + number + "/";
    var address = absUrl(streams.main || data.src);
    if (!/^https?:\/\//i.test(address)) throw new Error("黄桃该集暂无播放地址");
    var media = host.prepareWebMedia({ url: address, referer: pageUrl }, CHANNEL);
    var hevc = absUrl(streams.hevc);
    if (/^https?:\/\//i.test(hevc) && hevc !== address) {
      media.variants = [{ url: hevc, referer: pageUrl, quality: 1080 }];
    }
    media.referer = pageUrl;
    return media;
  },
};
