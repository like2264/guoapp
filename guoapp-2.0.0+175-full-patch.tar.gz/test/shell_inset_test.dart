import 'package:duanju_app/ui/app_scope.dart';
import 'package:duanju_app/ui/widgets/glass_tab_bar.dart';
import 'package:duanju_app/ui/widgets/shell_inset.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fakes.dart';

/// 2.0.0+156：追剧页的「下载 / 取消追剧」又被玻璃底栏压住了一半。
///
/// 真机上量出来：按钮底边距屏幕底部 ≈ 101pt，而底栏顶边在 113pt —— 差的
/// 正好是一个安全区（34）。原因是页面自己按 `viewPadding` 算出 88，底栏却是
/// 按 34 的安全区摆的。现在外壳把实际高度发布出来，页面直接读。
void main() {
  Widget harness({
    required ValueChanged<double> onMeasure,
    double? published,
    bool liquidGlass = true,
    double bottomInset = 0,
  }) {
    Widget child = Builder(
      builder: (context) {
        onMeasure(shellBottomInset(context));
        return const SizedBox.shrink();
      },
    );
    if (published != null) {
      child = ShellBottomInset(height: published, child: child);
    }
    return MediaQuery(
      data: MediaQueryData(
        size: const Size(400, 800),
        // 真机上页面这边的 viewPadding.bottom 是 0（底栏那边是 34）。
        viewPadding: EdgeInsets.only(bottom: bottomInset),
      ),
      child: AppScope(
        repository: FakeRepository(),
        formFactor: FormFactor.phone,
        liquidGlass: liquidGlass,
        child: child,
      ),
    );
  }

  testWidgets('用外壳发布的底栏高度，页面不再少留一个安全区', (tester) async {
    double measured = -1;
    await tester.pumpWidget(
      harness(onMeasure: (value) => measured = value, published: 122),
    );
    expect(measured, 122);
  });

  testWidgets('没有外壳发布时退回自己算（老路径仍可用）', (tester) async {
    double measured = -1;
    await tester.pumpWidget(harness(onMeasure: (value) => measured = value));
    // 胶囊 70 + 底部留白 10 + 安全区 0 + 余量 8
    expect(
      measured,
      GlassTabBar.barHeight + GlassTabBar.bottomGap + 8,
    );
  });

  testWidgets('普通底栏（非玻璃）不留额外高度', (tester) async {
    double measured = -1;
    await tester.pumpWidget(
      harness(
        onMeasure: (value) => measured = value,
        published: 122,
        liquidGlass: false,
      ),
    );
    expect(measured, 0);
  });
}
