import 'package:duanju_app/follow_state.dart';
import 'package:duanju_app/follow_updater.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fakes.dart';

/// 追剧页下拉刷新（2.0.0+152）：以前只能等后台那个 30 分钟一轮的定时复查，
/// 用户手动下拉什么都不会发生。
void main() {
  test('下拉刷新不管到期没到期，把追剧逐部核对一遍', () async {
    final repository = FakeRepository();
    final store = await openStore();
    final first = drama('f1', title: '追剧一');
    final second = drama('f2', title: '追剧二');
    await store.toggleFavorite(first);
    await store.toggleFavorite(second);
    // 定时任务刚查过：按 6 小时的复查间隔，这两部本来都还不该再查。
    final now = DateTime.now();
    await store.saveFollowChecks(
      {first.id: FollowCheck(now), second.id: FollowCheck(now)},
      epoch: store.profileEpoch,
    );
    final updater = FollowUpdater(
      repository,
      store,
      startDelay: const Duration(days: 1),
      interval: const Duration(days: 1),
      clock: () => now,
    );
    addTearDown(updater.dispose);

    expect(await updater.refresh(), isTrue);
    expect(repository.detailRequests, 2, reason: '两部追剧都要重新核对');
    expect(store.followChecks.keys, containsAll([first.id, second.id]));
  });

  test('一部都核对不下来时返回 false，界面据此提示重试', () async {
    final repository = FakeRepository()..detailFailure = '站源暂时不可用';
    final store = await openStore();
    final only = drama('f1', title: '追剧一');
    await store.toggleFavorite(only);
    final updater = FollowUpdater(
      repository,
      store,
      startDelay: const Duration(days: 1),
      interval: const Duration(days: 1),
    );
    addTearDown(updater.dispose);

    expect(await updater.refresh(), isFalse);
    expect(store.followChecks[only.id]?.failures, 1, reason: '失败要记下来做退避');
  });

  test('没有追剧时刷新直接算成功，不打扰用户', () async {
    final repository = FakeRepository();
    final store = await openStore();
    final updater = FollowUpdater(
      repository,
      store,
      startDelay: const Duration(days: 1),
      interval: const Duration(days: 1),
    );
    addTearDown(updater.dispose);

    expect(await updater.refresh(), isTrue);
    expect(repository.detailRequests, 0);
  });

  // 2.0.0+153：点底栏「追剧」切进来时顺手核对，但要节流 ——
  // 来回切栏目不能把 11 个站源的详情接口反复打一遍。
  test('切进追剧页：刚核对过就不重复请求', () async {
    final repository = FakeRepository();
    final store = await openStore();
    final only = drama('f1', title: '追剧一');
    await store.toggleFavorite(only);
    final now = DateTime.now();
    await store.saveFollowChecks(
      {only.id: FollowCheck(now.subtract(const Duration(minutes: 1)))},
      epoch: store.profileEpoch,
    );
    final updater = FollowUpdater(
      repository,
      store,
      startDelay: const Duration(days: 1),
      interval: const Duration(days: 1),
      clock: () => now,
    );
    addTearDown(updater.dispose);

    expect(await updater.refresh(force: false), isTrue);
    expect(repository.detailRequests, 0, reason: '1 分钟前刚查过，不该再打一次');
  });

  test('切进追剧页：隔了 5 分钟以上就核对', () async {
    final repository = FakeRepository();
    final store = await openStore();
    final only = drama('f1', title: '追剧一');
    await store.toggleFavorite(only);
    final now = DateTime.now();
    await store.saveFollowChecks(
      {only.id: FollowCheck(now.subtract(const Duration(minutes: 10)))},
      epoch: store.profileEpoch,
    );
    final updater = FollowUpdater(
      repository,
      store,
      startDelay: const Duration(days: 1),
      interval: const Duration(days: 1),
      clock: () => now,
    );
    addTearDown(updater.dispose);

    expect(await updater.refresh(force: false), isTrue);
    expect(repository.detailRequests, 1, reason: '10 分钟前的记录算过期');
    expect(
      store.followChecks[only.id]?.checkedAt,
      now,
      reason: '核对成功要把时间写成现在',
    );
  });

  test('上一次还没跑完时不当成失败，也不重复跑', () async {
    final repository = FakeRepository();
    final store = await openStore();
    final only = drama('f1', title: '追剧一');
    await store.toggleFavorite(only);
    final updater = FollowUpdater(
      repository,
      store,
      startDelay: const Duration(days: 1),
      interval: const Duration(days: 1),
    );
    addTearDown(updater.dispose);

    final first = updater.refresh();
    final second = await updater.refresh();
    expect(second, isTrue, reason: '正在跑的那一轮会自己收尾，界面别报失败');
    expect(await first, isTrue);
    expect(repository.detailRequests, 1, reason: '只跑一轮');
  });
}
