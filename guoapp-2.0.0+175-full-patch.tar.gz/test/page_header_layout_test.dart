import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:duanju_app/core_bridge.dart';
import 'package:duanju_app/ui/app_scope.dart';
import 'package:duanju_app/ui/theme/glass.dart';
import 'package:duanju_app/ui/widgets/page_header.dart';

/// 只为了让 [AppScope] 能建起来；这些用例只画顶栏，不会碰仓库。
class _FakeRepository implements AppRepository {
  @override
  dynamic noSuchMethod(Invocation invocation) =>
      throw UnimplementedError('${invocation.memberName} 不该在顶栏用例里被调用');
}

/// 顶栏：站名 + 右边竖排两行数字 + 最右三个图标。
///
/// +140 真机上是乱的：数字跑到最左边、站名消失、图标压在数字上。
/// 根因是同一条信息被 subtitle / note / subtitleLines 传了三遍，
/// subtitle 和统计行在 Row 里各占一个 Flexible，标题被挤成 0 宽。
/// 这个用例把那几条约束钉死。
void main() {
  Widget harness({double width = 390, String subtitle = ''}) => MaterialApp(
    home: MediaQuery(
      data: MediaQueryData(size: Size(width, 844), devicePixelRatio: 3),
      child: Scaffold(
        body: PageHeader(
          title: '黄果短剧',
          subtitle: subtitle,
          note: '共 1,152 部',
          subtitleLines: const ['今日更新 28 集'],
          actions: const [
            Icon(Icons.visibility_rounded, key: ValueKey('eye')),
            Icon(Icons.public_rounded, key: ValueKey('globe')),
            Icon(Icons.search_rounded, key: ValueKey('search')),
          ],
        ),
      ),
    ),
  );

  Future<void> check(
    WidgetTester tester,
    double width, {
    String subtitle = '',
  }) async {
    await tester.pumpWidget(harness(width: width, subtitle: subtitle));
    await tester.pumpAndSettle();

    final title = tester.getRect(find.text('黄果短剧'));
    final first = tester.getRect(find.text('共 1,152 部'));
    final second = tester.getRect(find.text('今日更新 28 集'));
    final eye = tester.getRect(find.byKey(const ValueKey('eye')));

    expect(title.width, greaterThan(48), reason: '站名被挤没了（$width）');
    // 两行数字贴在站名右边、共用同一个左边缘。
    expect(first.left, greaterThan(title.right), reason: '数字跑到站名左边了（$width）');
    expect((first.left - second.left).abs(), lessThan(1.0), reason: '两行数字左边缘没对齐（$width）');
    expect(second.top, greaterThan(first.top), reason: '两行数字没有竖排（$width）');
    // 图标在数字右边，不许压上来。
    expect(eye.left, greaterThanOrEqualTo(first.right - 0.5), reason: '图标压在数字上（$width）');
    // 同一条信息只画一遍：单行版本不该再出现。
    expect(find.text('共 1,152 部 · 今日更新 28 集'), findsNothing);
  }

  testWidgets('极窄 320 不重叠', (tester) async => check(tester, 320));
  testWidgets('窄屏 360 不重叠', (tester) async => check(tester, 360));
  testWidgets('常规 390 不重叠', (tester) async => check(tester, 390));
  testWidgets('大屏 430 不重叠', (tester) async => check(tester, 430));

  // 发现页以前同时传 subtitle + note + subtitleLines（同一句话三遍），
  // 这是 +140 顶栏散架的直接原因：subtitle 抢走一半宽度，标题被挤成 0。
  testWidgets('调用方多传一份 subtitle 也不会把标题挤没', (tester) async {
    await check(
      tester,
      390,
      subtitle: '共 1,152 部 · 今日更新 28 集',
    );
  });

  // 发现页：玻璃必须拉成一整条，把右边三颗按钮包进去。
  // +143 之前玻璃只包标题，按钮露在外面，看着像被切掉一块。
  Widget wideHarness() => AppScope(
    repository: _FakeRepository(),
    liquidGlass: true,
    formFactor: FormFactor.phone,
    child: MaterialApp(
      home: MediaQuery(
        data: const MediaQueryData(size: Size(390, 844), devicePixelRatio: 3),
        child: Scaffold(
          body: PageHeader(
            title: '野果',
            note: '共 1,388 部',
            stretch: true,
            actions: const [
              Icon(Icons.visibility_rounded, key: ValueKey('eye')),
              Icon(Icons.public_rounded, key: ValueKey('globe')),
              Icon(Icons.search_rounded, key: ValueKey('search')),
            ],
          ),
        ),
      ),
    ),
  );

  testWidgets('长条玻璃把右侧三颗按钮一起包住', (tester) async {
    await tester.pumpWidget(wideHarness());
    await tester.pumpAndSettle();
    final glass = tester.getRect(find.byType(GlassPanel));
    expect(glass.width, greaterThan(390 - 26), reason: '玻璃没有拉成长条');
    for (final key in ['eye', 'globe', 'search']) {
      final rect = tester.getRect(find.byKey(ValueKey(key)));
      expect(
        glass.contains(rect.center),
        isTrue,
        reason: '$key 露在玻璃外面',
      );
    }
    // 高度仍要和其他页的顶栏一致（58 + 上下描边），不能为了包按钮变高。
    expect(glass.height, lessThan(60));
  });

  testWidgets('「共 N 部」用主题色标出来', (tester) async {
    await tester.pumpWidget(wideHarness());
    await tester.pumpAndSettle();
    final text = tester.widget<Text>(find.text('共 1,388 部'));
    final primary = Theme.of(
      tester.element(find.byType(PageHeader)),
    ).colorScheme.primary;
    expect(text.style?.color, primary, reason: '「共 N 部」没有上色');
  });
}
