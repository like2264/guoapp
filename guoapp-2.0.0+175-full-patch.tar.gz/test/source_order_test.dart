import 'package:flutter_test/flutter_test.dart';

import 'support/fakes.dart';

void main() {
  /// 2.0.0+155：用户要求「退出重进就是上一次的保存顺序」。
  /// 面板里拖完立刻关掉再点开、或者干脆退出 App 重进，看到的都得是排好的顺序。
  test('拖完立刻生效，不用等写盘回来', () async {
    final store = await openStore();
    final ids = [for (final site in store.sources) site.id];
    expect(ids.length, greaterThan(2), reason: '站源太少没法验证换位');

    // 「写盘」这一步故意不 await：界面在拖完的同一帧就要读到新顺序。
    final pending = store.setSourceOrder([
      ids.last,
      ...ids.take(ids.length - 1),
    ]);
    expect([for (final site in store.sources) site.id], [
      ids.last,
      ...ids.take(ids.length - 1),
    ]);

    await pending;
    expect(store.sourceOrder.first, ids.last);
  });

  test('重新打开存储（退出重进）还是上一次拖的顺序', () async {
    final files = MemoryFiles();
    final first = await openStore(const {}, null, files);
    final ids = [for (final site in first.sources) site.id];
    expect(ids.length, greaterThan(2));

    // 把第二个挪到最前，尾巴顺序保持不变。
    final order = [ids[1], ids[0], ...ids.skip(2)];
    await first.setSourceOrder(order);
    expect(first.sourceOrder, order);

    // 同一个存储目录再开一次 = 冷启动。
    final again = await openStore(const {}, null, files);
    expect(
      [for (final site in again.sources) site.id],
      order,
      reason: '退出重进必须按上次保存的顺序摆',
    );
  });

  test('非法 id 与重复 id 被清掉，不会把顺序弄乱', () async {
    final store = await openStore();
    final ids = [for (final site in store.sources) site.id];
    // 站源 id 只校验字符格式（动态模块站源不在这里的枚举里），所以用带空格的
    // 非法值来验证「脏数据进不来」。
    await store.setSourceOrder([ids[1], 'bad id', ids[1], ids[0]]);
    expect(store.sourceOrder, [ids[1], ids[0]]);
  });

  test('顺序没变时不重复写盘', () async {
    final files = _CountingFiles();
    final store = await openStore(const {}, null, files);
    final ids = [for (final site in store.sources) site.id];
    await store.setSourceOrder([ids[1], ids[0]]);
    final writes = files.writes;
    await store.setSourceOrder([ids[1], ids[0]]);
    expect(files.writes, writes, reason: '同样的顺序再点一次不该再写一遍');
  });
}

class _CountingFiles extends MemoryFiles {
  int writes = 0;

  @override
  Future<void> write(String name, Object? value) {
    writes++;
    return super.write(name, value);
  }
}
