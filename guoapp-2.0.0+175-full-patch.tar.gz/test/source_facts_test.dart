import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:duanju_app/drama_feed.dart';
import 'package:duanju_app/models.dart';
import 'package:duanju_app/source_stats.dart';
import 'package:duanju_app/ui/widgets/drama_grid.dart';

/// 部数口径（2.0.0+150 定死）：顶栏 = 底部 = 末位卡片，三处是同一个数。
///
/// - 顶栏：站点所有作品数（各分类相加、去重）
/// - 底部：拉到底时一共加载过的作品数
/// - 末位卡片：作品总数（连续序号）
///
/// 所以「翻到底实测出来的独立条数」（[SourceFacts.listed]）优先，站点声明只在
/// 还没翻到底时当预期值。历史上这里反着来过两次：
/// - 顶栏报声明、底部报实际条数，差几十上百部（+143 之前）；
/// - +149 一律信声明，结果顶栏 1,401 / 末位卡片 1,388、夜社末位卡片不到 500。
void main() {
  test('翻到底实测的独立条数优先，顶栏跟着末位卡片走', () {
    const facts = SourceFacts(site: 1401, listed: 1388, probed: true);
    expect(facts.total, 1388, reason: '顶栏必须等于列表真正摆出来的作品数');
    expect(facts.headline, '共 1,388 部');
  });

  test('还没翻到底就用站点声明当预期值', () {
    const facts = SourceFacts(site: 2056, probed: true);
    expect(facts.total, 2056);
    expect(facts.headline, '共 2,056 部');
  });

  test('实测比声明多也以实测为准（页面真的摆出来这么多）', () {
    const facts = SourceFacts(site: 1900, listed: 1951, probed: true);
    expect(facts.total, 1951);
    expect(facts.headline, '共 1,951 部');
  });

  test('只有实测值（站点给不出总量）也报「共 N 部」', () {
    const facts = SourceFacts(listed: 843, probed: true);
    expect(facts.total, 843);
    expect(facts.headline, '共 843 部');
  });

  // 2.0.0+154：实测条数重新落盘并认账 —— 进站先显示上次量到的真实部数
  // （X短剧声明 2,180、实际 2,169），随后由 ExploreFeed 在后台重测，
  // 所以不会再出现 +148 那种「旧值永远压住站点声明」。
  test('落盘的实测条数读出来就是顶栏那个数', () {
    final raw = <String, Object?>{
      'huangtao': {
        'day': factsDay(DateTime.now()),
        'site': 2056,
        'local': 300,
        'updated': 12,
        'listed': 1951,
        'probed': true,
        'all': ['huangtao:1'],
      },
    };
    final facts = readFacts(raw, 'huangtao');
    expect(facts.listed, 1951);
    expect(facts.probed, isTrue);
    expect(facts.total, 1951, reason: '顶栏报实测部数，不报站点声明');
    expect(facts.site, 2056);
    expect(facts.updated, 12);
    expect(readKnown(raw, 'huangtao'), ['huangtao:1']);
  });

  test('writeFacts 重写整行时把实测值原样带回来，其它观测值照旧', () {
    final raw = <String, Object?>{
      'huangtao': {
        'day': factsDay(DateTime.now()),
        'site': 2056,
        'local': 300,
        'updated': 3,
        'listed': 1951,
        'probed': true,
      },
    };
    final saved = writeFacts(raw, 'huangtao', site: 2060, local: 301, gained: 2);
    final facts = readFacts(saved, 'huangtao');
    // 整行是重建的：漏带 listed 就等于每观测一次都把顶栏的实测值洗掉，
    // +148 的「顶栏又掉回站点声明」就是这么来的。
    expect(facts.listed, 1951);
    expect(facts.site, 2060);
    expect(facts.updated, 5);
    expect((saved['huangtao'] as Map)['listed'], 1951);
  });

  testWidgets('底栏滚到底只报一个数字', (tester) async {
    final feed = DramaFeed(
      load: (page, force) async => CatalogPage(const [], hasMore: false),
    );
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(body: FeedFooter(feed: feed, count: 1951)),
      ),
    );
    expect(find.text('已经到底了 · 共 1,951 部'), findsOneWidget);
    expect(find.textContaining('顶栏'), findsNothing);
    feed.dispose();
  });

  /// 2.0.0+154：实测条数和「多久之前测的」要落盘，进站先拿它当顶栏，
  /// 超过 listedFreshFor 再重测。
  test('实测条数连同时间和扫分类的时间一起落盘', () {
    final now = DateTime(2026, 11, 23, 22, 10);
    final saved = writeListedStats(
      const <String, Object?>{},
      'xduanju',
      listed: 2169,
      swept: now,
      now: now,
    );
    final stats = readListedStats(saved, 'xduanju');
    expect(stats.listed, 2169);
    expect(stats.at, now);
    expect(stats.swept, now);
    // 别的观测值不能被这个写操作弄丢。
    final facts = readFacts(
      writeFacts(saved, 'xduanju', site: 2180, local: 2000),
      'xduanju',
      now: now,
    );
    expect(facts.listed, 2169);
    expect(facts.site, 2180);
    expect(readListedStats(
      writeFacts(saved, 'xduanju', site: 2180, local: 2000),
      'xduanju',
    ).listed, 2169, reason: 'writeFacts 重建整行时必须把实测值带回来');
  });
}
