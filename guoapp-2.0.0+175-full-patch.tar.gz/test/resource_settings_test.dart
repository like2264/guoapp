import 'package:duanju_app/resource_settings.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('proxyBySource 往返：站源覆盖项按 JSON 原样保留', () {
    final settings = ResourceSettings.fromJson({
      'proxyMode': 'manual',
      'proxyUrl': 'http://127.0.0.1:7890',
      'proxyBySource': {
        'yesheai': {'mode': 'direct'},
        'huangtao': {'mode': 'manual', 'url': 'socks5://127.0.0.1:1080'},
      },
    });
    expect(settings.proxyBySource['yesheai']?.mode, 'direct');
    expect(settings.proxyBySource['huangtao']?.url, 'socks5://127.0.0.1:1080');

    final json = settings.toJson();
    expect((json['proxyBySource'] as Map)['yesheai']['mode'], 'direct');
    // 没单独设置的站源不写进 JSON，后端按「跟随全局」处理
    expect(
      ResourceSettings.fromJson(json).proxyBySource.keys,
      unorderedEquals(['yesheai', 'huangtao']),
    );
  });

  test('全部跟随全局时不写 proxyBySource 字段', () {
    expect(
      const ResourceSettings().toJson().containsKey('proxyBySource'),
      isFalse,
    );
    expect(
      ResourceSettings.fromJson({'proxyBySource': null}).proxyBySource,
      isEmpty,
    );
  });
}
