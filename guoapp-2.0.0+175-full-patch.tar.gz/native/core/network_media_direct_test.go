package core

import (
	"net/http"
	"testing"
)

func TestNoProxyMediaClientNeverUsesProxy(t *testing.T) {
	var downloader Downloader
	client := downloader.noProxyMediaClient()
	transport, ok := client.Transport.(*http.Transport)
	if !ok {
		t.Fatalf("媒体客户端 Transport 类型 = %T，期望 *http.Transport", client.Transport)
	}
	if transport.Proxy != nil {
		t.Fatal("媒体客户端仍然配置了 Proxy，下载字节会从代理走")
	}
	if again := downloader.noProxyMediaClient(); again != client {
		t.Fatal("无代理客户端应当复用同一个实例")
	}
}
