package core

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"
)

func TestChapterEpisodeNumber(t *testing.T) {
	cases := []struct {
		chapter Chapter
		want    int
	}{
		{Chapter{}, 1},
		{Chapter{CurrentEpisode: json.RawMessage(`7`)}, 7},
		{Chapter{CurrentEpisode: json.RawMessage(`"8"`)}, 8},
		{Chapter{CurrentEpisode: json.RawMessage(`0`)}, 1},
		{Chapter{CurrentEpisode: json.RawMessage(`null`)}, 1},
	}
	for _, test := range cases {
		if got := chapterEpisodeNumber(test.chapter); got != test.want {
			t.Fatalf("chapterEpisodeNumber(%s) = %d，期望 %d", test.chapter.CurrentEpisode, got, test.want)
		}
	}
}

func TestDurationCacheRoundTrip(t *testing.T) {
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	disk := engine.loadDurationCache()
	disk.Dramas["yeguo:1"] = &nativeDurationRecord{
		Updated: 12,
		Items:   map[string]int64{"yeguo:1:1": 305000},
		Missed:  map[string]int64{"yeguo:1:2": 34},
	}
	engine.saveDurationCache(disk)

	again := engine.loadDurationCache()
	record := again.Dramas["yeguo:1"]
	if record == nil {
		t.Fatal("缓存没有落盘")
	}
	if record.Items["yeguo:1:1"] != 305000 || record.Missed["yeguo:1:2"] != 34 {
		t.Fatalf("缓存内容不对：%+v", record)
	}
}

func TestLoadDurationCacheIgnoresBrokenFile(t *testing.T) {
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	if err := writeNativeCacheFile(engine.cacheDirectory+"/"+nativeDurationFile, []byte("{ 坏掉的")); err != nil {
		t.Fatal(err)
	}
	disk := engine.loadDurationCache()
	if disk == nil || len(disk.Dramas) != 0 {
		t.Fatalf("坏掉的缓存应退回空表，实际 %+v", disk)
	}
}

func TestTrimNativeDurations(t *testing.T) {
	dramas := map[string]*nativeDurationRecord{}
	for index := 0; index < nativeDurationDramaLimit+10; index++ {
		dramas[fmt.Sprintf("d%d", index)] = &nativeDurationRecord{Updated: int64(index)}
	}
	trimNativeDurations(dramas)
	if len(dramas) != nativeDurationDramaLimit {
		t.Fatalf("淘汰后应剩 %d 部，实际 %d", nativeDurationDramaLimit, len(dramas))
	}
	if _, found := dramas["d0"]; found {
		t.Fatal("最久没刷新的那部没有淘汰")
	}
	if _, found := dramas[fmt.Sprintf("d%d", nativeDurationDramaLimit+9)]; !found {
		t.Fatal("最新刷新的那部被误删")
	}
}

func TestChapterDurationsRejectsInvalidDrama(t *testing.T) {
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	_, err := engine.nativeChapterDurations(context.Background(), nativeInput{
		Drama:    LibraryDrama{},
		Chapters: []Chapter{{ID: "x"}},
	})
	if err == nil {
		t.Fatal("无效剧集应该报错")
	}
}

func TestChapterDurationsEmptyChapters(t *testing.T) {
	const source = "durationprobe"
	descriptor := SourceDescriptor{ID: source}
	factory := func(Host) Provider {
		return &registryTestProvider{descriptor: descriptor}
	}
	Register(descriptor, factory)
	t.Cleanup(func() { Unregister(source) })

	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	result, err := engine.nativeChapterDurations(context.Background(), nativeInput{
		Drama: LibraryDrama{ID: source + ":1"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(result.Items) != 0 {
		t.Fatalf("没有分集时不该有结果，实际 %+v", result.Items)
	}
}
