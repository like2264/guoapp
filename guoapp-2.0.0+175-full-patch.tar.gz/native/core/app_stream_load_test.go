package core

import (
	"bytes"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

// 播放器和预取要同一片时，只允许去上游取一次。
//
// 拖动进度时播放器会连着点好几片，预取也在同时拉后面几片；以前两边各取一遍，
// 一片 600KB，几个请求抢同一条网络，谁都慢，画面迟迟出不来。
func TestNativeStreamCoalescesSegmentLoad(t *testing.T) {
	var mu sync.Mutex
	hits := map[string]int{}
	upstream := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		mu.Lock()
		hits[request.URL.Path]++
		mu.Unlock()
		// 稍微慢一点，让并发的请求确实撞在「正在取」这段窗口里。
		time.Sleep(200 * time.Millisecond)
		body := bytes.Repeat([]byte("x"), 2048)
		writer.Header().Set("Content-Type", "video/mp4")
		writer.Header().Set("Content-Length", strconv.Itoa(len(body)))
		_, _ = writer.Write(body)
	}))
	defer upstream.Close()

	stream, err := newNativeStreamServer(&Downloader{client: &http.Client{}})
	if err != nil {
		t.Fatal(err)
	}
	defer stream.server.Close()
	playlist := "#EXTM3U\n#EXT-X-VERSION:7\n#EXT-X-MAP:URI=\"init.mp4\"\n" +
		"#EXTINF:2.000000,\nseg0.m4s\n#EXT-X-ENDLIST"
	local, token := stream.nativeOpen(ProviderMedia{URL: upstream.URL + "/playlist.m3u8", Playlist: playlist}, nil)
	defer stream.nativeRelease(token)

	response, err := http.Get(local)
	if err != nil {
		t.Fatal(err)
	}
	body, _ := io.ReadAll(response.Body)
	_ = response.Body.Close()
	segment := ""
	for _, line := range strings.Split(string(body), "\n") {
		if strings.HasSuffix(strings.TrimSpace(line), ".m4s") {
			segment = strings.TrimSpace(line)
		}
	}
	if segment == "" {
		t.Fatalf("播放列表里没有分片：%s", body)
	}

	var workers sync.WaitGroup
	for index := 0; index < 6; index++ {
		workers.Add(1)
		go func() {
			defer workers.Done()
			resp, err := http.Get(segment)
			if err != nil {
				return
			}
			_, _ = io.Copy(io.Discard, resp.Body)
			_ = resp.Body.Close()
		}()
	}
	workers.Wait()

	mu.Lock()
	count := hits["/seg0.m4s"]
	mu.Unlock()
	if count != 1 {
		t.Fatalf("同一片被取了 %d 次，应当合并成 1 次", count)
	}
}

// 预取失败或没取到时，播放器自己的请求必须还能拿到数据（不能因为等别人而饿死）。
func TestNativeStreamSegmentServesAfterOwnerFails(t *testing.T) {
	var mu sync.Mutex
	hits := 0
	upstream := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		mu.Lock()
		hits++
		mu.Unlock()
		body := bytes.Repeat([]byte("y"), 1024)
		writer.Header().Set("Content-Type", "video/mp4")
		writer.Header().Set("Content-Length", strconv.Itoa(len(body)))
		_, _ = writer.Write(body)
	}))
	defer upstream.Close()

	stream, err := newNativeStreamServer(&Downloader{client: &http.Client{}})
	if err != nil {
		t.Fatal(err)
	}
	defer stream.server.Close()
	playlist := "#EXTM3U\n#EXTINF:2.000000,\nseg0.m4s\n#EXT-X-ENDLIST"
	local, token := stream.nativeOpen(ProviderMedia{URL: upstream.URL + "/playlist.m3u8", Playlist: playlist}, nil)
	defer stream.nativeRelease(token)

	response, err := http.Get(local)
	if err != nil {
		t.Fatal(err)
	}
	body, _ := io.ReadAll(response.Body)
	_ = response.Body.Close()
	segment := ""
	for _, line := range strings.Split(string(body), "\n") {
		if strings.HasSuffix(strings.TrimSpace(line), ".m4s") {
			segment = strings.TrimSpace(line)
		}
	}
	if segment == "" {
		t.Fatalf("播放列表里没有分片：%s", body)
	}
	resp, err := http.Get(segment)
	if err != nil {
		t.Fatal(err)
	}
	data, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()
	if resp.StatusCode != http.StatusOK || len(data) != 1024 {
		t.Fatalf("分片响应是 %d，长度 %d", resp.StatusCode, len(data))
	}
}

// 预取卡在上游时，播放器不能跟着一起等：等满 nativePlayerWaitLimit 就自己取。
//
// 这是 +140 真机日志里那种「拖动到位 1.0s，20 秒后 seek_stalled」的根：
// 预取手里正拿着播放器要的那一片，而它的超时比拖动判死还长。
func TestNativeStreamPlayerDoesNotWaitForStuckLoad(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		body := bytes.Repeat([]byte("z"), 1024)
		writer.Header().Set("Content-Type", "video/mp4")
		writer.Header().Set("Content-Length", strconv.Itoa(len(body)))
		_, _ = writer.Write(body)
	}))
	defer upstream.Close()

	stream, err := newNativeStreamServer(&Downloader{client: &http.Client{}})
	if err != nil {
		t.Fatal(err)
	}
	defer stream.server.Close()
	playlist := "#EXTM3U\n#EXTINF:2.000000,\nseg0.m4s\n#EXT-X-ENDLIST"
	local, token := stream.nativeOpen(ProviderMedia{URL: upstream.URL + "/playlist.m3u8", Playlist: playlist}, nil)
	defer stream.nativeRelease(token)

	response, err := http.Get(local)
	if err != nil {
		t.Fatal(err)
	}
	body, _ := io.ReadAll(response.Body)
	_ = response.Body.Close()
	segment := ""
	for _, line := range strings.Split(string(body), "\n") {
		if strings.HasSuffix(strings.TrimSpace(line), ".m4s") {
			segment = strings.TrimSpace(line)
		}
	}
	if segment == "" {
		t.Fatalf("播放列表里没有分片：%s", body)
	}

	// 冒充一个「已经在下载但迟迟不结束」的预取：占住这一片的登记。
	parsed, err := url.Parse(segment)
	if err != nil {
		t.Fatal(err)
	}
	parts := strings.Split(strings.Trim(parsed.Path, "/"), "/")
	stream.mu.Lock()
	session := stream.sessions[parts[0]]
	stream.mu.Unlock()
	if session == nil {
		t.Fatalf("找不到会话：%s", parsed.Path)
	}
	stuck := &segmentLoad{done: make(chan struct{})}
	session.mu.Lock()
	if session.loads == nil {
		session.loads = map[string]*segmentLoad{}
	}
	session.loads[parts[1]] = stuck
	session.mu.Unlock()
	defer close(stuck.done)

	started := time.Now()
	resp, err := http.Get(segment)
	if err != nil {
		t.Fatal(err)
	}
	data, _ := io.ReadAll(resp.Body)
	_ = resp.Body.Close()
	cost := time.Since(started)
	if resp.StatusCode != http.StatusOK || len(data) != 1024 {
		t.Fatalf("分片响应是 %d，长度 %d", resp.StatusCode, len(data))
	}
	if cost < nativePlayerWaitLimit {
		t.Fatalf("没等够就让路了（%s），登记根本没用上", cost)
	}
	if cost > nativePlayerWaitLimit+2*time.Second {
		t.Fatalf("等太久才自己取：%s", cost)
	}
}
