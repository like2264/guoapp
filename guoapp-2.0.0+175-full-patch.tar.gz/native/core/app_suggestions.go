package core

import (
	"context"
	"errors"
	"sort"
	"strings"
	"sync"
	"time"
)

// 联想搜索。老版本靠红果的搜索联想接口给所有站源供词，2.0 没有红果了，
// 于是这里补一条通用兜底：站源自己实现了 suggestions 就用它，否则拿它
// 的搜索接口跑一遍关键词，把命中的剧名当成联想词返回。
//
// 只回「看起来像剧名」的短词（太长的是标题党，当联想词没有意义），
// 并按「以关键词开头 > 包含关键词 > 其它」排一下，最多 10 条。
const (
	nativeSuggestionLimit  = 10
	nativeSuggestionRunes  = 24
	nativeSuggestionBudget = 8 * time.Second
)

func (engine *nativeEngine) suggestions(ctx context.Context, source, query string) ([]string, error) {
	query = strings.TrimSpace(query)
	if query == "" {
		return []string{}, nil
	}
	source = canonicalProviderSource(source)
	p, ok := engine.downloader.provider(source)
	if !ok {
		return nil, errors.New("请选择有效站源")
	}
	if cached, found := nativeSuggestionLookup(source, query); found {
		return cached, nil
	}
	if suggester, ok := providerAs[Suggester](p); ok {
		budget, cancel := context.WithTimeout(ctx, nativeSuggestionBudget)
		defer cancel()
		if items, err := suggester.Suggestions(budget, query); err == nil && len(items) > 0 {
			cleaned := nativeCleanSuggestions(items, query)
			nativeSuggestionStore(source, query, cleaned)
			return cleaned, nil
		}
	}
	items, err := engine.searchSuggestions(ctx, source, query)
	if err == nil {
		nativeSuggestionStore(source, query, items)
	}
	return items, err
}

// 联想词缓存。联想是「打一个字问一次」，同一条前缀（还有退格回去）会反复
// 命中同一个搜索接口，而站点一次要 1~2 秒。缓存 3 分钟，够覆盖打字这段时间。
const (
	nativeSuggestionTTL       = 3 * time.Minute
	nativeSuggestionCacheSize = 64
)

type nativeSuggestionEntry struct {
	items   []string
	expires time.Time
}

var (
	nativeSuggestionMu     sync.Mutex
	nativeSuggestionsByKey = map[string]nativeSuggestionEntry{}
)

func nativeSuggestionKey(source, query string) string {
	return source + "\x00" + NativeSearchText(query)
}

func nativeSuggestionLookup(source, query string) ([]string, bool) {
	key := nativeSuggestionKey(source, query)
	nativeSuggestionMu.Lock()
	defer nativeSuggestionMu.Unlock()
	entry, found := nativeSuggestionsByKey[key]
	if !found || time.Now().After(entry.expires) {
		return nil, false
	}
	return entry.items, true
}

func nativeSuggestionStore(source, query string, items []string) {
	if len(items) == 0 {
		return
	}
	key := nativeSuggestionKey(source, query)
	now := time.Now()
	nativeSuggestionMu.Lock()
	defer nativeSuggestionMu.Unlock()
	if len(nativeSuggestionsByKey) >= nativeSuggestionCacheSize {
		for existing, entry := range nativeSuggestionsByKey {
			if now.After(entry.expires) {
				delete(nativeSuggestionsByKey, existing)
			}
		}
		if len(nativeSuggestionsByKey) >= nativeSuggestionCacheSize {
			nativeSuggestionsByKey = map[string]nativeSuggestionEntry{}
		}
	}
	copied := make([]string, len(items))
	copy(copied, items)
	nativeSuggestionsByKey[key] = nativeSuggestionEntry{
		items:   copied,
		expires: now.Add(nativeSuggestionTTL),
	}
}

// searchSuggestions 用站源搜索接口反推联想词。
func (engine *nativeEngine) searchSuggestions(ctx context.Context, source, query string) ([]string, error) {
	items, _, err := engine.searchFirstPage(ctx, source, query)
	if err != nil {
		return []string{}, err
	}
	titles := make([]string, 0, len(items))
	for _, item := range items {
		titles = append(titles, item.Title)
	}
	return nativeCleanSuggestions(titles, query), nil
}

// searchFirstPage 只取搜索结果，供联想搜索和全站搜索复用。
func (engine *nativeEngine) searchFirstPage(ctx context.Context, source, query string) ([]LibraryDrama, bool, error) {
	source = canonicalProviderSource(source)
	if !registeredProviderSource(source) {
		return nil, false, errors.New("请选择有效站源")
	}
	p, ok := engine.downloader.provider(source)
	if !ok {
		return nil, false, errors.New("请选择有效站源")
	}
	budget, cancel := context.WithTimeout(ctx, nativeSuggestionBudget)
	defer cancel()
	var items []Drama
	var more bool
	var err error
	switch searcher := p.(type) {
	case WarningSearcher:
		items, more, _, err = searcher.SearchWithWarning(budget, 1, query)
	case Searcher:
		items, more, err = searcher.Search(budget, 1, query)
	default:
		return nil, false, errors.New("该站源不支持在线搜索")
	}
	if err != nil {
		return nil, false, err
	}
	normalized := make([]LibraryDrama, 0, len(items))
	for _, drama := range items {
		normalized = append(normalized, NativeNormalize(drama))
	}
	return normalized, more, nil
}

// nativeCleanSuggestions 去重、截断、按与关键词的贴合度排序。
func nativeCleanSuggestions(raw []string, query string) []string {
	keyword := NativeSearchText(query)
	seen := map[string]bool{}
	type scored struct {
		text  string
		score int
		order int
	}
	rows := make([]scored, 0, len(raw))
	for index, item := range raw {
		text := strings.TrimSpace(item)
		if text == "" || len([]rune(text)) > nativeSuggestionRunes {
			continue
		}
		key := NativeSearchText(text)
		if key == "" || seen[key] || key == keyword {
			continue
		}
		seen[key] = true
		score := 1
		switch {
		case strings.HasPrefix(key, keyword):
			score = 3
		case strings.Contains(key, keyword):
			score = 2
		}
		rows = append(rows, scored{text: text, score: score, order: index})
	}
	sort.SliceStable(rows, func(i, j int) bool {
		if rows[i].score != rows[j].score {
			return rows[i].score > rows[j].score
		}
		return rows[i].order < rows[j].order
	})
	out := make([]string, 0, nativeSuggestionLimit)
	for _, row := range rows {
		out = append(out, row.text)
		if len(out) >= nativeSuggestionLimit {
			break
		}
	}
	return out
}

// nativeSearchAllIssue 记录某个站源在全站搜索里失败的原因。
type nativeSearchAllIssue struct {
	Source string `json:"source"`
	Name   string `json:"name"`
	Error  string `json:"error"`
}

type nativeSearchAllResult struct {
	Items  []LibraryDrama         `json:"items"`
	Issues []nativeSearchAllIssue `json:"issues,omitempty"`
	Total  int                    `json:"total"`
}

// nativeSearchAll 并发在所有支持的站源里搜同一个关键词，按相关度合并。
// 单个站源失败只记录下来，不影响其它站源的结果。
func (engine *nativeEngine) nativeSearchAll(ctx context.Context, query string) (nativeSearchAllResult, error) {
	query = strings.TrimSpace(query)
	if query == "" {
		return nativeSearchAllResult{}, errors.New("请输入搜索关键词")
	}
	type target struct {
		id   string
		name string
	}
	var targets []target
	for _, descriptor := range registeredDescriptors() {
		if !nativeSourceAvailable(descriptor.ID) {
			continue
		}
		if _, ok := engine.downloader.provider(descriptor.ID); !ok {
			continue
		}
		// 2.0.0+148 起不再要求模块声明 search 能力：模块商店里的「黄果旧版 1.0.0」
		// 只有 cover 能力、main.js 压根没导出 search，按老逻辑会被整站跳过，
		// 用户在全站搜索里永远看不到它的作品。没有在线搜索的站源改走本地
		// 目录/索引兜底（见 searchAllSource），有搜索的照旧并发去问站点。
		targets = append(targets, target{id: descriptor.ID, name: descriptor.Name})
	}
	if len(targets) == 0 {
		return nativeSearchAllResult{}, errors.New("没有支持在线搜索的站源")
	}
	ctx, cancel := context.WithTimeout(ctx, 35*time.Second)
	defer cancel()
	results := make([][]LibraryDrama, len(targets))
	issues := make([]nativeSearchAllIssue, 0, 2)
	var mu sync.Mutex
	var wg sync.WaitGroup
	for index, item := range targets {
		wg.Add(1)
		go func(index int, id, name string) {
			defer wg.Done()
			items, err := engine.searchAllSource(ctx, id, query)
			if err != nil {
				mu.Lock()
				issues = append(issues, nativeSearchAllIssue{Source: id, Name: name, Error: PublicError(err).Error()})
				mu.Unlock()
				return
			}
			results[index] = items
		}(index, item.id, item.name)
	}
	wg.Wait()
	merged := NativeMergeSearch(results, query)
	sort.SliceStable(issues, func(i, j int) bool { return issues[i].Source < issues[j].Source })
	return nativeSearchAllResult{Items: merged, Issues: issues, Total: len(targets)}, nil
}

// searchAllSource 取某个站源在全站搜索里的第一页。
//
// 有在线搜索的站源直接问站点；没有的（模块只实现了目录）走 nativeCatalogRaw
// 的本地兜底：内存里已经翻回来的目录 + 落盘的搜索索引。索引不够新时补一次
// searchIndexed，让「翻到过」的作品至少能被搜到。
func (engine *nativeEngine) searchAllSource(ctx context.Context, source, query string) ([]LibraryDrama, error) {
	p, ok := engine.downloader.provider(source)
	if !ok {
		return nil, errors.New("请选择有效站源")
	}
	online := false
	if _, ok := providerAs[WarningSearcher](p); ok {
		online = true
	} else if _, ok := providerAs[Searcher](p); ok {
		online = true
	}
	var failure error
	if online {
		items, _, err := engine.searchFirstPage(ctx, source, query)
		if err == nil && len(items) > 0 {
			return items, nil
		}
		failure = err
	} else {
		raw, err := engine.nativeCatalogRaw(ctx, nativeInput{Source: source, Query: query, Page: 1})
		if err == nil && len(raw.Items) > 0 {
			return raw.Items, nil
		}
		failure = err
	}
	// 站点这条线没给出东西：用本地索引补一页（翻到过、补到过简介的作品）。
	hits := searchIndexPageSlice(engine.searchIndexed(source, query), 1)
	if len(hits) > 0 || failure == nil {
		return hits, nil
	}
	return nil, failure
}
