package core

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func writeTestModuleManifest(t *testing.T, dataDir, id, version string) {
	t.Helper()
	dir := filepath.Join(dataDir, moduleDirectory, id)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	body := []byte(`{"id":"` + id + `","name":"test","version":"` + version + `","runtime":"js","api":1}`)
	if err := os.WriteFile(filepath.Join(dir, moduleManifest), body, 0o644); err != nil {
		t.Fatal(err)
	}
}

// 模块换代后，上一版写进 catalogs.json 的目录必须作废：
// 否则 saveCatalogCache 在 page==1 时会把旧卡片整段补回去，
// 用户看到的就是「新模块白装了」（夜社 1.0.5 → 1.0.6 就是这么被旧卡顶住的）。
func TestCatalogCacheDroppedWhenModuleVersionChanges(t *testing.T) {
	dataDir, cache := t.TempDir(), t.TempDir()
	writeTestModuleManifest(t, dataDir, "yesheai", "1.0.7")

	start := func() *nativeEngine {
		engine := &nativeEngine{
			directory:       dataDir,
			cacheDirectory:  cache,
			downloader:      &Downloader{cfg: Config{dataDir: dataDir}},
			catalogs:        map[string][]LibraryDrama{},
			catalogStates:   map[string]nativeCatalogState{},
			categoryOptions: map[string][]Category{},
		}
		engine.loadCatalogCache()
		return engine
	}
	writeDisk := func(version int, modules map[string]string) {
		body, err := json.Marshal(nativeCatalogDisk{
			Version: version,
			Modules: modules,
			Catalogs: map[string][]LibraryDrama{
				"yesheai":   {{ID: "yesheai:1", Source: "yesheai", Title: "国产短剧一"}},
				"yesheai|3": {{ID: "yesheai:2", Source: "yesheai", Title: "国产短剧二"}},
				"hongguo":   {{ID: "hongguo:1", Source: "hongguo", Title: "红果"}},
			},
			States: map[string]nativeCatalogState{
				"yesheai":   {Page: 5, HasMore: true},
				"yesheai|3": {Page: 2, HasMore: true},
			},
			Categories: map[string][]Category{
				"yesheai": {{ID: "1", Name: "成人短剧"}, {ID: "3", Name: "国产短剧"}, {ID: "16", Name: "AI 漫剧"}},
			},
		})
		if err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(cache, "catalogs.json"), body, 0o600); err != nil {
			t.Fatal(err)
		}
	}

	// 老缓存（Version 4，没记模块版本）：有模块的站一律按「版本未知」作废，
	// 没有模块的 Go 站源（红果）原样保留。
	writeDisk(4, nil)
	engine := start()
	if _, ok := engine.catalogs["yesheai"]; ok {
		t.Fatal("换版后旧目录还在：「全部」会把这些卡片补回来")
	}
	if _, ok := engine.catalogs["yesheai|3"]; ok {
		t.Fatal("换版后旧分类目录还在：点「国产短剧」还能翻出作品")
	}
	if _, ok := engine.catalogStates["yesheai"]; ok {
		t.Fatal("换版后旧页码还在：会从旧索引接着翻")
	}
	if _, ok := engine.categoryOptions["yesheai"]; ok {
		t.Fatal("换版后旧分类还在：分类栏仍会显示国产短剧 / AI 漫剧")
	}
	if _, ok := engine.catalogs["hongguo"]; !ok {
		t.Fatal("没有模块的站不该被清")
	}

	// Version 5 且版本一致：缓存继续用，不要无谓重拉。
	writeDisk(5, map[string]string{"yesheai": "1.0.7"})
	engine = start()
	if _, ok := engine.catalogs["yesheai"]; !ok {
		t.Fatal("模块版本没变，不该清目录缓存")
	}

	// Version 5 但版本对不上：只清这一站。
	writeDisk(5, map[string]string{"yesheai": "1.0.6"})
	engine = start()
	if _, ok := engine.catalogs["yesheai"]; ok {
		t.Fatal("模块版本变了还留着旧目录")
	}
	if _, ok := engine.catalogs["hongguo"]; !ok {
		t.Fatal("别的站被误清")
	}
}

// 装模块后立刻作废该站缓存，用户不用重启 App。
func TestInstallModuleInvalidatesCatalogCache(t *testing.T) {
	dataDir, cache := t.TempDir(), t.TempDir()
	engine := &nativeEngine{
		directory:      dataDir,
		cacheDirectory: cache,
		downloader:     &Downloader{cfg: Config{dataDir: dataDir}},
		catalogs: map[string][]LibraryDrama{
			"yesheai": {{ID: "yesheai:1", Source: "yesheai", Title: "旧卡"}},
		},
		catalogStates:   map[string]nativeCatalogState{"yesheai": {Page: 3}},
		categoryOptions: map[string][]Category{"yesheai": {{ID: "3", Name: "国产短剧"}}},
	}
	writeTestModuleManifest(t, dataDir, "yesheai", "1.0.7")
	engine.invalidateModuleCache("yesheai")
	if _, ok := engine.catalogs["yesheai"]; ok {
		t.Fatal("装模块后旧目录没清")
	}
	if _, ok := engine.categoryOptions["yesheai"]; ok {
		t.Fatal("装模块后旧分类没清")
	}
	body, err := os.ReadFile(filepath.Join(cache, "catalogs.json"))
	if err != nil {
		t.Fatal(err)
	}
	var disk nativeCatalogDisk
	if err := json.Unmarshal(body, &disk); err != nil {
		t.Fatal(err)
	}
	if disk.Version != 5 {
		t.Fatalf("磁盘缓存版本应为 5，实际 %d", disk.Version)
	}
	if disk.Modules["yesheai"] != "1.0.7" {
		t.Fatalf("磁盘缓存没记住模块版本：%v", disk.Modules)
	}
}
