package core

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"
)

// directMarkTransport 给「直连通道」的请求打一个标记头，服务端据此区分
// 这是代理出口还是绕开代理的那条通道。
type directMarkTransport struct{ base http.RoundTripper }

func (t directMarkTransport) RoundTrip(request *http.Request) (*http.Response, error) {
	clone := request.Clone(request.Context())
	clone.Header.Set("X-Direct-Probe", "1")
	return t.base.RoundTrip(clone)
}

// TestFetchMediaPlaylist403FallsBackToDirect 覆盖 +173 夜社间歇 403 修复：
// 常规（代理）通道全部回 403 时，fetchMediaPlaylist 应换直连通道再试一轮并成功。
func TestFetchMediaPlaylist403FallsBackToDirect(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("X-Direct-Probe") == "1" {
			w.Header().Set("Content-Type", "application/vnd.apple.mpegurl")
			_, _ = w.Write([]byte("#EXTM3U\n#EXTINF:60,\nseg0.ts\n"))
			return
		}
		http.Error(w, "forbidden", http.StatusForbidden)
	}))
	defer server.Close()

	address := server.URL + "/index.m3u8"
	referer := "http://example.com/play/1/1.html"

	var downloader Downloader
	// 常规 client：不带直连标记 → 服务端回 403。
	downloader.client = &http.Client{}
	// 先把 once 走完，再把直连 client 换成带标记的自定义实例。
	_ = downloader.noProxyMediaClient()
	downloader.mediaDirect = &http.Client{
		Transport: directMarkTransport{base: http.DefaultTransport},
	}

	playlist, _, err := downloader.fetchMediaPlaylist(context.Background(), address, referer)
	if err != nil {
		t.Fatalf("403 后直连兜底应当成功，实际失败: %v", err)
	}
	if playlist != "#EXTM3U\n#EXTINF:60,\nseg0.ts" {
		t.Fatalf("兜底拿到的播放列表不符: %q", playlist)
	}
}
