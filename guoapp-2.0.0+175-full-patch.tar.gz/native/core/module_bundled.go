package core

import (
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io/fs"
	"os"
	"path"
	"path/filepath"
	"slices"
	"sort"
	"strconv"
	"strings"
)

const bundledRemovedFile = ".bundled-removed.json"

//go:embed all:bundled
var embeddedModules embed.FS

var bundledModules = func() fs.FS {
	modules, err := fs.Sub(embeddedModules, "bundled")
	if err != nil {
		panic(err)
	}
	return modules
}()

type bundledModule struct {
	manifest ModuleManifest
	raw      []byte
	code     []byte
}

func readBundledModules() (map[string]bundledModule, []error) {
	entries, err := fs.ReadDir(bundledModules, ".")
	if err != nil {
		return nil, []error{err}
	}
	modules := map[string]bundledModule{}
	var failures []error
	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		id := entry.Name()
		raw, err := fs.ReadFile(bundledModules, path.Join(id, moduleManifest))
		if err != nil {
			failures = append(failures, err)
			continue
		}
		code, err := fs.ReadFile(bundledModules, path.Join(id, moduleEntry))
		if err != nil {
			failures = append(failures, err)
			continue
		}
		var manifest ModuleManifest
		if err := json.Unmarshal(raw, &manifest); err != nil || manifest.ID != id || !moduleIDPattern.MatchString(id) {
			failures = append(failures, errors.New("内置模块 "+id+" 的清单无效"))
			continue
		}
		modules[id] = bundledModule{manifest: manifest, raw: raw, code: code}
	}
	return modules, failures
}

func isBundledModule(id string) bool {
	info, err := fs.Stat(bundledModules, id)
	return err == nil && info.IsDir()
}

// 已经从内置清单撤下的模块：2.0.0+146 起黄果旧版由作者自己发模块维护，
// 内置那份（含我们改过的封面域名）不再打包。老用户机器上还留着当年装进去的
// 那一份 —— 按 **main.js 的字节指纹**识别，只删我们自己塞进去的那份。
//
// 以前按「磁盘版本 ≤ 1.0.3」判，作者发回来的模块版本号同样叫 1.0.3，
// 于是用户每次杀进程重进 App 都被删掉，只能反复从文件装。
var retiredBundledModules = map[string]string{
	"huangguo-old": "5fde877bc6f82baea185ebd3c60b361b8b025894ba4a29bfb87ce604fa3358c9",
}

// 已经清过的模块记一笔：指纹匹配只可能命中一次，之后用户再装回来
// （哪怕内容真的一模一样）也不该再被删。
const retiredBundledFile = ".retired-bundled.json"

func (d *Downloader) retiredBundledDone() map[string]bool {
	done := map[string]bool{}
	raw, err := os.ReadFile(filepath.Join(d.moduleRoot(), retiredBundledFile))
	if err != nil {
		return done
	}
	var ids []string
	if json.Unmarshal(raw, &ids) == nil {
		for _, id := range ids {
			done[id] = true
		}
	}
	return done
}

func (d *Downloader) markRetiredBundled(id string) {
	done := d.retiredBundledDone()
	if done[id] {
		return
	}
	done[id] = true
	ids := make([]string, 0, len(done))
	for name := range done {
		ids = append(ids, name)
	}
	sort.Strings(ids)
	raw, err := json.Marshal(ids)
	if err != nil {
		return
	}
	if err := os.MkdirAll(d.moduleRoot(), 0o700); err != nil {
		return
	}
	_ = os.WriteFile(filepath.Join(d.moduleRoot(), retiredBundledFile), raw, 0o600)
}

func (d *Downloader) retireBundledModulesLocked() {
	done := d.retiredBundledDone()
	for id, digest := range retiredBundledModules {
		// 万一哪天又接回内置，这条就不该再删它。
		if done[id] || isBundledModule(id) {
			continue
		}
		dir := filepath.Join(d.moduleRoot(), id)
		code, err := os.ReadFile(filepath.Join(dir, moduleEntry))
		if err != nil {
			continue
		}
		sum := sha256.Sum256(code)
		if hex.EncodeToString(sum[:]) != digest {
			continue
		}
		if err := os.RemoveAll(dir); err != nil {
			d.recordModuleFailure(id, err)
			continue
		}
		d.markRetiredBundled(id)
	}
}

func (d *Downloader) installBundledModulesLocked() {
	d.retireBundledModulesLocked()
	modules, failures := readBundledModules()
	for _, err := range failures {
		d.recordModuleFailure("", err)
	}
	removed := d.removedBundledModules()
	for id, module := range modules {
		if removed[id] {
			continue
		}
		if installed, err := readModule(filepath.Join(d.moduleRoot(), id)); err == nil &&
			!newerModuleVersion(module.manifest.Version, installed.manifest.Version) {
			continue
		}
		if err := d.writeModuleLocked(id, module.raw, module.code); err != nil {
			d.recordModuleFailure(id, err)
		}
	}
}

func (d *Downloader) removedBundledModules() map[string]bool {
	removed := map[string]bool{}
	raw, err := os.ReadFile(filepath.Join(d.moduleRoot(), bundledRemovedFile))
	if err != nil {
		return removed
	}
	var ids []string
	if json.Unmarshal(raw, &ids) == nil {
		for _, id := range ids {
			removed[id] = true
		}
	}
	return removed
}

func (d *Downloader) markBundledRemoved(id string, removed bool) error {
	set := d.removedBundledModules()
	if !isBundledModule(id) || set[id] == removed {
		return nil
	}
	if removed {
		set[id] = true
	} else {
		delete(set, id)
	}
	ids := make([]string, 0, len(set))
	for name := range set {
		ids = append(ids, name)
	}
	sort.Strings(ids)
	raw, err := json.Marshal(ids)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(d.moduleRoot(), 0o700); err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(d.moduleRoot(), bundledRemovedFile), raw, 0o600)
}

func newerModuleVersion(candidate, current string) bool {
	parse := func(version string) []int {
		parts := strings.Split(version, ".")
		if len(parts) != 3 {
			return nil
		}
		numbers := make([]int, 3)
		for index, part := range parts {
			number, err := strconv.Atoi(part)
			if err != nil || number < 0 {
				return nil
			}
			numbers[index] = number
		}
		return numbers
	}
	next, installed := parse(candidate), parse(current)
	return next != nil && installed != nil && slices.Compare(next, installed) > 0
}

func bundledIndexEntries() []moduleIndexEntry {
	modules, _ := readBundledModules()
	entries := make([]moduleIndexEntry, 0, len(modules))
	for _, module := range modules {
		entries = append(entries, moduleIndexEntry{ID: module.manifest.ID, Name: module.manifest.Name, Version: module.manifest.Version,
			Description: module.manifest.Description, API: module.manifest.API, Adult: *module.manifest.Adult, Bundled: true})
	}
	sort.Slice(entries, func(a, b int) bool { return entries[a].ID < entries[b].ID })
	return entries
}
