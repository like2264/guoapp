package core

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// 单个站源的代理设置。没有出现的站源一律跟随全局。
type nativeProxyChoice struct {
	Mode string `json:"mode"`
	URL  string `json:"url,omitempty"`
}

type nativeResourceSettings struct {
	ProxyMode           string                       `json:"proxyMode"`
	ProxyURL            string                       `json:"proxyUrl"`
	ProxyBySource       map[string]nativeProxyChoice `json:"proxyBySource,omitempty"`
	CatalogConcurrency  int                          `json:"catalogConcurrency"`
	CatalogIntervalMS   int                          `json:"catalogIntervalMs"`
	DownloadConcurrency int                          `json:"downloadConcurrency"`
	DownloadBySource    bool                         `json:"downloadBySource"`
	Warning             string                       `json:"warning,omitempty"`
	SystemProxyStatus   string                       `json:"systemProxyStatus,omitempty"`
}

func defaultResourceSettings() nativeResourceSettings {
	// 2.0.0+128 起站源请求不再额外加间隔：原来默认 250ms 是给老接口留的，
	// 现在的模块自己会限流，全局再加一层只会让翻页变慢。
	return nativeResourceSettings{ProxyMode: "auto", CatalogConcurrency: 3, CatalogIntervalMS: 0, DownloadConcurrency: 2}
}

func (settings nativeResourceSettings) validate() error {
	if settings.CatalogConcurrency < 1 || settings.CatalogConcurrency > 6 ||
		settings.CatalogIntervalMS < 0 || settings.CatalogIntervalMS > 5000 ||
		settings.DownloadConcurrency < 1 || settings.DownloadConcurrency > 6 {
		return errors.New("并发应为 1 至 6，请求间隔应为 0 至 5000 毫秒")
	}
	if settings.ProxyMode != "auto" && settings.ProxyMode != "direct" && settings.ProxyMode != "manual" {
		return errors.New("代理模式无效")
	}
	if settings.ProxyMode == "manual" || settings.ProxyURL != "" {
		if err := validateProxyAddress(settings.ProxyURL); err != nil {
			return err
		}
	}
	// 按站源设置：模式与全局同一套，地址规则也一样。未列出的站源跟随全局。
	for source, choice := range settings.ProxyBySource {
		if source == "" || len(source) > 64 {
			return errors.New("站源代理设置无效")
		}
		if choice.Mode != "auto" && choice.Mode != "direct" && choice.Mode != "manual" {
			return fmt.Errorf("%s 的连接方式无效", source)
		}
		if choice.Mode == "manual" || choice.URL != "" {
			if err := validateProxyAddress(choice.URL); err != nil {
				return fmt.Errorf("%s：%w", source, err)
			}
		}
	}
	return nil
}

func validateProxyAddress(address string) error {
	if len(address) > 2048 {
		return errors.New("代理地址过长")
	}
	parsed, err := url.Parse(address)
	if err != nil || parsed.Hostname() == "" || parsed.Fragment != "" || parsed.RawQuery != "" ||
		(parsed.Path != "" && parsed.Path != "/") ||
		(parsed.Scheme != "http" && parsed.Scheme != "https" && parsed.Scheme != "socks5" && parsed.Scheme != "socks5h") {
		return errors.New("请输入有效的 HTTP、HTTPS 或 SOCKS5 代理地址")
	}
	if port := parsed.Port(); port != "" {
		number, err := strconv.Atoi(port)
		if err != nil || number < 1 || number > 65535 {
			return errors.New("代理端口无效")
		}
	}
	return nil
}

// 一个站源走哪条线路。mode 与全局同义，manual 是解析后的地址。
type proxyRoute struct {
	mode   string
	manual *url.URL
}

type proxyRouter struct {
	mu             sync.RWMutex
	mode           string
	manual         *url.URL
	overrides      map[string]proxyRoute
	system         nativeSystemProxy
	systemRead     time.Time
	systemOverride bool
	// 直连试过不通的媒体 host → 发现时间。10 分钟内同一个 host 不再先试直连，
	// 否则每个分片都要白等一次超时（2.0.0+158）。
	directBlocked sync.Map
}

// directNetworkKey 标记「这条请求优先走本机网络」。值必须是 *directNetworkFlag：
// 整条下载链路（播放列表、密钥、分片）都挂同一个可变标记，直连失败时切成代理再
// 重试，不用为每次请求重建 context（2.0.0+158）。
type directNetworkKey struct{}

type directNetworkFlag struct{ direct atomic.Bool }

// directBlockWindow 直连失败的 host 多久之内不再尝试直连。
const directBlockWindow = 10 * time.Minute

func (router *proxyRouter) blockDirect(host string) {
	if host == "" {
		return
	}
	router.directBlocked.Store(host, time.Now())
}

func (router *proxyRouter) directBlockedHost(host string) bool {
	value, ok := router.directBlocked.Load(host)
	if !ok {
		return false
	}
	at, ok := value.(time.Time)
	return ok && time.Since(at) < directBlockWindow
}

// mediaDirect 读「这条下载链路现在要不要直连」。
func mediaDirect(ctx context.Context) bool {
	flag, _ := ctx.Value(directNetworkKey{}).(*directNetworkFlag)
	return flag != nil && flag.direct.Load()
}

// mediaSetDirect 切换整条下载链路的直连与否（没有标记时什么都不做）。
func mediaSetDirect(ctx context.Context, direct bool) {
	if flag, _ := ctx.Value(directNetworkKey{}).(*directNetworkFlag); flag != nil {
		flag.direct.Store(direct)
	}
}

// withMediaDirect 给一条下载链路挂上「默认直连」的标记。
func withMediaDirect(ctx context.Context) context.Context {
	if _, ok := ctx.Value(directNetworkKey{}).(*directNetworkFlag); ok {
		return ctx
	}
	flag := &directNetworkFlag{}
	flag.direct.Store(true)
	return context.WithValue(ctx, directNetworkKey{}, flag)
}

func (router *proxyRouter) proxy(request *http.Request) (*url.URL, error) {
	if request.URL.Hostname() == "127.0.0.1" || request.URL.Hostname() == "localhost" || request.URL.Hostname() == "::1" {
		return nil, nil
	}
	// 下载走直连：不管全局是 auto / manual / 按站源覆盖，媒体字节一律不过代理。
	// 只有「这个 host 刚刚直连没过」才落到下面按设置选线路 —— 每个分片都等一次
	// 超时会把下载拖到比代理还慢。
	if mediaDirect(request.Context()) && !router.directBlockedHost(request.URL.Hostname()) {
		return nil, nil
	}
	router.mu.RLock()
	mode, manual := router.mode, router.manual
	// 站源请求会把 source 塞进 context（见 withNativeSource）；
	// 只有这条链路能命中覆盖，封面、播放分片这些公共请求仍走全局。
	if source, _ := request.Context().Value(nativeSourceKey{}).(string); source != "" {
		if route, ok := router.overrides[source]; ok {
			mode, manual = route.mode, route.manual
		}
	}
	router.mu.RUnlock()
	switch mode {
	case "direct":
		return nil, nil
	case "manual":
		return manual, nil
	}
	return router.systemSettings().resolve(request)
}

func (engine *nativeEngine) loadResourceSettings() {
	settings := defaultResourceSettings()
	file := filepath.Join(engine.directory, "resource-settings.json")
	info, err := os.Stat(file)
	if err == nil {
		var stored nativeResourceSettings
		if info.Mode().IsRegular() && info.Size() <= 16384 {
			if data, readErr := os.ReadFile(file); readErr == nil && json.Unmarshal(data, &stored) == nil && stored.validate() == nil {
				settings = stored
			} else {
				settings.Warning = "网络与下载设置无法读取，已使用默认值，请重新保存设置"
			}
		} else {
			settings.Warning = "网络与下载设置无效，已使用默认值，请重新保存设置"
		}
	} else if !os.IsNotExist(err) {
		settings.Warning = "网络与下载设置无法读取，已使用默认值，请重新保存设置"
	}
	engine.settings = settings
	engine.applyResourceSettings(settings)
}

func (engine *nativeEngine) resourceSettings() nativeResourceSettings {
	engine.settingsMu.Lock()
	defer engine.settingsMu.Unlock()
	if engine.settings.ProxyMode == "" {
		return defaultResourceSettings()
	}
	settings := engine.settings
	system := engine.downloader.proxyRouter.systemSettings()
	settings.SystemProxyStatus = "自动读取系统静态代理及环境变量"
	if system.PACURL != "" {
		settings.SystemProxyStatus = "系统配置了自动代理脚本，按脚本结果选择代理；脚本取不到结果时改用系统静态代理或环境变量"
	} else if system.PAC && system.HTTP == "" && system.HTTPS == "" {
		settings.SystemProxyStatus = "检测到系统自动代理脚本；请配置手动代理或选择直连"
	} else if system.HTTP != "" || system.HTTPS != "" {
		settings.SystemProxyStatus = "已读取系统静态代理"
	}
	return settings
}

func (engine *nativeEngine) applyResourceSettings(settings nativeResourceSettings) {
	router := engine.downloader.proxyRouter
	manual, _ := url.Parse(settings.ProxyURL)
	overrides := make(map[string]proxyRoute, len(settings.ProxyBySource))
	for source, choice := range settings.ProxyBySource {
		address, _ := url.Parse(choice.URL)
		overrides[source] = proxyRoute{mode: choice.Mode, manual: address}
	}
	router.mu.Lock()
	router.mode, router.manual, router.overrides = settings.ProxyMode, manual, overrides
	router.mu.Unlock()
	limiter := engine.downloader.limiter
	limiter.mu.Lock()
	limiter.concurrency = settings.CatalogConcurrency
	// 设置页里「目录请求间隔」已经整块去掉了（2.0.0+128）。老用户机器上还存着
	// 250/500 这些值，这里一律按 0 处理，否则翻页仍然被拖慢。
	limiter.interval = 0
	limiter.notifyLocked()
	limiter.mu.Unlock()
	if engine.downloads != nil {
		engine.downloads.mu.Lock()
		engine.downloads.concurrency = settings.DownloadConcurrency
		engine.downloads.bySource = settings.DownloadBySource
		engine.downloads.scheduleLocked()
		engine.downloads.mu.Unlock()
	}
}

func (engine *nativeEngine) saveResourceSettings(settings nativeResourceSettings) (nativeResourceSettings, error) {
	settings.ProxyURL = strings.TrimSpace(settings.ProxyURL)
	settings.Warning = ""
	settings.SystemProxyStatus = ""
	if err := settings.validate(); err != nil {
		return nativeResourceSettings{}, err
	}
	engine.settingsMu.Lock()
	defer engine.settingsMu.Unlock()
	data, err := json.Marshal(settings)
	if err == nil {
		err = nativeDownloadWrite(filepath.Join(engine.directory, "resource-settings.json"), data)
	}
	if err != nil {
		return nativeResourceSettings{}, errors.New("未能保存网络与下载设置，原设置保持不变")
	}
	engine.settings = settings
	engine.applyResourceSettings(settings)
	engine.downloader.client.CloseIdleConnections()
	return settings, nil
}
