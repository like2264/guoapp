package core

import (
	"context"
	"strings"
)

// lockSourceCatalog 按「站源 + 道」串行目录请求。
//
// 原生以前按站源单锁：重走目录虽然用了 4 条独立 lane，到了这里仍被排成
// 一队串行拉，黄果视频 89 页要 3～5 分钟，超过 300 秒预算就一页都换不成；
// 用户下拉刷新几次才偶然赶上某轮走完（+174 修）。模块本身有 4 个 goja
// 实例槽（moduleInstanceLimit），并发拉页是安全的；按 lane 分锁后每条道
// 各走各的，缓存写入仍由 saveCatalogCache 里的 engine.mu 保护。
//
// 普通翻页 lane 为空，仍按站源单锁，语义不变。
func (engine *nativeEngine) lockSourceCatalog(ctx context.Context, source, lane string) (func(), error) {
	engine.sourceCatalogMu.Lock()
	if engine.sourceCatalogs == nil {
		engine.sourceCatalogs = map[string]chan struct{}{}
	}
	gateKey := source
	if lane != "" {
		gateKey = source + "|" + strings.TrimPrefix(lane, "-")
	}
	gate := engine.sourceCatalogs[gateKey]
	if gate == nil {
		gate = make(chan struct{}, 1)
		engine.sourceCatalogs[gateKey] = gate
	}
	engine.sourceCatalogMu.Unlock()
	select {
	case gate <- struct{}{}:
		return func() { <-gate }, nil
	case <-ctx.Done():
		return nil, ctx.Err()
	}
}
