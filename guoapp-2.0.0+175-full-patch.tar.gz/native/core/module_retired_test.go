package core

import (
	"crypto/sha256"
	"encoding/hex"
	"os"
	"path/filepath"
	"testing"
)

const retiredTestCode = "exports.catalog = function () { return { items: [] }; };\n"

func writeModuleCopy(t *testing.T, dataDir, id, version, code string) {
	t.Helper()
	dir := filepath.Join(dataDir, moduleDirectory, id)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	manifest := `{"id":"` + id + `","name":"测试","version":"` + version + `","runtime":"js","api":1,"adult":false}`
	if err := os.WriteFile(filepath.Join(dir, moduleManifest), []byte(manifest), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, moduleEntry), []byte(code), 0o644); err != nil {
		t.Fatal(err)
	}
}

// 退役清单按 main.js 的字节指纹认人：只删我们自己内置过的那一份。
//
// 以前的判定是「磁盘版本 ≤ 1.0.3」，作者发回来的模块版本号同样叫 1.0.3，
// 结果用户每次杀进程重进 App 都被删一次，只能反复从文件装。
func TestRetiredBundledModuleUsesContentDigest(t *testing.T) {
	digest := sha256.Sum256([]byte(retiredTestCode))
	original := retiredBundledModules
	retiredBundledModules = map[string]string{"huangguo-old": hex.EncodeToString(digest[:])}
	t.Cleanup(func() { retiredBundledModules = original })

	t.Run("内容一致才删", func(t *testing.T) {
		dataDir := t.TempDir()
		writeModuleCopy(t, dataDir, "huangguo-old", "1.0.3", retiredTestCode)
		(&Downloader{cfg: Config{dataDir: dataDir}}).retireBundledModulesLocked()
		if _, err := os.Stat(filepath.Join(dataDir, moduleDirectory, "huangguo-old")); !os.IsNotExist(err) {
			t.Fatalf("内置那一份应该被删掉，err=%v", err)
		}
		if _, err := os.Stat(filepath.Join(dataDir, moduleDirectory, retiredBundledFile)); err != nil {
			t.Fatalf("清完应该留下标记文件：%v", err)
		}
	})

	t.Run("版本号一样但内容不同必须留着", func(t *testing.T) {
		dataDir := t.TempDir()
		// 作者自己发的模块，版本号同样是 1.0.3，但脚本内容不是我们那份。
		writeModuleCopy(t, dataDir, "huangguo-old", "1.0.3", "exports.other = 1;\n")
		(&Downloader{cfg: Config{dataDir: dataDir}}).retireBundledModulesLocked()
		if _, err := os.Stat(filepath.Join(dataDir, moduleDirectory, "huangguo-old")); err != nil {
			t.Fatalf("外部装的模块被误删：%v", err)
		}
	})

	t.Run("清过一次之后不再删", func(t *testing.T) {
		dataDir := t.TempDir()
		writeModuleCopy(t, dataDir, "huangguo-old", "1.0.3", retiredTestCode)
		downloader := &Downloader{cfg: Config{dataDir: dataDir}}
		downloader.retireBundledModulesLocked()
		// 用户把内容一模一样的那份又装回来了。
		writeModuleCopy(t, dataDir, "huangguo-old", "1.0.3", retiredTestCode)
		downloader.retireBundledModulesLocked()
		if _, err := os.Stat(filepath.Join(dataDir, moduleDirectory, "huangguo-old")); err != nil {
			t.Fatalf("已经清过的模块又被删了一次：%v", err)
		}
	})
}

// 不在退役清单里的模块一个都不许动。
func TestRetiredBundledModuleLeavesOthersAlone(t *testing.T) {
	digest := sha256.Sum256([]byte(retiredTestCode))
	original := retiredBundledModules
	retiredBundledModules = map[string]string{"huangguo-old": hex.EncodeToString(digest[:])}
	t.Cleanup(func() { retiredBundledModules = original })

	dataDir := t.TempDir()
	// 内容和退役那份完全一样，但它是夜社，不在清单里。
	writeModuleCopy(t, dataDir, "yesheai", "1.0.8", retiredTestCode)
	(&Downloader{cfg: Config{dataDir: dataDir}}).retireBundledModulesLocked()
	if _, err := os.Stat(filepath.Join(dataDir, moduleDirectory, "yesheai")); err != nil {
		t.Fatalf("夜社被误删：%v", err)
	}
}
