package core

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// 选集面板要显示「本剧总时长 = 每一集时长相加」。站点的详情接口几乎都不带
// 每集时长，只能按集解析一次播放列表（HLS 的 #EXTINF 求和，或者模块自己给的
// durationMs），代价是每集一次请求。所以这里做两件事：
//
//  1. 只解析、不开播放会话：拿到 media.Duration 就返回，不建流、不预取；
//  2. 按「剧 → 分集」落盘缓存，第二次打开详情页直接读缓存，不再联网。
//
// 解析失败的集记一次时间戳，10 分钟内不再重试（免得每次开详情页都去撞同一集），
// 过期后会自动再试；解析成功但站点没给时长的，同样按失败记。
const (
	// +171 起每集缓存同时记时长和最高画质档；+175 起画质改以播放器解码出的
	// 真值为准（Decoded），站点声明或字节探测只作没播过时的兜底。+174 的
	// 档位闸门误杀了站点给的真档位（834/470 这类），整条字节探测也又慢又不全，
	// 所以不再用它标注。升版让旧缓存里的假档位整份丢弃重探。
	nativeDurationCacheVersion = 6
	nativeDurationFile         = "durations.json"
	nativeDurationMaxBytes     = 4 << 20
	nativeDurationDramaLimit   = 320
	nativeDurationWorkers      = 3
	nativeDurationPerRequest   = 240
	nativeDurationRetryAfter   = 10 * time.Minute
	// 单集上限 8 小时：短剧不可能超过，超过就当站点给了脏数据。
	nativeDurationMaxMS = 8 * 60 * 60 * 1000
)

type nativeDurationDisk struct {
	Version int                              `json:"version"`
	Dramas  map[string]*nativeDurationRecord `json:"dramas"`
}

type nativeDurationRecord struct {
	// Updated 是这部剧最后一次刷新缓存的时刻，用来在超过上限时淘汰最旧的。
	Updated int64 `json:"updated"`
	// Items 是已经拿到的每集时长（毫秒）。
	Items map[string]int64 `json:"items"`
	// Qualities 是站点声明的最高档位（高度像素），0 表示站点没给。
	Qualities map[string]int64 `json:"qualities"`
	// Decoded 是播放器解码这集时报告的真实高度（短边），优先级高于
	// Qualities：播过一次就用真值标注，不再拿探测/声明值覆盖。
	Decoded map[string]int64 `json:"decoded"`
	// Missed 记解析失败的集与失败时刻，10 分钟内不再重试。
	Missed map[string]int64 `json:"missed"`
}

type nativeDurationItem struct {
	ID         string `json:"id"`
	DurationMS int64  `json:"durationMs"`
	// QualityHeight 交前端在选集格子左下角标「1080P」这类档位。
	QualityHeight int64 `json:"quality"`
}

type nativeDurationsResult struct {
	Items []nativeDurationItem `json:"items"`
}

// nativeChapterDurations 返回给定分集各自的时长（毫秒），拿不到的给 0。
// 前端按批调用（一批十来集），既能显示「已统计 24/60 集」，也不会让一次
// 原生调用挂上几分钟。
func (engine *nativeEngine) nativeChapterDurations(ctx context.Context, input nativeInput) (nativeDurationsResult, error) {
	if _, _, valid := SplitProviderDramaID(input.Drama.ID); !valid {
		return nativeDurationsResult{}, errors.New("剧集信息无效")
	}
	wanted := make([]Chapter, 0, len(input.Chapters))
	seen := make(map[string]bool, len(input.Chapters))
	for _, chapter := range input.Chapters {
		if chapter.ID == "" || seen[chapter.ID] {
			continue
		}
		seen[chapter.ID] = true
		wanted = append(wanted, chapter)
	}
	if len(wanted) == 0 {
		return nativeDurationsResult{Items: []nativeDurationItem{}}, nil
	}
	if len(wanted) > nativeDurationPerRequest {
		wanted = wanted[:nativeDurationPerRequest]
	}
	// 整段都持锁：一次只跑一批探测，避免两批同时读到旧快照、后写的那批
	// 把先写进去的时长覆盖掉。前端本来就是一批接一批地发，串行不额外增加等待。
	engine.durationMu.Lock()
	defer engine.durationMu.Unlock()
	disk := engine.loadDurationCache()
	record := disk.Dramas[input.Drama.ID]
	if record == nil {
		record = &nativeDurationRecord{}
		disk.Dramas[input.Drama.ID] = record
	}
	if record.Items == nil {
		record.Items = map[string]int64{}
	}
	if record.Qualities == nil {
		record.Qualities = map[string]int64{}
	}
	if record.Decoded == nil {
		record.Decoded = map[string]int64{}
	}
	if record.Missed == nil {
		record.Missed = map[string]int64{}
	}
	now := time.Now()
	results := make([]nativeDurationItem, len(wanted))
	pending := make([]int, 0, len(wanted))
	// qualityFor 取一集的标注档位：播放器解码真值优先，站点声明的兜底。
	qualityFor := func(id string) int64 {
		if decoded := record.Decoded[id]; decoded > 0 {
			return decoded
		}
		return record.Qualities[id]
	}
	for index, chapter := range wanted {
		results[index] = nativeDurationItem{ID: chapter.ID}
		if input.Force {
			pending = append(pending, index)
			continue
		}
		if duration := record.Items[chapter.ID]; duration > 0 {
			results[index].DurationMS = duration
			results[index].QualityHeight = qualityFor(chapter.ID)
			continue
		}
		if at, missed := record.Missed[chapter.ID]; missed && now.Sub(time.UnixMilli(at)) < nativeDurationRetryAfter {
			// 没时长但有画质的集被记进冷却：时长缓存命中不了，这里若不带出
			// 画质，选集格子就始终空着。把已经探到的档位回填回去。
			results[index].QualityHeight = qualityFor(chapter.ID)
			continue
		}
		pending = append(pending, index)
	}
	if len(pending) > 0 {
		engine.probeDurations(ctx, input.Drama, wanted, pending, results)
		for _, index := range pending {
			id := wanted[index].ID
			// 画质跟时长同一次解析得来：就算站点没给时长，档位也照记，
			// 免得下一批又为画质白跑一遍。播放器解码真值（Decoded）优先，
			// 探测/声明值不能盖掉它。
			if height := results[index].QualityHeight; height > 0 {
				if record.Decoded[id] == 0 {
					record.Qualities[id] = height
				}
				results[index].QualityHeight = qualityFor(id)
			}
			if duration := results[index].DurationMS; duration > 0 {
				record.Items[id] = duration
				delete(record.Missed, id)
				continue
			}
			record.Missed[id] = now.UnixMilli()
		}
		record.Updated = now.UnixMilli()
		engine.saveDurationCache(disk)
	}
	return nativeDurationsResult{Items: results}, nil
}

// nativeRecordChapterQuality 把播放器解码某集时报告的真实高度记进缓存。
// 真值优先于站点声明/探测值：播过一次之后，选集格就用这个真值标注。
// 这是「没给画质档的站源直接用日志里的画质」的落地——日志那行
// size=854x480 是解码器给出的实际分辨率，比猜 m3u8 字节可靠得多。
func (engine *nativeEngine) nativeRecordChapterQuality(input nativeInput) bool {
	if input.Chapter.ID == "" || input.Quality <= 0 {
		return false
	}
	if _, _, valid := SplitProviderDramaID(input.Drama.ID); !valid {
		return false
	}
	engine.durationMu.Lock()
	defer engine.durationMu.Unlock()
	disk := engine.loadDurationCache()
	record := disk.Dramas[input.Drama.ID]
	if record == nil {
		record = &nativeDurationRecord{}
		disk.Dramas[input.Drama.ID] = record
	}
	if record.Items == nil {
		record.Items = map[string]int64{}
	}
	if record.Qualities == nil {
		record.Qualities = map[string]int64{}
	}
	if record.Decoded == nil {
		record.Decoded = map[string]int64{}
	}
	if record.Missed == nil {
		record.Missed = map[string]int64{}
	}
	if record.Decoded[input.Chapter.ID] == int64(input.Quality) {
		return true
	}
	record.Decoded[input.Chapter.ID] = int64(input.Quality)
	record.Updated = time.Now().UnixMilli()
	engine.saveDurationCache(disk)
	return true
}

// probeDurations 用固定并发把待解析的集跑一遍，结果写回 results。
// 单集失败不影响其他集：拿不到就是 0，前端据此把这一集算作「时长未知」。
func (engine *nativeEngine) probeDurations(ctx context.Context, drama LibraryDrama, chapters []Chapter, pending []int, results []nativeDurationItem) {
	queue := make(chan int)
	workers := min(nativeDurationWorkers, len(pending))
	var group sync.WaitGroup
	for worker := 0; worker < workers; worker++ {
		group.Add(1)
		go func() {
			defer group.Done()
			for index := range queue {
				results[index].DurationMS, results[index].QualityHeight =
					engine.probeChapterFacts(ctx, drama, chapters[index])
			}
		}()
	}
	for _, index := range pending {
		select {
		case queue <- index:
		case <-ctx.Done():
			close(queue)
			group.Wait()
			return
		}
	}
	close(queue)
	group.Wait()
}

func (engine *nativeEngine) probeChapterFacts(ctx context.Context, drama LibraryDrama, chapter Chapter) (int64, int64) {
	if err := ctx.Err(); err != nil {
		return 0, 0
	}
	task := Task{
		DramaID:    drama.ID,
		DramaTitle: drama.Title,
		Chapter:    chapter,
		Index:      chapterEpisodeNumber(chapter),
	}
	media, err := engine.downloader.resolveProviderMedia(ctx, task)
	if err != nil {
		return 0, 0
	}
	// 档位只用站点明说的（RESOLUTION / media.Quality）。单路列表没写分辨率
	// 的不再猜——字节探测（SPS/AES）又慢又不全，还会拼出假档位；那类集等
	// 播放器解码后由 recordChapterQuality 回写真值，选集格再显示。
	height := nativeMaxPlaylistHeight(media)
	duration := media.Duration
	if duration <= 0 && media.Playlist != "" {
		// 有些站点给的是总播放列表（#EXT-X-STREAM-INF，没有 #EXTINF），
		// 总时长在子列表里：挑一路子列表再抓一次。
		duration = engine.variantPlaylistDuration(ctx, media)
	}
	value := duration.Milliseconds()
	if value <= 0 || value > nativeDurationMaxMS {
		return 0, height
	}
	return value, height
}

// nativeMaxPlaylistHeight 取这一集站点自己给的最高画质档（高度像素）。
// 只有总播放列表里的 #EXT-X-STREAM-INF 带 RESOLUTION，单路列表不给档位，
// 那种情况返回 0，界面不标——不要拿码率猜，猜出来的是假的。
func nativeMaxPlaylistHeight(media ProviderMedia) int64 {
	best := int64(0)
	if media.Quality > 0 {
		best = int64(media.Quality)
	}
	for _, variant := range media.Variants {
		if int64(variant.Quality) > best {
			best = int64(variant.Quality)
		}
	}
	for _, line := range strings.Split(media.Playlist, "\n") {
		text := strings.TrimSpace(line)
		if !strings.HasPrefix(text, "#EXT-X-STREAM-INF:") {
			continue
		}
		if height := nativeResolutionHeight(nativeHLSAttributes(text)["RESOLUTION"]); height > best {
			best = height
		}
	}
	return best
}

// nativeResolutionHeight 解析 1920x1080 这类分辨率。竖屏片源按短边算，
// 跟下载选档 nativeHLSSelect 的口径一致。
func nativeResolutionHeight(value string) int64 {
	parts := strings.Split(strings.TrimSpace(strings.ToLower(value)), "x")
	if len(parts) != 2 {
		return 0
	}
	width, _ := strconv.Atoi(parts[0])
	height, _ := strconv.Atoi(parts[1])
	if width <= 0 || height <= 0 {
		return 0
	}
	if width < height {
		return int64(width)
	}
	return int64(height)
}

// variantPlaylistDuration 从总播放列表里挑一路子列表，抓回来按 #EXTINF 求和。
// 只抓第一路：一集的时长跟线路无关，没必要把每一路都拉一遍。
func (engine *nativeEngine) variantPlaylistDuration(ctx context.Context, media ProviderMedia) time.Duration {
	base, err := url.Parse(media.URL)
	if err != nil {
		return 0
	}
	// 子列表同样要带上这集的凭证（柚子的 Cookie 只对同一次会话的有效），
	// 否则会拿到 403、时长算成 0。
	if media.Credentials != nil {
		ctx = providerMediaContext(ctx, media.Credentials)
	}
	lines := strings.Split(media.Playlist, "\n")
	for index, raw := range lines {
		if !strings.HasPrefix(strings.TrimSpace(raw), "#EXT-X-STREAM-INF:") {
			continue
		}
		for next := index + 1; next < len(lines); next++ {
			text := strings.TrimSpace(lines[next])
			if text == "" || strings.HasPrefix(text, "#") {
				continue
			}
			reference, err := url.Parse(text)
			if err != nil {
				return 0
			}
			playlist, _, err := engine.downloader.fetchMediaPlaylist(ctx, base.ResolveReference(reference).String(), media.Referer)
			if err != nil {
				return 0
			}
			return M3u8Duration(playlist)
		}
	}
	return 0
}

func chapterEpisodeNumber(chapter Chapter) int {
	// 分集编号有的是数字、有的是字符串，统一走 Chapter.EpisodeString。
	number, err := strconv.Atoi(chapter.EpisodeString(1))
	if err != nil || number < 1 {
		return 1
	}
	return number
}

func (engine *nativeEngine) loadDurationCache() *nativeDurationDisk {
	disk := &nativeDurationDisk{Version: nativeDurationCacheVersion, Dramas: map[string]*nativeDurationRecord{}}
	if engine.cacheDirectory == "" {
		return disk
	}
	file, err := os.Open(filepath.Join(engine.cacheDirectory, nativeDurationFile))
	if err != nil {
		return disk
	}
	defer file.Close()
	body, err := io.ReadAll(io.LimitReader(file, nativeDurationMaxBytes+1))
	if err != nil || len(body) > nativeDurationMaxBytes {
		return disk
	}
	var saved nativeDurationDisk
	if json.Unmarshal(body, &saved) != nil || saved.Dramas == nil {
		return disk
	}
	// 旧版缓存没有画质字段，整份丢掉重探一次；之后照旧命中缓存。
	if saved.Version != nativeDurationCacheVersion {
		return disk
	}
	return &saved
}

func (engine *nativeEngine) saveDurationCache(disk *nativeDurationDisk) {
	if engine.cacheDirectory == "" || disk == nil {
		return
	}
	trimNativeDurations(disk.Dramas)
	body, err := json.Marshal(disk)
	if err != nil {
		return
	}
	_ = writeNativeCacheFile(filepath.Join(engine.cacheDirectory, nativeDurationFile), body)
}

// trimNativeDurations 按「最后一次刷新」淘汰，超过上限时把最老的整部丢掉，
// 免得缓存文件一直长。
func trimNativeDurations(dramas map[string]*nativeDurationRecord) {
	if len(dramas) <= nativeDurationDramaLimit {
		return
	}
	ids := make([]string, 0, len(dramas))
	for id := range dramas {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(left, right int) bool {
		return dramas[ids[left]].Updated < dramas[ids[right]].Updated
	})
	for _, id := range ids[:len(dramas)-nativeDurationDramaLimit] {
		delete(dramas, id)
	}
}
