package core

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/hex"
	"os"
	"path/filepath"
	"testing"
)

func probeSegmentBytes() []byte {
	packet := append([]byte{0, 0, 1}, probeSPSBytes()...)
	return append(packet, 0x00, 0x00, 0x01, 0x68)
}

func probeSeal(data, key, iv []byte) []byte {
	block, _ := aes.NewCipher(key)
	for len(data)%16 != 0 {
		data = append(data, 0x47)
	}
	out := make([]byte, len(data))
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(out, data)
	return out
}

func probeManager(root string) *nativeDownloads {
	return &nativeDownloads{
		root:          root,
		jobs:          map[string]*nativeDownloadRecord{},
		qualityProbed: map[string]bool{},
	}
}

func TestBackfillDownloadQualitiesPlain(t *testing.T) {
	root := t.TempDir()
	directory := filepath.Join(root, "job1")
	if err := os.MkdirAll(directory, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(directory, "seg0.ts"), probeSegmentBytes(), 0600); err != nil {
		t.Fatal(err)
	}
	list := "#EXTM3U\n#EXTINF:6,\nseg0.ts\n"
	if err := os.WriteFile(filepath.Join(directory, "index.m3u8"), []byte(list), 0600); err != nil {
		t.Fatal(err)
	}
	manager := probeManager(root)
	record := &nativeDownloadRecord{
		nativeDownloadJob: nativeDownloadJob{ID: "job1", State: "completed", Index: 1},
		File:              "index.m3u8",
	}
	manager.jobs[record.ID] = record
	manager.backfillDownloadQualities()
	if record.ActualQuality != 480 {
		t.Fatalf("回填档位 = %d，期望 480", record.ActualQuality)
	}
	// 回填过就不再重复探测。
	record.ActualQuality = 0
	manager.backfillDownloadQualities()
	if record.ActualQuality != 0 {
		t.Fatalf("已探测过的任务不该再次回填，得到 %d", record.ActualQuality)
	}
}

func TestBackfillDownloadQualitiesEncrypted(t *testing.T) {
	for _, withIV := range []bool{true, false} {
		root := t.TempDir()
		directory := filepath.Join(root, "job2")
		if err := os.MkdirAll(directory, 0700); err != nil {
			t.Fatal(err)
		}
		key := []byte("0123456789abcdef")
		iv, _ := hex.DecodeString("fedcba98765432100123456789abcdef")
		if !withIV {
			iv = nativeSegmentIV(0)
		}
		if err := os.WriteFile(filepath.Join(directory, "key.key"), key, 0600); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(directory, "seg0.ts"), probeSeal(probeSegmentBytes(), key, iv), 0600); err != nil {
			t.Fatal(err)
		}
		attributes := "METHOD=AES-128,URI=\"key.key\""
		if withIV {
			attributes += ",IV=0xfedcba98765432100123456789abcdef"
		}
		list := "#EXTM3U\n#EXT-X-KEY:" + attributes + "\n#EXTINF:6,\nseg0.ts\n"
		if err := os.WriteFile(filepath.Join(directory, "index.m3u8"), []byte(list), 0600); err != nil {
			t.Fatal(err)
		}
		manager := probeManager(root)
		record := &nativeDownloadRecord{
			nativeDownloadJob: nativeDownloadJob{ID: "job2", State: "completed", Index: 2},
			File:              "index.m3u8",
		}
		manager.jobs[record.ID] = record
		manager.backfillDownloadQualities()
		if record.ActualQuality != 480 {
			t.Fatalf("withIV=%v 回填档位 = %d，期望 480", withIV, record.ActualQuality)
		}
	}
}
