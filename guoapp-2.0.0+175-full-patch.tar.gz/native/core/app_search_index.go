package core

// 本地搜索索引（2.0.0+128 起）
//
// 为什么要有这一层：
//
//	八个站源里有一半的搜索接口只索引标题和标签，简介里出现的关键词根本
//	搜不到——黄果视频搜简介里的「曹贼系统」、黑桃搜「重生归来」、禁果短剧
//	搜详情简介里的人名，返回都是 0 条。而「简介命中」正是七档里最低的第 7
//	档，站点自己不召回，模块层的 attachIntros 就没有可补的对象，第 7 档在
//	这三站永远产不出来。
//
// 做法：
//
//	把每个站源翻过的目录页（标题、标签、分类、封面、集数、简介）按行存成
//	本地索引；搜索时先在索引里跑一遍七档打分，再和站点返回的结果合并去重。
//	索引里的条目不受站点搜索接口的限制，只要翻到过、或者后台补到过简介，
//	之后就能靠简介命中，第 7 档才真正有东西。顺带解决了另一个问题：剧果、
//	黑桃、X 短剧、柚子、黄果视频把「总裁 离婚」当整串匹配，双词查询直接
//	0 条，而本地打分是按空格拆词算的。
//
// 存储：
//
//	<应用目录>/search-index/<source>.tsv，每行一条，字段用制表符分隔，
//	首行是版本头。索引是纯缓存性质的东西，读坏了就丢掉重建，不影响其他状态。

import (
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	searchIndexVersion    = 1
	searchIndexFolder     = "search-index"
	searchIndexMaxPerSite = 20000
	// searchIndexPageSize 是本地命中一页给多少条。站点一页 20~40 条，这里取
	// 20 条补充量，一页总条数还在可接受范围内，翻页也不会一次吐几百条。
	searchIndexPageSize = 20
	// searchIndexFlushDelay 是写盘节流：翻一页目录会写一次索引，连着翻十页
	// 就是十次 2MB 落盘，没必要。合并到 1.5 秒一次。
	searchIndexFlushDelay = 1500 * time.Millisecond
	searchIndexFieldLimit = 900
	searchIndexTitleLimit = 160
	// searchIndexWarmThreshold 是「索引还算空」的判断线。低于它搜不到东西时
	// 提示用户稍后再搜，避免被当成站源坏了。
	searchIndexWarmThreshold = 200
)

// searchIndexEntry 是索引里的一条作品。只存能参与搜索和列表展示的字段：
// 分集列表、播放凭证这些等用户点进去再问站点要，不在本地存。
type searchIndexEntry struct {
	ID       string
	Title    string
	Category string
	Tags     string
	Desc     string
	Cover    string
	Episodes int
}

type searchIndexSite struct {
	entries     []searchIndexEntry
	pos         map[string]int
	intros      int
	pages       int
	introCursor int
	loaded      bool
	dirty       bool
	flushed     time.Time
	timer       *time.Timer
	// version 是建这份索引时的模块版本。模块换代（分类收缩、解析规则变了）
	// 以后，上一版翻回来的卡片可能属于已经砍掉的分类 —— 夜社 1.0.8 把国产短剧
	// 整类去掉之后，站源搜索里还能搜到那些作品，就是因为索引里躺着旧卡片。
	version string
}

type searchIndexStore struct {
	mu      sync.Mutex
	sites   map[string]*searchIndexSite
	busy    map[string]bool
	synced  map[string]time.Time
	introAt map[string]time.Time
	// pending 是「刚刚在搜索结果里出现过、但还没有简介」的条目，按站源排队。
	// 站点搜索只按标题和标签召回，简介命中的条目只有补完简介才判得出来；
	// 这批排在普通轮转前面，用户这次没搜全，下一轮就能从索引里捞回来。
	pending     map[string][]LibraryDrama
	pendingSeen map[string]map[string]bool
	// query 是最近一次搜索的关键词。页面只返回前几页，后面几页里可能还有
	// 只有简介沾边的作品；后台按这个关键词把剩下的页翻完再补简介。
	query map[string]string
}

// index 懒加载索引存储。测试里会直接构造 nativeEngine{}，directory 可能为空，
// 所有磁盘操作都对空目录做了短路。
func (engine *nativeEngine) index() *searchIndexStore {
	engine.indexMu.Lock()
	defer engine.indexMu.Unlock()
	if engine.indexStore == nil {
		engine.indexStore = &searchIndexStore{
			sites:       map[string]*searchIndexSite{},
			busy:        map[string]bool{},
			synced:      map[string]time.Time{},
			introAt:     map[string]time.Time{},
			pending:     map[string][]LibraryDrama{},
			pendingSeen: map[string]map[string]bool{},
			query:       map[string]string{},
		}
	}
	return engine.indexStore
}

func (engine *nativeEngine) indexFilePath(source string) string {
	if engine.directory == "" {
		return ""
	}
	return filepath.Join(engine.directory, searchIndexFolder, source+".tsv")
}

// indexSiteLocked 返回某站源的索引，首次访问时把文件读进内存。
func (engine *nativeEngine) indexSiteLocked(store *searchIndexStore, source string) *searchIndexSite {
	site := store.sites[source]
	if site == nil {
		site = &searchIndexSite{pos: map[string]int{}}
		store.sites[source] = site
	}
	if !site.loaded {
		engine.loadIndexFile(source, site)
		site.loaded = true
	}
	return site
}

func (engine *nativeEngine) loadIndexFile(source string, site *searchIndexSite) {
	path := engine.indexFilePath(source)
	if path == "" {
		return
	}
	// 目录缓存是按「站源 + 模块版本」作废的（见 app_catalog_cache.go），
	// 搜索索引同理：版本对不上就整份丢掉重攒，否则上一版的条目会一直
	// 通过「简介命中」漏进搜索结果里。
	current := engine.moduleVersion(source)
	site.version = current
	body, err := os.ReadFile(path)
	if err != nil {
		return
	}
	for _, line := range strings.Split(string(body), "\n") {
		line = strings.TrimRight(line, "\r")
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "#") {
			// 版本头：#v<版本>\t<pages>\t<写入时间>\t<模块版本>
			fields := strings.Split(line, "\t")
			if len(fields) >= 2 && fields[0] == "#v"+strconv.Itoa(searchIndexVersion) {
				// 老文件没有第 4 段（模块版本）：留着用，下次写盘时补上。
				// 明写了版本且对不上的，整份作废。
				if len(fields) >= 4 {
					stamped := strings.TrimSpace(fields[3])
					if stamped != "" && stamped != current {
						return
					}
				}
				site.pages, _ = strconv.Atoi(fields[1])
			}
			continue
		}
		fields := strings.Split(line, "\t")
		if len(fields) < 7 {
			continue
		}
		entry := searchIndexEntry{ID: fields[0], Title: fields[1], Category: fields[2], Tags: fields[5], Desc: fields[6]}
		entry.Episodes, _ = strconv.Atoi(fields[3])
		entry.Cover = fields[4]
		if entry.ID == "" {
			continue
		}
		if _, exists := site.pos[entry.ID]; exists {
			continue
		}
		if len(site.entries) >= searchIndexMaxPerSite {
			break
		}
		if entry.Desc != "" {
			site.intros++
		}
		site.pos[entry.ID] = len(site.entries)
		site.entries = append(site.entries, entry)
	}
}

// indexField 把制表符和换行清掉：索引是行式存储，字段里出现分隔符会把整行
// 解析错位。按 rune 截断，避免把中文切一半变成乱码。
func indexField(value string, limit int) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return ""
	}
	value = strings.NewReplacer("\t", " ", "\n", " ", "\r", " ").Replace(value)
	if limit > 0 {
		runes := []rune(value)
		if len(runes) > limit {
			value = string(runes[:limit])
		}
	}
	return value
}

// indexDramas 把一页（目录页或搜索结果）写进索引。已存在的条目只补空字段，
// 不拿短简介覆盖已有长简介——站点列表页给的简介经常是截断版。
func (engine *nativeEngine) indexDramas(source string, items []LibraryDrama) {
	if len(items) == 0 {
		return
	}
	source = canonicalProviderSource(source)
	store := engine.index()
	store.mu.Lock()
	defer store.mu.Unlock()
	site := engine.indexSiteLocked(store, source)
	touched := false
	for _, item := range items {
		id := strings.TrimSpace(item.ID)
		if id == "" {
			continue
		}
		title := indexField(item.Title, searchIndexTitleLimit)
		category := indexField(item.Category, 40)
		tags := indexField(strings.Join(item.Tags, ","), 240)
		desc := indexField(item.Description, searchIndexFieldLimit)
		cover := strings.TrimSpace(item.Cover)
		if at, exists := site.pos[id]; exists {
			entry := &site.entries[at]
			if title != "" && entry.Title == "" {
				entry.Title = title
			}
			if category != "" && entry.Category == "" {
				entry.Category = category
			}
			if tags != "" && entry.Tags == "" {
				entry.Tags = tags
			}
			if cover != "" && entry.Cover == "" {
				entry.Cover = cover
			}
			if item.Episodes > entry.Episodes {
				entry.Episodes = item.Episodes
			}
			if desc != "" && len([]rune(desc)) > len([]rune(entry.Desc)) {
				if entry.Desc == "" {
					site.intros++
				}
				entry.Desc = desc
			}
			touched = true
			continue
		}
		if len(site.entries) >= searchIndexMaxPerSite {
			break
		}
		entry := searchIndexEntry{ID: id, Title: title, Category: category, Tags: tags, Desc: desc, Cover: cover, Episodes: item.Episodes}
		if entry.Desc != "" {
			site.intros++
		}
		site.pos[id] = len(site.entries)
		site.entries = append(site.entries, entry)
		touched = true
	}
	if touched {
		site.dirty = true
		engine.flushIndexLocked(source, site, false)
	}
}

func (engine *nativeEngine) flushIndexLocked(source string, site *searchIndexSite, force bool) {
	if !site.dirty {
		return
	}
	path := engine.indexFilePath(source)
	if path == "" {
		return
	}
	if !force && time.Since(site.flushed) < searchIndexFlushDelay {
		if site.timer == nil {
			site.timer = time.AfterFunc(searchIndexFlushDelay, func() { engine.flushIndex(source) })
		}
		return
	}
	var builder strings.Builder
	builder.WriteString("#v")
	builder.WriteString(strconv.Itoa(searchIndexVersion))
	builder.WriteString("\t")
	builder.WriteString(strconv.Itoa(site.pages))
	builder.WriteString("\t")
	builder.WriteString(strconv.FormatInt(time.Now().Unix(), 10))
	builder.WriteString("\t")
	builder.WriteString(site.version)
	builder.WriteString("\n")
	for _, entry := range site.entries {
		builder.WriteString(entry.ID)
		builder.WriteString("\t")
		builder.WriteString(entry.Title)
		builder.WriteString("\t")
		builder.WriteString(entry.Category)
		builder.WriteString("\t")
		builder.WriteString(strconv.Itoa(entry.Episodes))
		builder.WriteString("\t")
		builder.WriteString(entry.Cover)
		builder.WriteString("\t")
		builder.WriteString(entry.Tags)
		builder.WriteString("\t")
		builder.WriteString(entry.Desc)
		builder.WriteString("\n")
	}
	directory := filepath.Dir(path)
	if err := os.MkdirAll(directory, 0700); err != nil {
		return
	}
	temporary := path + ".tmp"
	if err := os.WriteFile(temporary, []byte(builder.String()), 0600); err != nil {
		return
	}
	if err := os.Rename(temporary, path); err != nil {
		return
	}
	site.dirty = false
	site.flushed = time.Now()
	if site.timer != nil {
		site.timer.Stop()
		site.timer = nil
	}
}

// flushIndex 是写盘节流到期后的异步回调。
func (engine *nativeEngine) flushIndex(source string) {
	store := engine.index()
	store.mu.Lock()
	defer store.mu.Unlock()
	site := store.sites[source]
	if site == nil {
		return
	}
	engine.flushIndexLocked(source, site, true)
}

// searchIndexed 用本地索引做七档匹配，返回按相关度排好、带 Rank 的条目。
// 打分直接复用 NativePreciseSearchStrict，索引命中和站点命中的档位口径一致。
func (engine *nativeEngine) searchIndexed(source, query string) []LibraryDrama {
	query = strings.TrimSpace(query)
	if query == "" {
		return nil
	}
	source = canonicalProviderSource(source)
	store := engine.index()
	store.mu.Lock()
	site := engine.indexSiteLocked(store, source)
	entries := make([]searchIndexEntry, len(site.entries))
	copy(entries, site.entries)
	store.mu.Unlock()
	if len(entries) == 0 {
		return nil
	}
	items := make([]LibraryDrama, 0, len(entries))
	for _, entry := range entries {
		items = append(items, entry.libraryDrama())
	}
	return NativePreciseSearchStrict(items, query)
}

// splitIndexID 只按「源:站内 id」的前缀切开，不查注册表：索引里的条目即使
// 对应的站源已经被卸载，也应该能被搜到、被列出来，只是点进去会提示站源不可用。
func splitIndexID(id string) (source, sourceID string) {
	head, tail, ok := strings.Cut(strings.TrimSpace(id), ":")
	if !ok {
		return "", ""
	}
	return strings.ToLower(strings.TrimSpace(head)), strings.TrimSpace(tail)
}

func (entry searchIndexEntry) libraryDrama() LibraryDrama {
	source, sourceID := splitIndexID(entry.ID)
	var tags []string
	for _, tag := range strings.Split(entry.Tags, ",") {
		if tag = strings.TrimSpace(tag); tag != "" {
			tags = append(tags, tag)
		}
	}
	return LibraryDrama{
		MetadataSchema: 1,
		ID:             entry.ID,
		Source:         source,
		SourceID:       sourceID,
		Title:          entry.Title,
		Description:    entry.Desc,
		Category:       entry.Category,
		Tags:           tags,
		Cover:          entry.Cover,
		Episodes:       entry.Episodes,
	}
}

// dropSearchIndex 把某站源的搜索索引整体丢掉（装 / 换 / 卸模块时）。
// 索引是纯缓存，删掉只是下次搜索时少几条简介命中，不影响任何持久数据。
func (engine *nativeEngine) dropSearchIndex(source string) {
	source = canonicalProviderSource(source)
	if source == "" {
		return
	}
	store := engine.index()
	store.mu.Lock()
	delete(store.sites, source)
	delete(store.pending, source)
	delete(store.pendingSeen, source)
	delete(store.query, source)
	delete(store.synced, source)
	delete(store.introAt, source)
	store.mu.Unlock()
	if path := engine.indexFilePath(source); path != "" {
		_ = os.Remove(path)
	}
}

// indexStats 给自检和排查用：条目数、已抓到简介的条数、目录同步到第几页。
func (engine *nativeEngine) indexStats(source string) (entries, intros, pages int) {
	store := engine.index()
	store.mu.Lock()
	defer store.mu.Unlock()
	site := engine.indexSiteLocked(store, canonicalProviderSource(source))
	return len(site.entries), site.intros, site.pages
}

// indexNextPage 是后台扩页的起点：目录翻到第几页，下次就从下一页继续。
func (engine *nativeEngine) indexNextPage(source string) int {
	store := engine.index()
	store.mu.Lock()
	defer store.mu.Unlock()
	site := engine.indexSiteLocked(store, canonicalProviderSource(source))
	return site.pages + 1
}

func (engine *nativeEngine) indexMarkPage(source string, page int) {
	source = canonicalProviderSource(source)
	store := engine.index()
	store.mu.Lock()
	defer store.mu.Unlock()
	site := engine.indexSiteLocked(store, source)
	if page > site.pages {
		site.pages = page
		site.dirty = true
		engine.flushIndexLocked(source, site, true)
	}
}

// indexIntroTargets 挑出还没抓到简介的条目。用游标轮转，避免前几条一直失败
// 把队头堵死、后面的条目永远轮不到。
func (engine *nativeEngine) indexIntroTargets(source string, limit int) []string {
	source = canonicalProviderSource(source)
	store := engine.index()
	store.mu.Lock()
	defer store.mu.Unlock()
	site := engine.indexSiteLocked(store, source)
	if len(site.entries) == 0 || limit <= 0 {
		return nil
	}
	targets := make([]string, 0, limit)
	scanned := 0
	for scanned < len(site.entries) && len(targets) < limit {
		at := (site.introCursor + scanned) % len(site.entries)
		entry := site.entries[at]
		if entry.Desc == "" && entry.Title != "" {
			targets = append(targets, entry.ID)
		}
		scanned++
	}
	site.introCursor = (site.introCursor + scanned) % len(site.entries)
	return targets
}

func (engine *nativeEngine) indexSetIntro(id, description string) {
	description = indexField(description, searchIndexFieldLimit)
	if description == "" {
		return
	}
	source, _ := splitIndexID(id)
	if source == "" {
		return
	}
	store := engine.index()
	store.mu.Lock()
	defer store.mu.Unlock()
	site := engine.indexSiteLocked(store, source)
	at, exists := site.pos[id]
	if !exists {
		return
	}
	entry := &site.entries[at]
	if len([]rune(description)) <= len([]rune(entry.Desc)) {
		return
	}
	if entry.Desc == "" {
		site.intros++
	}
	entry.Desc = description
	site.dirty = true
	engine.flushIndexLocked(source, site, false)
}

// searchIndexPageSlice 取本地命中的第 page 页。本地命中一次可能几千条，
// 不能整页塞给界面，否则第一屏全是本地结果、翻页还会重复。
func searchIndexPageSlice(items []LibraryDrama, page int) []LibraryDrama {
	if len(items) == 0 {
		return nil
	}
	page = max(1, page)
	start := (page - 1) * searchIndexPageSize
	if start >= len(items) {
		return nil
	}
	end := min(len(items), start+searchIndexPageSize)
	return items[start:end]
}

// mergeSearchWithIndex 把站点结果和本地索引命中合成一页。两边都已按七档
// 过滤过，这里走 NativeMergeSearch：先比分数，再比来源（站点在前），最后
// 保持各自原本的先后，并且按 id 去重——同一部剧两边都有时保留站点那条，
// 字段更全。
func mergeSearchWithIndex(remote, local []LibraryDrama, query string) []LibraryDrama {
	if len(remote) == 0 && len(local) == 0 {
		return nil
	}
	// 只有一侧也走 NativeMergeSearch：它顺手把「完全对不上关键词」的条目
	// 丢掉，索引命中里混进无关条目时不会漏出去，档位口径也和站点侧一致。
	groups := make([][]LibraryDrama, 0, 2)
	if len(remote) > 0 {
		groups = append(groups, remote)
	}
	if len(local) > 0 {
		groups = append(groups, local)
	}
	return NativeMergeSearch(groups, query)
}
