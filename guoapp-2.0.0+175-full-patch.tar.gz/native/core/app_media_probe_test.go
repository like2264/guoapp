package core

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"testing"
)

type probeBitWriter struct {
	bits []int
}

func (writer *probeBitWriter) put(value, width int) {
	for index := width - 1; index >= 0; index-- {
		writer.bits = append(writer.bits, (value>>index)&1)
	}
}

func (writer *probeBitWriter) ue(value int) {
	width := 0
	for (1<<(width+1))-1 <= value {
		width++
	}
	writer.put(0, width)
	writer.put(1, 1)
	writer.put(value-((1<<width)-1), width)
}

func (writer *probeBitWriter) bytes() []byte {
	out := make([]byte, (len(writer.bits)+7)/8)
	for index, bit := range writer.bits {
		if bit != 0 {
			out[index/8] |= 1 << (7 - uint(index%8))
		}
	}
	return out
}

// 造一条 baseline SPS：54x30 个宏块 = 864x480，右边裁掉 5 个 4:2:0 单元
// （10 像素），得到实际分辨率 854x480。
func probeSPSBytes() []byte {
	writer := &probeBitWriter{}
	writer.put(66, 8)
	writer.put(0, 8)
	writer.put(30, 8)
	writer.ue(0)
	writer.ue(0)
	writer.ue(0)
	writer.ue(0)
	writer.ue(1)
	writer.put(0, 1)
	writer.ue(53)
	writer.ue(29)
	writer.put(1, 1)
	writer.put(0, 1)
	writer.put(1, 1)
	writer.ue(0) // crop left
	writer.ue(5) // crop right
	writer.ue(0) // crop top
	writer.ue(0) // crop bottom
	return append([]byte{0x67}, writer.bytes()...)
}

func TestH264SPSResolution(t *testing.T) {
	sps := probeSPSBytes()
	width, height := nativeParseH264SPS(sps)
	if width != 854 || height != 480 {
		t.Fatalf("SPS 宽高 = %dx%d，期望 854x480", width, height)
	}
	packet := append([]byte{0, 0, 1}, sps...)
	if width, height = nativeH264SPSResolution(append(packet, 0x00, 0x00, 0x01, 0x68)); width != 854 || height != 480 {
		t.Fatalf("TS 分片里解析宽高 = %dx%d，期望 854x480", width, height)
	}
}

func probeMP4Box(kind string, body []byte) []byte {
	out := make([]byte, 8+len(body))
	binary.BigEndian.PutUint32(out, uint32(len(out)))
	copy(out[4:8], kind)
	copy(out[8:], body)
	return out
}

func TestMP4Resolution(t *testing.T) {
	tkhd := make([]byte, 92)
	binary.BigEndian.PutUint32(tkhd[76:], 1280<<16)
	binary.BigEndian.PutUint32(tkhd[80:], 720<<16)
	moov := probeMP4Box("moov", probeMP4Box("trak", probeMP4Box("tkhd", tkhd)))
	width, height := nativeMP4Resolution(append(probeMP4Box("ftyp", []byte("isom")), moov...))
	if width != 1280 || height != 720 {
		t.Fatalf("MP4 宽高 = %dx%d，期望 1280x720", width, height)
	}
	if width, height = nativeMP4Resolution(append([]byte{0, 0, 0, 8, 'f', 'r', 'e', 'e'}, moov...)); width != 1280 || height != 720 {
		t.Fatalf("尾部 moov 宽高 = %dx%d，期望 1280x720", width, height)
	}
}

func TestSanitizeHeight(t *testing.T) {
	cases := map[int64]int64{
		360: 360, 480: 480, 720: 720, 1080: 1080,
		470: 470, 834: 834, 404: 404,
		320: 320, 4320: 4320,
		0: 0,
	}
	for value, want := range cases {
		if got := nativeSanitizeHeight(value); got != want {
			t.Fatalf("档位 %d 校验 = %d，期望 %d", value, got, want)
		}
	}
	for _, bad := range []int64{80, 123, 200, 319, 5000, -1} {
		if got := nativeSanitizeHeight(bad); got != 0 {
			t.Fatalf("假档位 %d 没被丢弃，得到 %d", bad, got)
		}
	}
}

func TestPlaylistKey(t *testing.T) {
	list := `#EXTM3U
#EXT-X-KEY:METHOD=AES-128,URI="key.key",IV=0x87445e2c330d2d8b89bd052e088f6222
#EXTINF:6,
seg.ts
`
	info := nativePlaylistKey(list, "index.m3u8")
	if info == nil {
		t.Fatal("没解析出 key")
	}
	if info.uri != "key.key" {
		t.Fatalf("key URI = %s", info.uri)
	}
	if len(info.iv) != 16 || info.iv[0] != 0x87 || info.iv[15] != 0x22 {
		t.Fatalf("IV 不对：%x", info.iv)
	}
}

func TestDecryptSegment(t *testing.T) {
	packet := append([]byte{0, 0, 1}, probeSPSBytes()...)
	packet = append(packet, 0x00, 0x00, 0x01, 0x68)
	for len(packet)%16 != 0 {
		packet = append(packet, 0x47)
	}
	key := []byte("0123456789abcdef")
	iv := []byte("fedcba9876543210")
	sealed := make([]byte, len(packet))
	block, _ := aes.NewCipher(key)
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(sealed, packet)
	plain := nativeDecryptSegment(sealed, key, iv)
	if h := nativeMediaBytesHeight(plain, "seg.ts"); h != 480 {
		t.Fatalf("解密后分辨率 = %d，期望 480", h)
	}
	if h := nativeMediaBytesHeight(sealed, "seg.ts"); h > 0 {
		t.Fatalf("密文不该解出分辨率，得到 %d", h)
	}
}

func TestLocalPlaylistSegmentPrefersMap(t *testing.T) {
	list := `#EXTM3U
#EXTINF:10,
seg0.ts
#EXT-X-MAP:URI="init.mp4"
`
	if got := nativeLocalPlaylistSegment(list); got != "init.mp4" {
		t.Fatalf("探测目标 = %s，期望 fMP4 初始化段", got)
	}
}
