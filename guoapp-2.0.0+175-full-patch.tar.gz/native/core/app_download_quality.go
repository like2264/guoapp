package core

import (
	"io"
	"os"
	"path/filepath"
	"strings"
)

// +172：下载完的剧集要集集显示画质档位。站点用单路播放列表时
// downloadBundle 只能把 quality 留在 0，这里在列出下载记录时从本地
// 文件字节里补量一次短边，回填到 actualQuality（存盘，之后不再重复）。
const localQualityBatch = 12

func (manager *nativeDownloads) backfillDownloadQualities() {
	manager.mu.Lock()
	if manager.qualityProbed == nil {
		manager.qualityProbed = map[string]bool{}
	}
	type pending struct {
		id     string
		record nativeDownloadRecord
	}
	var queue []pending
	for id, record := range manager.jobs {
		if record.State != "completed" || record.ActualQuality > 0 || manager.qualityProbed[id] {
			continue
		}
		manager.qualityProbed[id] = true
		queue = append(queue, pending{id, *record})
		if len(queue) >= localQualityBatch {
			break
		}
	}
	manager.mu.Unlock()
	var changed bool
	for _, item := range queue {
		height := manager.probeLocalDownload(item.record)
		if height <= 0 {
			continue
		}
		manager.mu.Lock()
		if record := manager.jobs[item.id]; record != nil && record.ActualQuality == 0 {
			record.ActualQuality = int(height)
			changed = true
		}
		manager.mu.Unlock()
	}
	if changed {
		manager.mu.Lock()
		_ = manager.saveLocked()
		manager.mu.Unlock()
	}
}

func (manager *nativeDownloads) probeLocalDownload(record nativeDownloadRecord) int64 {
	if record.Output != "" {
		if height := probeLocalMediaFile(manager.outputFile(record.Output)); height > 0 {
			return height
		}
	}
	if record.File == "" {
		return 0
	}
	directory := manager.jobDirectory(record.nativeDownloadJob)
	entry := filepath.Join(directory, filepath.FromSlash(record.File))
	if !strings.HasSuffix(strings.ToLower(entry), ".m3u8") {
		return probeLocalMediaFile(entry)
	}
	playlist, err := os.ReadFile(entry)
	if err != nil || len(playlist) > 4<<20 {
		return 0
	}
	text := strings.ReplaceAll(string(playlist), "\r\n", "\n")
	segment := nativeLocalPlaylistSegment(text)
	if segment == "" {
		return 0
	}
	target := filepath.Join(directory, filepath.FromSlash(segment))
	data, err := os.ReadFile(target)
	if err != nil {
		return 0
	}
	if int64(len(data)) > nativeProbeBytes {
		data = data[:nativeProbeBytes]
	}
	key, iv := []byte(nil), []byte(nil)
	if info := nativePlaylistKey(text, record.File); info != nil {
		iv = info.iv
		if raw, err := os.ReadFile(filepath.Join(directory, filepath.FromSlash(info.uri))); err == nil && len(raw) == 16 {
			key = raw
		}
	}
	if len(key) == 16 {
		if len(iv) == 16 {
			if plain := nativeDecryptSegment(data, key, iv); plain != nil {
				data = plain
			}
		} else {
			// HLS 缺省 IV 是分片序号。本地列表未必保留原始 sequence，
			// 头几片的序号都很小，逐个试一遍；只认解出来的真实分辨率。
			for sequence := int64(0); sequence < 32; sequence++ {
				plain := nativeDecryptSegment(data, key, nativeSegmentIV(sequence))
				if plain == nil {
					continue
				}
				if height := nativeMediaBytesHeight(plain, target); height > 0 {
					return height
				}
			}
			return 0
		}
	}
	return nativeMediaBytesHeight(data, target)
}

// nativeLocalPlaylistSegment 优先取 #EXT-X-MAP 的初始化段（fMP4 的分辨率在
// 这里），否则取第一个分片。下载时播放列表已改写成相对本地文件名。
func nativeLocalPlaylistSegment(playlist string) string {
	var init string
	var first string
	for _, raw := range strings.Split(playlist, "\n") {
		line := strings.TrimSpace(raw)
		if strings.HasPrefix(line, "#EXT-X-MAP:") {
			if reference := nativeHLSAttributes(line)["URI"]; reference != "" {
				init = reference
			}
			continue
		}
		if line == "" || strings.HasPrefix(line, "#") || first != "" {
			continue
		}
		first = line
	}
	if init != "" {
		return init
	}
	return first
}

func probeLocalMediaFile(path string) int64 {
	file, err := os.Open(path)
	if err != nil {
		return 0
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil || info.Size() <= 0 {
		return 0
	}
	size := nativeProbeBytes
	if info.Size() < size {
		size = info.Size()
	}
	head := make([]byte, size)
	if _, err := file.ReadAt(head, 0); err != nil && err != io.EOF {
		return 0
	}
	if height := nativeMediaBytesHeight(head, path); height > 0 {
		return height
	}
	// MP4 的 moov 常被写在文件末尾，开头这一截只有 mdat。
	if size >= 8 && string(head[4:8]) == "ftyp" && info.Size() > nativeProbeBytes {
		tail := make([]byte, nativeProbeBytes)
		if _, err := file.ReadAt(tail, info.Size()-nativeProbeBytes); err == nil {
			return nativeMediaBytesHeight(tail, path)
		}
	}
	return 0
}
