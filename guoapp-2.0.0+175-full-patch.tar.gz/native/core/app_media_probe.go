package core

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"encoding/hex"
	"net/url"
	"strings"
)

// 下载页要给每一集显示画质档位，但站点用了单路播放列表（#EXTINF + 分片）
// 时文本里根本没有分辨率，downloadBundle 的 quality 也就留在 0。
// 已下载的文件就在本地，直接从字节里量一次短边（TS 分片查 H.264 SPS、
// MP4 查 tkhd），不联网、不猜地址、不拿假值冒充。
const nativeProbeBytes = int64(256 << 10)

// nativeKeyInfo 是 #EXT-X-KEY 的取参结果：本地 key 文件名与 IV。
type nativeKeyInfo struct {
	uri string
	iv  []byte
}

// nativePlaylistKey 从已下载的播放列表里取 AES-128 的 key 文件与 IV。
func nativePlaylistKey(playlist, base string) *nativeKeyInfo {
	baseURL, err := url.Parse(base)
	if err != nil {
		return nil
	}
	for _, raw := range strings.Split(playlist, "\n") {
		line := strings.TrimSpace(raw)
		if !strings.HasPrefix(line, "#EXT-X-KEY:") {
			continue
		}
		attributes := nativeHLSAttributes(line)
		method := strings.ToUpper(strings.TrimSpace(attributes["METHOD"]))
		if method != "AES-128" {
			continue
		}
		reference := strings.TrimSpace(attributes["URI"])
		if reference == "" {
			continue
		}
		parsed, err := url.Parse(reference)
		if err != nil {
			continue
		}
		// 已下载的播放列表里 key URI 是本地文件名，base 也是相对路径；
		// 只有网络地址才需要按 URL 解析，否则 resolve 会得到 "/key.key"。
		uri := reference
		if baseURL.IsAbs() {
			uri = baseURL.ResolveReference(parsed).String()
		}
		info := &nativeKeyInfo{uri: uri}
		if hexIV := strings.TrimSpace(attributes["IV"]); strings.HasPrefix(strings.ToLower(hexIV), "0x") {
			if decoded, err := hex.DecodeString(hexIV[2:]); err == nil && len(decoded) == 16 {
				info.iv = decoded
			}
		}
		return info
	}
	return nil
}

// nativeDecryptSegment 用 AES-128-CBC 解密分片。IV 显式给出时直接用；否则
// 调用方按 HLS 规范用分片序号作 IV 逐个尝试。
func nativeDecryptSegment(data, key, iv []byte) []byte {
	if len(key) != 16 || len(data) < 16 || len(iv) != 16 {
		return nil
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil
	}
	length := len(data) / 16 * 16
	plain := make([]byte, length)
	cipher.NewCBCDecrypter(block, iv).CryptBlocks(plain, data[:length])
	return plain
}

func nativeSegmentIV(sequence int64) []byte {
	iv := make([]byte, 16)
	for index := 15; index >= 0; index-- {
		iv[index] = byte(sequence)
		sequence >>= 8
	}
	return iv
}

// 字节探测读错位置时可能拼出 80、374 这类离谱假值。这里只做最基本的
// 合法性校验：短边必须落在 320~4320 之间，其余照实标、不吸附到标准档。
func nativeSanitizeHeight(value int64) int64 {
	if value < 320 || value > 4320 {
		return 0
	}
	return value
}

func nativeMediaBytesHeight(data []byte, address string) int64 {
	if width, height := nativeMP4Resolution(data); width > 0 && height > 0 {
		return nativeSanitizeHeight(int64(min(width, height)))
	}
	if width, height := nativeH264SPSResolution(data); width > 0 && height > 0 {
		return nativeSanitizeHeight(int64(min(width, height)))
	}
	return 0
}

// nativeMP4Resolution 从 moov/trak/tkhd 读宽高。tkhd 里的宽高是 16.16 定点数。
func nativeMP4Resolution(data []byte) (int, int) {
	for index := 0; index+8 <= len(data); index++ {
		if string(data[index+4:index+8]) != "moov" {
			continue
		}
		boxes, err := mp4Boxes(data, index, len(data))
		if err != nil || len(boxes) == 0 {
			continue
		}
		tracks, err := mp4Boxes(data, boxes[0].body, boxes[0].end)
		if err != nil {
			continue
		}
		for _, track := range tracks {
			if track.kind != "trak" {
				continue
			}
			header, found := mp4Child(data, track.body, track.end, "tkhd")
			if !found || header.end-header.body < 92 {
				continue
			}
			offset := header.body + 76
			if data[header.body] == 1 {
				offset = header.body + 88
			}
			if offset+8 > header.end {
				continue
			}
			width := int(binary.BigEndian.Uint32(data[offset:]) >> 16)
			height := int(binary.BigEndian.Uint32(data[offset+4:]) >> 16)
			if width > 0 && height > 0 && width <= 8192 && height <= 8192 {
				return width, height
			}
		}
	}
	return 0, 0
}

// nativeH264SPSResolution 在 TS / Annex-B 分片里找 H.264 SPS（NAL type 7），
// 直接读里面的宽高。SPS 一般就在分片头部几 KB 内。
func nativeH264SPSResolution(data []byte) (int, int) {
	for index := 0; index+4 < len(data); index++ {
		if data[index] != 0 || data[index+1] != 0 || data[index+2] != 1 {
			continue
		}
		if data[index+3]&0x1f != 7 {
			continue
		}
		end := len(data)
		for next := index + 3; next+3 < len(data); next++ {
			if data[next] == 0 && data[next+1] == 0 && data[next+2] == 1 {
				end = next
				break
			}
		}
		return nativeParseH264SPS(data[index+3 : end])
	}
	return 0, 0
}

type nativeBitReader struct {
	data []byte
	bit  int
}

func (reader *nativeBitReader) read(count int) int {
	value := 0
	for index := 0; index < count; index++ {
		position := reader.bit / 8
		if position >= len(reader.data) {
			return -1
		}
		value = value<<1 | int((reader.data[position]>>(7-uint(reader.bit%8)))&1)
		reader.bit++
	}
	return value
}

func (reader *nativeBitReader) ue() int {
	zeros := 0
	for {
		bit := reader.read(1)
		if bit < 0 {
			return -1
		}
		if bit == 1 {
			break
		}
		zeros++
		if zeros > 32 {
			return -1
		}
	}
	value := (1 << zeros) - 1
	if zeros > 0 {
		tail := reader.read(zeros)
		if tail < 0 {
			return -1
		}
		value += tail
	}
	return value
}

func (reader *nativeBitReader) se() int {
	value := reader.ue()
	if value < 0 {
		return -1
	}
	if value%2 == 0 {
		return -(value / 2)
	}
	return (value + 1) / 2
}

// nativeUnescapeRBSP 去掉 H.264 为了防止伪起始码插入的 0x03。
func nativeUnescapeRBSP(nal []byte) []byte {
	out := make([]byte, 0, len(nal))
	zeros := 0
	for _, value := range nal {
		if zeros >= 2 && value == 3 {
			zeros = 0
			continue
		}
		out = append(out, value)
		if value == 0 {
			zeros++
		} else {
			zeros = 0
		}
	}
	return out
}

func nativeSkipScalingList(reader *nativeBitReader, size int) bool {
	last, next := 8, 8
	for index := 0; index < size; index++ {
		if next != 0 {
			delta := reader.se()
			if delta < 0 {
				return false
			}
			next = (last + delta + 256) % 256
		}
		if next != 0 {
			last = next
		}
	}
	return true
}

func nativeParseH264SPS(nal []byte) (int, int) {
	rbsp := nativeUnescapeRBSP(nal)
	if len(rbsp) < 8 || rbsp[0]&0x1f != 7 {
		return 0, 0
	}
	reader := &nativeBitReader{data: rbsp[1:]}
	profile := reader.read(8)
	if reader.read(8) < 0 || reader.read(8) < 0 { // constraints + level
		return 0, 0
	}
	if reader.ue() < 0 { // seq_parameter_set_id
		return 0, 0
	}
	chroma := 1
	switch profile {
	case 100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135:
		value := reader.ue()
		if value < 0 {
			return 0, 0
		}
		chroma = value
		if chroma == 3 && reader.read(1) < 0 {
			return 0, 0
		}
		if reader.ue() < 0 || reader.ue() < 0 || reader.read(1) < 0 {
			return 0, 0
		}
		if reader.read(1) == 1 {
			lists := 8
			if chroma != 3 {
				lists = 12
			}
			for index := 0; index < lists; index++ {
				if reader.read(1) == 1 && !nativeSkipScalingList(reader, min(16+(index/6)*48, 64)) {
					return 0, 0
				}
			}
		}
	}
	if reader.ue() < 0 { // log2_max_frame_num_minus4
		return 0, 0
	}
	pocType := reader.ue()
	if pocType < 0 {
		return 0, 0
	}
	switch pocType {
	case 0:
		if reader.ue() < 0 {
			return 0, 0
		}
	case 1:
		if reader.read(1) < 0 || reader.se() < 0 || reader.se() < 0 {
			return 0, 0
		}
		count := reader.ue()
		if count < 0 {
			return 0, 0
		}
		for index := 0; index < count; index++ {
			if reader.se() < 0 {
				return 0, 0
			}
		}
	}
	if reader.ue() < 0 || reader.read(1) < 0 { // max refs + gaps flag
		return 0, 0
	}
	widthUnits, heightUnits := reader.ue(), reader.ue()
	frameOnly := reader.read(1)
	if frameOnly < 0 || widthUnits < 0 || heightUnits < 0 {
		return 0, 0
	}
	if frameOnly == 0 && reader.read(1) < 0 {
		return 0, 0
	}
	if reader.read(1) < 0 { // direct_8x8_inference_flag
		return 0, 0
	}
	var left, right, top, bottom int
	if reader.read(1) == 1 {
		// H.264 SPS 的顺序是 left, right, top, bottom。
		left, right = reader.ue(), reader.ue()
		top, bottom = reader.ue(), reader.ue()
		if left < 0 || right < 0 || top < 0 || bottom < 0 {
			return 0, 0
		}
	}
	width := (widthUnits + 1) * 16
	height := (2 - frameOnly) * (heightUnits + 1) * 16
	unitX, unitY := 1, 2-frameOnly
	if chroma == 1 || chroma == 2 {
		unitX, unitY = 2, unitY*2
	}
	width -= (left + right) * unitX
	height -= (top + bottom) * unitY
	if width <= 0 || height <= 0 || width > 8192 || height > 8192 {
		return 0, 0
	}
	return width, height
}
