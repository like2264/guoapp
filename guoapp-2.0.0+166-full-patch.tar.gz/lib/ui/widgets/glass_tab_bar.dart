import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// 浮动玻璃标签栏：半透明胶囊 + 背景磨砂 + 细高光边。
///
/// 参考效果（用户 2026-11-24/25 发的视频）：底下的封面、标题要能清楚读出来，
/// 玻璃感靠描边和顶部高光表达，不靠把背景糊掉。磨砂维持 1.2（比 0.8 略有一
/// 点磨砂，但后面缩略图的字仍清晰可读）。
///
/// 2.0.0+166 按用户视频与 +165 反馈重做：
/// - 修 +165 的布局塌陷：Stack 外层补回 [SizedBox] 高度约束，底栏回到底部；
/// - 胶囊改成**横向长条 pill**：圆角恒等于高度一半，按住横向放大、圆头不变方；
/// - 滑动加**水球动效**：按拖动速度横向拉伸、纵向压缩，松手果冻回弹；
/// - 底栏**边框彩色辉光跟随胶囊**滑动，经过文字时能看到光晕。
class GlassTabBar extends StatefulWidget {
  const GlassTabBar({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
    required this.destinations,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final List<GlassTabDestination> destinations;

  /// 胶囊本体高度（不含底部安全区）。2.0.0+136 从 62 撑到 70：
  /// 图标底下那行字在 62 里太挤，撑大之后更像一块真的浮起来的玻璃。
  static const barHeight = 70.0;

  /// 底栏上下的留白。内容要躲开底栏时，用 [reservedHeight]。
  static const horizontalInset = 10.0;
  static const bottomGap = 10.0;

  static const _radius = barHeight / 2;

  /// 玻璃条内边距：胶囊在这里面移动。
  static const _pad = 6.0;

  /// 底栏实际占用的总高度（胶囊 + 上下留白 + 安全区）。
  /// 页面底部留白按它算，内容就不会被浮起来的玻璃条盖住。
  static double reservedHeight(BuildContext context) =>
      barHeight + bottomGap + MediaQuery.viewPaddingOf(context).bottom + 8;

  @override
  State<GlassTabBar> createState() => _GlassTabBarState();
}

/// 外壳把底栏的**实际预留高度**发布给页面。
///
/// 为什么不各页自己算：底栏是在外壳的 Scaffold 里当 `bottomNavigationBar` 摆的，
/// 它拿到的安全区（`viewPadding.bottom`）和 tab 页面里拿到的不一定一样 ——
/// 真机上出现过页面这边是 0、底栏那边是 34，于是页面少留了整整一个安全区，
/// 「取消追剧」被底栏压掉一截（2.0.0+156 的反馈）。这里由外壳统一量一次，
/// 页面直接读，两边永远同一个数。
class ShellBottomInset extends InheritedWidget {
  const ShellBottomInset({
    super.key,
    required this.height,
    required super.child,
  });

  /// 底栏占掉的高度（非玻璃底栏时是 0）。
  final double height;

  static double? maybeOf(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<ShellBottomInset>()?.height;

  @override
  bool updateShouldNotify(ShellBottomInset oldWidget) =>
      oldWidget.height != height;
}

class _GlassTabBarState extends State<GlassTabBar> {
  /// 拖胶囊时相对「选中格左边缘」的偏移。
  double _drag = 0;
  bool _dragging = false;

  /// 按住态：按下即放大胶囊并亮起彩虹光晕，松手恢复（+165 视频）。
  bool _pressed = false;

  /// 水球形变：拖动速度驱动的挤压量（0~0.32）。横向拉伸、纵向压缩，松手归零。
  double _squash = 0;

  /// 拖动过程中已经掠过（并震动过）的格子，避免同一格反复震。
  int? _hovered;

  /// 果冻回弹：拖动结束松手时，胶囊带一点弹性地落位（+161 反馈）。
  static const _jellySnap = Duration(milliseconds: 480);
  static const _jellyCurve = Curves.elasticOut;

  /// 胶囊四周的淡淡彩虹光晕（+165 视频：白主体不变，只在边缘透出彩色辉光）。
  /// 这是边缘辉光色，不是 +164 之前那版整块彩虹填充，别混回去。
  static const _haloColors = <Color>[
    Color(0xFFFF8FA8),
    Color(0xFFFFD86B),
    Color(0xFF8FFFC4),
    Color(0xFF7FD4FF),
    Color(0xFFB79BFF),
  ];

  /// 胶囊**恒宽一格**，拖动只跟手平移，不从起点格拉到手指位置形成横跨多格
  /// 的大椭圆（用户明确说那个像「拉面条」，不是他要的效果）。
  /// 返回 (left, width)，宽度恒为 cell；_drag 已在 [_dragUpdate] 里钳到首尾格。
  (double, double) _capsuleRect(double cell, double baseLeft) {
    final left = _dragging ? baseLeft + _drag : baseLeft;
    return (left, cell);
  }

  void _pressDown() {
    if (_pressed) return;
    setState(() => _pressed = true);
  }

  void _pressUp() {
    if (!_pressed) return;
    setState(() => _pressed = false);
  }

  void _dragStart(DragStartDetails details) {
    HapticFeedback.selectionClick();
    setState(() {
      _pressed = true;
      _dragging = true;
      _drag = 0;
      _squash = 0;
      _hovered = widget.selectedIndex;
    });
  }

  void _dragUpdate(DragUpdateDetails details, double cell) {
    setState(() {
      final dx = details.delta.dx;
      _drag += dx;
      // 胶囊最多移到首尾两格，再往外拖没有意义。
      final travel = cell * (widget.destinations.length - 1);
      _drag = _drag.clamp(
        -widget.selectedIndex * cell,
        travel - widget.selectedIndex * cell,
      );
      // 水球：拖得快就横向拉长、纵向压扁；停手自然回正。
      final target = (dx.abs() / cell * 1.1).clamp(0.0, 0.32);
      _squash = target > _squash ? target : _squash * 0.82;
      final index = widget.selectedIndex + (_drag / cell).round();
      if (index != _hovered) {
        _hovered = index;
        HapticFeedback.selectionClick();
      }
    });
  }

  void _dragEnd(double cell) {
    final index = (widget.selectedIndex + (_drag / cell).round()).clamp(
      0,
      widget.destinations.length - 1,
    );
    setState(() {
      _dragging = false;
      _pressed = false;
      _drag = 0;
      _squash = 0;
      _hovered = null;
    });
    if (index != widget.selectedIndex) widget.onSelected(index);
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors = Theme.of(context).colorScheme;
    final inset = MediaQuery.viewPaddingOf(context).bottom;
    final radius = BorderRadius.circular(GlassTabBar._radius);
    return Padding(
      padding: EdgeInsets.fromLTRB(
        GlassTabBar.horizontalInset,
        0,
        GlassTabBar.horizontalInset,
        GlassTabBar.bottomGap + inset,
      ),
      // +165 布局塌陷病根：Stack 里全是 Positioned，没有非定位子元素撑高度，
      // 整条底栏被顶到屏幕顶部。+166 补回固定高度，Stack 只负责叠层与溢出。
      child: SizedBox(
        height: GlassTabBar.barHeight,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final inner = constraints.maxWidth - GlassTabBar._pad * 2;
            final cell = inner / widget.destinations.length;
            final baseLeft = GlassTabBar._pad + widget.selectedIndex * cell;
            final (capLeft, capWidth) = _capsuleRect(cell, baseLeft);

            // 按住（未拖动）：横向放大成长条 pill，纵向少增并向上溢出盖住封面。
            final grow = _pressed && !_dragging ? 1.55 : 1.0;
            // 滑动中的水球挤压：横宽纵窄，幅度随速度。
            final squash = _dragging ? _squash : 0.0;
            final baseH = GlassTabBar.barHeight - GlassTabBar._pad * 2;
            final holdLift = (_pressed && !_dragging) ? 12.0 : 0.0;
            final capW = capWidth * grow * (1 + squash * 0.6);
            final capH = (baseH + holdLift * 0.5) * (1 - squash * 0.4);
            // 圆角恒为高度一半 —— 全程 pill，不再出现 +165 的方角。
            final capRadius = capH / 2;
            final capX = capLeft + capWidth / 2 - capW / 2;
            final capY = GlassTabBar._pad - (capH - baseH) / 2 - holdLift;

            return Stack(
              clipBehavior: Clip.none,
              children: [
                // 1. 磨砂底栏本体（裁圆角、带阴影与彩色辉光）。
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: radius,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(
                            alpha: dark ? 0.18 : 0.08,
                          ),
                          blurRadius: 22,
                          spreadRadius: -6,
                          offset: const Offset(0, 8),
                        ),
                        // 边框扫过文字时的淡淡彩色辉光。
                        BoxShadow(
                          color: _haloColors[3].withValues(
                            alpha: dark ? 0.10 : 0.07,
                          ),
                          blurRadius: 18,
                          spreadRadius: -4,
                          offset: const Offset(0, -2),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: radius,
                      child: BackdropFilter(
                        // 几乎不糊：底下的封面和标题要一眼能读出来，玻璃感交给
                        // 描边和顶部高光去表达（2.0.0+163 按视频从 6 退回 1.2）。
                        filter: ImageFilter.blur(
                          sigmaX: 1.2,
                          sigmaY: 1.2,
                          tileMode: TileMode.clamp,
                        ),
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            borderRadius: radius,
                            // 先垫一层灰：纯白胶囊压在亮内容上会「发飘」，
                            // 掺一点中性灰才像磨砂玻璃（参考腾讯视频那条）。
                            color: dark
                                ? Colors.white.withValues(alpha: 0.032)
                                : Colors.black.withValues(alpha: 0.058),
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: dark
                                  ? [
                                      Colors.white.withValues(alpha: 0.06),
                                      Colors.white.withValues(alpha: 0.022),
                                    ]
                                  : [
                                      Colors.white.withValues(alpha: 0.27),
                                      Colors.white.withValues(alpha: 0.14),
                                    ],
                            ),
                            border: Border.all(
                              color: dark
                                  ? Colors.white.withValues(alpha: 0.30)
                                  : Colors.white.withValues(alpha: 0.75),
                              width: 1,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                // 2. 选中胶囊：恒宽一格、跟手平移、水球挤压；按住放大成长条
                //    pill 并溢出底栏上沿；四周彩虹光晕，圆角恒等于高度一半。
                AnimatedPositioned(
                  duration: _dragging ? Duration.zero : _jellySnap,
                  curve: _jellyCurve,
                  left: capX,
                  top: capY,
                  width: capW,
                  height: capH,
                  child: IgnorePointer(
                    child: AnimatedContainer(
                      duration: _dragging ? Duration.zero : _jellySnap,
                      curve: _jellyCurve,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(capRadius),
                        // 主体仍是白色半透明玻璃，不把整块染成彩虹（+164 定稿）。
                        color: dark
                            ? Colors.white.withValues(alpha: 0.18)
                            : Colors.white.withValues(alpha: 0.58),
                        border: Border.all(
                          color: dark
                              ? Colors.white.withValues(alpha: 0.34)
                              : Colors.white.withValues(alpha: 0.92),
                          width: 1.2,
                        ),
                        // 淡淡彩虹光晕：五束低透明彩色柔光分别落在五边，
                        // 按住时 alpha / blur / spread 一起加大，松手收回。
                        boxShadow: [
                          BoxShadow(
                            color: _haloColors[0].withValues(
                              alpha: _pressed ? 0.30 : 0.13,
                            ),
                            blurRadius: _pressed ? 16 : 9,
                            spreadRadius: _pressed ? 2 : 0,
                            offset: const Offset(-8, 0),
                          ),
                          BoxShadow(
                            color: _haloColors[1].withValues(
                              alpha: _pressed ? 0.26 : 0.11,
                            ),
                            blurRadius: _pressed ? 15 : 8,
                            spreadRadius: _pressed ? 1.5 : 0,
                            offset: const Offset(0, -8),
                          ),
                          BoxShadow(
                            color: _haloColors[2].withValues(
                              alpha: _pressed ? 0.30 : 0.13,
                            ),
                            blurRadius: _pressed ? 16 : 9,
                            spreadRadius: _pressed ? 2 : 0,
                            offset: const Offset(8, 0),
                          ),
                          BoxShadow(
                            color: _haloColors[3].withValues(
                              alpha: _pressed ? 0.30 : 0.13,
                            ),
                            blurRadius: _pressed ? 16 : 9,
                            spreadRadius: _pressed ? 2 : 0,
                            offset: const Offset(0, 8),
                          ),
                          BoxShadow(
                            color: _haloColors[4].withValues(
                              alpha: _pressed ? 0.24 : 0.10,
                            ),
                            blurRadius: _pressed ? 20 : 12,
                          ),
                          BoxShadow(
                            color: Colors.black.withValues(
                              alpha: dark ? 0.20 : 0.10,
                            ),
                            blurRadius: 14,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // 3. 边框彩色辉光：一段跟随胶囊的渐变光带贴在底栏顶边，
                //    滑动时随之移动，经过文字时能看到淡淡光晕（+166 反馈第 4 条）。
                AnimatedPositioned(
                  duration: _dragging ? Duration.zero : _jellySnap,
                  curve: _jellyCurve,
                  left: capX,
                  top: 0,
                  width: capW,
                  height: 2,
                  child: IgnorePointer(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(1),
                        gradient: LinearGradient(
                          colors: [
                            _haloColors[0].withValues(alpha: 0),
                            _haloColors[4].withValues(
                              alpha: dark ? 0.52 : 0.62,
                            ),
                            _haloColors[2].withValues(
                              alpha: dark ? 0.42 : 0.52,
                            ),
                            _haloColors[3].withValues(
                              alpha: dark ? 0.52 : 0.62,
                            ),
                            _haloColors[0].withValues(alpha: 0),
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _haloColors[4].withValues(
                              alpha: _pressed ? 0.45 : 0.26,
                            ),
                            blurRadius: _pressed ? 14 : 9,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // 4. 栏目行（点击/拖动手势 + 图标文字）。
                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.all(GlassTabBar._pad),
                    child: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTapDown: (_) => _pressDown(),
                      onTapUp: (_) => _pressUp(),
                      onTapCancel: _pressUp,
                      onHorizontalDragStart: _dragStart,
                      onHorizontalDragUpdate: (details) =>
                          _dragUpdate(details, cell),
                      onHorizontalDragEnd: (_) => _dragEnd(cell),
                      onHorizontalDragCancel: () => _dragEnd(cell),
                      child: Row(
                        children: [
                          for (
                            var index = 0;
                            index < widget.destinations.length;
                            index++
                          )
                            Expanded(
                              child: _item(
                                context,
                                index,
                                dark,
                                colors,
                                pressed: _pressed,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),

                // 5. 顶部一条细高光：玻璃感主要靠它，保持白色细线。
                Positioned(
                  left: GlassTabBar._radius * 0.6,
                  right: GlassTabBar._radius * 0.6,
                  top: 0,
                  child: IgnorePointer(
                    child: Container(
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withValues(alpha: 0),
                            Colors.white.withValues(
                              alpha: dark ? 0.45 : 0.9,
                            ),
                            Colors.white.withValues(alpha: 0),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _item(
    BuildContext context,
    int index,
    bool dark,
    ColorScheme colors, {
    required bool pressed,
  }) {
    final destination = widget.destinations[index];
    final selected = index == widget.selectedIndex;
    // 按住选中项时图标文字也轻微放大，和胶囊「整块变大」一致。
    final scale = selected && pressed ? 1.10 : 1.0;
    // 每个栏目给自己的一点颜色，未选中时压淡，选中时用主色。
    final accent = destination.color ?? colors.primary;
    final idle = dark
        ? Colors.white.withValues(alpha: 0.92)
        : Colors.black.withValues(alpha: 0.78);
    // 背景很透，内容可能很亮也可能很暗，给字加一圈很轻的影子保证可读。
    final legibility = <Shadow>[
      Shadow(
        offset: const Offset(0, 1),
        blurRadius: 2,
        color: dark
            ? Colors.black.withValues(alpha: 0.65)
            : Colors.white.withValues(alpha: 0.85),
      ),
    ];
    return Semantics(
      button: true,
      selected: selected,
      label: destination.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => widget.onSelected(index),
        child: Transform.scale(
          scale: scale,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconTheme.merge(
                data: IconThemeData(
                  size: 24,
                  color: selected
                      ? accent
                      : Color.alphaBlend(
                          accent.withValues(alpha: dark ? 0.55 : 0.62),
                          idle,
                        ),
                ),
                child: selected ? destination.selectedIcon : destination.icon,
              ),
              const SizedBox(height: 2),
              Text(
                destination.label,
                maxLines: 1,
                overflow: TextOverflow.fade,
                softWrap: false,
                style: TextStyle(
                  fontSize: 11,
                  height: 1.1,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  color: selected ? accent : idle,
                  shadows: legibility,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GlassTabDestination {
  const GlassTabDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
    this.color,
  });

  final String label;
  final Widget icon;
  final Widget selectedIcon;

  /// 这个栏目的点缀色。不填就跟着主题主色走。
  final Color? color;
}
