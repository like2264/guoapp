# 开发指南

## 环境

Flutter `3.47.9`、Dart `3.12+`、Go `1.24.1+`、Python `3.10+`。

- Android：JDK 17、SDK 36、NDK `28.2.13676358`
- Windows：Visual Studio C++ 桌面组件、MinGW-w64 x64、Inno Setup 6.5+（`winget install JRSoftware.InnoSetup`）
- iOS：macOS、完整 Xcode、CocoaPods
- macOS：完整 Xcode、CocoaPods，打 dmg 需 `pip install dmgbuild Pillow`；`xcode-select` 指向 Command Line Tools 时 `build_macos.py` 会自动改用 `/Applications/Xcode*.app`，也可以在系统层面执行 `sudo xcode-select -s`

构建脚本对子进程默认设置 `GOPROXY=https://goproxy.cn,direct`、`GOSUMDB=off`，同名环境变量可覆盖。

## 调试运行

官方站源不在本仓库，放在单独的私有站源仓库里（Go 模块 `guoapp/sources`）。编译 Go 核心时用 `--sources <站源仓库路径>` 接入站源，可以多次指定以同时接入多个站源模块；脚本会在 `native/` 下生成不入库的 `go.work` 与 `bridge/sources_gen.go`，之后可以省略。从未接入过站源时自动使用 `native/sources_example` 的示例站源，它只返回假数据、不访问网络、不能播放，用来在没有站源仓库时调试界面；想换回示例站源，传 `--sources native/sources_example`。所有出包脚本都接受同一个参数。站源模块的写法见[站源开发约定](#站源开发约定)。

Flutter 运行前必须先编译对应平台 / 架构的 Go 核心：

~~~sh
python3 scripts/build_native.py --platform android --abi arm64-v8a --sources ../guoapp-sources
flutter pub get --enforce-lockfile
flutter run
~~~

调试全站源版：`build_native.py` 加 `--all-sources`，再 `flutter run --dart-define=APP_FLAVOR=zhenguojian`；iOS 对应 `build_ios.py --core-only --all-sources`，macOS 用 `build_native.py --platform darwin --all-sources`。版本是编译期开关，Dart 常量和 Go 编译参数必须一致，应用启动时会校验，避免混装原生库。

## 出包

~~~sh
python3 scripts/build_android.py                 # 红果鉴
python3 scripts/build_android.py --all-sources   # 全站源版
python3 scripts/build_android.py --abi arm64-v8a
python scripts/build_windows.py [--all-sources]
python3 scripts/build_ios.py [--all-sources]
python3 scripts/build_macos.py [--all-sources]
python3 scripts/build_ios.py --core-only [--simulator]
python3 scripts/build_ios.py --export-options /path/to/ExportOptions.plist
~~~

产物在 `dist/android`、`dist/windows`、`dist/ios`、`dist/macos`，红果鉴以 `hongguojian-` 开头，全站源版以 `zhenguojian-` 开头。Windows 同时出便携 zip 和 Inno Setup 安装包（`windows/installer/setup.iss`，简体中文语言文件取自 Inno Setup 官方仓库），安装包以包名为 AppId，两个版本可同时安装，默认装到 `%LOCALAPPDATA%\Programs\<包名>`，安装时可提权改为所有用户，卸载窗口先显示「卸载选项」页（插在卸载进度窗口里），勾选「同时清除本地数据」才删除 `%APPDATA%\<包名>`（含默认下载目录），默认保留；静默卸载不删。macOS 出 arm64 + x86_64 通用 dmg；dmg 的安装窗口（背景图、图标位置、隐藏工具栏）由 `dmgbuild` 写入 `.DS_Store`，打包机需要 `pip install dmgbuild Pillow`，没装时会退回普通镜像并提示。默认 ad-hoc 签名，从网络下载的 dmg 在其他 Mac 上首次打开会被 Gatekeeper 拦一次（右键「打开」，或执行 `xattr -dr com.apple.quarantine /Applications/红果鉴.app`）。有 Developer ID 时用 `package_release.py --platform macos --identity "Developer ID Application: ..."` 重新打包并公证，才能免掉这一步。本机 Android 签名：红果鉴用 `android/key.properties`，全站源版用 `android/key-all-sources.properties`（均不入库）。

其他脚本：`generate_brand_assets.py` 从 `brand_icon.svg` 生成各平台图标；`clear_app_data.py`、`clear_catalog_cache.py` 清理 Windows 上的应用数据和剧库缓存。

## 检查与测试

~~~sh
dart format --output=none --set-exit-if-changed lib test
dart analyze --fatal-infos lib test
flutter test --dart-define=DISABLE_REMOTE_IMAGES=true
flutter test --dart-define=DISABLE_REMOTE_IMAGES=true --dart-define=APP_FLAVOR=zhenguojian
cd native
go test -race ./...
go test -race -tags=zhenguojian ./...
~~~

Flutter 测试一律带 `DISABLE_REMOTE_IMAGES=true`，避免加载站源图片。测试只覆盖数据兼容、权限和逻辑层，界面改动不写测试；公共假仓库在 `test/support/`。

## 架构

Flutter 界面 + Go 原生核心。站源请求、解析、签名、缓存、下载调度和播放代理都在 Go 里完成，Dart 只负责界面、播放器和本地用户数据。

- **FFI**：`native/bridge` 以 `-buildmode=c-shared` 只导出 `DuanjuRequest(json) -> json` 与 `DuanjuFree`。`lib/core_bridge.dart` 的 `NativeRepository` 把每次调用编码成 `{"action": ...}`，在 `Isolate.run` 中调用；Go 侧在 `native/core/app_runtime.go` 的 `NativeRequest` 里按 action 分派。新增能力两端都要改。Android 与 Windows 动态加载（`libduanju_core.so` / `duanju_core.dll`）；iOS 与 macOS 改成 `-buildmode=c-archive` 静态库（`ios/DuanjuCore`、`macos/DuanjuCore`）链进主程序，Dart 侧用 `DynamicLibrary.process()` 查符号，避免 dylib 的签名与库校验问题。
- **Go 核心**：`native/core` 是运行时，站源只经它导出的接口（`Provider`、`Host` 及各可选接口）访问。站源与各版本的站源名单放在站源模块里（官方站源模块是私有站源仓库，示例站源模块是 `native/sources_example`），只单向依赖 core，由构建脚本生成的 `native/bridge/sources_gen.go` 空白导入接入。core 里 `app_*.go` 运行时与业务（目录缓存、下载、弹幕、存储、设置），`network_*.go` HTTP 客户端、DNS、CDN、限流。`app_stream.go` 在本机起播放代理，重写 HLS playlist、透传 Range，并处理带密钥的媒体。
- **Flutter**：界面在 `lib/ui/`（按页面分子目录，入口 `lib/main.dart` → `lib/ui/app.dart`），逻辑层平铺在 `lib/`，状态管理只用 ChangeNotifier。
- **播放与下载**：播放器用 [media_kit](https://github.com/media-kit/media-kit) / libmpv；每集下载完由 [FFmpegKit min-gpl](https://github.com/sk3llo/ffmpeg_kit_flutter)（含 GPL 媒体组件）转成单个 mp4，只换封装、不重新编码，不参与正常播放。
- **本地数据**：存储格式须兼容旧版。本地快照遇到未知键会整体报错，新增设置若要兼容旧版须存为快照外的独立键。

## 目录结构

| 目录 | 内容 |
| --- | --- |
| `lib/ui` | 界面：主题、导航壳、各页面、播放器、公共组件 |
| `lib` | 逻辑层：FFI、站源目录、播放、下载、本地存储与用户 |
| `native/core`、`native/bridge` | Go 运行时（缓存、下载、播放代理）及 C ABI |
| `native/sources_example` | 示例站源模块（假数据，不访问网络） |
| `android`、`windows`、`ios`、`macos` | 平台工程与资源 |
| `packages/media_kit_libs_windows_video` | 本地覆盖的 Windows 媒体依赖插件 |
| `scripts` | 构建、图标生成与数据清理脚本 |
| `test` | 逻辑层测试 |

## 站源开发约定

站源是站源模块里的 Go 原生 provider，不是运行期加载的脚本。新增站源实现 `core.Provider`（按需实现可选接口），在 `init` 里用 `core.Register` 登记描述符和工厂，并加进所在模块 `flavor_*.go` 的版本名单；运行时与界面代码都不用改，界面的站源列表由核心在初始化时下发。

### 站源模块

- 站源模块是任意路径的 Go 模块，经构建脚本生成的 `go.work` 解析 `duanjuapp/native/core`，`go.mod` 不需要 `require` 它。构建脚本只空白导入模块根包，所有注册都要在根包的 `init` 里完成。新模块从复制 `native/sources_example` 开始，改掉 `go.mod` 的模块名和站源 ID。
- 按编译标签调用 `core.RegisterFlavor`：默认（`!zhenguojian`）注册 `hongguojian`，`zhenguojian` 标签下注册 `zhenguojian`，列出本模块要在该版本启用的站源 ID。没列进当前版本名单的站源在该版本不可用。多个模块注册的同名版本会合并站源名单。
- 版本名不一致或站源 ID 重复时原生库加载即 panic，不提供覆盖规则：编译期拼装的站源本来就该在出包时暴露冲突。别名不查重，撞上时后注册的生效，起别名时自己避开。
- 模块要声明它所适配的站源接口版本：`var _ core.SourceAPI1`。

### 接口版本

站源接口指 `native/core` 的全部导出标识符，包括下面列出的类型和站源常用的工具函数（`core.Truncate`、`core.FirstNonEmpty` 等）。core 对这些标识符做不兼容改动（删除、改名、改签名、改语义）时，把 `native/core/source_api.go` 的 `SourceAPI1` 改名为下一个版本号，并在 `CHANGELOG.md` 写明迁移办法。没跟上的模块会以 `undefined: core.SourceAPI1` 编译失败，而不是装到设备上才出错。只新增导出标识符、新增可选接口或给描述符加字段不升版本。

### 标识

- 站源 ID 用小写字母、数字和 `-`，不能含 `:`；`Aliases` 里的域名或旧 ID 也会解析到本站源。
- 剧的 ID 用 `core.ProviderDramaID(站源 ID, 站内 ID)`，分集 ID 用 `core.ProviderChapterID(站源 ID, 站内 ID, 分集键)`。这些 ID 会写进用户的追剧、记录和下载，发布后不能改格式。
- 分类 ID 由站源自定，空字符串表示「全部」；`ValidCategory` 必须放行站源自己返回的所有分类 ID，否则界面切换分类时会被拒绝。

### `SourceDescriptor`

| 字段 | 作用 |
| --- | --- |
| `ID`、`Name`、`Description` | 站源 ID、显示名、站源列表里的说明 |
| `Group`、`GroupName`、`EntryName` | 同组站源在界面里合并成一个入口时的分组 ID、分组名和组内名称 |
| `DefaultOff` | 新用户默认不启用 |
| `SkipVIPPrompt` | 不对 VIP 剧弹提示 |
| `Aliases`、`HostSuffixes`、`MatchesHost` | 把别名、域名后缀或任意判断函数匹配到的主机归到本站源，用于按地址识别站源 |
| `BaseURL` | 站点默认地址，`Host.BaseURL` 和域名轮换以它为准 |
| `NoHostRotation` | 请求失败时不在多个站点地址间轮换 |
| `AllowEmptyCatalog` | 目录第一页为空时不报错 |
| `ContinuousFeed` | 目录是不分页的信息流：运行时经 `ctx` 传入已知剧集（`core.LibraryKnownKey`）和是否加载更多（`core.LibraryMoreKey`），缓存合并也按信息流处理 |
| `KeepDetailEpisodes` | 详情的分集少于剧集信息里的总集数时，保留较大的总集数 |
| `BrowserFingerprint` | 本站源域名的请求改用浏览器 TLS 指纹 |
| `ValidCategory` | 校验分类 ID，见上 |
| `Rankings` | 榜单列表，配合 `Ranker` 使用 |

### `Provider` 与可选接口

`Provider` 必须实现：`Descriptor`、`Categories`（分类列表）、`CatalogPage`（按页取目录，返回本页剧集和是否还有下一页）、`Detail`（按站内 ID 取剧集信息和分集）、`ResolveMedia`（把分集解析成可播放的媒体）。

需要哪种能力就实现哪个接口，运行时用类型断言检测，界面上的对应入口随之出现：

| 接口 | 能力 |
| --- | --- |
| `Searcher`、`WarningSearcher` | 搜索；后者可以在有结果的同时附带一条提示 |
| `Suggester` | 搜索联想 |
| `Recommender` | 推荐流 |
| `Ranker` | 榜单分页 |
| `DanmakuProvider` | 弹幕 |
| `DeviceProvider`、`AccountProvider` | 站源设备注册、站源账号操作 |
| `CatalogStateful` | 目录翻页状态随剧库缓存一起保存和恢复 |
| `Sited`、`URLRotator` | 运行时决定的站点地址；同一地址的候选镜像 |
| `CoverResolver`、`CoverRepairer`、`CoverRefererProvider` | 按需解析封面地址；修复旧数据的封面；封面请求的 Referer |
| `MetadataEnricher` | 详情之外再补齐剧集元数据 |
| `SeasonProvider` | 同一部剧的各季，按季序返回；详情页显示季标签，本季播完自动接下一季 |
| `MediaAuthorizer` | 播放请求需要临时授权头时由站源签发，失效时被告知 |

返回 `core.SourceLoginError` 表示要先登录站源账号；`Categories` 同时返回已取到的分类和 `core.ErrCategoriesIncomplete` 表示分类不完整，本次照常显示但不写入缓存，下次重新获取。

### `Host`

工厂函数收到的 `core.Host` 是站源访问运行时的唯一入口。所有网络请求都走 `Fetch`、`FetchText`、`FetchPlaylist`，不要自建 `http.Client`，代理、限流、重试、DNS 和诊断日志都由运行时统一处理。

| 方法 | 作用 |
| --- | --- |
| `Fetch`、`FetchText` | 通用 HTTP 请求；取文本页面 |
| `FetchPlaylist` | 取 HLS 播放列表，可带媒体凭证 |
| `Reserve` | 先占用限流名额再请求，返回的票据填进 `HTTPRequest.Ticket` |
| `Retries`、`MaxPages` | 用户设置的重试次数、每个分类最多翻页数 |
| `BaseURL`、`PreferredSite`、`RememberSite` | 站点地址；上次可用的站点；记住可用站点 |
| `LoadState`、`SaveState` | 读写站源自己的状态文件。各站源共用一个目录，文件名只能是单个文件名，请带上站源 ID 前缀 |
| `PrepareWebMedia`、`FinishMedia` | 把网页或播放列表里取到的媒体整理成播放器可用的形式 |

## 发布

工作流 `.github/workflows/build.yml` 只能在 `main` 上手动触发，推送和 PR 不会自动运行。

1. 同时提升 `pubspec.yaml` 的版本号与构建号。
2. 在 `CHANGELOG.md` 新增同名一节（标题如 `## 1.0.1+101`），工作流会把它写入 Release 说明；未验证的改动标为开发快照。
3. 推送到 `main`，在 Actions 中手动运行 **Build app packages**。

工作流先检查版本：tag `app-v{version}`（`+` 替换为 `-`）或同名 Release 已存在时直接失败。随后四个平台各构建红果鉴、全站源版两版：

| 产物 | 内容 |
| --- | --- |
| `*-android` | 三种架构 APK，使用发布证书签名并通过指纹校验 |
| `*-windows` | Windows x64 安装包和便携 ZIP |
| `*-ios-unsigned` | arm64 iPhone 未签名 IPA |
| `*-macos` | arm64 + x86_64 通用 dmg，ad-hoc 签名、未公证 |

各平台出包任务用仓库 Secret `SOURCES_DEPLOY_KEY`（站源仓库只读 deploy key 的私钥）把站源仓库检出到 `guoapp-sources/`，再以 `--sources guoapp-sources` 构建，示例站源不会进入发布包。检查任务会对示例站源单独做编译检查。

格式、分析、测试不阻塞出包；Android、Windows、iOS、macOS 全部成功后才创建 tag 和 Release，任一平台失败就不发布，已有 Release 不会被覆盖。

Android 签名只用仓库 Secrets，两个版本各用一套：红果鉴为 `ANDROID_KEYSTORE_BASE64`、`ANDROID_KEYSTORE_PASSWORD`、`ANDROID_KEY_ALIAS`、`ANDROID_KEY_PASSWORD`，另需仓库变量 `ANDROID_CERT_SHA256`；全站源版把前缀 `ANDROID_` 换成 `ZHENGUOJIAN_`，证书变量为 `ZHENGUOJIAN_CERT_SHA256`（证书 SHA-256，冒号和大小写不限）。工作流按矩阵的 `signing` 前缀选取，缺任意一项都会失败。CI 通过环境变量把签名传给 Gradle；本机红果鉴读 `android/key.properties`，全站源版读 `android/key-all-sources.properties`（均不入库）。

全站源版的包名和显示名取环境变量（CI 取同名仓库变量），没设或为空时用默认值；红果鉴固定为 `com.guoapp.phoenix`、`红果鉴`、`HongGuoJian`：

| 变量 | 默认值 | 读取位置 |
| --- | --- | --- |
| `ZHENGUOJIAN_PACKAGE_NAME` | `com.guoapp.all` | Android `build.gradle.kts`、Windows `app_branding.cmake`、iOS / macOS `scripts/app_build.py` |
| `ZHENGUOJIAN_DISPLAY_NAME` | `真果鉴` | 由 `scripts/app_build.py` 作为 `--dart-define` 传入，Dart `appName`、Android `build.gradle.kts`、iOS「Thin Binary」构建阶段读取；Windows `app_branding.cmake` 直接读环境变量；macOS 由 `package_release.py` 写入 |
| `ZHENGUOJIAN_LATIN_NAME` | `ZhenGuoJian` | iOS「Thin Binary」构建阶段，作为英文 `CFBundleDisplayName` |

Windows 数据目录为 `%APPDATA%\<包名>`：`Runner.rc` 不设 CompanyName，ProductName 为包名，`path_provider` 据此拼出应用支持目录，两个版本数据互不共用。旧版数据在 `%APPDATA%\真果鉴\真果鉴`，`lib/windows_data_migration.dart` 在启动最早阶段检查：新目录为空且旧目录存在时整个改名移入，先启动的版本拿到旧数据；新目录已有内容或移动失败都不处理，失败写入日志。Android TV 横幅 `tv_banner_all_sources.png` 只有图标不带文字，改名不用重新生成。

关于页的重建版 GitHub、Telegram 交流群组和更新频道链接分别取环境变量 `PROJECT_URL`、`TELEGRAM_GROUP_URL`、`TELEGRAM_CHANNEL_URL`（CI 取同名仓库变量），由 `scripts/app_build.py` 作为 `--dart-define` 传给 Flutter；没设的链接在关于页不显示，直接 `flutter run` 时需自行加 `--dart-define`。`PROJECT_URL` 同时注入 Go 的 `nativeProjectURL`，检查更新只接受 `{PROJECT_URL}/releases/` 开头的发布页，没设时不提示更新。

## 检查更新与使用统计

接收端是 Cloudflare Worker `guoapp-update`（`worker/`，D1 数据库 `guoapp-stats`），地址在编译期由环境变量 `UPDATE_SERVER_URL` 经 `scripts/app_build.py` 注入 Go（CI 取仓库变量 `UPDATE_SERVER_URL`），没设时检查更新和使用统计都不发请求，fork 和本地构建默认不会连到这里。变量可填逗号分隔的多个地址，Go 按顺序尝试，前一个连不上或返回错误时换下一个；CI 里先填国内可直连的中转服务器，再填 Worker。Go 核心（`native/core/app_update.go`）的 `checkUpdate` 请求 `GET /v1/latest`，只读不写；`reportUsage` 请求 `POST /v1/ping`，按北京时间日期和随机编号在 `pings` 表里每天记一行。两者分别由设置里的「启动时检查更新」和「匿名使用统计」控制。各平台点「更新」都只打开发布页，应用内不下载安装包。Worker 每小时从 GitHub 读取最新 Release 写入 `meta` 表。改 Worker 后在 `worker/` 下运行 `npx wrangler deploy`。

在 `worker/` 下查询（`--remote` 查线上库）：

~~~sh
npx wrangler d1 execute guoapp-stats --remote --command "SELECT day, COUNT(*) AS users FROM pings GROUP BY day ORDER BY day DESC LIMIT 30"   # 日活
npx wrangler d1 execute guoapp-stats --remote --command "SELECT COUNT(DISTINCT id) FROM pings WHERE day >= date('now', '-30 days')"          # 近 30 天活跃
npx wrangler d1 execute guoapp-stats --remote --command "SELECT COUNT(DISTINCT id) FROM pings"                                               # 累计装机
npx wrangler d1 execute guoapp-stats --remote --command "SELECT platform, build, version, COUNT(*) FROM pings WHERE day = date('now', '+8 hours') GROUP BY 1, 2, 3 ORDER BY 4 DESC"  # 今日分布
~~~

应用显示名：Android 在 `android/app/build.gradle.kts`，Windows 在 `windows/runner/app_branding.cmake`，iOS 由 Xcode「Thin Binary」构建阶段按 `DART_DEFINES` 写入，macOS 由 `scripts/package_release.py` 打包时改 `CFBundleDisplayName` / `CFBundleName` / `CFBundleIdentifier` 后重新签名。iOS 的 `CFBundleDisplayName` 用英文名（红果鉴 `HongGuoJian`，真果鉴取 `ZHENGUOJIAN_LATIN_NAME`）以通过侧载工具的名称校验，中文名写在 `zh-Hans.lproj/InfoPlist.strings`。macOS 关闭了 App Sandbox，以便本地播放代理和自选下载目录正常工作；系统代理由 `MainFlutterWindow.swift` 的 `duanju/device` 通道读取。
