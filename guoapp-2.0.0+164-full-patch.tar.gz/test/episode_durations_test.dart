import 'package:duanju_app/episode_durations.dart';
import 'package:duanju_app/models.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fakes.dart';

List<Episode> episodes(int count, {int from = 1}) => [
  for (var number = from; number < from + count; number++)
    Episode({'id': '$number', 'currentEpisode': number}, number),
];

void main() {
  final show = drama('dur', title: '剧乙');

  test('把每一集的时长加起来，按 mins/s 显示', () async {
    final repository = FakeRepository();
    for (var number = 1; number <= 25; number++) {
      repository.durationMap['$number'] = 300000; // 每集 5 分钟
    }
    final stats = EpisodeDurations(repository, show);
    addTearDown(stats.dispose);

    stats.sync(episodes(25));
    // 先显示「统计中」，拿到之后给最终数字。
    expect(stats.summary, '总时长 统计中…');
    await pumpEventQueue();

    expect(stats.known, 25);
    expect(stats.running, isFalse);
    expect(stats.summary, '总时长 125 mins 0 s');
  });

  test('一批十来集地取，不会一集一次请求', () async {
    final repository = FakeRepository();
    for (var number = 1; number <= 30; number++) {
      repository.durationMap['$number'] = 60000;
    }
    final stats = EpisodeDurations(repository, show);
    addTearDown(stats.dispose);

    stats.sync(episodes(30));
    await pumpEventQueue();

    expect(repository.durationRequests, hasLength(3));
    expect(repository.durationRequests.first, hasLength(12));
    expect(stats.summary, '总时长 30 mins 0 s');
  });

  test('同一份分集列表反复 sync 不重复统计', () async {
    final repository = FakeRepository();
    repository.durationMap['1'] = 90000;
    final stats = EpisodeDurations(repository, show);
    addTearDown(stats.dispose);

    final list = episodes(1);
    stats.sync(list);
    await pumpEventQueue();
    stats.sync(list);
    stats.sync(episodes(1));
    await pumpEventQueue();

    expect(repository.durationRequests, hasLength(1));
    expect(stats.summary, '总时长 1 mins 30 s');
  });

  test('集数更新后只补新集，总数跟着涨', () async {
    final repository = FakeRepository();
    repository.durationMap['1'] = 120000;
    repository.durationMap['2'] = 180000;
    final stats = EpisodeDurations(repository, show);
    addTearDown(stats.dispose);

    stats.sync(episodes(1));
    await pumpEventQueue();
    expect(stats.summary, '总时长 2 mins 0 s');

    stats.sync(episodes(2));
    await pumpEventQueue();

    expect(repository.durationRequests.last, ['2']);
    expect(stats.summary, '总时长 5 mins 0 s');
  });

  test('有集拿不到时长时把统计到的集数摆出来', () async {
    final repository = FakeRepository();
    repository.durationMap['1'] = 600000;
    repository.durationMap['3'] = 600000;
    final stats = EpisodeDurations(repository, show);
    addTearDown(stats.dispose);

    stats.sync(episodes(3));
    await pumpEventQueue();

    expect(stats.known, 2);
    expect(stats.summary, '总时长 20 mins 0 s（2/3 集）');
  });

  test('整批都失败就收手，不反复重试', () async {
    final repository = FakeRepository()..durationFailure = '站源暂时不可用';
    final stats = EpisodeDurations(repository, show);
    addTearDown(stats.dispose);

    stats.sync(episodes(40));
    await pumpEventQueue();

    expect(repository.durationRequests, hasLength(1));
    expect(stats.running, isFalse);
    expect(stats.summary, isNull);
  });

  test('时长按四舍五入取整到秒', () {
    expect(formatDuration(0), '0 mins 0 s');
    expect(formatDuration(65400), '1 mins 5 s');
    expect(formatDuration(3005000), '50 mins 5 s');
  });
}
