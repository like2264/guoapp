import 'package:flutter/material.dart';

import '../../local_store.dart';
import '../../models.dart';
import '../../resource_settings.dart';
import '../../resource_settings_editor.dart';
import '../widgets/group_card.dart';
import 'proxy_address_dialog.dart';
import 'settings_rows.dart';

/// 设置 › 代理 › 按站源设置（对照作者 2.0.3+115）。
///
/// 只存「和全局不一样」的站源：选回「跟随全局」就把这一项从表里删掉，
/// 所以以后改全局连接方式，没单独设过的站源会跟着一起变。
class SourceProxySettings extends StatelessWidget {
  const SourceProxySettings({
    super.key,
    required this.store,
    required this.editor,
  });
  final LocalStore store;
  final ResourceSettingsEditor editor;

  static const _modes = {
    'follow': '跟随全局',
    'auto': '自动',
    'direct': '直连',
    'manual': '手动代理',
  };

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: Listenable.merge([store, editor]),
    builder: (context, _) {
      final colors = Theme.of(context).colorScheme;
      final settings = editor.settings;
      if (settings == null) {
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Text(
              editor.error ?? '需要管理员',
              textAlign: TextAlign.center,
              style: TextStyle(color: colors.onSurfaceVariant),
            ),
          ),
        );
      }
      final sites = store.sources;
      final editable = !editor.saving;
      return ListView(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 28),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 12),
            child: Text(
              '没单独设置的站源跟随全局（当前：${_modes[settings.proxyMode] ?? '自动'}）。'
              '播放地址、封面这些公共请求始终走全局。',
              style: TextStyle(fontSize: 13, color: colors.onSurfaceVariant),
            ),
          ),
          SettingsCard(
            children: [
              for (final site in sites)
                SettingsTile(
                  title: site.name,
                  subtitle: site.description,
                  value: _label(settings.proxyBySource[site.id]),
                  enabled: editable,
                  onTap: () => _pick(context, settings, site),
                ),
            ],
          ),
        ],
      );
    },
  );

  static String _label(SourceProxy? choice) => switch (choice?.mode) {
    'auto' => '自动',
    'direct' => '直连',
    'manual' => choice!.url.isEmpty ? '手动代理（未填地址）' : '手动代理',
    _ => '跟随全局',
  };

  Future<void> _pick(
    BuildContext context,
    ResourceSettings settings,
    SourceSite site,
  ) async {
    final choice = settings.proxyBySource[site.id];
    final picked = await showOptionDialog<String>(
      context,
      title: '${site.name} · 连接方式',
      options: _modes,
      selected: choice?.mode ?? 'follow',
    );
    if (picked == null || !context.mounted) return;
    if (picked == 'follow') {
      await _save(context, settings, site.id, null);
      return;
    }
    if (picked != 'manual') {
      await _save(context, settings, site.id, SourceProxy(mode: picked));
      return;
    }
    // 已经有地址就直接沿用，免得每次改线路都要重新敲一遍。
    final address = await showProxyAddressDialog(
      context,
      initial: choice?.url ?? '',
    );
    if (address == null || !context.mounted) return;
    await _save(
      context,
      settings,
      site.id,
      SourceProxy(mode: 'manual', url: address),
    );
  }

  Future<void> _save(
    BuildContext context,
    ResourceSettings settings,
    String source,
    SourceProxy? choice,
  ) {
    final next = Map<String, SourceProxy>.from(settings.proxyBySource);
    if (choice == null) {
      next.remove(source);
    } else {
      next[source] = choice;
    }
    return saveSetting(
      context,
      () => editor.save(settings.copyWith(proxyBySource: next)),
    );
  }
}
