import 'package:flutter/material.dart';

import '../theme/glass.dart';

/// 页面顶栏。
///
/// Liquid Glass 打开时它是一块浮起来的玻璃（左右留白、四角圆掉、背景模糊），
/// 关掉时退回原来的「纯文字 + 右侧按钮」。
///
/// 2.0.0+136 起，带站源统计的顶栏改成**三行**：
///
/// ```
/// 剧果  共 4,379 部          ← 站名整行显示，不再为了给数字让位而省略
/// 新上 12 部
/// 今日更新 56 集
/// ```
///
/// 没有统计的页面（我的、追剧、模块）玻璃只包住标题本身，
/// 不再是一条占满整行、什么也没装的长玻璃。
class PageHeader extends StatelessWidget {
  const PageHeader({
    super.key,
    required this.title,
    this.subtitle = '',
    this.subtitleLines = const [],
    this.note = '',
    this.actions = const [],
    this.stretch = false,
    this.noteColor,
  });
  final String title;

  /// 紧跟标题的一行小字（不带统计的页面用）。
  final String subtitle;

  /// 站源统计，最多三行，每行一件事。
  final List<String> subtitleLines;

  /// 标题行右侧的补充说明（发现页放「共 4,379 部」）。
  final String note;

  /// 「共 N 部」的颜色。不传就用次要文字色。
  final Color? noteColor;

  /// 玻璃强制拉成长条（标题 + 数字 + 右侧按钮都装在里面）。
  ///
  /// 发现页专用：它右侧常驻三颗按钮（模糊封面 / 切换站源 / 搜索），
  /// 之前玻璃只包住标题、按钮露在玻璃外面，看着像被切掉一块。
  /// 无统计的页面（我的 / 追剧 / 模块）不能开这个 —— 那会又变成
  /// 一条只装两个字的满屏玻璃。
  final bool stretch;

  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    final glass = glassEnabled(context);
    final stats = subtitleLines.where((line) => line.isNotEmpty).toList();
    // 有统计（发现页的「共 N 部」）或者显式要求长条时，整行都是一块玻璃：
    // 标题、数字、右侧按钮全在里面。没有统计的页面（我的 / 追剧 / 模块）
    // 仍只让玻璃包住标题，按钮放在玻璃外面，不再是一条空荡荡的长玻璃。
    final wide = stretch || stats.isNotEmpty || note.isNotEmpty;
    final body = _body(context, stats, glass, withActions: wide);
    if (!glass) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 8, 0),
        child: wide ? body : Row(children: [Expanded(child: body), ...actions]),
      );
    }
    final panel = GlassPanel(
      radius: 24,
      blur: 18,
      tint: 1.05,
      // 无统计的页面左右必须一样宽，标题才在玻璃里居中。
      // 长条玻璃纵向内边距归零，高度只由 [_body] 里那个 SizedBox(height: 58)
      // 决定；这里再加 8 + 9 就等于 75，会比别的页高出一截。
      padding: wide
          ? const EdgeInsets.fromLTRB(14, 0, 8, 0)
          : const EdgeInsets.symmetric(horizontal: 18),
      child: body,
    );
    return Padding(
      // 底部 10：和下面第一张卡片留出缝。以前是 0，两条描边贴在一起，
      // 看起来像同一块玻璃被硬切成两半。
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
      child: wide
          ? panel
          // 只包住标题。IntrinsicWidth 让玻璃的宽度跟着文字走。
          : Row(
              children: [
                Flexible(
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: IntrinsicWidth(child: panel),
                  ),
                ),
                ...actions,
              ],
            ),
    );
  }

  /// 站名。`style` 允许为空 —— 它的来源是 `textTheme.headlineMedium?.copyWith()`，
  /// 主题里没配 headlineMedium 时就是 null，`Text.style` 本身也接受 null。
  Widget _titleText(TextStyle? style) {
    return FittedBox(
      fit: BoxFit.scaleDown,
      alignment: Alignment.centerLeft,
      child: Semantics(
        header: true,
        child: Text(title, maxLines: 1, softWrap: false, style: style),
      ),
    );
  }

  Widget _body(
    BuildContext context,
    List<String> lines,
    bool glass, {
    bool withActions = true,
  }) {
    final colors = Theme.of(context).colorScheme;
    final style = Theme.of(context).textTheme.headlineMedium?.copyWith(
      fontSize: glass && lines.isNotEmpty ? 24 : 28,
      fontWeight: FontWeight.w800,
    );
    final noteStyle = TextStyle(
      fontSize: 10.5,
      height: 1.2,
      fontWeight: FontWeight.w500,
      color: colors.onSurfaceVariant.withValues(alpha: 0.85),
    );

    // 站源统计贴着站名右边竖排（「共 N 部」在上、「今日更新 N 集」在下），
    // 两行共用同一个左边缘。
    //
    // +137 为了让两行左边缘对齐，把「共 N 部」挪到站名下面单起一行；但那样玻璃
    // 变成三行、站名独占一行，跟以前的样式不一样（用户要的是「数字跟在站名右边」）。
    // 现在挪回来，关键是这两行必须并进同一个 Column：只要有一行跟着标题、另一行
    // 另起，左边缘就永远差一个站名的宽度。
    final rows = <String>[
      if (note.isNotEmpty) note,
      ...lines.where((line) => line.isNotEmpty),
    ];
    final stats = rows.take(3).toList();
    // 有分行统计时就不再显示单行 subtitle：发现页把「共 N 部 · 今日更新 M 集」
    // 同时塞进 subtitle + note + subtitleLines，三份同样的字画了三遍；
    // 更要命的是它和统计行抢宽度（Row 里两个 Flexible 各占一半），
    // 标题被挤成 0 宽、图标压到数字上 —— +140 的顶栏就是这么乱的。
    final trailing = stats.isEmpty ? subtitle : '';

    Widget numbers() => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final (index, line) in stats.indexed)
          Text(
            line,
            maxLines: 1,
            softWrap: false,
            overflow: TextOverflow.clip,
            // 第一行是 note（「共 N 部」）：给它上色，扫一眼就能看到总量；
            // 下面几行仍是次要灰（发现页现在只有这一行）。
            style: index == 0 && note.isNotEmpty
                ? noteStyle.copyWith(
                    color: noteColor ?? colors.primary,
                    fontWeight: FontWeight.w700,
                  )
                : noteStyle,
          ),
      ],
    );

    // 站名 + 数字整体靠左，按钮固定贴最右。
    final title = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // 站名先按自身宽度排，真放不下才等比缩小（缩也不截断）。
        Flexible(child: _titleText(style)),
        if (stats.isNotEmpty) ...[const SizedBox(width: 9), numbers()],
      ],
    );
    final head = Row(
      // 没有按钮时让 Row 收成内容宽度：它会被 IntrinsicWidth 包住，
      // 玻璃跟着文字走；用 Expanded 撑满反而把字压到左边。
      mainAxisSize: withActions ? MainAxisSize.max : MainAxisSize.min,
      children: [
        if (withActions) Expanded(child: title) else Flexible(child: title),
        if (withActions) ...[const SizedBox(width: 4), ...actions],
      ],
    );

    // 数字是竖排的，上下各留 5 就够；没有数字时按原来的 8。
    final row = Padding(
      padding: EdgeInsets.fromLTRB(2, stats.isEmpty ? 8 : 5, 2, stats.isEmpty ? 8 : 5),
      child: trailing.isEmpty
          ? head
          : Row(
              children: [
                Flexible(child: head),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    trailing,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: noteStyle,
                  ),
                ),
              ],
            ),
    );
    // 玻璃版：
    // 所有玻璃顶栏统一回到 +135 那会儿「长条玻璃」的 58 —— 发现页也一起回去。
    // 发现页原来由内容撑高（站名 24px + 上下各 5 ≈ 44），比追剧 / 模块 / 我的
    // 矮一截，页面之间一切换高度就跳；现在三处同高，站名与右边的数字一起居中。
    // 高度不能靠上下 padding 凑：SizedBox + Center 才是真正居中，靠内边距
    // 凑会随字体行高漂 1~2px。
    if (glass) {
      return SizedBox(height: 58, child: Center(child: row));
    }
    return SizedBox(height: 64, child: Center(child: row));
  }
}
