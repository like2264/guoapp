import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:duanju_app/ui/widgets/page_header.dart';

/// 顶栏：站名 + 右边竖排两行数字 + 最右三个图标。
///
/// +140 真机上是乱的：数字跑到最左边、站名消失、图标压在数字上。
/// 根因是同一条信息被 subtitle / note / subtitleLines 传了三遍，
/// subtitle 和统计行在 Row 里各占一个 Flexible，标题被挤成 0 宽。
/// 这个用例把那几条约束钉死。
void main() {
  Widget harness({double width = 390, String subtitle = ''}) => MaterialApp(
    home: MediaQuery(
      data: MediaQueryData(size: Size(width, 844), devicePixelRatio: 3),
      child: Scaffold(
        body: PageHeader(
          title: '黄果短剧',
          subtitle: subtitle,
          note: '共 1,152 部',
          subtitleLines: const ['今日更新 28 集'],
          actions: const [
            Icon(Icons.visibility_rounded, key: ValueKey('eye')),
            Icon(Icons.public_rounded, key: ValueKey('globe')),
            Icon(Icons.search_rounded, key: ValueKey('search')),
          ],
        ),
      ),
    ),
  );

  Future<void> check(
    WidgetTester tester,
    double width, {
    String subtitle = '',
  }) async {
    await tester.pumpWidget(harness(width: width, subtitle: subtitle));
    await tester.pumpAndSettle();

    final title = tester.getRect(find.text('黄果短剧'));
    final first = tester.getRect(find.text('共 1,152 部'));
    final second = tester.getRect(find.text('今日更新 28 集'));
    final eye = tester.getRect(find.byKey(const ValueKey('eye')));

    expect(title.width, greaterThan(48), reason: '站名被挤没了（$width）');
    // 两行数字贴在站名右边、共用同一个左边缘。
    expect(first.left, greaterThan(title.right), reason: '数字跑到站名左边了（$width）');
    expect((first.left - second.left).abs(), lessThan(1.0), reason: '两行数字左边缘没对齐（$width）');
    expect(second.top, greaterThan(first.top), reason: '两行数字没有竖排（$width）');
    // 图标在数字右边，不许压上来。
    expect(eye.left, greaterThanOrEqualTo(first.right - 0.5), reason: '图标压在数字上（$width）');
    // 同一条信息只画一遍：单行版本不该再出现。
    expect(find.text('共 1,152 部 · 今日更新 28 集'), findsNothing);
  }

  testWidgets('极窄 320 不重叠', (tester) async => check(tester, 320));
  testWidgets('窄屏 360 不重叠', (tester) async => check(tester, 360));
  testWidgets('常规 390 不重叠', (tester) async => check(tester, 390));
  testWidgets('大屏 430 不重叠', (tester) async => check(tester, 430));

  // 发现页以前同时传 subtitle + note + subtitleLines（同一句话三遍），
  // 这是 +140 顶栏散架的直接原因：subtitle 抢走一半宽度，标题被挤成 0。
  testWidgets('调用方多传一份 subtitle 也不会把标题挤没', (tester) async {
    await check(
      tester,
      390,
      subtitle: '共 1,152 部 · 今日更新 28 集',
    );
  });
}
