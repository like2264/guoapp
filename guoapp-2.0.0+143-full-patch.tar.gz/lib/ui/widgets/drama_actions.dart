import 'package:flutter/material.dart';

import '../../local_store.dart';
import '../../models.dart';
import '../app_scope.dart';
import '../downloads/download_picker_page.dart';
import '../shell/app_shell.dart';
import '../theme/glass.dart';
import 'focus_ring.dart';
import 'follow_button.dart';

/// 长按作品卡片弹出的操作面板：追剧 / 下载。
///
/// 2.0.0+143 之前长按是**直接**追剧：想下载只能点进详情页再翻到「下载选集」，
/// 而长按又常常是误触——一按就追上了，还得再去追剧列表里取消。
/// 现在长按先出两块玻璃按钮，动作由用户挑。
Future<void> showDramaActions(
  BuildContext context,
  LocalStore store,
  Drama drama,
) async {
  final followed = store.isFavorite(drama.id);
  final picked = await showModalBottomSheet<String>(
    context: context,
    showDragHandle: false,
    useSafeArea: true,
    isScrollControlled: false,
    backgroundColor: Colors.transparent,
    // showModalBottomSheet 本身没有 shadowColor / surfaceTintColor，
    // 只有 BottomSheet 组件与主题里有；这里只能靠 elevation: 0 + 透明底。
    elevation: 0,
    // 不传 shape 的话主题里 BottomSheetThemeData 那圈 `side` 会照画，
    // 玻璃外面会再多一层细线框。
    shape: const RoundedRectangleBorder(),
    clipBehavior: Clip.antiAlias,
    barrierColor: Colors.black.withValues(alpha: 0.28),
    builder: (sheet) => Padding(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
      child: GlassPanel(
        radius: 26,
        blur: 12,
        tint: 1.5,
        shade: Theme.of(sheet).brightness == Brightness.dark ? 0.6 : 0,
        padding: EdgeInsets.zero,
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const _Grip(),
              _ActionRow(
                icon: followed
                    ? Icons.bookmark_remove_rounded
                    : Icons.bookmark_add_outlined,
                label: followed ? '取消追剧' : '追剧',
                onTap: () => Navigator.pop(sheet, 'follow'),
              ),
              _ActionRow(
                icon: Icons.download_rounded,
                label: '下载',
                onTap: () => Navigator.pop(sheet, 'download'),
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    ),
  );
  if (!context.mounted) return;
  switch (picked) {
    case 'follow':
      await quickFollow(context, store, drama);
    case 'download':
      await _download(context, store, drama);
  }
}

/// 先拉一次详情页（要拿选集列表），再进「下载选集」。
/// 这中间可能要等一两秒，所以给一个不可取消的转圈，别让用户以为没点到。
Future<void> _download(
  BuildContext context,
  LocalStore store,
  Drama drama,
) async {
  final repository = AppScope.of(context).repository;
  final messenger = ScaffoldMessenger.of(context);
  final navigator = Navigator.of(context, rootNavigator: true);
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => const _Busy(),
  );
  try {
    final detail = await repository.detail(drama);
    if (!navigator.mounted) return;
    navigator.pop();
    if (!context.mounted) return;
    await openPage<void>(
      context,
      (_) => DownloadPickerPage(store: store, detail: detail),
    );
  } catch (failure) {
    if (navigator.mounted) navigator.pop();
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text('读取选集失败：$failure')));
  }
}

class _Grip extends StatelessWidget {
  const _Grip();

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 9, bottom: 5),
    child: Container(
      width: 40,
      height: 4,
      decoration: BoxDecoration(
        color: Theme.of(
          context,
        ).colorScheme.onSurface.withValues(alpha: 0.22),
        borderRadius: BorderRadius.circular(2),
      ),
    ),
  );
}

class _ActionRow extends StatelessWidget {
  const _ActionRow({
    required this.icon,
    required this.label,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return FocusRing(
      radius: 18,
      child: InkWell(
        key: ValueKey('drama-action-$label'),
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
          child: Row(
            children: [
              Icon(icon, size: 22, color: colors.onSurfaceVariant),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  label,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Busy extends StatelessWidget {
  const _Busy();

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: false,
    child: Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: GlassPanel(
        radius: 22,
        blur: 14,
        tint: 1.5,
        shade: Theme.of(context).brightness == Brightness.dark ? 0.6 : 0,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox.square(
              dimension: 20,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            ),
            const SizedBox(width: 14),
            Text(
              '正在读取选集…',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    ),
  );
}
