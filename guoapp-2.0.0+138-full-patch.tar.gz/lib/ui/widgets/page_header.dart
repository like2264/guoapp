import 'package:flutter/material.dart';

import '../theme/glass.dart';

/// 页面顶栏。
///
/// Liquid Glass 打开时它是一块浮起来的玻璃（左右留白、四角圆掉、背景模糊），
/// 关掉时退回原来的「纯文字 + 右侧按钮」。
///
/// 2.0.0+136 起，带站源统计的顶栏改成**三行**：
///
/// ```
/// 剧果  共 4,379 部          ← 站名整行显示，不再为了给数字让位而省略
/// 新上 12 部
/// 今日更新 56 集
/// ```
///
/// 没有统计的页面（我的、追剧、模块）玻璃只包住标题本身，
/// 不再是一条占满整行、什么也没装的长玻璃。
class PageHeader extends StatelessWidget {
  const PageHeader({
    super.key,
    required this.title,
    this.subtitle = '',
    this.subtitleLines = const [],
    this.note = '',
    this.actions = const [],
  });
  final String title;

  /// 紧跟标题的一行小字（不带统计的页面用）。
  final String subtitle;

  /// 站源统计，最多三行，每行一件事。
  final List<String> subtitleLines;

  /// 标题行右侧的补充说明（发现页放「共 4,379 部」）。
  final String note;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    final glass = glassEnabled(context);
    final stats = subtitleLines.where((line) => line.isNotEmpty).toList();
    // 没有统计时按钮放在玻璃外面：玻璃只包住标题，
    // 不然一条只装着「我的」两个字、却横贯整屏的长玻璃又回来了。
    final body = _body(context, stats, glass, withActions: stats.isNotEmpty);
    if (!glass) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 8, 0),
        child: stats.isEmpty
            ? Row(children: [Expanded(child: body), ...actions])
            : body,
      );
    }
    final panel = GlassPanel(
      radius: 24,
      blur: 18,
      tint: 1.05,
      // 没有统计的页面（追剧 / 模块 / 我的）：左右必须一样宽，标题才在玻璃里居中。
      // 以前是左 16 右 8，配 IntrinsicWidth 一缩，字就明显偏左。
      padding: stats.isEmpty
          ? const EdgeInsets.symmetric(horizontal: 18, vertical: 10)
          : const EdgeInsets.fromLTRB(16, 8, 8, 9),
      child: body,
    );
    return Padding(
      // 底部 10：和下面第一张卡片留出缝。以前是 0，两条描边贴在一起，
      // 看起来像同一块玻璃被硬切成两半。
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
      child: stats.isEmpty
          // 只包住标题。IntrinsicWidth 让玻璃的宽度跟着文字走，
          // 不再是一条占满整行、里面什么也没有的长玻璃。
          ? Row(
              children: [
                Flexible(
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: IntrinsicWidth(child: panel),
                  ),
                ),
                ...actions,
              ],
            )
          : panel,
    );
  }

  /// 站名。`style` 允许为空 —— 它的来源是 `textTheme.headlineMedium?.copyWith()`，
  /// 主题里没配 headlineMedium 时就是 null，`Text.style` 本身也接受 null。
  Widget _titleText(TextStyle? style) {
    return FittedBox(
      fit: BoxFit.scaleDown,
      alignment: Alignment.centerLeft,
      child: Semantics(
        header: true,
        child: Text(title, maxLines: 1, softWrap: false, style: style),
      ),
    );
  }

  Widget _body(
    BuildContext context,
    List<String> lines,
    bool glass, {
    bool withActions = true,
  }) {
    final colors = Theme.of(context).colorScheme;
    final style = Theme.of(context).textTheme.headlineMedium?.copyWith(
      fontSize: glass && lines.isNotEmpty ? 24 : 28,
      fontWeight: FontWeight.w800,
    );
    final noteStyle = TextStyle(
      fontSize: 10.5,
      height: 1.2,
      fontWeight: FontWeight.w500,
      color: colors.onSurfaceVariant.withValues(alpha: 0.85),
    );

    // 站源信息这几行全部单独成行、共用同一个左边缘。
    //
    // +136/+137 把「共 N 部」当成标题行右侧的小字（`note`），跟站名挤在一行，
    // 下面那行「今日更新 N 集」又从玻璃最左边起，两行左边缘差着一个站名的宽度，
    // 看着就是歪的（用户截图）。现在只要有分行，就把它也并进这组行里。
    final rows = lines.any((line) => line.isNotEmpty)
        ? <String>[
            if (note.isNotEmpty) note,
            ...lines.where((line) => line.isNotEmpty),
          ]
        : const <String>[];
    final stacked = rows.isNotEmpty;

    // 站名占左边一整个区域，按钮固定贴最右。
    //
    // +136 把按钮紧跟在数字后面，于是三个图标浮在玻璃中间、右边空一大片
    // （用户截图里的样子）。这里用 Expanded 把标题区撑满，
    // 按钮自然被顶到右边缘，回到原来的位置。
    final head = Row(
      // 没有按钮时让 Row 收成内容宽度：它会被 IntrinsicWidth 包住，
      // 玻璃跟着文字走；用 Expanded 撑满反而把字压到左边。
      mainAxisSize: withActions ? MainAxisSize.max : MainAxisSize.min,
      children: [
        if (withActions)
          // 站名先按自身宽度排，真放不下才等比缩小（缩也不截断）。
          Expanded(child: _titleText(style))
        else
          Flexible(child: _titleText(style)),
        if (!stacked && note.isNotEmpty) ...[
          const SizedBox(width: 7),
          Flexible(
            child: Text(
              note,
              maxLines: 1,
              softWrap: false,
              overflow: TextOverflow.clip,
              style: noteStyle,
            ),
          ),
        ],
        if (withActions) ...[const SizedBox(width: 4), ...actions],
      ],
    );

    if (rows.isEmpty) {
      final row = Padding(
        padding: const EdgeInsets.fromLTRB(2, 8, 2, 8),
        child: subtitle.isEmpty
            ? head
            : Row(
                children: [
                  Flexible(child: head),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: noteStyle,
                    ),
                  ),
                ],
              ),
      );
      return glass ? row : SizedBox(height: 64, child: Center(child: row));
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 8),
          child: SizedBox(height: 34, child: head),
        ),
        for (final line in rows.take(3))
          Padding(
            padding: const EdgeInsets.only(top: 1),
            child: Text(
              line,
              maxLines: 1,
              softWrap: false,
              style: noteStyle,
            ),
          ),
      ],
    );
  }
}
