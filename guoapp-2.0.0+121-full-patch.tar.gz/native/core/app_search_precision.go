package core

import (
	"sort"
	"strings"
)

// 精准搜索：站源的搜索接口是「标题/简介/标签里出现过就算命中」的宽匹配，
// 搜「总裁」会带出大量只在简介里提一句、甚至只是同字不同词的剧。
//
// 这里在搜索出口统一做一次相关度分级并按分数重排：
//
//	标题完全相同 > 标题以关键词开头 > 标题包含关键词 >
//	标题拆词全命中 > 标题命中任一词 > 标签/分类命中 > 仅简介命中
//
// 分级为「完全不命中」（标题、标签、分类、简介里都找不到关键词的任何一个词）
// 的条目直接丢弃——用户明确要求「与搜索词完全无关的作品不要显示」。
// 其余条目一条不少地保留，只调整先后；同分保持站源原本的顺序。
//
// 两条保护：
//  1. 关键词为空，或整页一条都没命中时不丢任何条目。整页零命中说明分级判断
//     在这里失灵了（繁体/异体/别名等），此时宁可原样返回，也不能让用户
//     看到「一片空白」却怪到站源头上。
//  2. 调用方（nativeCatalog）不因过滤后变空就把 hasMore 关掉——站点在第 5 页
//     才给出相关作品的场景必须继续往后翻。
type searchRelevance int

const (
	searchRelevanceNone searchRelevance = iota
	searchRelevanceIntro
	searchRelevanceMeta
	searchRelevanceLoose
	searchRelevanceFuzzy
	searchRelevanceContains
	searchRelevancePrefix
	searchRelevanceExact
)

type scoredDrama struct {
	drama LibraryDrama
	score searchRelevance
	order int
}

// NativePreciseSearch 丢弃完全无关的条目，其余按相关度重排。
func NativePreciseSearch(items []LibraryDrama, query string) []LibraryDrama {
	scored := nativeScoredSearch(items, query)
	if len(scored) == 0 {
		return items
	}
	matched := 0
	for _, entry := range scored {
		if entry.score != searchRelevanceNone {
			matched++
		}
	}
	// 整页零命中：分级在这里失效了，原样返回，不制造「搜不到」。
	if matched == 0 {
		return items
	}
	out := make([]LibraryDrama, 0, matched)
	for _, entry := range scored {
		if entry.score == searchRelevanceNone {
			continue
		}
		out = append(out, entry.drama)
	}
	return out
}

// NativePreciseSearchStrict 与 NativePreciseSearch 同样按相关度重排，
// 但整页零命中时返回空（不保留整页）。
//
// 搜索出口用这个：站点的搜索接口是宽匹配，搜「总裁」会带出大量只在简介里
// 提一句、甚至完全无关的剧；这种整页一条都对不上关键词的页，原样返回就是
// 把无关作品直接塞给用户。调用方拿到空页后会继续往后翻，直到找到真正
// 相关的内容或站点到底，所以不会漏掉「后面几页才出现」的相关作品。
func NativePreciseSearchStrict(items []LibraryDrama, query string) []LibraryDrama {
	scored := nativeScoredSearch(items, query)
	if len(scored) == 0 {
		return nil
	}
	out := make([]LibraryDrama, 0, len(scored))
	for _, entry := range scored {
		if entry.score == searchRelevanceNone {
			continue
		}
		out = append(out, entry.drama)
	}
	if len(out) == 0 {
		return nil
	}
	return out
}

// nativeScoredSearch 返回按相关度排好序（分数高在前）的全部条目。
// 完全对不上关键词的条目分数为 0，排在最后，由调用方决定是否丢弃。
func nativeScoredSearch(items []LibraryDrama, query string) []scoredDrama {
	keyword := NativeSearchText(query)
	if keyword == "" || len(items) == 0 {
		return nil
	}
	words := nativeSearchWords(query)
	scored := make([]scoredDrama, 0, len(items))
	for index, item := range items {
		scored = append(scored, scoredDrama{
			drama: item,
			score: nativeDramaRelevance(item, keyword, words),
			order: index,
		})
	}
	sort.SliceStable(scored, func(i, j int) bool {
		if scored[i].score != scored[j].score {
			return scored[i].score > scored[j].score
		}
		return scored[i].order < scored[j].order
	})
	return scored
}

// NativeMergeSearch 把多个站源的结果按同一套相关度合并成一页。
// 全站搜索用它排序：先比相关度，再比站源顺序，最后保持各站源原本的先后。
// 每个站源同样严格丢弃完全无关的条目——某个站源的宽匹配把整页无关作品
// 带回来时，这一页整体不参与合并，不能因为「它是某个站源」就放行。
func NativeMergeSearch(groups [][]LibraryDrama, query string) []LibraryDrama {
	total := 0
	for _, group := range groups {
		total += len(group)
	}
	if total == 0 {
		return nil
	}
	type ranked struct {
		drama LibraryDrama
		score searchRelevance
		group int
		order int
	}
	rows := make([]ranked, 0, total)
	for group, items := range groups {
		scored := nativeScoredSearch(items, query)
		if scored == nil {
			for index, item := range items {
				rows = append(rows, ranked{drama: item, score: searchRelevanceNone, group: group, order: index})
			}
			continue
		}
		for _, entry := range scored {
			// 完全无关的条目一律丢弃，不再按站源整页保留。
			if entry.score == searchRelevanceNone {
				continue
			}
			rows = append(rows, ranked{drama: entry.drama, score: entry.score, group: group, order: entry.order})
		}
	}
	sort.SliceStable(rows, func(i, j int) bool {
		if rows[i].score != rows[j].score {
			return rows[i].score > rows[j].score
		}
		if rows[i].group != rows[j].group {
			return rows[i].group < rows[j].group
		}
		return rows[i].order < rows[j].order
	})
	out := make([]LibraryDrama, 0, len(rows))
	seen := map[string]bool{}
	for _, row := range rows {
		if row.drama.ID != "" && seen[row.drama.ID] {
			continue
		}
		seen[row.drama.ID] = true
		out = append(out, row.drama)
	}
	return out
}

func nativeSearchWords(query string) []string {
	raw := strings.FieldsFunc(query, func(r rune) bool {
		return r == ' ' || r == '\t' || r == '\n' || r == '\r' || r == '　'
	})
	words := make([]string, 0, len(raw))
	seen := map[string]bool{}
	for _, word := range raw {
		word = NativeSearchText(word)
		if word == "" || seen[word] {
			continue
		}
		seen[word] = true
		words = append(words, word)
	}
	return words
}

func nativeDramaRelevance(item LibraryDrama, keyword string, words []string) searchRelevance {
	title := NativeSearchText(item.Title)
	if title != "" {
		switch {
		case title == keyword:
			return searchRelevanceExact
		case strings.HasPrefix(title, keyword):
			return searchRelevancePrefix
		case strings.Contains(title, keyword):
			return searchRelevanceContains
		}
		if len(words) > 1 && nativeContainsAll(title, words) {
			return searchRelevanceFuzzy
		}
		// 任一拆词出现在标题里就算相关，单字词（搜「女」「婚」）同样成立：
		// 这里宁可多留，也不能把用户真正想看的条目当无关丢掉。
		for _, word := range words {
			if word != "" && strings.Contains(title, word) {
				return searchRelevanceLoose
			}
		}
	}
	for _, value := range append([]string{item.Category}, item.Tags...) {
		value = NativeSearchText(value)
		if value == "" {
			continue
		}
		if strings.Contains(value, keyword) {
			return searchRelevanceMeta
		}
		for _, word := range words {
			if word != "" && strings.Contains(value, word) {
				return searchRelevanceMeta
			}
		}
	}
	description := NativeSearchText(item.Description)
	if strings.Contains(description, keyword) {
		return searchRelevanceIntro
	}
	for _, word := range words {
		if word != "" && strings.Contains(description, word) {
			return searchRelevanceIntro
		}
	}
	return searchRelevanceNone
}

func nativeContainsAll(text string, words []string) bool {
	for _, word := range words {
		if !strings.Contains(text, word) {
			return false
		}
	}
	return true
}
