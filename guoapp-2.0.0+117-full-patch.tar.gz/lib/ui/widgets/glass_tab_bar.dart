import 'dart:ui';

import 'package:flutter/material.dart';

/// iOS 26 那种浮动玻璃标签栏：整条是半透明胶囊、背景做高斯模糊，
/// 选中项在条内再浮起一层更亮的胶囊（高光边 + 主题色投影），
/// 图标与文字跟随主题色，其余项保持低对比度。
class GlassTabBar extends StatelessWidget {
  const GlassTabBar({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
    required this.destinations,
    this.onSwipe,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final List<GlassTabDestination> destinations;

  /// 在底栏上左右滑时回调：-1 = 上一栏，+1 = 下一栏。
  /// 手势只挂在底栏这一条上，页面本身不响应横滑。
  final ValueChanged<int>? onSwipe;

  /// 胶囊本体高度（不含底部安全区）。
  static const barHeight = 62.0;

  /// 底栏上下的留白。内容要躲开底栏时，用 [reservedHeight]。
  static const horizontalInset = 14.0;
  static const bottomGap = 10.0;

  /// 底栏实际占用的总高度（胶囊 + 上下留白 + 安全区）。
  /// 页面底部留白按它算，内容就不会被浮起来的玻璃条盖住。
  static double reservedHeight(BuildContext context) =>
      barHeight +
      bottomGap +
      MediaQuery.viewPaddingOf(context).bottom +
      8;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors = Theme.of(context).colorScheme;
    final inset = MediaQuery.viewPaddingOf(context).bottom;
    final bar = Padding(
      padding: EdgeInsets.fromLTRB(
        horizontalInset,
        0,
        horizontalInset,
        bottomGap + inset,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(34),
        child: BackdropFilter(
          // 只做「很轻的一层磨砂」：sigma 3 基本还能认出后面的字，
          // 再高就把封面和文字糊成一整块灰，看着像实心条压在上面。
          filter: ImageFilter.blur(
            sigmaX: 3,
            sigmaY: 3,
            tileMode: TileMode.clamp,
          ),
          child: Container(
            height: barHeight,
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(34),
              // 深色主题用「压暗」而不是「提亮」：一层薄黑膜既保证白色图标看得清，
              // 又不会把底下的画面洗成灰白色。浅色主题反过来用薄白膜。
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: dark
                    ? [
                        Colors.black.withValues(alpha: 0.24),
                        Colors.black.withValues(alpha: 0.12),
                      ]
                    : [
                        Colors.white.withValues(alpha: 0.30),
                        Colors.white.withValues(alpha: 0.16),
                      ],
              ),
              border: Border.all(
                color: dark
                    ? Colors.white.withValues(alpha: 0.12)
                    : Colors.white.withValues(alpha: 0.42),
              ),
            ),
            child: Row(
              children: [
                for (var index = 0; index < destinations.length; index++)
                  Expanded(child: _item(context, index, dark, colors)),
              ],
            ),
          ),
        ),
      ),
    );
    final swipe = onSwipe;
    if (swipe == null) return bar;
    return _SwipeDetector(onSwipe: swipe, child: bar);
  }

  Widget _item(
    BuildContext context,
    int index,
    bool dark,
    ColorScheme colors,
  ) {
    final destination = destinations[index];
    final selected = index == selectedIndex;
    final idle = dark
        ? Colors.white.withValues(alpha: 0.80)
        : Colors.black.withValues(alpha: 0.60);
    return Semantics(
      button: true,
      selected: selected,
      label: destination.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => onSelected(index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 240),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            color: selected
                ? (dark
                      ? Colors.white.withValues(alpha: 0.15)
                      : Colors.white.withValues(alpha: 0.55))
                : Colors.transparent,
            border: selected
                ? Border.all(
                    color: dark
                        ? Colors.white.withValues(alpha: 0.22)
                        : Colors.white.withValues(alpha: 0.8),
                  )
                : null,
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: colors.primary.withValues(
                        alpha: dark ? 0.26 : 0.14,
                      ),
                      blurRadius: 18,
                      offset: const Offset(0, 6),
                    ),
                  ]
                : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconTheme.merge(
                data: IconThemeData(
                  size: 22,
                  color: selected ? colors.primary : idle,
                ),
                child: selected ? destination.selectedIcon : destination.icon,
              ),
              const SizedBox(height: 2),
              Text(
                destination.label,
                maxLines: 1,
                overflow: TextOverflow.fade,
                softWrap: false,
                style: TextStyle(
                  fontSize: 11,
                  height: 1.1,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  color: selected ? colors.primary : idle,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GlassTabDestination {
  const GlassTabDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
  });

  final String label;
  final Widget icon;
  final Widget selectedIcon;
}

/// 底栏上的横滑识别：按「累计位移」判断，不只看松手瞬间的速度——
/// 慢慢拖一段再松手也算切换，手指划过 24 逻辑像素就够。
class _SwipeDetector extends StatefulWidget {
  const _SwipeDetector({required this.onSwipe, required this.child});

  final ValueChanged<int> onSwipe;
  final Widget child;

  @override
  State<_SwipeDetector> createState() => _SwipeDetectorState();
}

class _SwipeDetectorState extends State<_SwipeDetector> {
  double _travel = 0;

  static const _threshold = 24.0;

  @override
  Widget build(BuildContext context) => GestureDetector(
    behavior: HitTestBehavior.translucent,
    onHorizontalDragStart: (_) => _travel = 0,
    onHorizontalDragUpdate: (details) => _travel += details.delta.dx,
    onHorizontalDragEnd: (details) {
      final velocity = details.primaryVelocity ?? 0;
      final travel = _travel.abs() >= _threshold
          ? _travel
          : velocity.abs() >= 120
          ? velocity
          : 0.0;
      _travel = 0;
      if (travel == 0) return;
      widget.onSwipe(travel < 0 ? 1 : -1);
    },
    onHorizontalDragCancel: () => _travel = 0,
    child: widget.child,
  );
}
