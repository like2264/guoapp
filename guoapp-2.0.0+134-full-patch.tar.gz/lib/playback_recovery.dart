import 'models.dart';

enum PlaybackRecoveryAction { alternative, refresh, stop }

class PlaybackRecovery {
  // 站点侧分片要跨网取，拖到未缓冲位置时首片常常要几秒到十几秒；
  // 之前 3 次就收手，慢网络下会把还能救的播放直接判死（黑屏）。
  static const maxAttempts = 4;
  int _attempts = 0;
  bool _refreshed = false;

  void reset() {
    _attempts = 0;
    _refreshed = false;
  }

  /// [preferRefresh]：拖动失败时优先「重新取一次播放地址」。
  /// 站点给的播放地址带签名/时限，拖到未缓冲位置才去取新分片；这时旧地址
  /// 往往已经不能用了，换个线路也是同一个过期地址，换新地址才有救。
  PlaybackRecoveryAction next(PlaybackPlan plan, {bool preferRefresh = false}) {
    if (_attempts >= maxAttempts) {
      return PlaybackRecoveryAction.stop;
    }
    if (preferRefresh && !_refreshed) {
      _attempts++;
      _refreshed = true;
      return PlaybackRecoveryAction.refresh;
    }
    if (plan.hasAlternative) {
      _attempts++;
      return PlaybackRecoveryAction.alternative;
    }
    if (!_refreshed) {
      _attempts++;
      _refreshed = true;
      return PlaybackRecoveryAction.refresh;
    }
    return PlaybackRecoveryAction.stop;
  }
}

class PlaybackHealth {
  // 20 秒对跨网站源太紧：拖进度后首片就要 5~15 秒，还没到数据就把会话判死，
  // 于是「卡一下 → 跳下一集 / 黑屏」。
  static const stallTimeout = Duration(seconds: 40);

  // 拖动之后播放器在等分片时不会报 buffering（它自认为还在播），
  // 所以「拖完多久没进度」要单独盯：2 秒先亮加载圈，5 秒还没跳到目标位置
  // 就自动重开当前线路（作者 2.0 最新版的行为，2.0.0+128 对齐）。
  static const seekStallTimeout = Duration(seconds: 5);
  static const seekSpinnerDelay = Duration(seconds: 2);

  Duration? _position;
  DateTime? _lastProgress;

  void reset() {
    _position = null;
    _lastProgress = null;
  }

  /// 距离上一次进度变化过了多久。位置一变就归零。
  Duration idle({
    required Duration position,
    required bool playing,
    required bool foreground,
    required DateTime now,
  }) {
    if (!playing || !foreground || position != _position) {
      _position = position;
      _lastProgress = now;
      return Duration.zero;
    }
    _lastProgress ??= now;
    return now.difference(_lastProgress!);
  }

  bool stalled({
    required Duration position,
    required bool playing,
    required bool foreground,
    required DateTime now,
    Duration timeout = stallTimeout,
  }) => idle(
    position: position,
    playing: playing,
    foreground: foreground,
    now: now,
  ) >= timeout;
}
