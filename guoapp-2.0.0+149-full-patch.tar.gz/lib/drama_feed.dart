import 'package:flutter/foundation.dart';

import 'models.dart';

typedef PageLoader = Future<CatalogPage> Function(int page, bool force);

class DramaFeed extends ChangeNotifier {
  DramaFeed({required this.load, this.cached, this.cumulative = false});
  final PageLoader load;
  final Future<CatalogPage> Function()? cached;
  final bool cumulative;

  List<Drama> _items = const [];

  /// 与 [items] 一一对应：这一部在**站点列表里的原始位置**（1 起）。
  ///
  /// 跨页去重会把站点重复吐出来的卡片藏掉（夜社·海外短剧 2166 张卡里 10 张是
  /// 重复的），但序号不能跟着少 —— 一旦按去重后的下标编号，最后一张卡就是
  /// 「第 2156 部」，而站点和自己的顶栏都说 2166，用户一对账就差 10 部。
  /// 所以编号走原始位置，被藏掉的重复卡片照样占掉一个号。
  List<int> _seq = const [];

  /// 本轮已经消费掉的原始卡片数（含被去重藏掉的那些）。
  int _raw = 0;

  /// 连续几页请求直接报错（不是「空页」，是被取消 / 超时）。
  ///
  /// 翻到站点尾部时这里的请求容易被同一个 session 的新请求取消，回一句
  /// `context canceled`；失败时 [hasMore] 会保持为真，滚动监听于是不停重试，
  /// 表现就是「一直转圈然后弹 context canceled」。连错两次就收尾，别转下去。
  int _failedPages = 0;

  bool _loading = false;
  bool _loadingMore = false;
  bool _hasMore = false;
  String _error = '';
  int _next = 1;
  int _generation = 0;
  bool _disposed = false;

  /// 连续几页「空页但站点还说有下一页」。
  ///
  /// 目录拼错页（夜社的「全部」是两栏按页接的虚拟列表）或者站点尾页错位时，
  /// 会出现 hasMore 永远为真、页页返回空 —— 界面就一直转圈，转到底再吐一句
  /// 「context canceled」。连着两页空就直接收尾，当作翻到底。
  int _emptyPages = 0;

  List<Drama> get items => _items;

  /// 每张卡片在站点列表里的原始位置（1 起，与 [items] 同长）。
  /// 去重藏掉的重复卡片照样占号，所以最后一张卡的号 = 站点声明的总数。
  List<int> get ordinals => _seq;

  bool get loading => _loading;
  bool get loadingMore => _loadingMore;
  bool get hasMore => _hasMore;
  String get error => _error;
  bool get canLoadMore =>
      _hasMore && !_loading && !_loadingMore && _error.isEmpty;

  Future<void> reload({bool force = false}) async {
    final generation = ++_generation;
    _loading = true;
    _loadingMore = false;
    _failedPages = 0;
    _error = '';
    _notify();
    if (!force && cached != null) {
      try {
        final page = await cached!();
        if (generation != _generation) return;
        if (page.items.isNotEmpty) {
          _accept(page, more: false, requested: page.page);
          if (page.fresh && page.warning.isEmpty) {
            _loading = false;
            _notify();
            return;
          }
          _notify();
        }
      } catch (_) {}
    }
    await _fetch(generation, page: 1, force: force, more: false);
  }

  Future<void> loadMore() async {
    if (_loading || _loadingMore || !_hasMore) return;
    final generation = ++_generation;
    _loadingMore = true;
    _error = '';
    _notify();
    await _fetch(generation, page: _next, force: false, more: true);
  }

  void update(Drama drama) {
    if (!_items.any((item) => item.id == drama.id)) return;
    _items = [
      for (final item in _items) item.id == drama.id ? item.merge(drama) : item,
    ];
    _notify();
  }

  Future<void> _fetch(
    int generation, {
    required int page,
    required bool force,
    required bool more,
  }) async {
    try {
      final result = await load(page, force);
      if (generation != _generation) return;
      _accept(result, more: more, requested: page);
    } catch (error) {
      if (generation != _generation) return;
      _error = _describe(error);
      // 请求被取消 / 超时（翻到尾部时同一个 session 的新请求会取消旧的）：
      // 这种错误不会让 hasMore 变假，滚动监听就会一直重试，界面上就是永远转圈
      // 加一句 `context canceled`。连错两次直接收尾。
      if (more) {
        _failedPages++;
        if (_failedPages >= 2) _hasMore = false;
      }
    }
    _loading = _loadingMore = false;
    _notify();
  }

  /// 把原生抛上来的英文错误翻成能给人看的一句话。
  static String _describe(Object error) {
    final text = error.toString();
    if (text.contains('context canceled')) return '翻页超时，稍后再试';
    if (text.contains('context deadline exceeded')) return '翻页超时，稍后再试';
    return text;
  }

  void _accept(CatalogPage page, {required bool more, required int requested}) {
    if (cumulative || !more) {
      _items = page.items;
      _seq = [for (var index = 0; index < page.items.length; index++) index + 1];
      _raw = page.items.length;
    } else {
      final known = {for (final item in _items) item.id};
      final items = <Drama>[..._items];
      final seq = <int>[..._seq];
      for (var index = 0; index < page.items.length; index++) {
        final item = page.items[index];
        // 位置照算（含重复卡片），这样最后一张卡的号仍然等于站点声明的总数。
        final position = _raw + index + 1;
        if (!known.add(item.id)) continue;
        items.add(item);
        seq.add(position);
      }
      _raw += page.items.length;
      _items = items;
      _seq = seq;
    }
    final failed = page.warning.isNotEmpty;
    _failedPages = 0;
    _emptyPages = more && page.items.isEmpty ? _emptyPages + 1 : 0;
    _next = failed ? requested : page.page + 1;
    _hasMore = (page.hasMore || failed) && _emptyPages < 2;
    _error = page.warning;
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _generation++;
    super.dispose();
  }
}
