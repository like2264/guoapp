import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:duanju_app/drama_feed.dart';
import 'package:duanju_app/models.dart';
import 'package:duanju_app/source_stats.dart';
import 'package:duanju_app/ui/widgets/drama_grid.dart';

/// 部数口径：顶栏、列表底部、最后一张卡片的序号，三者必须是同一个数，而且
/// 要等于站点自己声明的那个数。
///
/// 历史上翻过两次车：
/// - 顶栏报站点声明、底部报实际条数，差几十上百部（+143 之前）；
/// - 反过来一律用「翻到底实测值」，可列表在跨页按 id 去重，站点分页本身会重复
///   吐同一部作品 —— 夜社海外短剧 2166 张卡去重后剩 2156，黑桃 1536 剩 1528，
///   于是 App 的数和站点永远差几部到十几部（+149 改成以站点声明为准）。
void main() {
  test('站点声明优先，实测值只在站点给不出总量时兜底', () {
    const facts = SourceFacts(site: 2056, listed: 1951, probed: true);
    expect(facts.total, 2056, reason: '去重后的实测值比站点少，不能被它顶掉');
    expect(facts.headline, '共 2,056 部');
  });

  test('还没滚到底（没有实测值）就用站点声明', () {
    const facts = SourceFacts(site: 2056, probed: true);
    expect(facts.total, 2056);
    expect(facts.headline, '共 2,056 部');
  });

  test('实测值比站点多也一样以站点为准', () {
    const facts = SourceFacts(site: 1900, listed: 1951, probed: true);
    expect(facts.total, 1900);
    expect(facts.headline, '共 1,900 部');
  });

  test('只有实测值（站点给不出总量）也报「共 N 部」', () {
    const facts = SourceFacts(listed: 843, probed: true);
    expect(facts.total, 843);
    expect(facts.headline, '共 843 部');
  });

  // 2.0.0+148：实测条数不落盘了。留在存储里的旧值一律不认 —— 它会永远压过
  // 站点声明，站点加了作品顶栏也不动（野果 1388/1396、黑桃 1527/1536 就是）。
  test('落盘的实测条数读出来也是 0', () {
    final raw = <String, Object?>{
      'huangtao': {
        'day': factsDay(DateTime.now()),
        'site': 2056,
        'local': 300,
        'updated': 12,
        'listed': 1951,
        'probed': true,
        'all': ['huangtao:1'],
      },
    };
    final facts = readFacts(raw, 'huangtao');
    expect(facts.listed, 0);
    expect(facts.probed, isTrue);
    expect(facts.total, 2056, reason: '顶栏必须回到站点声明');
    expect(facts.site, 2056);
    expect(facts.updated, 12);
    expect(readKnown(raw, 'huangtao'), ['huangtao:1']);
  });

  test('writeFacts 重写整行时不再写实测值，其它观测值照旧', () {
    final raw = <String, Object?>{
      'huangtao': {
        'day': factsDay(DateTime.now()),
        'site': 2056,
        'local': 300,
        'updated': 3,
        'listed': 1951,
        'probed': true,
      },
    };
    final saved = writeFacts(raw, 'huangtao', site: 2060, local: 301, gained: 2);
    final facts = readFacts(saved, 'huangtao');
    expect(facts.listed, 0);
    expect(facts.site, 2060);
    expect(facts.updated, 5);
    expect((saved['huangtao'] as Map).containsKey('listed'), isFalse);
  });

  testWidgets('底栏滚到底只报一个数字', (tester) async {
    final feed = DramaFeed(
      load: (page, force) async => CatalogPage(const [], hasMore: false),
    );
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(body: FeedFooter(feed: feed, count: 1951)),
      ),
    );
    expect(find.text('已经到底了 · 共 1,951 部'), findsOneWidget);
    expect(find.textContaining('顶栏'), findsNothing);
    feed.dispose();
  });
}
