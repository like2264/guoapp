package core

import "testing"

// 完全无关的条目丢掉，相关的按相关度重排。
// 站源是宽匹配，这里替它收一次口：搜「总裁」时只在简介里提一句的排后面，
// 标题、标签、分类、简介里一个字都对不上的直接不显示。
func TestNativePreciseSearchDropsUnrelated(t *testing.T) {
	items := []LibraryDrama{
		{ID: "a:1", Title: "都市爱情故事", Description: "总裁会很心动"},
		{ID: "a:2", Title: "霸道总裁的替身新娘", Description: "无"},
		{ID: "a:3", Title: "总裁", Description: "无"},
		{ID: "a:4", Title: "总裁在上", Description: "无"},
		{ID: "a:5", Title: "完全无关的倒霉蛋", Description: "无", Tags: []string{"总裁剧"}},
		{ID: "a:6", Title: "另一个无关剧", Description: "无"},
	}
	got := NativePreciseSearch(items, "总裁")
	want := []string{"a:3", "a:4", "a:2", "a:5", "a:1"}
	if len(got) != len(want) {
		t.Fatalf("expected %v, got %v", want, preciseIDs(got))
	}
	for index, id := range want {
		if got[index].ID != id {
			t.Fatalf("position %d: want %s, got %v", index, id, preciseIDs(got))
		}
	}
}

// 整页都对不上关键词时原样返回：分级在这里失灵了（繁体、别名等），
// 宁可全留，也不能让用户看到空白结果。
func TestNativePreciseSearchKeepsPageWhenNothingMatches(t *testing.T) {
	items := []LibraryDrama{
		{ID: "a:1", Title: "喜剧"},
		{ID: "a:2", Title: "悲剧"},
	}
	got := NativePreciseSearch(items, "完全不存在")
	if len(got) != len(items) {
		t.Fatalf("expected page kept as-is, got %d", len(got))
	}
	if got[0].ID != "a:1" || got[1].ID != "a:2" {
		t.Fatalf("expected original order kept, got %v", preciseIDs(got))
	}
}

func TestNativePreciseSearchMultiWord(t *testing.T) {
	items := []LibraryDrama{
		{ID: "a:1", Title: "总裁的契约新娘"},
		{ID: "a:2", Title: "总裁归来"},
		{ID: "a:3", Title: "无关剧"},
	}
	got := NativePreciseSearch(items, "总裁 新娘")
	// 拆词全命中的 a:1 排最前，只命中一个词的 a:2 次之，无关的 a:3 丢掉。
	want := []string{"a:1", "a:2"}
	if len(got) != len(want) {
		t.Fatalf("expected %v, got %v", want, preciseIDs(got))
	}
	for index, id := range want {
		if got[index].ID != id {
			t.Fatalf("position %d: want %s, got %v", index, id, preciseIDs(got))
		}
	}
}

// 单字关键词（「女」这类）同样按字命中，不能因为只有一个字就判成无关。
func TestNativePreciseSearchSingleCharacter(t *testing.T) {
	items := []LibraryDrama{
		{ID: "a:1", Title: "女神网咖"},
		{ID: "a:2", Title: "男儿当自强"},
	}
	got := NativePreciseSearch(items, "女")
	if len(got) != 1 || got[0].ID != "a:1" {
		t.Fatalf("expected only a:1, got %v", preciseIDs(got))
	}
}

// 多站源合并：同一套相关度排序，跨站源去重，无关条目丢掉。
func TestNativeMergeSearchRanksAcrossSources(t *testing.T) {
	groups := [][]LibraryDrama{
		{{ID: "b:1", Title: "无关剧"}, {ID: "b:2", Title: "总裁的替身"}},
		{{ID: "c:1", Title: "总裁"}, {ID: "c:2", Title: "别的东西"}},
	}
	got := NativeMergeSearch(groups, "总裁")
	want := []string{"c:1", "b:2"}
	if len(got) != len(want) {
		t.Fatalf("expected %d items, got %v", len(want), preciseIDs(got))
	}
	for index, id := range want {
		if got[index].ID != id {
			t.Fatalf("position %d: want %s, got %v", index, id, preciseIDs(got))
		}
	}
}

func preciseIDs(items []LibraryDrama) []string {
	out := make([]string, 0, len(items))
	for _, item := range items {
		out = append(out, item.ID)
	}
	return out
}
