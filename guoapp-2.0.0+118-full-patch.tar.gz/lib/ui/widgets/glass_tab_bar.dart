import 'package:flutter/material.dart';

/// 浮动标签栏：背景完全透明，底下的内容原样透过来。
/// 选中项只保留一圈淡描边，靠图标/文字颜色和加粗区分。
class GlassTabBar extends StatelessWidget {
  const GlassTabBar({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
    required this.destinations,
    this.onSwipe,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final List<GlassTabDestination> destinations;

  /// 在底栏上左右滑时回调：-1 = 上一栏，+1 = 下一栏。
  /// 手势只挂在底栏这一条上，页面本身不响应横滑。
  final ValueChanged<int>? onSwipe;

  /// 胶囊本体高度（不含底部安全区）。
  static const barHeight = 62.0;

  /// 底栏上下的留白。内容要躲开底栏时，用 [reservedHeight]。
  static const horizontalInset = 14.0;
  static const bottomGap = 10.0;

  /// 底栏实际占用的总高度（胶囊 + 上下留白 + 安全区）。
  /// 页面底部留白按它算，内容就不会被浮起来的玻璃条盖住。
  static double reservedHeight(BuildContext context) =>
      barHeight +
      bottomGap +
      MediaQuery.viewPaddingOf(context).bottom +
      8;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors = Theme.of(context).colorScheme;
    final inset = MediaQuery.viewPaddingOf(context).bottom;
    // 要的就是「完全透明」：不铺色、不模糊、不描边，底下的文字和封面
    // 原样透过来。选中态只留一圈很淡的描边，靠图标/文字颜色和加粗区分。
    final bar = Padding(
      padding: EdgeInsets.fromLTRB(
        horizontalInset,
        0,
        horizontalInset,
        bottomGap + inset,
      ),
      child: SizedBox(
        height: barHeight,
        child: Row(
          children: [
            for (var index = 0; index < destinations.length; index++)
              Expanded(child: _item(context, index, dark, colors)),
          ],
        ),
      ),
    );
    final swipe = onSwipe;
    if (swipe == null) return bar;
    return _SwipeDetector(onSwipe: swipe, child: bar);
  }

  Widget _item(
    BuildContext context,
    int index,
    bool dark,
    ColorScheme colors,
  ) {
    final destination = destinations[index];
    final selected = index == selectedIndex;
    final idle = dark
        ? Colors.white.withValues(alpha: 0.92)
        : Colors.black.withValues(alpha: 0.78);
    // 背景全透明后，内容可能很亮也可能很暗，给字加一圈很轻的影子保证可读。
    final legibility = <Shadow>[
      Shadow(
        offset: const Offset(0, 1),
        blurRadius: 2,
        color: dark
            ? Colors.black.withValues(alpha: 0.65)
            : Colors.white.withValues(alpha: 0.85),
      ),
    ];
    return Semantics(
      button: true,
      selected: selected,
      label: destination.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => onSelected(index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 240),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            color: Colors.transparent,
            border: selected
                ? Border.all(
                    color: dark
                        ? Colors.white.withValues(alpha: 0.30)
                        : colors.primary.withValues(alpha: 0.30),
                  )
                : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconTheme.merge(
                data: IconThemeData(
                  size: 22,
                  color: selected ? colors.primary : idle,
                ),
                child: selected ? destination.selectedIcon : destination.icon,
              ),
              const SizedBox(height: 2),
              Text(
                destination.label,
                maxLines: 1,
                overflow: TextOverflow.fade,
                softWrap: false,
                style: TextStyle(
                  fontSize: 11,
                  height: 1.1,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  color: selected ? colors.primary : idle,
                  shadows: legibility,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GlassTabDestination {
  const GlassTabDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
  });

  final String label;
  final Widget icon;
  final Widget selectedIcon;
}

/// 底栏上的横滑识别：指针横移越过 22 逻辑像素就立刻切一栏。
/// 用 Listener 直接读指针事件，不依赖手势竞技场，慢拖快划都能触发。
class _SwipeDetector extends StatefulWidget {
  const _SwipeDetector({required this.onSwipe, required this.child});

  final ValueChanged<int> onSwipe;
  final Widget child;

  @override
  State<_SwipeDetector> createState() => _SwipeDetectorState();
}

class _SwipeDetectorState extends State<_SwipeDetector> {
  int? _pointer;
  double _startX = 0;
  bool _fired = false;

  static const _threshold = 22.0;

  @override
  Widget build(BuildContext context) => Listener(
    // opaque 保证空白区域也收得到指针事件；Listener 不参与手势竞技场，
    // 子项的 onTap 照常工作。
    behavior: HitTestBehavior.opaque,
    onPointerDown: (event) {
      if (_pointer != null) return;
      _pointer = event.pointer;
      _startX = event.localPosition.dx;
      _fired = false;
    },
    onPointerMove: (event) {
      if (event.pointer != _pointer || _fired) return;
      final dx = event.localPosition.dx - _startX;
      if (dx.abs() < _threshold) return;
      _fired = true;
      widget.onSwipe(dx < 0 ? 1 : -1);
    },
    onPointerUp: (event) {
      if (event.pointer == _pointer) _pointer = null;
    },
    onPointerCancel: (event) {
      if (event.pointer == _pointer) _pointer = null;
    },
    child: widget.child,
  );
}
