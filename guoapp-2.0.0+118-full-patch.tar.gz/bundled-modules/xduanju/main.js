// X短剧（x-duanju.com）：SSR 列表页 + 详情页 JSON-LD。
//
// 列表：/zuixin、/zuixin/{n}、/fenlei/{slug}、/wanjie，卡片是 <li class="card">。
// 搜索：/sousuo?q=，单页结果（没有翻页）。
// 详情：/ju/{slug}，分集是 <li data-n="N"><a href="/ju/{slug}/{n}">，
//       ld+json 里 @type=TVSeries 给标题/简介/封面/标签/上线日期。
// 播放：分集页里 <div class="player" data-src="/bf/{id}/master.m3u8">。

var SITE = "https://x-duanju.com";
var UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
var CHANNEL = "X短剧";
var DONE_CATEGORY = "wanjie";
var MAX_PAGE = 10000;
var MAX_EPISODES = 2000;

var RE_CARD = /<li class="card"[^>]*>\s*<a href="\/ju\/([a-z0-9-]+)"[^>]*>([\s\S]*?)<\/li>/gi;
var RE_CARD_COVER = /<img[^>]+src="([^"]+)"/i;
var RE_CARD_ALT = /<img[^>]+alt="([^"]*)">/i;
var RE_CARD_ALT2 = /<img[^>]+alt="([^"]*)"/i;
var RE_CARD_NAME = /<span class="name">([\s\S]*?)<\/span>/i;
var RE_CARD_REMARK = /<em class="eps">([\s\S]*?)<\/em>/i;
var RE_TAGS = /<[^>]+>/g;
var RE_TILE = /<a class="fl-tile" href="\/fenlei\/([a-z0-9-]+)"[^>]*>([\s\S]*?)<\/a>/gi;
var RE_TILE_NAME = /<span class="fl-name">([\s\S]*?)<\/span>/i;
var RE_LDJSON = /<script[^>]+application\/ld\+json[^>]*>([\s\S]*?)<\/script>/gi;
var RE_SYNOPSIS = /<div class="jd-desc"[^>]*>\s*<p>([\s\S]*?)<\/p>/i;
var RE_EPISODE = /<li data-n="(\d+)"[^>]*>\s*<a href="\/ju\/([a-z0-9-]+)\/(\d+)"([^>]*)>/gi;
var RE_TITLE_ATTR = /title="([^"]*)"/i;
var RE_PLAYER = /<div[^>]*class="[^"]*\bplayer\b[^"]*"[^>]*data-src="([^"]+)"/i;
var RE_PLAYER_NUM = /<div[^>]*class="[^"]*\bplayer\b[^"]*"[^>]*data-n="(\d+)"/i;
var RE_ES_TITLE = /<h1[^>]*class="[^"]*\bes-title\b[^"]*"[^>]*>([\s\S]*?)<\/h1>/i;
var RE_OG_TITLE = /<meta[^>]+property="og:title"[^>]+content="([^"]*)"/i;
var RE_OG_DESC = /<meta[^>]+property="og:description"[^>]+content="([^"]*)"/i;
var RE_OG_IMAGE = /<meta[^>]+property="og:image"[^>]+content="([^"]*)"/i;
var RE_COVER_ANY = /<img[^>]+src="(\/tu\/[^"]+)"/i;
var RE_SLUG = /^[a-z0-9][a-z0-9-]{0,79}$/;
var RE_EMPTY = /class="ss-empty"/;
var RE_SPACES = /\s+/g;

function unescapeHtml(text) {
  return String(text)
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&#(\d+);/g, function (_, code) {
      return String.fromCharCode(parseInt(code, 10));
    });
}

function clean(text) {
  if (text === null || text === undefined) return "";
  var raw = unescapeHtml(String(text).replace(RE_TAGS, " "));
  raw = raw.replace(/\u3000/g, " ");
  return raw.replace(RE_SPACES, " ").replace(/^\s+|\s+$/g, "");
}

function clip(text, limit) {
  var value = String(text === null || text === undefined ? "" : text);
  return value.length > limit ? value.slice(0, limit) : value;
}

function titleOf(raw) {
  var value = clean(raw);
  var dash = value.indexOf(" - ");
  if (dash > 0) value = value.slice(0, dash).replace(/^\s+|\s+$/g, "");
  value = value.replace(/在线观看$/, "").replace(/全集$/, "");
  return clip(value.replace(/^\s+|\s+$/g, ""), 512);
}

function validSlug(slug) {
  return RE_SLUG.test(String(slug || "").replace(/^\s+|\s+$/g, ""));
}

function absUrl(raw) {
  var value = String(raw || "").replace(/^\s+|\s+$/g, "");
  if (value === "") return "";
  if (value.indexOf("//") === 0) {
    value = "https:" + value;
  } else if (value.charAt(0) === "/") {
    value = SITE + value;
  }
  if (!/^https?:\/\//i.test(value)) return "";
  return value;
}

function textGet(path) {
  var address = path.indexOf("http") === 0 ? path : SITE + path;
  var response = host.fetchText({ url: address, referer: SITE + "/", userAgent: UA });
  return response && response.body ? response.body : "";
}

function asNumber(value, fallback) {
  var parsed = parseInt(String(value), 10);
  return isNaN(parsed) ? fallback : parsed;
}

function makeDrama(sourceId, title, cover, extra) {
  var drama = {
    id: host.dramaId(sourceId),
    source: host.source,
    sourceId: sourceId,
    title: title,
    name: title,
    channelName: CHANNEL,
    categoryName: "短剧",
  };
  if (cover) {
    drama.cover = cover;
    drama.coverUrl = cover;
  }
  if (extra) {
    for (var key in extra) {
      if (Object.prototype.hasOwnProperty.call(extra, key) && extra[key] !== "" && extra[key] !== null) {
        drama[key] = extra[key];
      }
    }
  }
  return drama;
}

function parseCards(body) {
  var items = [];
  var seen = {};
  RE_CARD.lastIndex = 0;
  var match;
  while ((match = RE_CARD.exec(body)) !== null) {
    var slug = match[1];
    var chunk = match[2];
    if (!validSlug(slug) || seen[slug]) continue;
    var title = "";
    var nameMatch = RE_CARD_NAME.exec(chunk);
    if (nameMatch) title = clean(nameMatch[1]);
    if (title === "") {
      var altMatch = RE_CARD_ALT.exec(chunk) || RE_CARD_ALT2.exec(chunk);
      if (altMatch) title = clean(altMatch[1]);
    }
    if (title === "") continue;
    seen[slug] = true;
    var coverMatch = RE_CARD_COVER.exec(chunk);
    var cover = coverMatch ? absUrl(coverMatch[1]) : "";
    var remark = "";
    var remarkMatch = RE_CARD_REMARK.exec(chunk);
    if (remarkMatch) remark = clip(clean(remarkMatch[1]), 64);
    var drama = makeDrama(slug, clip(title, 512), cover, { remark: remark });
    if (chunk.indexOf("tag-vip") >= 0) drama.vip = true;
    items.push(drama);
    if (items.length >= 200) break;
  }
  return items;
}

function listPath(category, page) {
  var base = "/zuixin";
  if (category === DONE_CATEGORY) base = "/wanjie";
  else if (category) base = "/fenlei/" + category;
  return page > 1 ? base + "/" + page : base;
}

function hasNextPage(body, category, page) {
  var base = listPath(category, 1);
  return body.indexOf(base + "/" + (page + 1) + '"') >= 0;
}

function ldItems(body) {
  var items = [];
  RE_LDJSON.lastIndex = 0;
  var match;
  while ((match = RE_LDJSON.exec(body)) !== null) {
    try {
      var value = JSON.parse(match[1]);
      if (value && value["@type"]) items.push(value);
    } catch (error) {}
  }
  return items;
}

function ldText(value) {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") return clip(value.replace(/^\s+|\s+$/g, ""), 512);
  if (value instanceof Array) {
    for (var index = 0; index < value.length; index++) {
      var item = ldText(value[index]);
      if (item) return item;
    }
  }
  if (typeof value === "object") return ldText(value.url || value.contentUrl || value.name);
  return "";
}

function ldList(value) {
  if (value === null || value === undefined) return [];
  if (value instanceof Array) return value;
  return [value];
}

function buildChapters(body, sourceId) {
  var chapters = [];
  var seen = {};
  RE_EPISODE.lastIndex = 0;
  var match;
  while ((match = RE_EPISODE.exec(body)) !== null) {
    var number = asNumber(match[1], 0);
    if (number < 1 || number > MAX_PAGE || seen[number]) continue;
    if (match[2] !== sourceId) continue;
    seen[number] = true;
    var title = "";
    var titleMatch = RE_TITLE_ATTR.exec(match[4]);
    if (titleMatch) title = clean(titleMatch[1]);
    if (title === "") title = "第 " + number + " 集";
    chapters.push({
      id: host.chapterId(sourceId, String(number)),
      source: host.source,
      title: clip(title, 128),
      currentEpisode: number,
      videoUrl: "xduanju-play://" + number,
      pageUrl: SITE + "/ju/" + sourceId + "/" + number,
      referer: SITE + "/",
    });
  }
  chapters.sort(function (left, right) {
    return left.currentEpisode - right.currentEpisode;
  });
  return chapters;
}

function singleChapter(body, sourceId) {
  var match = RE_PLAYER.exec(body);
  if (!match) return null;
  var address = absUrl(match[1]);
  if (!/^https?:\/\//i.test(address) || !/\.(m3u8|mp4)(\?|$)/i.test(address)) {
    // 站点有的单片直接给 /bf/xxx/master.m3u8，允许无扩展名的地址
    if (!/^https?:\/\//i.test(address)) return null;
  }
  var number = 1;
  var numMatch = RE_PLAYER_NUM.exec(body);
  if (numMatch) {
    var parsed = asNumber(numMatch[1], 0);
    if (parsed > 0 && parsed <= MAX_PAGE) number = parsed;
  }
  return {
    id: host.chapterId(sourceId, String(number)),
    source: host.source,
    title: "第 " + number + " 集",
    currentEpisode: number,
    videoUrl: "xduanju-play://" + number,
    pageUrl: number > 1 ? SITE + "/ju/" + sourceId + "/" + number : SITE + "/ju/" + sourceId,
    referer: SITE + "/",
  };
}

module.exports = {
  validCategory: function (category) {
    var value = String(category || "").replace(/^\s+|\s+$/g, "");
    return value === "" || validSlug(value);
  },

  categories: function () {
    var body = textGet("/fenlei");
    var categories = [{ id: DONE_CATEGORY, name: "完结" }];
    var seen = { wanjie: true };
    var genres = 0;
    RE_TILE.lastIndex = 0;
    var match;
    while ((match = RE_TILE.exec(body)) !== null) {
      var slug = match[1];
      if (!validSlug(slug) || seen[slug]) continue;
      var name = "";
      var nameMatch = RE_TILE_NAME.exec(match[2]);
      if (nameMatch) name = clean(nameMatch[1].split("<")[0]);
      if (name === "") name = slug;
      seen[slug] = true;
      genres++;
      categories.push({ id: slug, name: clip(name, 32) });
      if (categories.length >= 96) break;
    }
    if (genres === 0 && categories.length <= 1) throw new Error("X短剧暂未返回内容分类");
    return categories;
  },

  catalogPage: function (page, category) {
    var index = asNumber(page, 0);
    if (index < 1 || index > MAX_PAGE) throw new Error("X短剧目录页码无效");
    if (!this.validCategory(category)) throw new Error("X短剧内容分类无效");
    var body = textGet(listPath(category, index));
    var items = parseCards(body);
    if (items.length === 0) return { items: [], hasMore: false };
    return { items: items, hasMore: hasNextPage(body, category, index) };
  },

  search: function (page, query) {
    var index = asNumber(page, 0);
    var keyword = String(query || "").replace(/^\s+|\s+$/g, "");
    if (keyword === "") return { items: [], hasMore: false };
    if (index < 1) throw new Error("X短剧搜索页码无效");
    if (index > 1) return { items: [], hasMore: false };
    if (keyword.length > 40) throw new Error("X短剧搜索关键词无效");
    var body = textGet("/sousuo?q=" + encodeURIComponent(keyword));
    if (RE_EMPTY.test(body)) return { items: [], hasMore: false };
    return { items: parseCards(body), hasMore: false };
  },

  detail: function (sourceId) {
    var slug = String(sourceId || "").replace(/^\s+|\s+$/g, "");
    if (!validSlug(slug)) throw new Error("X短剧剧集标识无效");
    var body = textGet("/ju/" + slug);
    var chapters = buildChapters(body, slug);
    if (chapters.length === 0) {
      var single = singleChapter(body, slug);
      if (single) chapters = [single];
    }
    if (chapters.length === 0) throw new Error("X短剧该剧暂无可播放分集");

    var series = null;
    var items = ldItems(body);
    for (var index = 0; index < items.length; index++) {
      if (items[index]["@type"] === "TVSeries") {
        series = items[index];
        break;
      }
    }
    var title = series ? clean(series.name) : "";
    if (title === "") {
      var esMatch = RE_ES_TITLE.exec(body);
      if (esMatch) title = titleOf(esMatch[1]);
    }
    if (title === "") {
      var ogMatch = RE_OG_TITLE.exec(body);
      if (ogMatch) title = titleOf(ogMatch[1]);
    }
    if (title === "") throw new Error("X短剧详情缺少剧集名称");

    var cover = series ? absUrl(ldText(series.image)) : "";
    if (cover === "") {
      var imageMatch = RE_OG_IMAGE.exec(body);
      if (imageMatch) cover = absUrl(imageMatch[1]);
    }
    if (cover === "") {
      var coverMatch = RE_COVER_ANY.exec(body);
      if (coverMatch) cover = absUrl(coverMatch[1]);
    }

    var description = "";
    var synopsisMatch = RE_SYNOPSIS.exec(body);
    if (synopsisMatch) description = clean(synopsisMatch[1]);
    if (description === "" && series) description = ldText(series.description);
    if (description === "") {
      var descMatch = RE_OG_DESC.exec(body);
      if (descMatch) description = descMatch[1];
    }
    description = clean(description);

    var tags = [];
    var seenTags = {};
    var rawTags = series ? ldList(series.genre) : [];
    for (var tagIndex = 0; tagIndex < rawTags.length; tagIndex++) {
      var tag = clip(clean(ldText(rawTags[tagIndex])), 24);
      if (tag === "" || seenTags[tag] || tags.length >= 8) continue;
      seenTags[tag] = true;
      tags.push(tag);
    }
    var onlineDate = "";
    if (series) {
      var published = String(series.datePublished || "").replace(/^\s+|\s+$/g, "");
      if (published.length >= 10) onlineDate = published.slice(0, 10);
    }

    var extra = {
      desc: clip(description, 12000),
      intro: clip(description, 12000),
      episodeCount: chapters.length,
      totalEpisode: chapters.length,
      onlineDate: onlineDate,
    };
    if (tags.length > 0) {
      extra.tags = tags;
      extra.categoryName = tags[0];
    }
    return { drama: makeDrama(slug, clip(title, 512), cover, extra), chapters: chapters };
  },

  resolveMedia: function (task) {
    var chapter = task && task.chapter ? task.chapter : {};
    var dramaId = String((task && task.dramaId) || "");
    var prefix = host.source + ":";
    var rest = dramaId.indexOf(prefix) === 0 ? dramaId.slice(prefix.length) : "";
    var sourceId = rest;
    var number = 0;
    var separator = rest.lastIndexOf(":");
    if (separator > 0) {
      sourceId = rest.slice(0, separator);
      number = asNumber(rest.slice(separator + 1), 0);
    } else if (chapter.id) {
      var chapterId = String(chapter.id);
      var cut = chapterId.lastIndexOf(":");
      if (cut > 0) number = asNumber(chapterId.slice(cut + 1), 0);
    }
    if (!validSlug(sourceId)) throw new Error("X短剧播放信息无效，请刷新详情");
    if (number < 1 || number > MAX_PAGE) throw new Error("X短剧播放分集信息无效，请刷新详情");

    var pageUrl = SITE + "/ju/" + sourceId + "/" + number;
    var body = textGet(pageUrl);
    var match = RE_PLAYER.exec(body);
    if (!match) throw new Error("X短剧该集暂无播放地址，可能需要在站点开通会员");
    var address = absUrl(match[1]);
    if (!/^https?:\/\//i.test(address)) throw new Error("X短剧播放地址无效");
    var media = host.prepareWebMedia({ url: address, referer: pageUrl }, CHANNEL);
    media.referer = pageUrl;
    return media;
  },
};
