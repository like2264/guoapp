import 'package:flutter/services.dart';

/// +181：全应用统一的震动反馈。
///
/// iOS 侧走原生 Core Haptics，能直接指定强度（系统自带的 selection/light/
/// medium 三档太轻，用户反馈「点了没感觉」）。iPhone 7/8 之前不支持
/// Core Haptics 的设备、以及尚未注册通道的测试环境，统一回落到系统
/// heavyImpact，保证任何机器上都有反馈。
class AppHaptic {
  const AppHaptic._();

  static const MethodChannel _channel = MethodChannel('duanju/haptic');

  /// 按钮、列表轻点（替代 selectionClick）。
  static Future<void> tap() => _fire(0.72);

  /// 拖动档位、开关（替代 lightImpact）。
  static Future<void> light() => _fire(0.84);

  /// 完成、确认（替代 mediumImpact）。
  static Future<void> medium() => _fire(0.93);

  /// 最强一档：整页刷新完毕。
  static Future<void> heavy() => _fire(1.0);

  static Future<void> _fire(double intensity) async {
    try {
      await _channel.invokeMethod<void>('impact', {'intensity': intensity});
      return;
    } on MissingPluginException {
      // 宿主还没注册原生通道。
    } catch (_) {
      // 原生震动失败也不能影响交互。
    }
    await HapticFeedback.heavyImpact();
  }
}
