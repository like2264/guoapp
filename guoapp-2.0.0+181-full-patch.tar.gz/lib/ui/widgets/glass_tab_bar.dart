import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../haptics.dart';

/// 浮动玻璃标签栏：半透明胶囊 + 背景磨砂 + 细高光边。
///
/// 2.0.0+167 按用户对 iBox 的对照视频彻底收敛成极简通透风：
/// - 选中 pill 比一格小、更淡、垂直居中，**不放大不溢出**；
/// - 去掉 +165/+166 的彩虹光晕、边框辉光、按住放大、水球动效；
/// - 底栏本体更淡，几乎融入背景。
///
/// 必须保留：+166 修好的 [SizedBox] 高度约束（否则布局塌陷、底栏跑到屏幕顶部）、
/// 胶囊恒宽一格跟手平移、磨砂 sigma 1.2、松手果冻回弹。
class GlassTabBar extends StatefulWidget {
  const GlassTabBar({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
    required this.destinations,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final List<GlassTabDestination> destinations;

  /// 胶囊本体高度（不含底部安全区）。2.0.0+136 从 62 撑到 70：
  /// 图标底下那行字在 62 里太挤，撑大之后更像一块真的浮起来的玻璃。
  static const barHeight = 70.0;

  /// 底栏上下的留白。内容要躲开底栏时，用 [reservedHeight]。
  static const horizontalInset = 10.0;
  static const bottomGap = 10.0;

  static const _radius = barHeight / 2;

  /// 玻璃条内边距：胶囊在这里面移动。
  static const _pad = 6.0;

  /// 底栏实际占用的总高度（胶囊 + 上下留白 + 安全区）。
  /// 页面底部留白按它算，内容就不会被浮起来的玻璃条盖住。
  static double reservedHeight(BuildContext context) =>
      barHeight + bottomGap + MediaQuery.viewPaddingOf(context).bottom + 8;

  @override
  State<GlassTabBar> createState() => _GlassTabBarState();
}

/// 外壳把底栏的**实际预留高度**发布给页面。
///
/// 为什么不各页自己算：底栏是在外壳的 Scaffold 里当 `bottomNavigationBar` 摆的，
/// 它拿到的安全区（`viewPadding.bottom`）和 tab 页面里拿到的不一定一样 ——
/// 真机上出现过页面这边是 0、底栏那边是 34，于是页面少留了整整一个安全区，
/// 「取消追剧」被底栏压掉一截（2.0.0+156 的反馈）。这里由外壳统一量一次，
/// 页面直接读，两边永远同一个数。
class ShellBottomInset extends InheritedWidget {
  const ShellBottomInset({
    super.key,
    required this.height,
    required super.child,
  });

  /// 底栏占掉的高度（非玻璃底栏时是 0）。
  final double height;

  static double? maybeOf(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<ShellBottomInset>()?.height;

  @override
  bool updateShouldNotify(ShellBottomInset oldWidget) =>
      oldWidget.height != height;
}

class _GlassTabBarState extends State<GlassTabBar> {
  /// 拖胶囊时相对「选中格左边缘」的偏移。
  double _drag = 0;
  bool _dragging = false;

  /// 按住态：iBox 里按下只是让 pill 略微加深一点点，不放大不溢出。
  bool _pressed = false;

  /// 拖动过程中已经掠过（并震动过）的格子，避免同一格反复震。
  int? _hovered;

  /// 果冻回弹：拖动结束松手时，胶囊带一点弹性地落位（+161 反馈）。
  static const _jellySnap = Duration(milliseconds: 480);
  static const _jellyCurve = Curves.elasticOut;

  /// 胶囊**恒宽一格**，拖动只跟手平移，不从起点格拉到手指位置形成横跨多格
  /// 的大椭圆（用户明确说那个像「拉面条」，不是他要的效果）。
  /// 返回 (left, width)，宽度恒为 cell；_drag 已在 [_dragUpdate] 里钳到首尾格。
  (double, double) _capsuleRect(double cell, double baseLeft) {
    final left = _dragging ? baseLeft + _drag : baseLeft;
    return (left, cell);
  }

  void _pressDown() {
    if (_pressed) return;
    setState(() => _pressed = true);
  }

  void _pressUp() {
    if (!_pressed) return;
    setState(() => _pressed = false);
  }

  void _dragStart(DragStartDetails details) {
    AppHaptic.tap();
    setState(() {
      _pressed = true;
      _dragging = true;
      _drag = 0;
      _hovered = widget.selectedIndex;
    });
  }

  void _dragUpdate(DragUpdateDetails details, double cell) {
    setState(() {
      _drag += details.delta.dx;
      // 胶囊最多移到首尾两格，再往外拖没有意义。
      final travel = cell * (widget.destinations.length - 1);
      _drag = _drag.clamp(
        -widget.selectedIndex * cell,
        travel - widget.selectedIndex * cell,
      );
      final index = widget.selectedIndex + (_drag / cell).round();
      if (index != _hovered) {
        _hovered = index;
        AppHaptic.tap();
      }
    });
  }

  void _dragEnd(double cell) {
    final index = (widget.selectedIndex + (_drag / cell).round()).clamp(
      0,
      widget.destinations.length - 1,
    );
    setState(() {
      _dragging = false;
      _pressed = false;
      _drag = 0;
      _hovered = null;
    });
    if (index != widget.selectedIndex) widget.onSelected(index);
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors = Theme.of(context).colorScheme;
    final inset = MediaQuery.viewPaddingOf(context).bottom;
    final radius = BorderRadius.circular(GlassTabBar._radius);
    return Padding(
      padding: EdgeInsets.fromLTRB(
        GlassTabBar.horizontalInset,
        0,
        GlassTabBar.horizontalInset,
        GlassTabBar.bottomGap + inset,
      ),
      // 布局塌陷病根（+165）：Stack 里全是 Positioned，没有非定位子元素撑高度。
      // 固定高度必须保留，Stack 只负责叠层。
      child: SizedBox(
        height: GlassTabBar.barHeight,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final inner = constraints.maxWidth - GlassTabBar._pad * 2;
            final cell = inner / widget.destinations.length;
            final baseLeft = GlassTabBar._pad + widget.selectedIndex * cell;
            final (capLeft, capWidth) = _capsuleRect(cell, baseLeft);

            // iBox 极简 pill：比一格略窄、明显更矮、宽高居中，不放大不溢出。
            final baseH = GlassTabBar.barHeight - GlassTabBar._pad * 2;
            final capH = baseH - 14;
            final capW = capWidth * 0.88;
            final capX = capLeft + (capWidth - capW) / 2;
            final capY = GlassTabBar._pad + (baseH - capH) / 2;
            final capRadius = capH / 2;

            return Stack(
              clipBehavior: Clip.none,
              children: [
                // 1. 磨砂底栏本体：很淡的灰白、淡阴影，无彩色光晕。
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: radius,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(
                            alpha: dark ? 0.16 : 0.06,
                          ),
                          blurRadius: 18,
                          spreadRadius: -6,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: radius,
                      child: BackdropFilter(
                        // 几乎不糊：底下的封面和标题要一眼能读出来。
                        filter: ImageFilter.blur(
                          sigmaX: 1.2,
                          sigmaY: 1.2,
                          tileMode: TileMode.clamp,
                        ),
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            borderRadius: radius,
                            // 垫一层中性灰：纯白胶囊压在亮内容上会「发飘」。
                            color: dark
                                ? Colors.white.withValues(alpha: 0.032)
                                : Colors.black.withValues(alpha: 0.058),
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: dark
                                  ? [
                                      Colors.white.withValues(alpha: 0.05),
                                      Colors.white.withValues(alpha: 0.02),
                                    ]
                                  : [
                                      Colors.white.withValues(alpha: 0.22),
                                      Colors.white.withValues(alpha: 0.12),
                                    ],
                            ),
                            border: Border.all(
                              color: dark
                                  ? Colors.white.withValues(alpha: 0.22)
                                  : Colors.white.withValues(alpha: 0.60),
                              width: 1,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                // 2. 选中 pill：淡灰白半透明、比一格小、pill 圆角、淡阴影，
                //    没有彩色光晕，不放大不溢出（iBox 对照）。
                AnimatedPositioned(
                  duration: _dragging ? Duration.zero : _jellySnap,
                  curve: _jellyCurve,
                  left: capX,
                  top: capY,
                  width: capW,
                  height: capH,
                  child: IgnorePointer(
                    child: AnimatedContainer(
                      duration: _dragging ? Duration.zero : _jellySnap,
                      curve: _jellyCurve,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(capRadius),
                        color: dark
                            ? Colors.white.withValues(alpha: 0.14)
                            : Colors.white.withValues(
                                alpha: _pressed ? 0.52 : 0.42,
                              ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(
                              alpha: dark ? 0.14 : 0.08,
                            ),
                            blurRadius: 10,
                            spreadRadius: -2,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // 3. 栏目行（点击/拖动手势 + 图标文字）。
                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.all(GlassTabBar._pad),
                    child: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTapDown: (_) => _pressDown(),
                      onTapUp: (_) => _pressUp(),
                      onTapCancel: _pressUp,
                      onHorizontalDragStart: _dragStart,
                      onHorizontalDragUpdate: (details) =>
                          _dragUpdate(details, cell),
                      onHorizontalDragEnd: (_) => _dragEnd(cell),
                      onHorizontalDragCancel: () => _dragEnd(cell),
                      child: Row(
                        children: [
                          for (
                            var index = 0;
                            index < widget.destinations.length;
                            index++
                          )
                            Expanded(
                              child: _item(context, index, dark, colors),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),

                // 4. 顶部一条细白高光：玻璃感靠它，无彩色。
                Positioned(
                  left: GlassTabBar._radius * 0.6,
                  right: GlassTabBar._radius * 0.6,
                  top: 0,
                  child: IgnorePointer(
                    child: Container(
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withValues(alpha: 0),
                            Colors.white.withValues(
                              alpha: dark ? 0.40 : 0.85,
                            ),
                            Colors.white.withValues(alpha: 0),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _item(BuildContext context, int index, bool dark, ColorScheme colors) {
    final destination = widget.destinations[index];
    final selected = index == widget.selectedIndex;
    // 每个栏目给自己的一点颜色，未选中时压淡，选中时用主色。
    final accent = destination.color ?? colors.primary;
    final idle = dark
        ? Colors.white.withValues(alpha: 0.92)
        : Colors.black.withValues(alpha: 0.78);
    // 背景很透，内容可能很亮也可能很暗，给字加一圈很轻的影子保证可读。
    final legibility = <Shadow>[
      Shadow(
        offset: const Offset(0, 1),
        blurRadius: 2,
        color: dark
            ? Colors.black.withValues(alpha: 0.65)
            : Colors.white.withValues(alpha: 0.85),
      ),
    ];
    return Semantics(
      button: true,
      selected: selected,
      label: destination.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => widget.onSelected(index),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconTheme.merge(
              data: IconThemeData(
                size: 24,
                color: selected
                    ? accent
                    : Color.alphaBlend(
                        accent.withValues(alpha: dark ? 0.55 : 0.62),
                        idle,
                      ),
              ),
              child: selected ? destination.selectedIcon : destination.icon,
            ),
            const SizedBox(height: 2),
            Text(
              destination.label,
              maxLines: 1,
              overflow: TextOverflow.fade,
              softWrap: false,
              style: TextStyle(
                fontSize: 11,
                height: 1.1,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected ? accent : idle,
                shadows: legibility,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class GlassTabDestination {
  const GlassTabDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
    this.color,
  });

  final String label;
  final Widget icon;
  final Widget selectedIcon;

  /// 这个栏目的点缀色。不填就跟着主题主色走。
  final Color? color;
}
