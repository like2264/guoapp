import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';

/// 缓存与数据清理（设置 → 存储）。
///
/// 只碰应用沙盒里自己的目录：
/// - 缓存 = 系统临时目录（封面、解码中间文件、模块下载包等）；
/// - 全部数据 = 应用支持目录里除「下载目录及其索引」以外的所有内容 + 临时目录。
///
/// +181 起删除全部数据会保留已下载视频（连同 index.json，否则重启后 App
/// 不认识这些文件）。外部下载目录（用户可能把下载指到共享存储）本来就不碰，
/// 那里由用户自己在文件管理器处理，程序删库外目录太危险。
class StorageCleanup {
  const StorageCleanup._();

  static int _bytes(Directory root) {
    if (!root.existsSync()) return 0;
    var total = 0;
    for (final entity in root.listSync(recursive: true, followLinks: false)) {
      if (entity is File) {
        try {
          total += entity.lengthSync();
        } catch (_) {}
      }
    }
    return total;
  }

  /// 缓存占用（字节）。
  static Future<int> cacheBytes() async {
    try {
      return _bytes(await getTemporaryDirectory());
    } catch (_) {
      return 0;
    }
  }

  /// 清空缓存，返回释放的字节数。
  static Future<int> clearCache() async {
    try {
      final root = await getTemporaryDirectory();
      final freed = _bytes(root);
      for (final entity in root.listSync(followLinks: false)) {
        try {
          entity.deleteSync(recursive: true);
        } catch (_) {
          // 正在被播放器占用的文件删不掉，跳过就好。
        }
      }
      return freed;
    } catch (_) {
      return 0;
    }
  }

  /// 删掉应用自己的全部数据，保留已下载的视频。调用方负责随后退出应用。
  static Future<void> eraseAll() async {
    final support = await getApplicationSupportDirectory();
    final keep = <String>{};

    // 默认下载目录在支持目录内，整棵留下（index.json + 视频文件）。
    keep.add(path.canonicalize(path.join(support.path, 'downloads')));

    // 自定义位置由这份指针文件指定；它也必须留下，否则重启后 App 会回退到
    // 默认目录，之前下载在别处的视频就「消失」了。
    final pointer = path.join(support.path, 'download-location.json');
    keep.add(path.canonicalize(pointer));
    try {
      final value = jsonDecode(File(pointer).readAsStringSync());
      final directory = value is Map ? value['directory'] : null;
      if (directory is String && directory.isNotEmpty) {
        keep.add(path.canonicalize(directory));
      }
    } catch (_) {}

    void clear(Directory directory) {
      if (!directory.existsSync()) return;
      for (final entity in directory.listSync(followLinks: false)) {
        if (keep.contains(path.canonicalize(entity.path))) continue;
        try {
          entity.deleteSync(recursive: true);
        } catch (_) {}
      }
    }

    clear(support);
    try {
      clear(await getTemporaryDirectory());
    } catch (_) {}
  }
}
