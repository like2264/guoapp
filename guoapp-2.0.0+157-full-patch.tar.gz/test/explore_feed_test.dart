import 'package:duanju_app/explore_feed.dart';
import 'package:duanju_app/local_store.dart';
import 'package:duanju_app/ranking_models.dart';
import 'package:duanju_app/source_stats.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fakes.dart';
import 'support/source_fixture.dart';

Future<ExploreFeed> _open(
  FakeRepository repository, [
  Future<void> Function(LocalStore store)? prepare,
]) async {
  final store = await openStore();
  await prepare?.call(store);
  final explore = ExploreFeed(repository, store);
  addTearDown(explore.dispose);
  await pumpEventQueue();
  return explore;
}

List<String> _titles(ExploreFeed explore) => [
  for (final item in explore.items) item.title,
];

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('hongguo opens on picks with the first one featured', () async {
    final explore = await _open(FakeRepository());
    expect(explore.source?.id, 'hongguo');
    expect(
      [for (final tab in explore.tabs) tab.id],
      [recommendTab.id, '', 'short_play'],
    );
    expect(explore.recommending, isTrue);
    expect(explore.featured?.title, '推荐剧一');
    // 2.0.0+147 起头条作品不再从列表里摘出去：它就是列表第一项，
    // 大卡片只是同一部作品的另一个入口。这样网格序号能从 1 连续排到底。
    expect(_titles(explore), ['推荐剧一', '推荐剧二', '推荐剧三']);
    expect(explore.feed!.items.length, explore.items.length);
  });

  test('「全部」分类没有头条，序号与部数一一对应', () async {
    final explore = await _open(FakeRepository());
    explore.select('');
    await pumpEventQueue();
    expect(explore.recommending, isFalse);
    expect(explore.featured, isNull);
    // 序号第 i 张就是 i（numberFrom = 1），所以最后一张 = items.length，
    // 恰好等于顶栏与底部报的那个数。
    expect(explore.items.length, explore.feed!.items.length);
  });

  test('recent watching takes the lead on the first tab only', () async {
    final explore = await _open(
      FakeRepository(),
      (store) => store.saveWatch(watching(drama('w'), episode: 4)),
    );
    expect(explore.resume?.episode, 4);
    expect(explore.featured, isNull);
    expect(_titles(explore), ['推荐剧一', '推荐剧二', '推荐剧三']);

    explore.select('short_play');
    await pumpEventQueue();
    expect(explore.resume, isNull);
    expect(_titles(explore), ['分类short_play']);
  });

  test(
    'a visited tab comes back with its list, without asking again',
    () async {
      final repository = FakeRepository();
      final explore = await _open(repository);
      final picks = explore.feed;
      final requests = repository.recommendRequests.length;

      explore.select('short_play');
      await pumpEventQueue();
      expect(_titles(explore), ['分类short_play']);

      explore.select(recommendTab.id);
      expect(explore.feed, same(picks));
      expect(_titles(explore), ['推荐剧一', '推荐剧二', '推荐剧三']);
      await pumpEventQueue();
      expect(repository.recommendRequests.length, requests);
    },
  );

  test('refresh forces the current tab only', () async {
    final repository = FakeRepository();
    final explore = await _open(repository);
    await explore.refresh();
    expect(repository.recommendRequests.last, (more: false, force: true));

    explore.select('short_play');
    await pumpEventQueue();
    await explore.refresh();
    expect(repository.catalogRequests, [
      'hongguo|short_play||1',
      'hongguo|short_play||1!',
    ]);
  });

  test('ranking boards of this source follow all, with their ranks', () async {
    final repository = FakeRepository()
      ..boardList = const [
        RankingBoard(id: 'hongguo-hot', source: 'hongguo', name: '总热播榜'),
        RankingBoard(id: 'huangdou-all', source: 'huangdou', name: '总榜'),
      ];
    final explore = await _open(repository);
    final tabs = explore.tabs;
    expect([for (final tab in tabs) tab.name], ['推荐', '全部', '总热播榜', '真人剧']);
    expect(explore.resume, isNull);

    explore.select(tabs[2].id);
    await pumpEventQueue();
    expect(explore.featured, isNull);
    expect(_titles(explore), ['hongguo-hot第1名', 'hongguo-hot第2名']);
    await explore.feed!.loadMore();
    expect(
      [for (final item in explore.items) explore.rankOf(item)],
      [1, 2, 3, 4],
    );
    await explore.refresh();
    expect(repository.rankingRequests, [
      'hongguo-hot|1',
      'hongguo-hot|2',
      'hongguo-hot|1!',
    ]);

    explore.select('short_play');
    await pumpEventQueue();
    expect(explore.rankOf(explore.items.single), isNull);
  });

  test('turning the source off moves on, then back when it returns', () async {
    late LocalStore store;
    final explore = await _open(FakeRepository(), (value) async {
      store = value;
    });
    await store.setSourceEnabled('hongguo', false);
    await pumpEventQueue();
    expect(explore.source?.id, allSourcesEnabled ? 'hanxiaoquan' : null);
    expect(explore.feed == null, !allSourcesEnabled);

    await store.setSourceEnabled('hongguo', true);
    await pumpEventQueue();
    expect(explore.source?.id, 'hongguo');
    expect(explore.featured?.title, '推荐剧一');
  });

  test('loaded and updated dramas refresh saved records', () async {
    final repository = FakeRepository();
    late LocalStore store;
    final explore = await _open(repository, (value) async {
      store = value;
      await store.toggleFavorite(drama('r1', title: '旧名'));
    });
    expect(store.favorites.single.title, '推荐剧一');

    repository.catalogUpdates.publish(drama('r2', title: '新名'));
    await pumpEventQueue();
    expect(_titles(explore), ['推荐剧一', '新名', '推荐剧三']);
  });

  // 2.0.0+150 的三数规矩：顶栏 = 底部 = 末位卡片。站点声明只当「还没翻到底」
  // 时的预期值，一旦真的翻到底，一律报列表实际摆出来的独立作品数。
  test('翻到底后顶栏、底部、末位卡片是同一个数', () async {
    // 站点声明 3 部，但目录一页就到底、只给 1 部（catalogHasMore 默认 false）。
    // 2.0.0+154 起还会去分类里补齐（这里分类给了 1 部别的），所以部数 ≥ 1。
    final repository = FakeRepository()..catalogTotal = 3;
    final explore = await _open(repository);
    explore.select('');
    await pumpEventQueue();
    final loaded = explore.feed!.items.length;
    expect(loaded, greaterThanOrEqualTo(1));
    expect(explore.footerCount, loaded);
    expect(
      explore.facts.total,
      loaded,
      reason: '翻到底以后顶栏必须跟着列表走，不能再报站点声明的 3 部',
    );
  });

  /// 2.0.0+154：有些站源的「全部」目录本身就漏作品 —— 黑桃、黄果视频各漏 8 部
  /// （「全部」里那几张卡是重复的，缺的那几部只在分类页出现）。用户要求
  /// 「只想在【全部】里面找」，所以翻到底后自己扫一遍分类把它们并进列表。
  test('【全部】漏掉的作品从分类里补进来，三处数字跟着一起变', () async {
    final repository = FakeRepository()
      ..catalogTotal = 4
      ..catalogPages = [
        [drama('a1'), drama('a2')],
        // 站点自己重复了一张（a2），真正缺的 a4 只出现在分类里。
        [drama('a2'), drama('a3')],
      ]
      ..categoryPages = {
        'short_play': [
          [drama('a4'), drama('a1')],
        ],
      };
    final explore = await _open(repository);
    explore.select('');
    await pumpEventQueue();
    while (explore.feed!.hasMore) {
      await explore.feed!.loadMore();
    }
    await pumpEventQueue();

    expect(_titles(explore), contains('a4'), reason: '分类里那部要并进「全部」');
    expect(explore.feed!.items.length, 4, reason: 'a1..a4 各一部，重复的 a2 不再计');
    expect(explore.footerCount, 4);
    expect(explore.facts.total, 4, reason: '顶栏 / 底部 / 末位卡片仍然是同一个数');
  });

  /// 2.0.0+154：落盘的实测条数重新生效 —— 进站先显示上次量到的真实部数，
  /// 不再先报站点声明（X短剧声明 2,180「页数×每页」估的，实际 2,169）。
  test('进站先显示上次实测的部数，不报站点声明的虚高数字', () async {
    final repository = FakeRepository()
      ..catalogTotal = 2180
      // hasMore 打开：否则一页到顶会被当成「翻到底」再覆盖一次。
      ..catalogHasMore = true;
    final explore = await _open(repository, (value) async {
      await value.setSourceStats({
        'hongguo': {
          'day': factsDay(DateTime.now()),
          'site': 2180,
          'local': 2100,
          'listed': 2169,
          'listedAt': DateTime.now().millisecondsSinceEpoch,
          'probed': true,
        },
      });
    });
    expect(explore.facts.site, 2180);
    expect(explore.facts.listed, 2169);
    expect(explore.facts.total, 2169, reason: '顶栏报实测部数，不报站点声明');
  });

  /// 2.0.0+156：进站第一次探针拿到的声明和上次不一样时，顶栏也不能退回声明。
  /// 黄果视频声明 2205、实测 2118；X短剧 2184 / 2170；柚子 1296 / 1267 ——
  /// 这几站声明几乎每次进站都在变，一退就永远是虚数（+155 的反馈）。
  test('进站时声明和上次不同，顶栏仍然显示实测的部数', () async {
    final repository = FakeRepository()
      ..catalogTotal = 2205
      ..catalogHasMore = true;
    final explore = await _open(repository, (value) async {
      await value.setSourceStats({
        'hongguo': {
          'day': factsDay(DateTime.now()),
          'site': 2204,
          'local': 2000,
          'listed': 2118,
          'listedAt': DateTime.now().millisecondsSinceEpoch,
          'probed': true,
        },
      });
    });
    expect(explore.facts.listed, 2118);
    // 进站后第 1 页、探针、预填都会动观测表：任何一步都不许把顶栏退回 2205。
    for (var round = 0; round < 8; round++) {
      await pumpEventQueue();
      expect(
        explore.facts.total,
        2118,
        reason: '第 $round 轮之后顶栏退回了声明，用户会看到虚高的数',
      );
    }
  });

  // 站点部数变了以后顶栏**不能**退回声明那个虚数（2.0.0+156）：
  // 黄果视频声明 2205、实际 2118，声明一涨就显示 2205，用户看到的就是
  // 「初次进站 2205、拉到底才 2118」（+155 的反馈）。
  test('站点声明的数变了，顶栏仍显示实测值，不退回虚高的声明', () async {
    // hasMore 打开，否则一页到顶会被当成「翻到底」，把 listed 覆盖成一页的条数。
    final repository = FakeRepository()
      ..catalogTotal = 2000
      ..catalogHasMore = true;
    final explore = await _open(repository, (value) async {
      // 上一版 App 留下的旧记录：站点 2000、实测 1990。
      await value.setSourceStats({
        'hongguo': {
          'day': factsDay(DateTime.now()),
          'site': 2000,
          'local': 1900,
          'listed': 1990,
          'probed': true,
        },
      });
    });
    expect(explore.facts.site, 2000);
    expect(explore.facts.total, 1990, reason: '进站先按上次实测值显示');

    // 切到「全部」：只有它拿回来的 total 才是全站总量。
    explore.select('');
    await pumpEventQueue();
    repository.catalogTotal = 2100;
    await explore.refresh();
    await pumpEventQueue();
    expect(explore.facts.site, 2100, reason: '站点声明本身还是要记下来');
    expect(
      explore.facts.total,
      1990,
      reason: '顶栏继续显示实测值，等重测完再换；不能退回 2100 这个声明',
    );
  });

  /// 2.0.0+152：站点上新以后，刷新一结束就自己把「全部」补到末尾。
  ///
  /// 以前只重拉第 1 页：顶栏那个数是翻到底量出来的，第 1 页看不出末尾多了一页，
  /// 用户必须先切到别的分类翻一遍、再回来刷新才看得到数字变化（原生会把分类页
  /// 的卡片并进「全部」缓存）。现在不依赖这个绕法。
  test('刷新后自动补到末尾，站点上新不用先去别的分类绕一圈', () async {
    final repository = FakeRepository()
      ..catalogTotal = 6
      ..catalogPages = [
        [drama('a1'), drama('a2')],
        [drama('a3'), drama('a4')],
        [drama('a5'), drama('a6')],
      ];
    final explore = await _open(repository);
    explore.select('');
    await pumpEventQueue();
    // 用户自己翻到底：三处（顶栏 / 底部 / 末位卡片）都是 6。
    while (explore.feed!.hasMore) {
      await explore.feed!.loadMore();
    }
    await pumpEventQueue();
    expect(explore.facts.total, 6);
    expect(explore.footerCount, 6);

    // 站点上新 2 部：第 1 页换成新的两部，末尾多出一页。
    // 注意站点自己报的总量**没变**（真实站点按「页数 × 每页」算，常常慢半拍），
    // 这正是以前「刷新后数字不动」的场景。
    repository.catalogPages = [
      [drama('n1'), drama('n2')],
      [drama('a1'), drama('a2')],
      [drama('a3'), drama('a4')],
      [drama('a5'), drama('a6')],
    ];
    await explore.refresh();
    await pumpEventQueue();

    expect(explore.feed!.hasMore, isFalse, reason: '刷新后要自己补到末尾');
    expect(explore.facts.total, 8);
    expect(explore.footerCount, 8, reason: '底部与顶栏必须是同一个数');
  });

  /// 2.0.0+151 反馈：刷新时与刷新完毕时顶栏数「在两个数之间变化」。
  ///
  /// 旧实现在刷新一开始就把实测条数清掉，顶栏立刻退回站点声明；新数据回来又
  /// 写回实测值，于是同一个刷新里数字来回跳。现在只有「站点自己报的总量变了」
  /// 才会换数，其余情况保持原值，等补到底再一次性换成实测值。
  test('刷新过程中顶栏不会在旧数和新数之间来回跳', () async {
    final repository = FakeRepository()
      ..catalogTotal = 6
      ..catalogPages = [
        [drama('a1'), drama('a2')],
        [drama('a3'), drama('a4')],
        [drama('a5'), drama('a6')],
      ];
    final explore = await _open(repository);
    explore.select('');
    await pumpEventQueue();
    while (explore.feed!.hasMore) {
      await explore.feed!.loadMore();
    }
    await pumpEventQueue();
    expect(explore.facts.total, 6);

    // 站点只往末尾加了一页，自己报的总量没变（真实站点很常见：按页数乘每页算）。
    repository.catalogPages = [
      [drama('a1'), drama('a2')],
      [drama('a3'), drama('a4')],
      [drama('a5'), drama('a6')],
      [drama('b1'), drama('b2')],
    ];
    final seen = <int>[];
    explore.addListener(() => seen.add(explore.facts.total));
    await explore.refresh();
    await pumpEventQueue();

    expect(seen, isNotEmpty);
    expect(
      seen.every((value) => value == 6 || value == 8),
      isTrue,
      reason: '刷新过程中不能出现 0 或别的中间数，实际见到：$seen',
    );
    expect(explore.facts.total, 8);
  });

  /// 站点自己报的总量变了（真的涨了）时，刷新一结束就该按新数显示，
  /// 不用等底下补完；数字只会朝「变大」的方向走，不会先跳回去再跳回来。
  test('站点声明的总量涨了，顶栏立刻跟着涨', () async {
    final repository = FakeRepository()
      ..catalogTotal = 6
      ..catalogPages = [
        [drama('a1'), drama('a2')],
        [drama('a3'), drama('a4')],
        [drama('a5'), drama('a6')],
      ];
    final explore = await _open(repository);
    explore.select('');
    await pumpEventQueue();
    while (explore.feed!.hasMore) {
      await explore.feed!.loadMore();
    }
    await pumpEventQueue();
    expect(explore.facts.total, 6);

    repository.catalogTotal = 8;
    repository.catalogPages = [
      [drama('n1'), drama('n2')],
      [drama('a1'), drama('a2')],
      [drama('a3'), drama('a4')],
      [drama('a5'), drama('a6')],
    ];
    final seen = <int>[];
    explore.addListener(() => seen.add(explore.facts.total));
    await explore.refresh();
    await pumpEventQueue();

    expect(seen.last, 8, reason: '新声明一到就换数，别让用户等补页');
    // 数字只能一路往上走：出现 6 → 8 → 6 这种回头，用户看到的就是「来回跳」。
    for (var index = 1; index < seen.length; index++) {
      expect(
        seen[index],
        greaterThanOrEqualTo(seen[index - 1]),
        reason: '顶栏数字不该往回跳，实际序列：$seen',
      );
    }
    expect(explore.facts.total, 8);
  });

  /// +153 第七条：拉到底之后顶栏就不跟着站点更新了。
  ///
  /// 2.0.0+157：定时探头发现第 1 页出现新作品就重走一遍整条目录，走完才一次性
  /// 替换 —— 顶栏 / 底部 / 末位卡片一起变大，中途列表不会缩水。
  test('拉到底之后站点上新，顶栏跟着变大且列表不会缩水', () async {
    final repository = FakeRepository()
      ..catalogTotal = 6
      ..catalogPages = [
        [drama('a1'), drama('a2')],
        [drama('a3'), drama('a4')],
        [drama('a5'), drama('a6')],
      ];
    final explore = await _open(repository);
    explore.select('');
    await pumpEventQueue();
    while (explore.feed!.hasMore) {
      await explore.feed!.loadMore();
    }
    await pumpEventQueue();
    expect(explore.facts.total, 6);
    expect(explore.footerCount, 6);

    // 站点把两部新剧排到最前面，自己报的总量**没变** —— 黄果视频 / X短剧 /
    // 柚子的声明都是按「页数 × 每页」估的，上新时根本不动。
    repository.catalogPages = [
      [drama('n1'), drama('n2')],
      [drama('a1'), drama('a2')],
      [drama('a3'), drama('a4')],
      [drama('a5'), drama('a6')],
    ];
    final seen = <int>[];
    explore.addListener(() => seen.add(explore.footerCount));
    await explore.pulseNow();
    await pumpEventQueue();

    expect(explore.facts.total, 8, reason: '探头发现上新，重走完顶栏要跟着变');
    expect(explore.footerCount, 8, reason: '底部与顶栏仍是同一个数');
    expect(
      seen.every((count) => count >= 6),
      isTrue,
      reason: '重走时列表不能先缩回第 1 页，实际序列：$seen',
    );
    expect(_titles(explore).take(2).toList(), ['n1', 'n2']);
  });

  /// 拉到底之后**手动下拉刷新**：顶栏 / 底部 / 末位卡片一起换成站点的新数。
  ///
  /// 刷新只拉回第 1 页，剩下上百页要 loadMore 一页页补 —— 预算根本不够，以前会
  /// 长期停在「顶栏 2118、底部 24」。现在同样走副本重走，走完一次性替换。
  test('拉到底之后手动刷新，顶栏也跟着站点更新', () async {
    final repository = FakeRepository()
      ..catalogTotal = 6
      ..catalogPages = [
        [drama('a1'), drama('a2')],
        [drama('a3'), drama('a4')],
        [drama('a5'), drama('a6')],
      ];
    final explore = await _open(repository);
    explore.select('');
    await pumpEventQueue();
    while (explore.feed!.hasMore) {
      await explore.feed!.loadMore();
    }
    await pumpEventQueue();
    expect(explore.facts.total, 6);

    // 声明还是 6，站点把两部新剧排到了最前面。
    repository.catalogPages = [
      [drama('n1'), drama('n2')],
      [drama('a1'), drama('a2')],
      [drama('a3'), drama('a4')],
      [drama('a5'), drama('a6')],
    ];
    await explore.refresh();
    for (var round = 0; round < 8; round++) {
      await pumpEventQueue();
    }

    expect(explore.facts.total, 8, reason: '刷新后顶栏要跟着站点变');
    expect(explore.footerCount, 8, reason: '底部不能停在刷新后的第 1 页');
    expect(explore.feed!.hasMore, isFalse);
    expect(_titles(explore).take(2).toList(), ['n1', 'n2']);
  });
}
