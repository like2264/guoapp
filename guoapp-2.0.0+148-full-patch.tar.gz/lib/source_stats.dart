/// 站源观测量：顶栏标题旁边那行「共 4,379 部」+ 下面一行「今日更新 56 集」。
///
/// - `site`：站源目录的**作品总量**，来自站源目录首页自己给的数字
///   （黄桃/91短剧/柚子/X短剧/夜社 = 总页数 × 每页条数，剧果/野果 = 站点 total，
///   黄果视频 = 列表页页眉，黄果AI = 各分类 total 之和，禁果 = 一次拉回的全量，
///   黑桃 = 总页数 × 每页条数 + 末页）。站源给不出时是 0，这时退回本地已见数。
/// - `local`：**「全部」分类里见过的作品数**（按 id 去重）。
///   它只累计「全部」目录里出现过的剧，搜索、排行榜、单独切开的分类都不计入，
///   所以往下翻多少就是多少，不会被别的入口撑大。站源给不出总量时才用它。
/// - `updated`：今天观察到「本来就在库里、集数变多了」的增量之和。
///   今天才第一次翻到的剧不算更新（否则往下翻几页就虚增几百集），跨天归零。
/// - `listed`：**本次会话里真翻到底那一次实际列出了多少部**（2.0.0+143 起）。
///   站源声明的总量普遍有水分：分页型站源按「总页数 × 每页条数」报，
///   末页不满就被多算；另一些站源把已下架的作品也算在里面。
///   翻到底时用真实条数把顶栏和列表底部对齐。
///   2.0.0+148 起这个数**不再落盘**：它一存下来就会永远压过站点声明，
///   站点后来加了作品、App 顶栏也一动不动（野果 / 黑桃 / 黄桃 都栽在这上面）。
///   现在它只活在 ExploreFeed 的内存里，重启后一律以站点声明为准。
/// - `arrived`：**已废弃，恒为 0**。原来记「今天第一次见到的作品数」，用来在
///   顶栏显示「新上 N 部」；但站点第一页每次都换新作品、落盘名单又只能留 1500 条，
///   数字每刷一次涨一次（真机上能涨到 26 万，大过「共 N 部」），2.0.0+137 删掉了。
///
/// 第二行的口径对所有站源统一：永远是「今日更新 N 集」，没有就写 0，
/// 不再出现「黄果视频两项、黄桃只有一项」这种不一致。
class SourceFacts {
  const SourceFacts({
    this.site = 0,
    this.local = 0,
    this.updated = 0,
    this.arrived = 0,
    this.listed = 0,
    this.probed = false,
  });

  final int site;
  final int local;
  final int updated;
  final int arrived;

  /// 翻到底时实际列出的条数（0 = 还没翻到底，没测过）。
  final int listed;

  /// 这个站源有没有成功观测过（至少拉回来过一页目录）。
  /// 没观测过时不显示任何数字——否则会先闪一下「已收录 24 部」再跳到「共 2,040 部」。
  final bool probed;

  bool get known => site > 0 || local > 0 || listed > 0;

  /// 顶栏与列表底部共用这一个数。
  ///
  /// 只要翻到底实测过就一律用实测值 —— 它就是列表最后一张卡片的序号，也是底部
  /// 报的条数。绝不能再回落到站点声明：声明偏大时顶栏会比底部多几十上百部
  /// （正是 +143 之前那个毛病），声明偏小时顶栏又会比底部少，两边怎么都对不上。
  /// 没实测过（还没滚到底、或这个站没有列表）才用站点声明。
  int get total {
    if (listed > 0) return listed;
    return site > 0 ? site : local;
  }

  /// 4,379 —— 数量上千后加千分位，扫一眼就知道是「几千部」还是「几十部」。
  static String count(int value) => '$value'.replaceAllMapped(
    RegExp(r'(\d)(?=(\d{3})+$)'),
    (match) => '${match[1]},',
  );

  /// 顶栏第一行：「共 4,379 部」或「已收录 2,051 部」。没数据时返回空串。
  String get headline {
    if (!probed) return '';
    final value = total;
    if (value <= 0) return '';
    return site > 0 || listed > 0
        ? '共 ${count(value)} 部'
        : '已收录 ${count(value)} 部';
  }

  /// 顶栏第二行：只留「今日更新 N 集」。
  ///
  /// 「新上 N 部」在 2.0.0+137 删掉了：站点第一页按更新时间排，每刷一次就有新作品
  /// 挤上来，落盘的名单又只留得住 1500 条，数字于是越刷越大，最后能大过「共 N 部」。
  /// 显示不出来就别显示，也不再用它给首页排序。
  String get detail {
    if (!probed) return '';
    return '今日更新 ${count(updated)} 集';
  }

  String get updatesLabel => probed ? '今日更新 ${count(updated)} 集' : '';

  /// 单行版本（电视顶栏、无障碍播报用）。
  String get label => [headline, detail].where((part) => part.isNotEmpty).join(' · ');
}

String factsDay(DateTime time) {
  String two(int value) => value.toString().padLeft(2, '0');
  return '${time.year}-${two(time.month)}-${two(time.day)}';
}

/// 每个站源记多少个「见过的作品 id」。只用来判断「这一部我今天以前见过没有」，
/// 记第一页到前几十页足够，记太多会把偏好存储撑肿。
const factsSeenLimit = 1500;

/// 每个站源记多少部剧的集数快照（用来算「今日更新」）。
/// 目录第一页每部都记，一千多部足够覆盖常用的几个分类入口。
const factsEpisodeLimit = 1200;

/// 今天优先显示的作品 id 记多少个。
const factsFreshLimit = 240;

int? _int(Object? value) => value is num ? value.toInt() : null;

/// 某个站源「全部」分类里见过的作品 id，用来接着往下累计。
List<String> readKnown(Map<String, Object?> raw, String source) =>
    _stringList(raw, source, 'all');

List<String> readFresh(Map<String, Object?> raw, String source, {DateTime? now}) {
  final row = raw[source];
  if (row is! Map) return const [];
  if (row['day'] != factsDay(now ?? DateTime.now())) return const [];
  return _stringList(raw, source, 'fresh');
}

List<String> _stringList(Map<String, Object?> raw, String source, String key) {
  final row = raw[source];
  if (row is! Map) return const [];
  final list = row[key];
  if (list is! List) return const [];
  return [
    for (final id in list)
      if (id is String && id.isNotEmpty) id,
  ];
}

/// 某个站源上次看到的「剧 id → 集数」。只记集数大于 0 的条目：
/// 站点不给集数的剧本来就无法比较，记下来只会白占地方。
Map<String, int> readEpisodes(Map<String, Object?> raw, String source) {
  final row = raw[source];
  if (row is! Map) return <String, int>{};
  final map = row['ep'];
  if (map is! Map) return <String, int>{};
  final out = <String, int>{};
  for (final entry in map.entries) {
    final key = entry.key;
    final value = _int(entry.value);
    if (key is String && key.isNotEmpty && value != null && value > 0) {
      out[key] = value;
    }
  }
  return out;
}

/// 这个站源有没有做过第一次基线观测。没做过时第一页整页都会被当成「新上」，
/// 得先安静地把名单和集数存下来，下次开始才算增量。
bool readSeeded(Map<String, Object?> raw, String source) {
  final row = raw[source];
  return row is Map && row['seeded'] == true;
}

/// 从存储的原始表里读某个站源的观测值；跨天自动把「今日更新 / 新上」归零。
SourceFacts readFacts(
  Map<String, Object?> raw,
  String source, {
  DateTime? now,
}) {
  final row = raw[source];
  if (row is! Map) return const SourceFacts();
  // 2.0.0+123 之前只存了 total（当时等于本地收录数），旧值按 local 读。
  final site = _int(row['site']) ?? 0;
  final local = _int(row['local']) ?? _int(row['total']) ?? 0;
  final today = row['day'] == factsDay(now ?? DateTime.now());
  final updated = today ? _int(row['updated']) ?? 0 : 0;
  final arrived = today ? _int(row['arrived']) ?? 0 : 0;
  // 落盘的 listed 一律不认（2.0.0+148）：可能是上一版 App 记下的旧条数。
  return SourceFacts(
    site: site < 0 ? 0 : site,
    local: local < 0 ? 0 : local,
    updated: updated < 0 ? 0 : updated,
    arrived: arrived < 0 ? 0 : arrived,
    // 老数据（2.0.0+123 之前）没有这个标记，但有数字就说明观测过。
    probed: row['probed'] == true || site > 0 || _int(row['listed']) != null,
  );
}

/// 把一次观测写回原始表。返回新的表，调用方负责持久化。
///
/// `known` 是「全部」里见过的作品 id（判「新上」用），`episodes` 是上次看到的
/// 集数（判「今日更新」用），`fresh` 是今天变化过的作品 id（首页优先显示用）。
/// 这三份都由上层维护，这里只负责裁剪长度后落盘。
Map<String, Object?> writeFacts(
  Map<String, Object?> raw,
  String source, {
  required int site,
  required int local,
  int gained = 0,
  int arrived = 0,
  Iterable<String>? known,
  Map<String, int>? episodes,
  Iterable<String>? fresh,
  bool seeded = true,
  DateTime? now,
}) {
  final clock = now ?? DateTime.now();
  final day = factsDay(clock);
  final row = raw[source];
  // 同一天才累加，跨天从 0 重新开始。
  final sameDay = row is Map && row['day'] == day;
  final carried = sameDay ? _int(row['updated']) ?? 0 : 0;
  final updated = carried + (gained > 0 ? gained : 0);
  // 「新上」已经不再统计（顶栏那一行删了），这里一律写 0，
  // 顺手把历史遗留的大数字（有的站存过 26 万）一并清掉。
  final arrivedTotal = 0;
  final ids = _tail(known, factsSeenLimit);
  final freshIds = _tail(fresh, factsFreshLimit);
  final snapshot = <String, int>{};
  if (episodes != null) {
    // 只保留最后写进来的若干条：Map 保持插入顺序，越靠前越旧。
    final keys = episodes.keys.toList(growable: false);
    final start = keys.length > factsEpisodeLimit ? keys.length - factsEpisodeLimit : 0;
    for (var index = start; index < keys.length; index++) {
      final key = keys[index];
      final value = episodes[key];
      if (value != null && value > 0) snapshot[key] = value;
    }
  }
  return {
    ...raw,
    source: {
      'day': day,
      'updated': updated < 0 ? 0 : updated,
      'arrived': arrivedTotal < 0 ? 0 : arrivedTotal,
      'site': site < 0 ? 0 : site,
      'local': local < 0 ? 0 : local,
      'probed': true,
      // 实测条数只在内存里（见 [SourceFacts.listed] 的说明），顺手把历史遗留
      // 的字段清掉，免得旧版本写下的数字继续影响判断。
      if (seeded) 'seeded': true,
      if (ids.isNotEmpty) 'all': ids,
      if (snapshot.isNotEmpty) 'ep': snapshot,
      if (freshIds.isNotEmpty) 'fresh': freshIds,
    },
  };
}

List<String> _tail(Iterable<String>? values, int limit) {
  if (values == null) return const [];
  final list = [
    for (final value in values)
      if (value.isNotEmpty) value,
  ];
  if (list.length <= limit) return list;
  return list.sublist(list.length - limit);
}
