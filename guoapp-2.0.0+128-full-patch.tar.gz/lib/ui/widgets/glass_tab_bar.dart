import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// 浮动玻璃标签栏。
///
/// 视觉按 2.0.0+128 反馈对齐「视频里的那个底栏」：
/// - 整条是一块很淡的磨砂玻璃，四角全圆，格子之间只有极淡的分隔线；
/// - 选中项不是染色块，而是一块**近乎实心的白色**圆角方块，浮在玻璃上面，
///   带一点点投影，图标用主题色；
/// - 拖动时这块白色跟着手指走，起点会留一道被抹开的残影（模糊 + 淡出），
///   像液体被拉过去一样；松手再回弹到最近的格子。
class GlassTabBar extends StatefulWidget {
  const GlassTabBar({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
    required this.destinations,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final List<GlassTabDestination> destinations;

  /// 胶囊本体高度（不含底部安全区）。
  static const barHeight = 62.0;

  /// 底栏上下的留白。内容要躲开底栏时，用 [reservedHeight]。
  static const horizontalInset = 14.0;
  static const bottomGap = 10.0;

  static const _radius = barHeight / 2;

  /// 玻璃条内边距：胶囊在这里面移动。
  static const _pad = 6.0;

  /// 底栏实际占用的总高度（胶囊 + 上下留白 + 安全区）。
  /// 页面底部留白按它算，内容就不会被浮起来的玻璃条盖住。
  static double reservedHeight(BuildContext context) =>
      barHeight +
      bottomGap +
      MediaQuery.viewPaddingOf(context).bottom +
      8;

  @override
  State<GlassTabBar> createState() => _GlassTabBarState();
}

class _GlassTabBarState extends State<GlassTabBar>
    with SingleTickerProviderStateMixin {
  /// 胶囊现在停在「第几格」（可以是小数：拖动时在两格之间）。
  late double _at = widget.selectedIndex.toDouble();

  bool _dragging = false;

  /// 残影位置（格为单位）与淡出进度。
  late double _trailAt = _at;
  late final AnimationController _trail = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 230),
  )..addListener(() {
      if (mounted) setState(() {});
    });

  static const _snap = Duration(milliseconds: 260);

  @override
  void didUpdateWidget(GlassTabBar old) {
    super.didUpdateWidget(old);
    // 外面切了栏目（点图标、左右滑）时把胶囊放回去；正在拖就别抢。
    if (!_dragging && old.selectedIndex != widget.selectedIndex) {
      setState(() {
        _at = widget.selectedIndex.toDouble();
        _trailAt = _at;
      });
    }
  }

  @override
  void dispose() {
    _trail.dispose();
    super.dispose();
  }

  void _dragStart(DragStartDetails details) {
    HapticFeedback.selectionClick();
    setState(() {
      _dragging = true;
      _trailAt = _at;
    });
  }

  void _dragUpdate(DragUpdateDetails details, double cell) {
    if (cell <= 0) return;
    final last = widget.destinations.length - 1;
    final next = (_at + details.delta.dx / cell).clamp(0.0, last.toDouble());
    final crossed = next.roundToDouble();
    if (crossed != _at.roundToDouble()) {
      // 掠过一格：留一道残影 + 震一下手指。
      HapticFeedback.lightImpact();
      _trailAt = _at.roundToDouble();
      _trail.forward(from: 0);
    }
    setState(() => _at = next);
  }

  void _dragEnd() {
    if (!_dragging) return;
    final index = _at.round().clamp(0, widget.destinations.length - 1);
    setState(() {
      _dragging = false;
      _at = index.toDouble();
      _trailAt = _at;
    });
    if (index != widget.selectedIndex) widget.onSelected(index);
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors = Theme.of(context).colorScheme;
    final inset = MediaQuery.viewPaddingOf(context).bottom;
    final radius = BorderRadius.circular(GlassTabBar._radius);
    return Padding(
      padding: EdgeInsets.fromLTRB(
        GlassTabBar.horizontalInset,
        0,
        GlassTabBar.horizontalInset,
        GlassTabBar.bottomGap + inset,
      ),
      // 阴影放在裁剪外面，否则会被 ClipRRect 一起剪掉。
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: radius,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: dark ? 0.22 : 0.10),
              blurRadius: 26,
              spreadRadius: -8,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: radius,
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: 2.2,
              sigmaY: 2.2,
              tileMode: TileMode.clamp,
            ),
            child: SizedBox(
              height: GlassTabBar.barHeight,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final inner = constraints.maxWidth - GlassTabBar._pad * 2;
                  final cell = inner / widget.destinations.length;
                  return Stack(
                    children: [
                      // 玻璃底：一层很淡的白，上亮下暗。
                      Positioned.fill(
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            borderRadius: radius,
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: dark
                                  ? [
                                      Colors.white.withValues(alpha: 0.075),
                                      Colors.white.withValues(alpha: 0.030),
                                    ]
                                  : [
                                      Colors.white.withValues(alpha: 0.40),
                                      Colors.white.withValues(alpha: 0.22),
                                    ],
                            ),
                            border: Border.all(
                              color: dark
                                  ? Colors.white.withValues(alpha: 0.24)
                                  : Colors.white.withValues(alpha: 0.72),
                            ),
                          ),
                        ),
                      ),
                      // 格子之间的细分隔线，只在滑块外面露出来。
                      Positioned.fill(
                        child: Padding(
                          padding: const EdgeInsets.all(GlassTabBar._pad),
                          child: CustomPaint(
                            painter: _Dividers(
                              count: widget.destinations.length,
                              color: Colors.white.withValues(
                                alpha: dark ? 0.10 : 0.55,
                              ),
                            ),
                          ),
                        ),
                      ),
                      // 拖动残影：起点的白块被「抹」出去，模糊 + 淡出。
                      if (_trail.isAnimating)
                        Positioned(
                          left:
                              GlassTabBar._pad + _trailAt * cell + 3,
                          width: cell - 6,
                          top: GlassTabBar._pad,
                          height:
                              GlassTabBar.barHeight - GlassTabBar._pad * 2,
                          child: IgnorePointer(
                            child: Opacity(
                              opacity: (1 - _trail.value) * 0.55,
                              child: ImageFiltered(
                                imageFilter: ImageFilter.blur(
                                  sigmaX: 2 + _trail.value * 8,
                                  sigmaY: 1 + _trail.value * 4,
                                ),
                                child: _blob(dark, colors, radius: 20),
                              ),
                            ),
                          ),
                        ),
                      // 滑块本体：拖动时零延时跟手，松手后缓动归位。
                      AnimatedPositioned(
                        duration: _dragging ? Duration.zero : _snap,
                        curve: Curves.easeOutCubic,
                        left: GlassTabBar._pad + _at * cell + 3,
                        width: cell - 6,
                        top: GlassTabBar._pad,
                        height: GlassTabBar.barHeight - GlassTabBar._pad * 2,
                        child: IgnorePointer(
                          child: _blob(dark, colors, radius: 20),
                        ),
                      ),
                      Positioned.fill(
                        child: Padding(
                          padding: const EdgeInsets.all(GlassTabBar._pad),
                          child: GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onHorizontalDragStart: _dragStart,
                            onHorizontalDragUpdate: (details) =>
                                _dragUpdate(details, cell),
                            onHorizontalDragEnd: (_) => _dragEnd(),
                            onHorizontalDragCancel: () => _dragEnd(),
                            child: Row(
                              children: [
                                for (
                                  var index = 0;
                                  index < widget.destinations.length;
                                  index++
                                )
                                  Expanded(
                                    child: _item(
                                      context,
                                      index,
                                      dark,
                                      colors,
                                      // 拖动时高亮跟着手指走，不用等松手。
                                      highlight: _dragging
                                          ? _at.round() == index
                                          : widget.selectedIndex == index,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      // 顶部一条细高光，玻璃感主要靠它。
                      Positioned(
                        left: GlassTabBar._radius * 0.6,
                        right: GlassTabBar._radius * 0.6,
                        top: 0,
                        child: IgnorePointer(
                          child: Container(
                            height: 1,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.white.withValues(alpha: 0),
                                  Colors.white.withValues(
                                    alpha: dark ? 0.45 : 0.9,
                                  ),
                                  Colors.white.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// 选中块：浅色主题下是一块实心白，深色主题下是一层亮白玻璃。
  Widget _blob(bool dark, ColorScheme colors, {required double radius}) {
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: dark
              ? [
                  Colors.white.withValues(alpha: 0.20),
                  Colors.white.withValues(alpha: 0.13),
                ]
              : [
                  Colors.white.withValues(alpha: 0.98),
                  Colors.white.withValues(alpha: 0.86),
                ],
        ),
        border: Border.all(
          color: dark
              ? Colors.white.withValues(alpha: 0.26)
              : Colors.white.withValues(alpha: 0.95),
        ),
        boxShadow: dark
            ? [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.28),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ]
            : [
                BoxShadow(
                  color: colors.primary.withValues(alpha: 0.10),
                  blurRadius: 14,
                  offset: const Offset(0, 4),
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.06),
                  blurRadius: 6,
                  offset: const Offset(0, 1),
                ),
              ],
      ),
    );
  }

  Widget _item(
    BuildContext context,
    int index,
    bool dark,
    ColorScheme colors, {
    required bool highlight,
  }) {
    final destination = widget.destinations[index];
    final idle = dark
        ? Colors.white.withValues(alpha: 0.92)
        : Colors.black.withValues(alpha: 0.72);
    // 背景很透，内容可能很亮也可能很暗，给字加一圈很轻的影子保证可读。
    final legibility = <Shadow>[
      Shadow(
        offset: const Offset(0, 1),
        blurRadius: 2,
        color: dark
            ? Colors.black.withValues(alpha: 0.55)
            : Colors.white.withValues(alpha: 0.85),
      ),
    ];
    return Semantics(
      button: true,
      selected: highlight,
      label: destination.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => widget.onSelected(index),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconTheme.merge(
              data: IconThemeData(
                size: 22,
                color: highlight ? colors.primary : idle,
              ),
              child: highlight ? destination.selectedIcon : destination.icon,
            ),
            const SizedBox(height: 2),
            Text(
              destination.label,
              maxLines: 1,
              overflow: TextOverflow.fade,
              softWrap: false,
              style: TextStyle(
                fontSize: 11,
                height: 1.1,
                fontWeight: highlight ? FontWeight.w700 : FontWeight.w500,
                color: highlight ? colors.primary : idle,
                shadows: legibility,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 格子之间的细竖线。
class _Dividers extends CustomPainter {
  const _Dividers({required this.count, required this.color});

  final int count;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    if (count < 2) return;
    final paint = Paint()..color = color..strokeWidth = 0.8;
    final cell = size.width / count;
    for (var i = 1; i < count; i++) {
      final x = cell * i;
      canvas.drawLine(
        Offset(x, size.height * 0.12),
        Offset(x, size.height * 0.88),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_Dividers old) =>
      old.count != count || old.color != color;
}

class GlassTabDestination {
  const GlassTabDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
  });

  final String label;
  final Widget icon;
  final Widget selectedIcon;
}
