import 'package:flutter/foundation.dart';

import 'models.dart';

typedef PageLoader = Future<CatalogPage> Function(int page, bool force);

class DramaFeed extends ChangeNotifier {
  DramaFeed({required this.load, this.cached, this.cumulative = false});
  final PageLoader load;
  final Future<CatalogPage> Function()? cached;
  final bool cumulative;

  List<Drama> _items = const [];

  /// 连续几页请求直接报错（不是「空页」，是被取消 / 超时）。
  ///
  /// 连错到 [_autoRetryLimit] 次只把**自动**翻页暂停（等用户点「重试」），
  /// 绝不把 [hasMore] 置假。置假等于宣布「站点只有这么多」，列表会永远停在
  /// 半路：野果停在 1,388（站点 1,401）、夜社停在 480 附近，底部「共 N 部」、
  /// 顶栏、末位卡片三个数从此再也对不上。
  int _failedPages = 0;

  /// 连续失败到上限，自动翻页暂停中（不是翻到底）。
  bool _autoPaused = false;

  /// 连续失败几次就暂停自动翻页。用户点一次「重试」即可恢复。
  static const _autoRetryLimit = 3;

  bool _loading = false;
  bool _loadingMore = false;
  bool _hasMore = false;
  String _error = '';
  int _next = 1;
  int _generation = 0;
  bool _disposed = false;

  /// 连续几页「空页但站点还说有下一页」。
  ///
  /// 目录拼错页（夜社的「全部」是两栏按页接的虚拟列表）或者站点尾页错位时，
  /// 会出现 hasMore 永远为真、页页返回空。连着三页空才当作翻到底 —— 只想跳过
  /// 一两页错位，不能把「站点还有货」误判成「到底了」。
  int _emptyPages = 0;

  static const _emptyPageLimit = 3;

  List<Drama> get items => _items;

  bool get loading => _loading;
  bool get loadingMore => _loadingMore;
  bool get hasMore => _hasMore;
  String get error => _error;

  /// 因为连续失败暂停了自动翻页 —— 列表没翻到底，[hasMore] 仍为真。
  bool get stalled => _autoPaused;

  bool get canLoadMore =>
      _hasMore && !_loading && !_loadingMore && !_autoPaused;

  Future<void> reload({bool force = false}) async {
    final generation = ++_generation;
    _loading = true;
    _loadingMore = false;
    _failedPages = 0;
    _autoPaused = false;
    _emptyPages = 0;
    _error = '';
    _notify();
    if (!force && cached != null) {
      try {
        final page = await cached!();
        if (generation != _generation) return;
        if (page.items.isNotEmpty) {
          _accept(page, more: false);
          if (page.fresh && page.warning.isEmpty) {
            _loading = false;
            _notify();
            return;
          }
          _notify();
        }
      } catch (_) {}
    }
    await _fetch(generation, page: 1, force: force, more: false);
  }

  Future<void> loadMore() async {
    if (!canLoadMore) return;
    final generation = ++_generation;
    _loadingMore = true;
    _error = '';
    _notify();
    await _fetch(generation, page: _next, force: false, more: true);
  }

  /// 用户在列表底部点了「重试」。
  ///
  /// 失败时页码没有推进，所以再拉一次就是重试失败的那一页 —— 不会跳页、
  /// 也不会把已经加载的作品丢掉。
  Future<void> retry() async {
    if (_loading || _loadingMore) return;
    _failedPages = 0;
    _autoPaused = false;
    _error = '';
    _notify();
    if (!_hasMore) {
      await reload(force: true);
      return;
    }
    await loadMore();
  }

  void update(Drama drama) {
    if (!_items.any((item) => item.id == drama.id)) return;
    _items = [
      for (final item in _items) item.id == drama.id ? item.merge(drama) : item,
    ];
    _notify();
  }

  /// 把别处（各分类目录）拿到的作品并进当前列表尾部，返回并进去几部。
  ///
  /// 用在「全部」翻到底之后：有些站源的「全部」本身就漏作品（黑桃、黄果视频
  /// 各漏 8 部，那 8 部只在分类页出现）。整部并进来，用户就不用再去别的分类
  /// 绕一圈找；序号 / 底部部数 / 末位卡片自然一起变大。
  ///
  /// 只追加、不改已有条目、不动 [hasMore]：调用方保证此时已经翻到底。
  int merge(Iterable<Drama> extra) {
    if (_items.isEmpty) return 0;
    final known = {for (final item in _items) item.id};
    final appended = <Drama>[];
    for (final drama in extra) {
      if (drama.id.isEmpty) continue;
      if (!known.add(drama.id)) continue;
      appended.add(drama);
    }
    if (appended.isEmpty) return 0;
    _items = [..._items, ...appended];
    _notify();
    return appended.length;
  }

  Future<void> _fetch(
    int generation, {
    required int page,
    required bool force,
    required bool more,
  }) async {
    try {
      final result = await load(page, force);
      if (generation != _generation) return;
      _accept(result, more: more);
    } catch (error) {
      if (generation != _generation) return;
      _error = _describe(error);
      // 请求被取消 / 超时（翻到尾部时同一个 session 的新请求会取消旧的）：
      // 页码不推进，下次 loadMore 会重试同一页。连错到上限只暂停自动翻页，
      // [hasMore] 保持为真 —— 置假等于宣布「站点只有这么多」，列表从此停在
      // 半路，顶栏/底部/末位卡片三个数再也对不上。
      if (more) {
        _failedPages++;
        if (_failedPages >= _autoRetryLimit) _autoPaused = true;
      }
    }
    _loading = _loadingMore = false;
    _notify();
  }

  /// 把原生抛上来的英文错误翻成能给人看的一句话。
  static String _describe(Object error) {
    final text = error.toString();
    if (text.contains('context canceled')) return '翻页超时，稍后再试';
    if (text.contains('context deadline exceeded')) return '翻页超时，稍后再试';
    return text;
  }

  void _accept(CatalogPage page, {required bool more}) {
    if (cumulative || !more) {
      _items = page.items;
    } else {
      final known = {for (final item in _items) item.id};
      _items = [
        ..._items,
        for (final item in page.items)
          if (known.add(item.id)) item,
      ];
    }
    _failedPages = 0;
    _autoPaused = false;
    // 这一页拿到了数据，旧错误就该撤掉。只有「一页一条都没拿到、还带了
    // warning」才算这一页失败；部分成功不能阻断继续翻页。
    _error = page.items.isEmpty && page.warning.isNotEmpty ? page.warning : '';
    if (more && page.items.isEmpty) {
      _emptyPages++;
    } else {
      _emptyPages = 0;
    }
    _next = page.page + 1;
    _hasMore = page.hasMore && _emptyPages < _emptyPageLimit;
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _generation++;
    super.dispose();
  }
}
