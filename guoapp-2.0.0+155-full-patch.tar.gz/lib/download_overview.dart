import 'dart:async';

import 'package:flutter/foundation.dart';

import 'core_bridge.dart';
import 'background_keepalive.dart';
import 'local_store.dart';
import 'models.dart';

class DownloadOverview extends ChangeNotifier {
  DownloadOverview(this.repository, this.store, {this.interval = _interval}) {
    store.addListener(_sync);
    _sync();
  }

  static const _interval = Duration(seconds: 2);
  final AppRepository repository;
  final LocalStore store;
  final Duration interval;
  Timer? _timer;
  int? _epoch;
  int _request = 0;
  bool _loading = false;
  bool _disposed = false;
  List<DownloadJob> _jobs = const [];

  bool get available => store.canDownload && repository.supportsDownloads;
  List<DownloadJob> get jobs => _jobs;
  int get active => _jobs.where((job) => job.active || job.converting).length;
  int get completed => _jobs.where((job) => job.completed).length;
  int get completedBytes => _jobs
      .where((job) => job.completed)
      .fold(0, (total, job) => total + job.bytes);

  /// 正在下载 / 处理的任务一共写了多少字节。
  int get activeBytes => _jobs
      .where((job) => job.active || job.converting)
      .fold(0, (total, job) => total + job.bytes);

  /// 当前下载速度（字节/秒），平滑过的。
  ///
  /// 原生只给「已下载多少字节」，没有速度字段：这里用两次轮询之间
  /// [activeBytes] 的增量除以真实间隔算瞬时值，再用 EMA 抹平 —— 直接用瞬时值
  /// 会随着分片落盘一跳一跳的，看着像心电图。
  double get speed => _speed;
  double _speed = 0;
  int _sampleBytes = 0;
  DateTime? _sampleAt;

  void _measure() {
    final now = DateTime.now();
    final bytes = activeBytes;
    final at = _sampleAt;
    _sampleAt = now;
    if (at == null) {
      _sampleBytes = bytes;
      return;
    }
    final seconds = now.difference(at).inMilliseconds / 1000;
    final delta = bytes - _sampleBytes;
    _sampleBytes = bytes;
    if (seconds <= 0) return;
    // 没有增长（暂停、换任务、刚好都在等响应）就归零，不显示一个假速度。
    if (delta <= 0) {
      _speed = 0;
      return;
    }
    final instant = delta / seconds;
    _speed = _speed <= 0 ? instant : _speed * 0.6 + instant * 0.4;
  }

  DownloadJob? get current =>
      _jobs.where((job) => job.state == 'downloading').firstOrNull ??
      _jobs.where((job) => job.active).firstOrNull;

  void _sync() {
    if (!available) {
      _stop();
      return;
    }
    if (_epoch != store.profileEpoch) {
      _epoch = store.profileEpoch;
      _request++;
      _loading = false;
      _replace(const []);
    }
    if (_timer == null) {
      _timer = Timer.periodic(interval, (_) => refresh());
      refresh();
    }
  }

  void _stop() {
    _timer?.cancel();
    _timer = null;
    _epoch = null;
    _request++;
    _loading = false;
    _resetSpeed();
    _replace(const []);
  }

  void _resetSpeed() {
    _speed = 0;
    _sampleBytes = 0;
    _sampleAt = null;
  }

  static String _signature(List<DownloadJob> jobs) => [
    for (final job in jobs)
      '${job.id}|${job.state}|${job.progress}|${job.bytes}|${job.total}|'
          '${job.actualQuality}|${job.error}|${job.drama.title}',
  ].join('\n');

  void _replace(List<DownloadJob> jobs) {
    if (identical(jobs, _jobs) || _signature(jobs) == _signature(_jobs)) {
      return;
    }
    _jobs = jobs;
    // iOS：有下载/处理在跑就向系统要后台时间，跑完立刻还回去（见
    // background_keepalive.dart）。以前这里只能提示用户保持前台。
    if (jobs.any((job) => job.active || job.converting)) {
      unawaited(BackgroundKeepAlive.hold());
    } else {
      unawaited(BackgroundKeepAlive.release());
    }
    if (!_disposed) notifyListeners();
  }

  Future<void> refresh() async {
    if (_loading || !available) return;
    _loading = true;
    final request = _request;
    try {
      final jobs = await repository.downloads();
      if (!_disposed && request == _request) {
        final before = _speed;
        _replace(jobs);
        // 速度要每次轮询都算（字节没变就归零），不能只在数据变化时才采样。
        _measure();
        // 但只有速度真的变了才通知：任务没动的时候别让界面每 2 秒白重建一次。
        if (!_disposed && (_speed - before).abs() >= 1024) notifyListeners();
      }
    } catch (_) {
    } finally {
      if (request == _request) _loading = false;
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    store.removeListener(_sync);
    super.dispose();
  }
}
