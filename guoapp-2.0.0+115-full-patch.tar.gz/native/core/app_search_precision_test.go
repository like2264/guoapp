package core

import "testing"

func TestNativePreciseSearchRanksAndDrops(t *testing.T) {
	items := []LibraryDrama{
		{ID: "a:1", Title: "都市爱情故事", Description: "总裁会很心动"},
		{ID: "a:2", Title: "霸道总裁的替身新娘", Description: "无"},
		{ID: "a:3", Title: "总裁", Description: "无"},
		{ID: "a:4", Title: "总裁在上", Description: "无"},
		{ID: "a:5", Title: "完全无关的倒霉蛋", Description: "无", Tags: []string{"总裁剧"}},
		{ID: "a:6", Title: "另一个无关剧", Description: "无"},
	}
	got := NativePreciseSearch(items, "总裁")
	// 「适中」策略：仅简介命中的保留在末尾，完全不命中的（a:6）剔除。
	if len(got) != 5 {
		t.Fatalf("expected 5 results, got %d: %+v", len(got), got)
	}
	want := []string{"a:3", "a:4", "a:2", "a:5", "a:1"}
	for index, id := range want {
		if got[index].ID != id {
			t.Fatalf("position %d: want %s, got %s (all=%v)", index, id, got[index].ID, preciseIDs(got))
		}
	}
}

// 整页都对不上关键词时原样返回：站点把结果分页给过来，某一页全是宽匹配很正常，
// 剔干净会让客户端以为「搜不到」，之前黄果视频搜不到全部相关作品就是这么来的。
func TestNativePreciseSearchKeepsPageWhenNothingMatches(t *testing.T) {
	items := []LibraryDrama{
		{ID: "a:1", Title: "喜剧"},
		{ID: "a:2", Title: "悲剧"},
	}
	got := NativePreciseSearch(items, "完全不存在")
	if len(got) != len(items) {
		t.Fatalf("expected page kept as-is, got %d", len(got))
	}
	if got[0].ID != "a:1" || got[1].ID != "a:2" {
		t.Fatalf("expected original order kept, got %v", preciseIDs(got))
	}
}

func TestNativePreciseSearchMultiWord(t *testing.T) {
	items := []LibraryDrama{
		{ID: "a:1", Title: "总裁的契约新娘"},
		{ID: "a:2", Title: "总裁归来"},
		{ID: "a:3", Title: "无关剧"},
	}
	got := NativePreciseSearch(items, "总裁 新娘")
	// 拆词全命中的 a:1 排最前；只命中其中一个词的 a:2 不再被丢掉。
	if len(got) != 2 || got[0].ID != "a:1" || got[1].ID != "a:2" {
		t.Fatalf("expected a:1 then a:2, got %v", preciseIDs(got))
	}
}

// 多站源合并：同一套相关度排序，跨站源去重。
func TestNativeMergeSearchRanksAcrossSources(t *testing.T) {
	groups := [][]LibraryDrama{
		{{ID: "b:1", Title: "无关剧"}, {ID: "b:2", Title: "总裁的替身"}},
		{{ID: "c:1", Title: "总裁"}, {ID: "c:2", Title: "别的东西"}},
	}
	got := NativeMergeSearch(groups, "总裁")
	// 完全对不上关键词的条目（b:1 无关剧、c:2 别的东西）在合并时丢掉，
	// 只有整个站源一条都对不上时才整组保留在末尾。
	want := []string{"c:1", "b:2"}
	if len(got) != len(want) {
		t.Fatalf("expected %d items, got %v", len(want), preciseIDs(got))
	}
	for index, id := range want {
		if got[index].ID != id {
			t.Fatalf("position %d: want %s, got %v", index, id, preciseIDs(got))
		}
	}
}

func preciseIDs(items []LibraryDrama) []string {
	out := make([]string, 0, len(items))
	for _, item := range items {
		out = append(out, item.ID)
	}
	return out
}
