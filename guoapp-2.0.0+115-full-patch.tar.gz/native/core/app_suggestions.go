package core

import (
	"context"
	"errors"
	"sort"
	"strings"
	"sync"
	"time"
)

// 联想搜索。老版本靠红果的搜索联想接口给所有站源供词，2.0 没有红果了，
// 于是这里补一条通用兜底：站源自己实现了 suggestions 就用它，否则拿它
// 的搜索接口跑一遍关键词，把命中的剧名当成联想词返回。
//
// 只回「看起来像剧名」的短词（太长的是标题党，当联想词没有意义），
// 并按「以关键词开头 > 包含关键词 > 其它」排一下，最多 10 条。
const (
	nativeSuggestionLimit  = 10
	nativeSuggestionRunes  = 24
	nativeSuggestionBudget = 8 * time.Second
)

func (engine *nativeEngine) suggestions(ctx context.Context, source, query string) ([]string, error) {
	query = strings.TrimSpace(query)
	if query == "" {
		return []string{}, nil
	}
	source = canonicalProviderSource(source)
	p, ok := engine.downloader.provider(source)
	if !ok {
		return nil, errors.New("请选择有效站源")
	}
	if suggester, ok := providerAs[Suggester](p); ok {
		budget, cancel := context.WithTimeout(ctx, nativeSuggestionBudget)
		defer cancel()
		if items, err := suggester.Suggestions(budget, query); err == nil && len(items) > 0 {
			return nativeCleanSuggestions(items, query), nil
		}
	}
	return engine.searchSuggestions(ctx, source, query)
}

// searchSuggestions 用站源搜索接口反推联想词。
func (engine *nativeEngine) searchSuggestions(ctx context.Context, source, query string) ([]string, error) {
	items, _, err := engine.searchFirstPage(ctx, source, query)
	if err != nil {
		return []string{}, err
	}
	titles := make([]string, 0, len(items))
	for _, item := range items {
		titles = append(titles, item.Title)
	}
	return nativeCleanSuggestions(titles, query), nil
}

// searchFirstPage 只取搜索结果，供联想搜索和全站搜索复用。
func (engine *nativeEngine) searchFirstPage(ctx context.Context, source, query string) ([]LibraryDrama, bool, error) {
	source = canonicalProviderSource(source)
	if !registeredProviderSource(source) {
		return nil, false, errors.New("请选择有效站源")
	}
	p, ok := engine.downloader.provider(source)
	if !ok {
		return nil, false, errors.New("请选择有效站源")
	}
	budget, cancel := context.WithTimeout(ctx, nativeSuggestionBudget)
	defer cancel()
	var items []Drama
	var more bool
	var err error
	switch searcher := p.(type) {
	case WarningSearcher:
		items, more, _, err = searcher.SearchWithWarning(budget, 1, query)
	case Searcher:
		items, more, err = searcher.Search(budget, 1, query)
	default:
		return nil, false, errors.New("该站源不支持在线搜索")
	}
	if err != nil {
		return nil, false, err
	}
	normalized := make([]LibraryDrama, 0, len(items))
	for _, drama := range items {
		normalized = append(normalized, NativeNormalize(drama))
	}
	return normalized, more, nil
}

// nativeCleanSuggestions 去重、截断、按与关键词的贴合度排序。
func nativeCleanSuggestions(raw []string, query string) []string {
	keyword := NativeSearchText(query)
	seen := map[string]bool{}
	type scored struct {
		text  string
		score int
		order int
	}
	rows := make([]scored, 0, len(raw))
	for index, item := range raw {
		text := strings.TrimSpace(item)
		if text == "" || len([]rune(text)) > nativeSuggestionRunes {
			continue
		}
		key := NativeSearchText(text)
		if key == "" || seen[key] || key == keyword {
			continue
		}
		seen[key] = true
		score := 1
		switch {
		case strings.HasPrefix(key, keyword):
			score = 3
		case strings.Contains(key, keyword):
			score = 2
		}
		rows = append(rows, scored{text: text, score: score, order: index})
	}
	sort.SliceStable(rows, func(i, j int) bool {
		if rows[i].score != rows[j].score {
			return rows[i].score > rows[j].score
		}
		return rows[i].order < rows[j].order
	})
	out := make([]string, 0, nativeSuggestionLimit)
	for _, row := range rows {
		out = append(out, row.text)
		if len(out) >= nativeSuggestionLimit {
			break
		}
	}
	return out
}

// nativeSearchAllIssue 记录某个站源在全站搜索里失败的原因。
type nativeSearchAllIssue struct {
	Source string `json:"source"`
	Name   string `json:"name"`
	Error  string `json:"error"`
}

type nativeSearchAllResult struct {
	Items  []LibraryDrama         `json:"items"`
	Issues []nativeSearchAllIssue `json:"issues,omitempty"`
	Total  int                    `json:"total"`
}

// nativeSearchAll 并发在所有支持的站源里搜同一个关键词，按相关度合并。
// 单个站源失败只记录下来，不影响其它站源的结果。
func (engine *nativeEngine) nativeSearchAll(ctx context.Context, query string) (nativeSearchAllResult, error) {
	query = strings.TrimSpace(query)
	if query == "" {
		return nativeSearchAllResult{}, errors.New("请输入搜索关键词")
	}
	type target struct {
		id   string
		name string
	}
	var targets []target
	for _, descriptor := range registeredDescriptors() {
		if !nativeSourceAvailable(descriptor.ID) {
			continue
		}
		p, ok := engine.downloader.provider(descriptor.ID)
		if !ok {
			continue
		}
		if _, ok := providerAs[WarningSearcher](p); !ok {
			if _, ok := providerAs[Searcher](p); !ok {
				continue
			}
		}
		targets = append(targets, target{id: descriptor.ID, name: descriptor.Name})
	}
	if len(targets) == 0 {
		return nativeSearchAllResult{}, errors.New("没有支持在线搜索的站源")
	}
	ctx, cancel := context.WithTimeout(ctx, 25*time.Second)
	defer cancel()
	results := make([][]LibraryDrama, len(targets))
	issues := make([]nativeSearchAllIssue, 0, 2)
	var mu sync.Mutex
	var wg sync.WaitGroup
	for index, item := range targets {
		wg.Add(1)
		go func(index int, id, name string) {
			defer wg.Done()
			items, _, err := engine.searchFirstPage(ctx, id, query)
			if err != nil {
				mu.Lock()
				issues = append(issues, nativeSearchAllIssue{Source: id, Name: name, Error: PublicError(err).Error()})
				mu.Unlock()
				return
			}
			results[index] = items
		}(index, item.id, item.name)
	}
	wg.Wait()
	merged := NativeMergeSearch(results, query)
	sort.SliceStable(issues, func(i, j int) bool { return issues[i].Source < issues[j].Source })
	return nativeSearchAllResult{Items: merged, Issues: issues, Total: len(targets)}, nil
}
