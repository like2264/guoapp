package core

import (
	"sort"
	"strings"
)

// 精准搜索：站源的搜索接口是「标题/简介/标签里出现过就算命中」的宽匹配，
// 搜「总裁」会带出大量只在简介里提一句、甚至只是同字不同词的剧。
//
// 这里在搜索出口统一做一次相关度分级：
//
//	标题完全相同 > 标题以关键词开头 > 标题包含关键词 >
//	标题拆词全命中 > 标题字序命中 > 标签/分类命中 > 仅简介命中 > 完全不命中（剔除）
//
// 排序稳定，同分保持站源原本的顺序。
//
// 关键约束：只排序、不做「宁可错杀」的过滤。站点把结果分页给过来时，某一页
// 全是宽匹配很正常，一旦整页被剔掉，客户端就会以为「搜不到」——之前黄果视频
// 搜不到全部相关作品就是这么来的。所以整页都被判成不相关时原样返回。
type searchRelevance int

const (
	searchRelevanceNone searchRelevance = iota
	searchRelevanceIntro
	searchRelevanceMeta
	searchRelevanceLoose
	searchRelevanceFuzzy
	searchRelevanceContains
	searchRelevancePrefix
	searchRelevanceExact
)

type scoredDrama struct {
	drama LibraryDrama
	score searchRelevance
	order int
}

// NativePreciseSearch 按相关度重排搜索结果，并剔除完全不相关的条目。
func NativePreciseSearch(items []LibraryDrama, query string) []LibraryDrama {
	scored := nativeScoredSearch(items, query)
	if len(scored) == 0 {
		// 整页都被判成不相关：宁可原样返回，也不要让用户以为没有结果。
		return items
	}
	out := make([]LibraryDrama, 0, len(scored))
	for _, entry := range scored {
		out = append(out, entry.drama)
	}
	return out
}

// nativeScoredSearch 返回按相关度排好序（分数高在前）的条目。
// 分数为 0 的条目会被丢弃；整页都是 0 分时返回 nil，由调用方决定怎么兜底。
func nativeScoredSearch(items []LibraryDrama, query string) []scoredDrama {
	keyword := NativeSearchText(query)
	if keyword == "" || len(items) == 0 {
		return nil
	}
	words := nativeSearchWords(query)
	scored := make([]scoredDrama, 0, len(items))
	for index, item := range items {
		score := nativeDramaRelevance(item, keyword, words)
		if score == searchRelevanceNone {
			continue
		}
		scored = append(scored, scoredDrama{drama: item, score: score, order: index})
	}
	if len(scored) == 0 {
		return nil
	}
	sort.SliceStable(scored, func(i, j int) bool {
		if scored[i].score != scored[j].score {
			return scored[i].score > scored[j].score
		}
		return scored[i].order < scored[j].order
	})
	return scored
}

// NativeMergeSearch 把多个站源的结果按同一套相关度合并成一页。
// 全站搜索用它排序：先比相关度，再比站源顺序，最后保持各站源原本的先后。
func NativeMergeSearch(groups [][]LibraryDrama, query string) []LibraryDrama {
	total := 0
	for _, group := range groups {
		total += len(group)
	}
	if total == 0 {
		return nil
	}
	type ranked struct {
		drama LibraryDrama
		score searchRelevance
		group int
		order int
	}
	rows := make([]ranked, 0, total)
	for group, items := range groups {
		scored := nativeScoredSearch(items, query)
		if scored == nil {
			// 该站源整页都对不上关键词，仍保留在末尾，避免漏掉相关作品。
			for index, item := range items {
				rows = append(rows, ranked{drama: item, score: searchRelevanceIntro, group: group, order: index})
			}
			continue
		}
		for _, entry := range scored {
			rows = append(rows, ranked{drama: entry.drama, score: entry.score, group: group, order: entry.order})
		}
	}
	sort.SliceStable(rows, func(i, j int) bool {
		if rows[i].score != rows[j].score {
			return rows[i].score > rows[j].score
		}
		if rows[i].group != rows[j].group {
			return rows[i].group < rows[j].group
		}
		return rows[i].order < rows[j].order
	})
	out := make([]LibraryDrama, 0, len(rows))
	seen := map[string]bool{}
	for _, row := range rows {
		if row.drama.ID != "" && seen[row.drama.ID] {
			continue
		}
		seen[row.drama.ID] = true
		out = append(out, row.drama)
	}
	return out
}

func nativeSearchWords(query string) []string {
	raw := strings.FieldsFunc(query, func(r rune) bool {
		return r == ' ' || r == '\t' || r == '\n' || r == '\r' || r == '　'
	})
	words := make([]string, 0, len(raw))
	seen := map[string]bool{}
	for _, word := range raw {
		word = NativeSearchText(word)
		if word == "" || seen[word] {
			continue
		}
		seen[word] = true
		words = append(words, word)
	}
	return words
}

func nativeDramaRelevance(item LibraryDrama, keyword string, words []string) searchRelevance {
	title := NativeSearchText(item.Title)
	if title != "" {
		switch {
		case title == keyword:
			return searchRelevanceExact
		case strings.HasPrefix(title, keyword):
			return searchRelevancePrefix
		case strings.Contains(title, keyword):
			return searchRelevanceContains
		}
		if len(words) > 1 && nativeContainsAll(title, words) {
			return searchRelevanceFuzzy
		}
		for _, word := range words {
			if len([]rune(word)) >= 2 && strings.Contains(title, word) {
				return searchRelevanceLoose
			}
		}
	}
	for _, value := range append([]string{item.Category}, item.Tags...) {
		if value = NativeSearchText(value); value != "" && strings.Contains(value, keyword) {
			return searchRelevanceMeta
		}
	}
	description := NativeSearchText(item.Description)
	if strings.Contains(description, keyword) {
		return searchRelevanceIntro
	}
	for _, word := range words {
		if len([]rune(word)) >= 2 && strings.Contains(description, word) {
			return searchRelevanceIntro
		}
	}
	return searchRelevanceNone
}

func nativeContainsAll(text string, words []string) bool {
	for _, word := range words {
		if !strings.Contains(text, word) {
			return false
		}
	}
	return true
}
