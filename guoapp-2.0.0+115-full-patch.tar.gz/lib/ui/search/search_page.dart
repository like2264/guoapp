import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core_bridge.dart';
import '../../drama_feed.dart';
import '../../local_store.dart';
import '../../models.dart';
import '../../source_catalog.dart';
import '../app_scope.dart';
import '../detail/detail_page.dart';
import '../shell/app_shell.dart';
import '../theme/motion.dart';
import '../widgets/drama_grid.dart';
import '../widgets/follow_button.dart';
import '../widgets/focus_ring.dart';
import '../widgets/motion/motion_widgets.dart';
import '../widgets/search_field.dart';
import '../widgets/status_view.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({
    super.key,
    required this.store,
    required this.source,
    this.query = '',
    this.allSources = false,
  });
  final LocalStore store;
  final SourceSite source;
  final String query;

  /// 打开时是否直接进「全站源搜索」。发现页的放大镜旁边那个按钮用它。
  final bool allSources;

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  late final _controller = TextEditingController(text: widget.query);
  final _focus = FocusNode();
  late AppRepository _repository;
  late SourceCatalog _catalog;
  DramaFeed? _results;
  String _submitted = '';
  List<String> _suggestions = const [];
  List<SourceSearchIssue> _issues = const [];
  Timer? _debounce;
  int _suggestion = 0;
  final _shownSuggestions = <Object>{};
  bool _ready = false;
  late bool _allSources = widget.allSources;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_ready) return;
    _ready = true;
    _repository = AppScope.of(context).repository;
    _catalog = SourceCatalog(_repository, widget.source);
    if (widget.query.trim().isNotEmpty) _submit(widget.query);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _suggestion++;
    unawaited(_repository.cancelSuggestions());
    unawaited(_repository.cancelCatalog());
    _results?.dispose();
    _controller.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _forget(String query) {
    unawaited(HapticFeedback.selectionClick());
    unawaited(widget.store.forgetSearch(query).catchError((Object _) {}));
  }

  void _scope(bool allSources) {
    if (allSources == _allSources) return;
    unawaited(HapticFeedback.selectionClick());
    final previous = _results;
    setState(() {
      _allSources = allSources;
      _results = null;
      _issues = const [];
      _submitted = '';
    });
    previous?.dispose();
    final query = _controller.text.trim();
    if (query.isNotEmpty) _submit(query);
  }

  /// 全站搜索的取数：native 侧并发跑所有站源，再按相关度合并成一页。
  Future<CatalogPage> _searchAll(String query, int page) async {
    if (page > 1) return CatalogPage(const [], hasMore: false);
    final result = await _repository.searchAll(query);
    _issues = result.issues;
    return CatalogPage(
      result.items,
      hasMore: false,
      warning: result.warning,
    );
  }

  void _submit(String text) {
    final query = text.trim();
    if (query.isEmpty) return;
    _controller.text = query;
    _focus.unfocus();
    _debounce?.cancel();
    _suggestion++;
    unawaited(widget.store.rememberSearch(query).catchError((Object _) {}));
    _results?.dispose();
    final all = _allSources;
    _issues = const [];
    final results = _results = DramaFeed(
      load: (page, _) => all
          ? _searchAll(query, page)
          : _catalog.search(query, page: page),
    )..addListener(() {
      if (mounted) setState(() {});
    });
    unawaited(results.reload());
    setState(() {
      _submitted = query;
      _suggestions = const [];
    });
  }

  void _changed(String text) {
    _debounce?.cancel();
    final query = text.trim();
    final generation = ++_suggestion;
    if (!widget.source.searchSuggestions || query.isEmpty) {
      setState(() => _suggestions = const []);
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 250), () async {
      try {
        final items = await _repository.suggestions(widget.source.id, query);
        if (mounted && generation == _suggestion) {
          setState(() => _suggestions = items);
        }
      } catch (_) {}
    });
  }

  void _open(Drama drama) => openPage<void>(
    context,
    (_) => DetailPage(store: widget.store, drama: drama),
  );

  @override
  Widget build(BuildContext context) {
    final field = SearchField(
      hint: _allSources ? '全站搜索剧名' : '在 ${widget.source.name} 中搜索',
      controller: _controller,
      focusNode: _focus,
      autofocus: widget.query.isEmpty,
      onChanged: _changed,
      onSubmitted: _submit,
      letterKeyboard: widget.store.televisionKeyboard,
      matches: widget.source.searchSuggestions
          ? (query) => _repository.suggestions(widget.source.id, query)
          : null,
    );
    final scopeBar = _ScopeBar(
      allSources: _allSources,
      sourceName: widget.source.name,
      onChanged: _scope,
    );
    if (AppScope.of(context).television) {
      return Scaffold(
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                televisionInset,
                27,
                televisionInset,
                0,
              ),
              child: field,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                televisionInset,
                8,
                televisionInset,
                0,
              ),
              child: scopeBar,
            ),
            Expanded(child: FadeSwitcher(child: _body(context))),
          ],
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Padding(padding: const EdgeInsets.only(right: 16), child: field),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(44),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
            child: scopeBar,
          ),
        ),
      ),
      body: SafeArea(
        top: false,
        bottom: false,
        child: FadeSwitcher(child: _body(context)),
      ),
    );
  }

  Widget _body(BuildContext context) {
    final television = AppScope.of(context).television;
    if (_suggestions.isNotEmpty && _controller.text.trim() != _submitted) {
      return ListView(
        key: const ValueKey('suggest'),
        padding: television
            ? const EdgeInsets.fromLTRB(televisionInset, 8, televisionInset, 27)
            : const EdgeInsets.symmetric(vertical: 8),
        children: [
          for (final (index, item) in _suggestions.indexed)
            EnterOnce(
              key: ValueKey(index),
              id: item,
              played: _shownSuggestions,
              index: index,
              child: TileFocus(
                builder: (focusNode) => ListTile(
                  focusNode: focusNode,
                  leading: const Icon(Icons.search_rounded),
                  title: Text(item),
                  onTap: () => _submit(item),
                ),
              ),
            ),
        ],
      );
    }
    final results = _results;
    if (results == null) {
      return KeyedSubtree(
        key: const ValueKey('recent'),
        child: _recent(context),
      );
    }
    if (results.items.isEmpty) {
      if (results.loading) {
        return StatusView.loading(
          key: const ValueKey('loading'),
          title: _allSources ? '正在全站搜索' : '正在搜索',
        );
      }
      if (results.error.isNotEmpty) {
        return StatusView(
          key: const ValueKey('error'),
          title: '搜索失败',
          message: results.error,
          icon: Icons.cloud_off_rounded,
          action: '重试',
          onAction: () => results.reload(),
        );
      }
      return StatusView(
        key: const ValueKey('empty'),
        title: '没有找到「$_submitted」',
        message: _allSources ? '换个关键词，或稍后重试' : '换个关键词试试',
        icon: Icons.search_off_rounded,
      );
    }
    final inset = television
        ? televisionInset
        : AppScope.formFactorOf(context) == FormFactor.phone
        ? 16.0
        : 24.0;
    return LayoutBuilder(
      key: ValueKey(('results', _submitted, _allSources)),
      builder: (context, constraints) => AutoLoadMore(
        feed: results,
        child: CustomScrollView(
          slivers: [
            if (_allSources && _issues.isNotEmpty)
              SliverPadding(
                padding: EdgeInsets.fromLTRB(inset, 4, inset, 0),
                sliver: SliverToBoxAdapter(child: _IssueNote(_issues)),
              ),
            SliverPadding(
              padding: EdgeInsets.fromLTRB(
                inset,
                television ? 16 : 8,
                inset,
                0,
              ),
              sliver: DramaSliverGrid(
                width: constraints.maxWidth - inset * 2,
                items: results.items,
                autofocus: television,
                heroScope: 'drama',
                subtitleOf: _allSources
                    ? (drama) => SourceSite.byId(drama.source).name
                    : null,
                onOpen: _open,
                onMore: (drama) => quickFollow(context, widget.store, drama),
              ),
            ),
            SliverPadding(
              padding: EdgeInsets.fromLTRB(
                inset,
                8,
                inset,
                television ? 27 : 16,
              ),
              sliver: SliverToBoxAdapter(child: FeedFooter(feed: results)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _recent(BuildContext context) => ListenableBuilder(
    listenable: widget.store,
    builder: (context, _) {
      final recent = widget.store.recentSearches;
      return FadeSwitcher(child: _recentContent(context, recent));
    },
  );

  Widget _recentContent(BuildContext context, List<String> recent) {
    if (recent.isEmpty) {
      return StatusView(
        key: const ValueKey('empty'),
        title: _allSources ? '全站源搜索' : '在 ${widget.source.name} 中搜索',
        message: _allSources ? '一次搜完所有已安装站源' : '输入剧名或关键词',
        icon: Icons.search_rounded,
      );
    }
    final theme = Theme.of(context);
    return ListView(
      key: const ValueKey('recent'),
      padding: AppScope.of(context).television
          ? const EdgeInsets.fromLTRB(televisionInset, 8, televisionInset, 27)
          : const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                '最近搜索',
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            FocusRing(
              radius: 999,
              child: TextButton(
                onPressed: () => widget.store.clearRecentSearches().catchError(
                  (Object _) {},
                ),
                child: const Text('清空'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        AnimatedSize(
          duration: Motion.of(context, Motion.medium),
          curve: Motion.enter,
          alignment: Alignment.topLeft,
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final query in recent)
                FocusRing(
                  radius: 8,
                  child: GestureDetector(
                    onLongPress: () => _forget(query),
                    onSecondaryTap: () => _forget(query),
                    child: ActionChip(
                      avatar: const Icon(Icons.history_rounded, size: 16),
                      label: Text(query),
                      onPressed: () => _submit(query),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

/// 「本站在线 / 全站源」切换。全站源搜索是 2.0 新加的：
/// 一次把关键词发给所有在线搜索站源，再按相关度合并。
class _ScopeBar extends StatelessWidget {
  const _ScopeBar({
    required this.allSources,
    required this.sourceName,
    required this.onChanged,
  });
  final bool allSources;
  final String sourceName;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) => Row(
    spacing: 8,
    children: [
      ChoiceChip(
        label: Text('本站在线'),
        avatar: const Icon(Icons.public_rounded, size: 16),
        selected: !allSources,
        onSelected: (_) => onChanged(false),
      ),
      ChoiceChip(
        label: const Text('全站源'),
        avatar: const Icon(Icons.travel_explore_rounded, size: 16),
        selected: allSources,
        onSelected: (_) => onChanged(true),
      ),
      Expanded(
        child: Text(
          allSources ? '一次搜完所有已安装站源' : '只在 $sourceName 里搜',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.right,
          style: TextStyle(
            fontSize: 12,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ),
    ],
  );
}

class _IssueNote extends StatelessWidget {
  const _IssueNote(this.issues);
  final List<SourceSearchIssue> issues;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(
        '${issues.length} 个站源没搜到：${issues.map((issue) => issue.name).join('、')}',
        style: TextStyle(fontSize: 12, color: colors.onSurfaceVariant),
      ),
    );
  }
}
