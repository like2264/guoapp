package core

import (
	"bytes"
	"encoding/json"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const nativeCatalogTTL = 15 * time.Minute

const nativeProviderStatesFile = "provider-states.json"

type nativeCatalogState struct {
	UpdatedAt time.Time `json:"updatedAt"`
	Page      int       `json:"page"`
	HasMore   bool      `json:"hasMore"`
	Warning   string    `json:"warning,omitempty"`
	// 站源目录的作品总量（部）。缓存在这里，切站源时不必先联网就能显示上次的数字。
	Total int `json:"total,omitempty"`
}

type nativeCatalogDisk struct {
	Version         int                                  `json:"version"`
	Modules         map[string]string                    `json:"modules,omitempty"`
	Catalogs        map[string][]LibraryDrama            `json:"catalogs"`
	States          map[string]nativeCatalogState        `json:"states"`
	Categories      map[string][]Category                `json:"categories,omitempty"`
	HongguoApp      json.RawMessage                      `json:"hongguoApp,omitempty"`
	ProviderStates  map[string]json.RawMessage           `json:"providerStates,omitempty"`
	Recommendations map[string]nativeRecommendationState `json:"recommendations,omitempty"`
}

func (engine *nativeEngine) commitProviderStateLocked(source string) {
	source, _, _ = strings.Cut(source, "|")
	p, ok := engine.downloader.provider(source)
	if !ok {
		return
	}
	stateful, ok := providerAs[CatalogStateful](p)
	if !ok {
		return
	}
	if engine.providerStates == nil {
		engine.providerStates = map[string]json.RawMessage{}
	}
	if raw := stateful.CatalogState(); len(raw) > 0 {
		engine.providerStates[p.Descriptor().ID] = raw
	} else {
		delete(engine.providerStates, p.Descriptor().ID)
	}
}

func (engine *nativeEngine) restoreProviderStates(disk nativeCatalogDisk) {
	if engine.downloader == nil {
		return
	}
	states := disk.ProviderStates
	if _, ok := states["hongguo"]; !ok && len(disk.HongguoApp) > 0 {
		if states == nil {
			states = map[string]json.RawMessage{}
		}
		states["hongguo"] = disk.HongguoApp
	}
	if body, err := os.ReadFile(filepath.Join(engine.directory, nativeProviderStatesFile)); err == nil {
		var saved map[string]json.RawMessage
		if json.Unmarshal(body, &saved) == nil {
			states, engine.providerStatesSaved = saved, body
		}
	}
	defer engine.writeProviderStatesLocked()
	for source, raw := range states {
		if p, ok := engine.downloader.provider(source); ok {
			if stateful, ok := providerAs[CatalogStateful](p); ok {
				stateful.RestoreCatalogState(raw)
				engine.commitProviderStateLocked(source)
			}
		}
	}
}

func (engine *nativeEngine) writeProviderStatesLocked() error {
	body, err := json.Marshal(engine.providerStates)
	if err != nil || len(engine.providerStates) == 0 || bytes.Equal(body, engine.providerStatesSaved) {
		return err
	}
	if err = nativeDownloadWrite(filepath.Join(engine.directory, nativeProviderStatesFile), body); err == nil {
		engine.providerStatesSaved = body
	}
	return err
}

func (engine *nativeEngine) loadCatalogCache() {
	var legacyStates nativeCatalogDisk
	defer func() { engine.restoreProviderStates(legacyStates) }()
	file, err := os.Open(filepath.Join(engine.cacheDirectory, "catalogs.json"))
	if err != nil {
		return
	}
	defer file.Close()
	body, err := io.ReadAll(io.LimitReader(file, nativeCatalogMaxBytes+1))
	if err != nil || len(body) > nativeCatalogMaxBytes {
		return
	}
	var disk nativeCatalogDisk
	// 4 之前的磁盘缓存是按「站源每页 20 条」记的页码：剧果改成 60 条/页、
	// 91短剧改成 100 条/页 之后，旧页码指向的已经是别的条目，接着往下翻会整段漏掉。
	// 这几版的目录和页码一律不恢复（重拉一页就补齐），设备号这些仍照旧迁移。
	if json.Unmarshal(body, &disk) == nil && (disk.Version == 2 || disk.Version == 3 || disk.Version == 4 || disk.Version == 5) {
		if disk.Version >= 4 {
			if disk.Catalogs != nil {
				engine.catalogs = disk.Catalogs
				trimNativeCatalogs(engine.catalogs)
				for _, items := range engine.catalogs {
					for index := range items {
						items[index] = migrateNativeDrama(items[index])
					}
				}
			}
			if disk.States != nil {
				engine.catalogStates = disk.States
			}
		}
		engine.categoryOptions = disk.Categories
		engine.recommendations = make(map[string]nativeRecommendationState)
		for key, state := range disk.Recommendations {
			source, genre, current := strings.Cut(key, "|recommendation:")
			if !current {
				source, genre = "hongguo", key
			}
			if recommender, err := engine.recommender(source); err == nil && state.Page > 0 && recommender.ValidRecommendation(genre, state.Query) == nil {
				engine.recommendations[nativeRecommendationKey(source, genre)] = state
			}
		}
		legacyStates = nativeCatalogDisk{HongguoApp: disk.HongguoApp, ProviderStates: disk.ProviderStates}
		engine.dropStaleModuleCaches(disk)
		return
	}
	var legacy map[string][]LibraryDrama
	if json.Unmarshal(body, &legacy) == nil && legacy != nil {
		engine.catalogs = legacy
		trimNativeCatalogs(engine.catalogs)
		for _, items := range engine.catalogs {
			for index := range items {
				items[index] = migrateNativeDrama(items[index])
			}
		}
	}
}

// ---- 模块换版 → 该站的目录缓存作废 ------------------------------------------
//
// catalogs.json 里存着上一版模块拉回来的卡片。模块换了代，这些卡片就不成立，
// 而 saveCatalogCache 在 page == 1 时会把「本页没出现的旧卡片」整段补回去：
// 夜社 1.0.5 的「全部」是 6+16 两栏（两万条混排，混着国产短剧和 AI 漫剧），
// 1.0.6 改成 1+4 两栏（3,028 条）后，旧卡片会被补回来、分类也继续走旧白名单，
// 用户看到的就是「模块白装了」。所以按「站源 → 模块版本」判定：版本对不上就把
// 该站的目录、页码、分类、推荐一起丢掉，让下一屏重新从第 1 页拉。
// 没有模块的站（红果、黄豆这类 Go 站源）读不到 manifest，这里直接跳过。

func (engine *nativeEngine) moduleVersion(source string) string {
	d := engine.downloader
	if d == nil {
		return ""
	}
	raw, err := os.ReadFile(filepath.Join(d.moduleRoot(), source, moduleManifest))
	if err != nil {
		return ""
	}
	var manifest struct {
		Version string `json:"version"`
	}
	if json.Unmarshal(raw, &manifest) != nil {
		return ""
	}
	return strings.TrimSpace(manifest.Version)
}

func (engine *nativeEngine) dropSourceCachesLocked(source string) {
	if source == "" {
		return
	}
	for key := range engine.catalogs {
		if key == source || strings.HasPrefix(key, source+"|") {
			delete(engine.catalogs, key)
		}
	}
	for key := range engine.catalogStates {
		if key == source || strings.HasPrefix(key, source+"|") {
			delete(engine.catalogStates, key)
		}
	}
	delete(engine.categoryOptions, source)
	for key := range engine.recommendations {
		if strings.HasPrefix(key, source+"|") {
			delete(engine.recommendations, key)
		}
	}
}

// 启动恢复磁盘缓存后调用：只清「模块版本变了」的站。
// 4 及更早的磁盘缓存没有记模块版本，一律按「版本未知」处理 —— 宁可重拉一页。
func (engine *nativeEngine) dropStaleModuleCaches(disk nativeCatalogDisk) {
	engine.mu.Lock()
	defer engine.mu.Unlock()
	if engine.moduleVersions == nil {
		engine.moduleVersions = map[string]string{}
	}
	sources := map[string]bool{}
	for key := range engine.catalogs {
		base, _, _ := strings.Cut(key, "|")
		sources[base] = true
	}
	for key := range engine.catalogStates {
		base, _, _ := strings.Cut(key, "|")
		sources[base] = true
	}
	for key := range engine.categoryOptions {
		sources[key] = true
	}
	for source := range sources {
		current := engine.moduleVersion(source)
		if current == "" {
			continue
		}
		engine.moduleVersions[source] = current
		if disk.Version >= 5 && disk.Modules[source] == current {
			continue
		}
		engine.dropSourceCachesLocked(source)
	}
}

// 装 / 换模块后立刻清掉这一站的旧目录，用户不用重启 App 就能看到新模块的形状。
func (engine *nativeEngine) invalidateModuleCache(source string) {
	engine.mu.Lock()
	defer engine.mu.Unlock()
	if engine.moduleVersions == nil {
		engine.moduleVersions = map[string]string{}
	}
	if version := engine.moduleVersion(source); version != "" {
		engine.moduleVersions[source] = version
	}
	engine.dropSourceCachesLocked(source)
	_ = engine.writeCatalogDiskLocked()
}

func trimNativeCatalogs(catalogs map[string][]LibraryDrama) {
	for key, items := range catalogs {
		if len(items) > nativeCatalogMaxItems {
			catalogs[key] = append([]LibraryDrama(nil), items[:nativeCatalogMaxItems]...)
		}
	}
}

func migrateNativeDrama(drama LibraryDrama) LibraryDrama {
	if drama.MetadataSchema == 0 && drama.Source == "huangdou" && drama.VIP != nil && !*drama.VIP {
		drama.VIP = nil
	}
	drama.MetadataSchema = 1
	return drama
}

func (engine *nativeEngine) nativeCached(source string) nativeCatalogResult {
	source = canonicalProviderSource(source)
	engine.mu.Lock()
	defer engine.mu.Unlock()
	items := append([]LibraryDrama{}, engine.catalogs[source]...)
	for index := range items {
		items[index].Cover = engine.downloader.repairCover(items[index])
	}
	state, found := engine.catalogStates[source]
	age := time.Since(state.UpdatedAt)
	result := nativeCatalogResult{
		Items: items, Page: max(1, state.Page), HasMore: !found || state.HasMore,
		Fresh:   len(items) > 0 && state.Warning == "" && !state.UpdatedAt.IsZero() && age >= 0 && age < nativeCatalogTTL,
		Warning: state.Warning,
		Total:   state.Total,
	}
	if engine.catalogSaveError != nil {
		result.Warning = joinNativeWarnings(result.Warning, engine.catalogSaveError.Error())
		result.saveError = engine.catalogSaveError
		result.Fresh, result.HasMore = false, true
	}
	return result
}

func mergeNativeCatalog(first, second []LibraryDrama) []LibraryDrama {
	items := append([]LibraryDrama{}, first...)
	indices := make(map[string]int, len(items))
	for index, item := range items {
		indices[item.ID] = index
	}
	for _, item := range second {
		if index, found := indices[item.ID]; found {
			items[index] = MergeNativeDrama(items[index], item)
		} else {
			indices[item.ID] = len(items)
			items = append(items, item)
		}
	}
	return items
}

func MergeNativeDrama(previous, fresh LibraryDrama) LibraryDrama {
	previous, fresh = migrateNativeDrama(previous), migrateNativeDrama(fresh)
	if previous.ID != "" && fresh.ID != previous.ID {
		return fresh
	}
	if fresh.Source == "" {
		fresh.Source = previous.Source
	}
	if fresh.SourceID == "" {
		fresh.SourceID = previous.SourceID
	}
	if fresh.Title == "" || fresh.Title == "短剧" {
		fresh.Title = previous.Title
	}
	if fresh.Description == "" {
		fresh.Description = previous.Description
	}
	if fresh.Cover == "" {
		fresh.Cover = previous.Cover
	}
	if fresh.Category == "" || nativeGenericCategory(fresh.Category) && previous.Category != "" && !nativeGenericCategory(previous.Category) {
		fresh.Category = previous.Category
	}
	if fresh.Episodes == 0 {
		fresh.Episodes = previous.Episodes
	}
	if fresh.VIP == nil {
		fresh.VIP = previous.VIP
	}
	if fresh.Heat == "" {
		fresh.Heat = previous.Heat
	}
	if fresh.Views == "" {
		fresh.Views = previous.Views
	}
	if fresh.OnlineDate == "" {
		fresh.OnlineDate = previous.OnlineDate
	}
	if fresh.Score == "" {
		fresh.Score = previous.Score
	}
	if len(fresh.Tags) == 0 {
		fresh.Tags = previous.Tags
	}
	if fresh.ReleaseStatus == "" || fresh.ReleaseStatus == "unknown" {
		fresh.ReleaseStatus = previous.ReleaseStatus
	}
	if fresh.Badge == "" {
		fresh.Badge = previous.Badge
	}
	return fresh
}

func nativeGenericCategory(category string) bool {
	switch category {
	case "短剧", "真人剧", "漫剧", "AI剧", "AI 剧", "AI短剧", "AI 短剧", "AI漫剧", "AI 漫剧":
		return true
	}
	return false
}

func (engine *nativeEngine) saveCatalogCache(source string, result *nativeCatalogResult) error {
	engine.mu.Lock()
	defer engine.mu.Unlock()
	previous := engine.catalogs[source]
	state := engine.catalogStates[source]
	var items []LibraryDrama
	if result.Page == 1 {
		items = result.Items
		if len(previous) > 0 {
			old := make(map[string]LibraryDrama, len(previous))
			for _, item := range previous {
				old[item.ID] = item
			}
			for index, item := range items {
				items[index] = MergeNativeDrama(old[item.ID], item)
			}
			fresh := make(map[string]bool, len(items))
			for _, item := range items {
				fresh[item.ID] = true
			}
			for _, item := range previous {
				if !fresh[item.ID] {
					items = append(items, item)
				}
			}
			result.Items = items
			result.Page = max(1, state.Page)
			descriptor, _ := registeredDescriptor(source)
			if !descriptor.ContinuousFeed && state.Page > 1 {
				result.HasMore = state.HasMore
			}
		}
	} else {
		items = mergeNativeCatalog(previous, result.Items)
		if result.Page < state.Page {
			result.Page, result.HasMore = state.Page, state.HasMore
		}
	}
	engine.catalogs[source] = items
	engine.commitProviderStateLocked(source)
	if result.Warning != "" {
		result.Page = max(1, state.Page)
		result.HasMore = true
	}
	state.Page, state.HasMore = result.Page, result.HasMore
	state.Warning = result.Warning
	if result.Total > 0 {
		state.Total = result.Total
	} else if result.Page == 1 && result.Warning == "" {
		// 第一页成功返回却没有总量：这台站源确实给不出，别留着旧数字骗人。
		state.Total = 0
	}
	if result.Warning == "" {
		state.UpdatedAt = time.Now()
		result.Fresh = true
	}
	engine.catalogStates[source] = state
	if base, _, categorized := strings.Cut(source, "|"); categorized {
		engine.catalogs[base] = mergeNativeCatalog(engine.catalogs[base], items)
	}
	err := engine.writeCatalogDiskLocked()
	result.saveError = err
	if err != nil {
		result.Warning = joinNativeWarnings(result.Warning, err.Error())
		result.Fresh, result.HasMore = false, true
	}
	return err
}

// 写盘前把「目录里出现过的站」的模块版本补齐；没有模块的站记空串（只读一次盘），
// 免得 Version 5 的缓存里 Modules 缺项、下次启动又把该站当成换过版本再清一遍。
func (engine *nativeEngine) ensureModuleVersionsLocked() {
	if engine.moduleVersions == nil {
		engine.moduleVersions = map[string]string{}
	}
	note := func(source string) {
		if source == "" {
			return
		}
		if _, ok := engine.moduleVersions[source]; ok {
			return
		}
		engine.moduleVersions[source] = engine.moduleVersion(source)
	}
	for key := range engine.catalogs {
		source, _, _ := strings.Cut(key, "|")
		note(source)
	}
	for source := range engine.categoryOptions {
		note(source)
	}
}

func (engine *nativeEngine) writeCatalogDiskLocked() error {
	trimNativeCatalogs(engine.catalogs)
	engine.ensureModuleVersionsLocked()
	body, err := json.Marshal(nativeCatalogDisk{Version: 5, Modules: engine.moduleVersions, Catalogs: engine.catalogs, States: engine.catalogStates, Categories: engine.categoryOptions, Recommendations: engine.recommendations})
	if err == nil && len(body) > nativeCatalogMaxBytes {
		err = errNativeCatalogLimit
	}
	if err == nil {
		err = writeNativeCacheFile(filepath.Join(engine.cacheDirectory, "catalogs.json"), body)
	}
	if stateErr := engine.writeProviderStatesLocked(); err == nil {
		err = stateErr
	}
	engine.catalogSaveError = nativeSaveError("剧库", err)
	return engine.catalogSaveError
}

func moveLegacyNativeCache(directory, cache string) {
	if filepath.Clean(directory) == filepath.Clean(cache) {
		return
	}
	for _, name := range []string{"catalogs.json", "rankings.json", "covers-v1"} {
		legacy, target := filepath.Join(directory, name), filepath.Join(cache, name)
		if _, err := os.Lstat(target); os.IsNotExist(err) && os.Rename(legacy, target) == nil {
			continue
		}
		_ = os.RemoveAll(legacy)
	}
}

func writeNativeCacheFile(path string, data []byte) error {
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	temporary, err := os.CreateTemp(filepath.Dir(path), ".cache-write-*")
	if err != nil {
		return err
	}
	defer os.Remove(temporary.Name())
	_, writeErr := temporary.Write(data)
	if writeErr == nil {
		writeErr = temporary.Sync()
	}
	closeErr := temporary.Close()
	if writeErr != nil {
		return writeErr
	}
	if closeErr != nil {
		return closeErr
	}
	return os.Rename(temporary.Name(), path)
}

func (engine *nativeEngine) saveDetailMetadata(drama LibraryDrama) error {
	engine.mu.Lock()
	defer engine.mu.Unlock()
	changed := false
	for _, items := range engine.catalogs {
		for index := range items {
			if items[index].ID == drama.ID {
				items[index] = MergeNativeDrama(items[index], drama)
				changed = true
			}
		}
	}
	if changed {
		return engine.writeCatalogDiskLocked()
	}
	return nil
}
