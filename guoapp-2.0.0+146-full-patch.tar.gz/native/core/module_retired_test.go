package core

import (
	"os"
	"path/filepath"
	"testing"
)

func writeModuleCopy(t *testing.T, dataDir, id, version string) {
	t.Helper()
	dir := filepath.Join(dataDir, moduleDirectory, id)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	manifest := `{"id":"` + id + `","name":"测试","version":"` + version + `","runtime":"js","api":1,"adult":false}`
	if err := os.WriteFile(filepath.Join(dir, moduleManifest), []byte(manifest), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, moduleEntry), []byte("exports.catalog = function () { return { items: [] }; };"), 0o644); err != nil {
		t.Fatal(err)
	}
}

// 黄果旧版从内置清单撤下后，老用户机器上当年装的那一份要清掉；
// 但用户自己从文件装过作者的新版（比内置最后一版新）就必须留着。
func TestRetiredBundledModuleRemovedOnlyForBuiltinCopy(t *testing.T) {
	for _, test := range []struct {
		name    string
		version string
		present bool
	}{
		{name: "内置那一版", version: "1.0.3", present: false},
		{name: "更老的残留", version: "1.0.2", present: false},
		{name: "作者的新版", version: "1.0.4", present: true},
	} {
		t.Run(test.name, func(t *testing.T) {
			dataDir := t.TempDir()
			writeModuleCopy(t, dataDir, "huangguo-old", test.version)
			(&Downloader{cfg: Config{dataDir: dataDir}}).retireBundledModulesLocked()
			_, err := os.Stat(filepath.Join(dataDir, moduleDirectory, "huangguo-old"))
			if present := err == nil; present != test.present {
				t.Fatalf("版本 %s：目录还在 = %v，期望 %v", test.version, present, test.present)
			}
		})
	}
}

// 不在退役清单里的模块一个都不许动。
func TestRetiredBundledModuleLeavesOthersAlone(t *testing.T) {
	dataDir := t.TempDir()
	writeModuleCopy(t, dataDir, "yesheai", "1.0.7")
	(&Downloader{cfg: Config{dataDir: dataDir}}).retireBundledModulesLocked()
	if _, err := os.Stat(filepath.Join(dataDir, moduleDirectory, "yesheai")); err != nil {
		t.Fatalf("夜社被误删：%v", err)
	}
}
