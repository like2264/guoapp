// 夜社（yesheai.com）：苹果 CMS 风格，没有加密接口。
//
// 列表：/filter/{type}.html，翻页 /filter/{type}/page/{n}.html，每页 30 条。
// 搜索：/vod/search/wd/{关键词}.html，翻页加 /page/{n}.html。
// 详情：/detail/{id}.html，分集是 data-episode + href="/play/{id}/1/{n}.html"。
// 播放：/play/{id}/1/{n}.html 里内联 var player_aaaa = {...}，
//       encrypt 为 0 时 url 就是 m3u8 直链，1 是 base64，2 是 base64 后再整体倒序。

var SITE = "https://yesheai.com";
var UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
var CHANNEL = "夜社";
var PAGE_SIZE = 30;
var MAX_PAGE = 10000;
var DEFAULT_TYPE = "1";

var FALLBACK_CATEGORIES = [
  { id: "1", name: "成人短剧" },
  { id: "4", name: "海外短剧" },
];

// 2.0.0+145：夜社只留「成人短剧（1）」和「海外短剧（4）」两类。
// 「短剧（6）」是站点自己的混排总库 —— 实测 /filter/6 第 50 页是 27 部海外 + 3 部国产、
// 第 100 页 30 张全是国产、末页 2 张里还有 1 部国产，拿它当「全部」根本摘不干净；
// 「国产短剧（3）」「AI 漫剧（16）」按用户要求整类去掉；
// 动漫 8/9/10/11、电影 26~29、网剧 22~24、综艺、影视解说 5 自 +144 起就不在内。
// 分类栏也按这张白名单出，用户点任何一项都不会再碰到国产短剧。
var KEEP_TYPES = { "1": true, "4": true };

var RE_ANCHOR = /<a\b([^>]*)>([\s\S]*?)<\/a>/gi;
var RE_CARD_COVER = /<img[^>]+src="([^"]+)"/i;
var RE_CARD_TYPE = /<div\s+class="type">([\s\S]*?)<\/div>/i;
var RE_CARD_INTRO = /<div\s+class="module-poster-item-intro">([\s\S]*?)<\/div>/i;
var RE_CARD_NAME = /class="module-poster-item-title"[^>]*>([\s\S]*?)</i;
var RE_EP_TEXT = /(\d+)\s*集/;
var RE_DETAIL_H1 = /class="ys-web-detail__info"[\s\S]*?<h1[^>]*>([\s\S]*?)<\/h1>/i;
var RE_DETAIL_PIC = /class="ys-web-detail__poster"[\s\S]*?<img[^>]+src="([^"]+)"/i;
var RE_DETAIL_CATE = /class="ys-web-detail__meta ys-web-detail__cate">([\s\S]*?)<\/div>/i;
var RE_DETAIL_DESC = /<p\s+class="ys-web-detail__desc"[^>]*>([\s\S]*?)<\/p>/i;
var RE_EPISODE = /data-episode="(\d+)"[^>]*href="\/play\/(\d+)\/1\/(\d+)\.html"/gi;
var RE_EPISODE_ALT = /href="\/play\/(\d+)\/1\/(\d+)\.html"[^>]*data-episode="(\d+)"/gi;
// 有的剧（尤其海外短剧）详情页压根不输出分集列表，只在 meta 里给「更新至 45 集」，
// 这时按集数合成 1..N，播放页 /play/{id}/1/{n}.html 是通的。
var RE_DETAIL_COUNT = /<span>\s*(?:更新至|全|共)\s*(\d{1,5})\s*集\s*<\/span>/i;
var RE_PLAYER = /var\s+player_aaaa\s*=\s*(\{[\s\S]*?\})\s*;?\s*<\/script>/i;
var RE_HTML_TAG = /<[^>]+>/g;
var RE_SPACES = /\s+/g;
var RE_ID = /^[1-9][0-9]{0,11}$/;
var RE_TYPE = /^[1-9][0-9]{0,5}$/;
var RE_NAV_TYPE = /<a\b[^>]*href="\/type\/(\d+)\.html"[^>]*>([\s\S]*?)<\/a>/gi;
var RE_CATE_TAG = /#([^<#]{1,16})/g;
var RE_ATTR = /\b([a-zA-Z:-]+)="([^"]*)"/g;
// 列表页分页控件里的页码链接：/filter/6/page/133.html（尾页会给到最大页码）。
var RE_PAGE_LINK = /\/page\/(\d+)\.html/gi;

function unescapeHtml(text) {
  return String(text)
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&#(\d+);/g, function (_, code) {
      return String.fromCharCode(parseInt(code, 10));
    });
}

function clean(text) {
  if (text === null || text === undefined) return "";
  var raw = unescapeHtml(String(text).replace(RE_HTML_TAG, " "));
  raw = raw.replace(/\u3000/g, " ").replace(/\u00a0/g, " ");
  return raw.replace(RE_SPACES, " ").replace(/^\s+|\s+$/g, "");
}

function clip(text, limit) {
  var value = String(text === null || text === undefined ? "" : text);
  return value.length > limit ? value.slice(0, limit) : value;
}

function attrOf(fragment, name) {
  var pattern = new RegExp('\\b' + name + '="([^"]*)"', "i");
  var match = pattern.exec(fragment);
  return match ? match[1] : "";
}

function absUrl(raw) {
  var value = String(raw || "").replace(/^\s+|\s+$/g, "");
  if (value === "") return "";
  if (value.indexOf("//") === 0) return "https:" + value;
  if (/^https?:\/\//i.test(value)) return value;
  if (value.charAt(0) === "/") return SITE + value;
  return SITE + "/" + value;
}

function textGet(path) {
  var address = path.indexOf("http") === 0 ? path : SITE + path;
  var response = host.fetchText({ url: address, referer: SITE + "/", userAgent: UA });
  return response && response.body ? response.body : "";
}

function asNumber(value, fallback) {
  var parsed = parseInt(String(value), 10);
  return isNaN(parsed) ? fallback : parsed;
}

function validId(id) {
  return RE_ID.test(String(id || "").replace(/^\s+|\s+$/g, ""));
}

function validCategory(category) {
  var value = String(category || "").replace(/^\s+|\s+$/g, "");
  return value === "" || RE_TYPE.test(value);
}

function makeDrama(sourceId, title, cover, extra) {
  var drama = {
    id: host.dramaId(sourceId),
    source: host.source,
    sourceId: sourceId,
    title: title,
    name: title,
    channelName: CHANNEL,
  };
  if (cover) {
    drama.cover = cover;
    drama.coverUrl = cover;
  }
  if (extra) {
    for (var key in extra) {
      if (Object.prototype.hasOwnProperty.call(extra, key) && extra[key] !== "" && extra[key] !== null) {
        drama[key] = extra[key];
      }
    }
  }
  if (!drama.categoryName) drama.categoryName = CHANNEL;
  return drama;
}

function listPath(category, page) {
  var type = String(category || "").replace(/^\s+|\s+$/g, "");
  if (!validCategory(type) || type === "") type = DEFAULT_TYPE;
  if (page > 1) return "/filter/" + type + "/page/" + page + ".html";
  return "/filter/" + type + ".html";
}

function searchPath(query, page) {
  var keyword = encodeURIComponent(String(query || "").replace(/^\s+|\s+$/g, ""));
  if (page > 1) return "/vod/search/wd/" + keyword + "/page/" + page + ".html";
  return "/vod/search/wd/" + keyword + ".html";
}

function parseCards(body) {
  var items = [];
  var seen = {};
  RE_ANCHOR.lastIndex = 0;
  var match;
  while ((match = RE_ANCHOR.exec(body)) !== null) {
    var attrs = match[1];
    var chunk = match[2];
    if (attrs.indexOf("module-poster-item") < 0) continue;
    var href = attrOf(attrs, "href");
    if (href.indexOf("/detail/") !== 0 || href.slice(-5) !== ".html") continue;
    var sourceId = href.slice(8, href.length - 5);
    if (!validId(sourceId) || seen[sourceId]) continue;
    var title = clean(attrOf(attrs, "title"));
    if (title === "") {
      var nameMatch = RE_CARD_NAME.exec(chunk);
      if (nameMatch) title = clean(nameMatch[1]);
    }
    if (title === "") {
      var coverMatch = RE_CARD_COVER.exec(chunk);
      if (coverMatch) title = clean(attrOf(coverMatch[0], "alt"));
    }
    if (title === "") continue;
    seen[sourceId] = true;
    var cover = "";
    var imageMatch = RE_CARD_COVER.exec(chunk);
    if (imageMatch) cover = absUrl(imageMatch[1]);
    var categoryName = "";
    var typeMatch = RE_CARD_TYPE.exec(chunk);
    if (typeMatch) categoryName = clip(clean(typeMatch[1]), 24);
    var remark = "";
    var description = "";
    var episodes = 0;
    var epMatch = RE_EP_TEXT.exec(chunk);
    if (epMatch) {
      remark = "更新至" + epMatch[1] + "集";
      var count = asNumber(epMatch[1], 0);
      if (count > 0 && count <= 100000) episodes = count;
    }
    // 卡片上本来就带着整段简介（module-poster-item-intro）。以前只取前 60 个字
    // 当角标文案用，等于把简介丢了 —— 搜索出口按「仅简介命中」分档时看不到它，
    // 结果就是只在简介里出现的作品被判成无关直接扔掉。这里把整段带上，
    // 角标仍然只用前 60 个字。
    var introMatch = RE_CARD_INTRO.exec(chunk);
    if (introMatch) {
      description = clip(clean(introMatch[1]), 800);
      if (remark === "") remark = clip(description, 60);
    }
    var extra = {
      categoryName: categoryName || CHANNEL,
      remark: remark,
      desc: description,
      intro: description,
    };
    if (episodes > 0) {
      extra.episodeCount = episodes;
      extra.totalEpisode = episodes;
    }
    items.push(makeDrama(sourceId, clip(title, 512), cover, extra));
    if (items.length >= 240) break;
  }
  return items;
}

function buildChapters(body, sourceId) {
  var chapters = [];
  var seen = {};
  var add = function (dramaId, episode) {
    var number = asNumber(episode, 0);
    if (number < 1 || number > MAX_PAGE || seen[number]) return;
    if (String(dramaId) !== String(sourceId)) return;
    seen[number] = true;
    chapters.push({
      id: host.chapterId(sourceId, String(episode)),
      source: host.source,
      title: "第" + number + "集",
      currentEpisode: number,
      videoUrl: "yesheai-play://" + episode,
      pageUrl: SITE + "/play/" + sourceId + "/1/" + episode + ".html",
      referer: SITE + "/",
    });
  };
  RE_EPISODE.lastIndex = 0;
  var match;
  while ((match = RE_EPISODE.exec(body)) !== null) add(match[2], match[3]);
  RE_EPISODE_ALT.lastIndex = 0;
  while ((match = RE_EPISODE_ALT.exec(body)) !== null) add(match[1], match[2]);
  chapters.sort(function (left, right) {
    return left.currentEpisode - right.currentEpisode;
  });
  return chapters;
}

function decodeBase64Text(raw) {
  try {
    return host.utf8Decode(host.base64Decode(raw));
  } catch (error) {
    return "";
  }
}

function decodePlayerUrl(raw, encrypt) {
  var value = String(raw || "").replace(/^\s+|\s+$/g, "");
  value = unescapeHtml(value);
  if (value === "" || encrypt === 0) return value;
  if (encrypt === 2) {
    var characters = value.split("");
    value = characters.reverse().join("");
  }
  var decoded = decodeBase64Text(value);
  if (decoded === "") return value;
  decoded = decoded.replace(/^\s+|\s+$/g, "");
  try {
    decoded = decodeURIComponent(decoded.replace(/\+/g, " "));
  } catch (error) {}
  return decoded;
}

// ---- 「全部」= 各栏目拼接 ----------------------------------------------------
//
// 站点没有跨栏目的总列表。/filter/6.html 是站点自己的「短剧」混排库，
// 里面按页混着成人 / 国产 / 海外三类（见文件头 KEEP_TYPES 的实测记录），
// 直接拿它当「全部」会漏掉用户不要的国产短剧。
// 2.0.0+145 起「全部」只拼两个纯净栏目：成人短剧（1，29 页）→ 海外短剧（4，73 页）。
// 两栏抽样（1 的第 15 页、4 的第 40 页）都是 30/30 同类卡片，没有混排。
// 每个栏目的总页数从它自己的「尾页」链接学到，末页条数单独量一次算真实总数，缓存一天。
var SECTIONS = ["1", "4"];
var SECTION_PAGES_KEY = "sections:pages";
var SECTION_LAST_KEY = "sections:last";
var SECTION_PAGES_TTL_MS = 24 * 60 * 60 * 1000;
var SECTION_PAGES_DEFAULT = {
  "1": 29,
  "4": 73,
};

function sectionPages() {
  var stored = null;
  try {
    stored = host.cacheGet(SECTION_PAGES_KEY);
  } catch (error) {
    stored = null;
  }
  var pages = {};
  var key;
  // host.cacheSet 只存字符串（传对象会被写成 "[object Object]"），所以这里
  // 先试着解析 JSON。老版本正是栽在这上面：学到的页数一次都没进过缓存，
  // 「全部」永远按默认页数收尾，尾页作品翻不到。
  if (typeof stored === "string" && stored !== "") {
    try {
      stored = JSON.parse(stored);
    } catch (error) {
      stored = null;
    }
  }
  if (stored && typeof stored === "object") {
    for (key in stored) {
      if (Object.prototype.hasOwnProperty.call(stored, key)) {
        pages[key] = asNumber(stored[key], 0);
      }
    }
  }
  for (key in SECTION_PAGES_DEFAULT) {
    if (!pages[key] || pages[key] <= 0) pages[key] = SECTION_PAGES_DEFAULT[key];
  }
  return pages;
}

function rememberSectionPages(type, count) {
  if (!count || count <= 0) return;
  var pages = sectionPages();
  if (pages[type] === count) return;
  pages[type] = count;
  try {
    host.cacheSet(SECTION_PAGES_KEY, JSON.stringify(pages), SECTION_PAGES_TTL_MS);
  } catch (error) {}
}

function lastPageOf(body) {
  RE_PAGE_LINK.lastIndex = 0;
  var last = 0;
  var found;
  while ((found = RE_PAGE_LINK.exec(body)) !== null) {
    var value = asNumber(found[1], 0);
    if (value > last && value <= MAX_PAGE) last = value;
  }
  return last;
}

// 拉某个栏目的一页，顺手把它真实的总页数记下来（免费：尾页链接就在这一页里）。
function loadSection(type, page) {
  var body = textGet(listPath(type, page));
  var items = parseCards(body);
  var last = lastPageOf(body);
  if (last > 0) rememberSectionPages(type, last);
  var pages = sectionPages();
  return { items: items, pages: pages[type], total: pages[type] * PAGE_SIZE };
}


// 缓存里四（三/两）栏的页数是否都学到了。上一次写缓存坏在传对象上，
// 用户机上一直只有默认值；只要发现缺任何一栏，开局就把各栏第一页拉一遍。
function sectionsKnown() {
  var stored = null;
  try {
    stored = host.cacheGet(SECTION_PAGES_KEY);
  } catch (error) {
    stored = null;
  }
  if (typeof stored === "string" && stored !== "") {
    try {
      stored = JSON.parse(stored);
    } catch (error) {
      stored = null;
    }
  }
  if (!stored || typeof stored !== "object") return false;
  for (var i = 0; i < SECTIONS.length; i++) {
    if (!(asNumber(stored[SECTIONS[i]], 0) > 0)) return false;
  }
  return true;
}


function sumPages(pages) {
  var total = 0;
  for (var i = 0; i < SECTIONS.length; i++) total += pages[SECTIONS[i]];
  return total;
}

// ---- 末页余数：顶栏「共 N 部」要的是真实作品数，不是页数 × 30 ----------------
//
// 站点每页 30 部，但两栏的末页都不满（成人短剧末页 22 部、海外短剧末页 6 部），
// 直接 页数 × 30 会虚高 32 部，用户滚到底会发现顶栏和最后一张卡片的序号对不上。
function sectionLast() {
  var stored = null;
  try {
    stored = host.cacheGet(SECTION_LAST_KEY);
  } catch (error) {
    stored = null;
  }
  var map = {};
  if (typeof stored === "string" && stored !== "") {
    try {
      stored = JSON.parse(stored);
    } catch (error) {
      stored = null;
    }
  }
  if (stored && typeof stored === "object") {
    for (var key in stored) {
      if (Object.prototype.hasOwnProperty.call(stored, key)) {
        var value = asNumber(stored[key], -1);
        if (value >= 0) map[key] = value;
      }
    }
  }
  return map;
}

function rememberSectionLast(type, count) {
  var value = asNumber(count, -1);
  if (value < 0 || value > PAGE_SIZE) return;
  var map = sectionLast();
  if (map[type] === value) return;
  map[type] = value;
  try {
    host.cacheSet(SECTION_LAST_KEY, JSON.stringify(map), SECTION_PAGES_TTL_MS);
  } catch (error) {}
}

// 量某栏末页有几部；学到过就直接用缓存，只有第一次真拉。
function sectionLastCount(type) {
  var map = sectionLast();
  if (typeof map[type] === "number") return map[type];
  var pages = sectionPages();
  var last = pages[type];
  if (!last || last < 1) return -1;
  try {
    var count = parseCards(textGet(listPath(type, last))).length;
    rememberSectionLast(type, count);
    return count;
  } catch (error) {
    return -1;
  }
}

function sectionTotalWith(pages, type) {
  var last = pages[type] || 0;
  if (last < 1) return 0;
  var tail = sectionLastCount(type);
  if (tail > 0) return (last - 1) * PAGE_SIZE + tail;
  return last * PAGE_SIZE;
}

function sectionTotal(type) {
  return sectionTotalWith(sectionPages(), type);
}

function allTotal(pages) {
  var total = 0;
  for (var i = 0; i < SECTIONS.length; i++) total += sectionTotalWith(pages, SECTIONS[i]);
  return total;
}

// 现场把两栏的第一页各拉一遍，学到真实页数（缓存过期或页码越界时才走）；
// 页数学到后顺手把各栏末页余数量出来，顶栏第一次就能给出准确的总数。
function refreshSectionPages() {
  for (var i = 0; i < SECTIONS.length; i++) {
    try {
      loadSection(SECTIONS[i], 1);
    } catch (error) {}
  }
  var pages = sectionPages();
  for (var j = 0; j < SECTIONS.length; j++) {
    try {
      var last = pages[SECTIONS[j]];
      if (last > 1) rememberSectionLast(SECTIONS[j], loadSection(SECTIONS[j], last).items.length);
    } catch (error) {}
  }
  return sectionPages();
}

// 「全部」第 index 页落在哪一栏的第几页；越界返回 null。
function serveAll(pages, index) {
  var remaining = index;
  for (var slot = 0; slot < SECTIONS.length; slot++) {
    var span = pages[SECTIONS[slot]];
    if (remaining > span) {
      remaining -= span;
      continue;
    }
    var section = loadSection(SECTIONS[slot], remaining);
    var learned = sectionPages();
    var totalPages = sumPages(learned);
    // 末页还满：短剧栏站点写 133 页、实际第 134 页还有 2 部，探一页把它捞回来。
    if (section.items.length >= PAGE_SIZE && index >= totalPages) {
      learned[SECTIONS[slot]] = learned[SECTIONS[slot]] + 1;
      rememberSectionPages(SECTIONS[slot], learned[SECTIONS[slot]]);
      totalPages = sumPages(sectionPages());
    }
    return { items: section.items, hasMore: index < totalPages, total: allTotal(learned) };
  }
  return null;
}

module.exports = {
  validCategory: validCategory,

  categories: function () {
    var body = "";
    try {
      body = textGet("/");
    } catch (error) {
      return FALLBACK_CATEGORIES.slice();
    }
    var categories = [];
    var seen = {};
    RE_NAV_TYPE.lastIndex = 0;
    var match;
    while ((match = RE_NAV_TYPE.exec(body)) !== null) {
      var id = match[1];
      var name = clip(clean(match[2]), 16);
      if (!validCategory(id) || name === "" || seen[id]) continue;
      if (name.length > 12 || name.indexOf("更多") >= 0) continue;
      if (!KEEP_TYPES[id]) continue;
      seen[id] = true;
      categories.push({ id: id, name: name });
    }
    if (categories.length === 0) return FALLBACK_CATEGORIES.slice();
    return categories;
  },

  catalogPage: function (page, category) {
    var index = asNumber(page, 0);
    if (index < 1 || index > MAX_PAGE) throw new Error("夜社目录页码无效");
    if (!validCategory(category)) throw new Error("夜社内容分类无效");
    var value = String(category || "").replace(/^\s+|\s+$/g, "");
    if (value !== "") {
      // 白名单外的分类（短剧 6 / 国产短剧 3 / AI 漫剧 16）一律当空表：
      // 分类栏已经不给入口了，但客户端分类缓存是按站源存的，旧版留下的项
      // 还没刷掉时点进来也不该再翻出作品。
      if (!KEEP_TYPES[value]) return { items: [], hasMore: false, total: 0 };
      var single = loadSection(value, index);
      return {
        items: single.items,
        hasMore: single.items.length >= PAGE_SIZE && index < single.pages,
        total: sectionTotal(value),
      };
    }
    // 「全部」= 各一级栏目按页接起来的虚拟列表。
    var pages0 = sectionPages();
    // 页数缓存不完整（第一次装、缓存过期、旧版本写坏过）就先补齐，
    // 否则默认值会把每栏的尾页截掉。
    if (!sectionsKnown()) pages0 = refreshSectionPages();
    var served = serveAll(pages0, index);
    if (served) return served;
    var pages = refreshSectionPages();
    var retried = serveAll(pages, index);
    if (retried) return retried;
    return { items: [], hasMore: false, total: allTotal(pages) };
  },

  search: function (page, query) {
    var index = asNumber(page, 0);
    var keyword = String(query || "").replace(/^\s+|\s+$/g, "");
    if (keyword === "") return { items: [], hasMore: false };
    if (index < 1 || index > MAX_PAGE) throw new Error("夜社搜索页码无效");
    if (keyword.length > 40) throw new Error("夜社搜索关键词无效");
    var body = textGet(searchPath(keyword, index));
    var items = parseCards(body);
    if (items.length === 0) return { items: [], hasMore: false };
    return { items: items, hasMore: items.length >= PAGE_SIZE };
  },

  detail: function (sourceId) {
    var id = String(sourceId || "").replace(/^\s+|\s+$/g, "");
    if (!validId(id)) throw new Error("夜社剧集标识无效");
    var body = textGet("/detail/" + id + ".html");
    var chapters = buildChapters(body, id);
    if (chapters.length === 0) {
      // 详情页没有分集标记时，用 meta 里的「更新至 N 集」合成分集。
      var countMatch = RE_DETAIL_COUNT.exec(body);
      var count = countMatch ? asNumber(countMatch[1], 0) : 0;
      if (count > 0 && count <= MAX_PAGE) {
        for (var number = 1; number <= count; number++) {
          chapters.push({
            id: host.chapterId(id, String(number)),
            source: host.source,
            title: "第" + number + "集",
            currentEpisode: number,
            videoUrl: "yesheai-play://" + number,
            pageUrl: SITE + "/play/" + id + "/1/" + number + ".html",
            referer: SITE + "/",
          });
        }
      }
    }
    if (chapters.length === 0) throw new Error("夜社该剧暂无可播放分集");

    var title = "";
    var h1Match = RE_DETAIL_H1.exec(body);
    if (h1Match) title = clip(clean(h1Match[1]), 512);
    if (title === "") throw new Error("夜社详情缺少剧集名称");

    var cover = "";
    var picMatch = RE_DETAIL_PIC.exec(body);
    if (picMatch) cover = absUrl(picMatch[1]);

    var description = "";
    var descMatch = RE_DETAIL_DESC.exec(body);
    if (descMatch) description = clean(descMatch[1]);

    var tags = [];
    var seenTags = {};
    var categoryName = "";
    var cateMatch = RE_DETAIL_CATE.exec(body);
    if (cateMatch) {
      var cateText = clean(cateMatch[1]);
      RE_CATE_TAG.lastIndex = 0;
      var tagMatch;
      while ((tagMatch = RE_CATE_TAG.exec(cateText)) !== null) {
        var tag = clip(String(tagMatch[1]).replace(/^\s+|\s+$/g, ""), 16);
        if (tag === "" || seenTags[tag] || tags.length >= 8) continue;
        seenTags[tag] = true;
        tags.push(tag);
        if (categoryName === "") categoryName = tag;
      }
    }

    var extra = {
      desc: clip(description, 12000),
      intro: clip(description, 12000),
      episodeCount: chapters.length,
      totalEpisode: chapters.length,
      remark: "全" + chapters.length + "集",
      categoryName: categoryName || CHANNEL,
    };
    if (tags.length > 0) extra.tags = tags;
    return { drama: makeDrama(id, title, cover, extra), chapters: chapters };
  },

  resolveMedia: function (task) {
    var chapter = task && task.chapter ? task.chapter : {};
    var dramaId = String((task && task.dramaId) || host.source + ":");
    var prefix = host.source + ":";
    var rest = dramaId.indexOf(prefix) === 0 ? dramaId.slice(prefix.length) : "";
    var sourceId = rest;
    var episode = 0;
    var separator = rest.indexOf(":");
    if (separator > 0) {
      sourceId = rest.slice(0, separator);
      episode = asNumber(rest.slice(separator + 1), 0);
    } else if (chapter.id) {
      var chapterId = String(chapter.id);
      var cut = chapterId.lastIndexOf(":");
      if (cut > 0) episode = asNumber(chapterId.slice(cut + 1), 0);
    }
    if (!validId(sourceId)) throw new Error("夜社播放信息无效，请刷新详情");
    if (episode < 1 || episode > MAX_PAGE) throw new Error("夜社播放分集信息无效，请刷新详情");

    var pageUrl = SITE + "/play/" + sourceId + "/1/" + episode + ".html";
    var body = textGet(pageUrl);
    var match = RE_PLAYER.exec(body);
    if (!match) throw new Error("夜社该集暂无可播放地址，可能需要在站点开通会员");
    var player = null;
    try {
      player = JSON.parse(match[1]);
    } catch (error) {
      throw new Error("夜社播放信息解析失败，请刷新后重试");
    }
    var encrypt = asNumber(player.encrypt, 0);
    var address = decodePlayerUrl(player.url, encrypt);
    if (address === "" || address === "null") address = decodePlayerUrl(player.url_next, encrypt);
    address = absUrl(address);
    if (!/^https?:\/\//i.test(address)) {
      throw new Error("夜社该集暂无可播放地址，可能需要在站点开通会员");
    }
    var media = host.prepareWebMedia({ url: address, referer: pageUrl }, CHANNEL);
    media.referer = pageUrl;
    return media;
  },
};
