package core

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"
)

func TestChapterEpisodeNumber(t *testing.T) {
	cases := []struct {
		chapter Chapter
		want    int
	}{
		{Chapter{}, 1},
		{Chapter{CurrentEpisode: json.RawMessage(`7`)}, 7},
		{Chapter{CurrentEpisode: json.RawMessage(`"8"`)}, 8},
		{Chapter{CurrentEpisode: json.RawMessage(`0`)}, 1},
		{Chapter{CurrentEpisode: json.RawMessage(`null`)}, 1},
	}
	for _, test := range cases {
		if got := chapterEpisodeNumber(test.chapter); got != test.want {
			t.Fatalf("chapterEpisodeNumber(%s) = %d，期望 %d", test.chapter.CurrentEpisode, got, test.want)
		}
	}
}

func TestDurationCacheRoundTrip(t *testing.T) {
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	disk := engine.loadDurationCache()
	disk.Dramas["yeguo:1"] = &nativeDurationRecord{
		Updated:   12,
		Items:     map[string]int64{"yeguo:1:1": 305000},
		Qualities: map[string]int64{"yeguo:1:1": 1080},
		Decoded:   map[string]int64{"yeguo:1:1": 720},
		Probed:    map[string]int64{"yeguo:1:3": 480},
		Missed:    map[string]int64{"yeguo:1:2": 34},
	}
	engine.saveDurationCache(disk)

	again := engine.loadDurationCache()
	record := again.Dramas["yeguo:1"]
	if record == nil {
		t.Fatal("缓存没有落盘")
	}
	if record.Items["yeguo:1:1"] != 305000 || record.Missed["yeguo:1:2"] != 34 ||
		record.Qualities["yeguo:1:1"] != 1080 || record.Decoded["yeguo:1:1"] != 720 ||
		record.Probed["yeguo:1:3"] != 480 {
		t.Fatalf("缓存内容不对：%+v", record)
	}
}

func TestRecordChapterQualityWins(t *testing.T) {
	const source = "qualityrecord"
	descriptor := SourceDescriptor{ID: source}
	Register(descriptor, func(Host) Provider { return &registryTestProvider{descriptor: descriptor} })
	t.Cleanup(func() { Unregister(source) })
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	record := &nativeDurationRecord{
		Items:     map[string]int64{"qualityrecord:1:1": 1000},
		Qualities: map[string]int64{"qualityrecord:1:1": 1080},
		Decoded:   map[string]int64{},
		Missed:    map[string]int64{},
	}
	disk := engine.loadDurationCache()
	disk.Dramas["qualityrecord:1"] = record
	engine.saveDurationCache(disk)

	// 播放器解码真值 480：回写后必须盖掉站点声明的 1080。
	if ok := engine.nativeRecordChapterQuality(nativeInput{
		Drama:   LibraryDrama{ID: "qualityrecord:1"},
		Chapter: Chapter{ID: "qualityrecord:1:1"},
		Quality: 480,
	}); !ok {
		t.Fatal("回写真值应成功")
	}
	again := engine.loadDurationCache()
	got := again.Dramas["qualityrecord:1"].Decoded["qualityrecord:1:1"]
	if got != 480 {
		t.Fatalf("解码真值 = %d，期望 480", got)
	}
	// 站点声明值仍在，但界面取值时 Decoded 优先。
	if again.Dramas["qualityrecord:1"].Qualities["qualityrecord:1:1"] != 1080 {
		t.Fatal("站点声明值不该被回写抹掉")
	}

	// 非法的空集 ID / 0 档位要被拒。
	if engine.nativeRecordChapterQuality(nativeInput{
		Drama: LibraryDrama{ID: "qualityrecord:1"}, Quality: 480,
	}) || engine.nativeRecordChapterQuality(nativeInput{
		Drama: LibraryDrama{ID: "qualityrecord:1"},
		Chapter: Chapter{ID: "qualityrecord:1:1"}, Quality: 0,
	}) {
		t.Fatal("空集 ID 或 0 档位应被拒绝")
	}
}

func TestProbeQualitiesPriority(t *testing.T) {
	const source = "qualityprobe"
	descriptor := SourceDescriptor{ID: source}
	Register(descriptor, func(Host) Provider { return &registryTestProvider{descriptor: descriptor} })
	t.Cleanup(func() { Unregister(source) })
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	record := &nativeDurationRecord{
		Items:     map[string]int64{},
		Qualities: map[string]int64{"qualityprobe:1:1": 1080},
		Decoded:   map[string]int64{"qualityprobe:1:2": 480},
		Probed:    map[string]int64{"qualityprobe:1:3": 720},
		Missed:    map[string]int64{},
	}
	disk := engine.loadDurationCache()
	disk.Dramas["qualityprobe:1"] = record
	engine.saveDurationCache(disk)

	got := engine.nativeProbeQualities(context.Background(), nativeInput{
		Drama: LibraryDrama{ID: "qualityprobe:1"},
		Chapters: []Chapter{
			{ID: "qualityprobe:1:1"}, {ID: "qualityprobe:1:2"}, {ID: "qualityprobe:1:3"},
		},
	})
	want := map[string]int64{
		"qualityprobe:1:1": 1080, // 站点声明
		"qualityprobe:1:2": 480,  // 播放真值
		"qualityprobe:1:3": 720,  // 字节探测
	}
	if len(got.Items) != len(want) {
		t.Fatalf("返回集数 = %d，期望 %d", len(got.Items), len(want))
	}
	for _, item := range got.Items {
		if item.QualityHeight != want[item.ID] {
			t.Fatalf("%s 档位 = %d，期望 %d", item.ID, item.QualityHeight, want[item.ID])
		}
	}
	// 有档位的集不该被写进 Missed（那说明它白撞了一遍探测）。
	again := engine.loadDurationCache().Dramas["qualityprobe:1"]
	for id := range want {
		if _, missed := again.Missed[id]; missed {
			t.Fatalf("%s 已有档位却被记进失败冷却", id)
		}
	}
}

func TestPlaylistMaxHeight(t *testing.T) {
	master := `#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=1282x720
720.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=2400000,RESOLUTION=1922x1080
1080.m3u8
`
	if got := nativeMaxPlaylistHeight(ProviderMedia{Playlist: master}); got != 1080 {
		t.Fatalf("总播放列表最高档 = %d，期望 1080", got)
	}
	portrait := `#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=720x1282
v.m3u8
`
	if got := nativeMaxPlaylistHeight(ProviderMedia{Playlist: portrait}); got != 720 {
		t.Fatalf("竖屏按短边算 = %d，期望 720", got)
	}
	if got := nativeMaxPlaylistHeight(ProviderMedia{Playlist: "#EXTM3U\n#EXTINF:10,\nseg.ts\n"}); got != 0 {
		t.Fatalf("单路列表没有档位，应该是 0，实际 %d", got)
	}
	if got := nativeMaxPlaylistHeight(ProviderMedia{Quality: 1080}); got != 1080 {
		t.Fatalf("站点直接给档位时 = %d，期望 1080", got)
	}
}

func TestLoadDurationCacheIgnoresBrokenFile(t *testing.T) {
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	if err := writeNativeCacheFile(engine.cacheDirectory+"/"+nativeDurationFile, []byte("{ 坏掉的")); err != nil {
		t.Fatal(err)
	}
	disk := engine.loadDurationCache()
	if disk == nil || len(disk.Dramas) != 0 {
		t.Fatalf("坏掉的缓存应退回空表，实际 %+v", disk)
	}
}

func TestLoadDurationCacheDropsOldVersion(t *testing.T) {
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	old := `{"version":1,"dramas":{"yeguo:1":{"updated":12,"items":{"1":300000}}}}`
	if err := writeNativeCacheFile(engine.cacheDirectory+"/"+nativeDurationFile, []byte(old)); err != nil {
		t.Fatal(err)
	}
	disk := engine.loadDurationCache()
	if len(disk.Dramas) != 0 {
		t.Fatalf("旧版缓存应整份丢弃以便补记画质，实际 %+v", disk.Dramas)
	}
}

func TestTrimNativeDurations(t *testing.T) {
	dramas := map[string]*nativeDurationRecord{}
	for index := 0; index < nativeDurationDramaLimit+10; index++ {
		dramas[fmt.Sprintf("d%d", index)] = &nativeDurationRecord{Updated: int64(index)}
	}
	trimNativeDurations(dramas)
	if len(dramas) != nativeDurationDramaLimit {
		t.Fatalf("淘汰后应剩 %d 部，实际 %d", nativeDurationDramaLimit, len(dramas))
	}
	if _, found := dramas["d0"]; found {
		t.Fatal("最久没刷新的那部没有淘汰")
	}
	if _, found := dramas[fmt.Sprintf("d%d", nativeDurationDramaLimit+9)]; !found {
		t.Fatal("最新刷新的那部被误删")
	}
}

func TestChapterDurationsRejectsInvalidDrama(t *testing.T) {
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	_, err := engine.nativeChapterDurations(context.Background(), nativeInput{
		Drama:    LibraryDrama{},
		Chapters: []Chapter{{ID: "x"}},
	})
	if err == nil {
		t.Fatal("无效剧集应该报错")
	}
}

func TestChapterDurationsEmptyChapters(t *testing.T) {
	const source = "durationprobe"
	descriptor := SourceDescriptor{ID: source}
	factory := func(Host) Provider {
		return &registryTestProvider{descriptor: descriptor}
	}
	Register(descriptor, factory)
	t.Cleanup(func() { Unregister(source) })

	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	result, err := engine.nativeChapterDurations(context.Background(), nativeInput{
		Drama: LibraryDrama{ID: source + ":1"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(result.Items) != 0 {
		t.Fatalf("没有分集时不该有结果，实际 %+v", result.Items)
	}
}
