package core

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// 选集面板要显示「本剧总时长 = 每一集时长相加」。站点的详情接口几乎都不带
// 每集时长，只能按集解析一次播放列表（HLS 的 #EXTINF 求和，或者模块自己给的
// durationMs），代价是每集一次请求。所以这里做两件事：
//
//  1. 只解析、不开播放会话：拿到 media.Duration 就返回，不建流、不预取；
//  2. 按「剧 → 分集」落盘缓存，第二次打开详情页直接读缓存，不再联网。
//
// 解析失败的集记一次时间戳，10 分钟内不再重试（免得每次开详情页都去撞同一集），
// 过期后会自动再试；解析成功但站点没给时长的，同样按失败记。
const (
	nativeDurationFile       = "durations.json"
	nativeDurationMaxBytes   = 4 << 20
	nativeDurationDramaLimit = 320
	nativeDurationWorkers    = 3
	nativeDurationPerRequest = 240
	nativeDurationRetryAfter = 10 * time.Minute
	// 单集上限 8 小时：短剧不可能超过，超过就当站点给了脏数据。
	nativeDurationMaxMS = 8 * 60 * 60 * 1000
)

type nativeDurationDisk struct {
	Version int                              `json:"version"`
	Dramas  map[string]*nativeDurationRecord `json:"dramas"`
}

type nativeDurationRecord struct {
	// Updated 是这部剧最后一次刷新缓存的时刻，用来在超过上限时淘汰最旧的。
	Updated int64 `json:"updated"`
	// Items 是已经拿到的每集时长（毫秒）。
	Items map[string]int64 `json:"items"`
	// Missed 记解析失败的集与失败时刻，10 分钟内不再重试。
	Missed map[string]int64 `json:"missed"`
}

type nativeDurationItem struct {
	ID         string `json:"id"`
	DurationMS int64  `json:"durationMs"`
}

type nativeDurationsResult struct {
	Items []nativeDurationItem `json:"items"`
}

// nativeChapterDurations 返回给定分集各自的时长（毫秒），拿不到的给 0。
// 前端按批调用（一批十来集），既能显示「已统计 24/60 集」，也不会让一次
// 原生调用挂上几分钟。
func (engine *nativeEngine) nativeChapterDurations(ctx context.Context, input nativeInput) (nativeDurationsResult, error) {
	if _, _, valid := SplitProviderDramaID(input.Drama.ID); !valid {
		return nativeDurationsResult{}, errors.New("剧集信息无效")
	}
	wanted := make([]Chapter, 0, len(input.Chapters))
	seen := make(map[string]bool, len(input.Chapters))
	for _, chapter := range input.Chapters {
		if chapter.ID == "" || seen[chapter.ID] {
			continue
		}
		seen[chapter.ID] = true
		wanted = append(wanted, chapter)
	}
	if len(wanted) == 0 {
		return nativeDurationsResult{Items: []nativeDurationItem{}}, nil
	}
	if len(wanted) > nativeDurationPerRequest {
		wanted = wanted[:nativeDurationPerRequest]
	}
	// 整段都持锁：一次只跑一批探测，避免两批同时读到旧快照、后写的那批
	// 把先写进去的时长覆盖掉。前端本来就是一批接一批地发，串行不额外增加等待。
	engine.durationMu.Lock()
	defer engine.durationMu.Unlock()
	disk := engine.loadDurationCache()
	record := disk.Dramas[input.Drama.ID]
	if record == nil {
		record = &nativeDurationRecord{}
		disk.Dramas[input.Drama.ID] = record
	}
	if record.Items == nil {
		record.Items = map[string]int64{}
	}
	if record.Missed == nil {
		record.Missed = map[string]int64{}
	}
	now := time.Now()
	results := make([]nativeDurationItem, len(wanted))
	pending := make([]int, 0, len(wanted))
	for index, chapter := range wanted {
		results[index] = nativeDurationItem{ID: chapter.ID}
		if input.Force {
			pending = append(pending, index)
			continue
		}
		if duration := record.Items[chapter.ID]; duration > 0 {
			results[index].DurationMS = duration
			continue
		}
		if at, missed := record.Missed[chapter.ID]; missed && now.Sub(time.UnixMilli(at)) < nativeDurationRetryAfter {
			continue
		}
		pending = append(pending, index)
	}
	if len(pending) > 0 {
		engine.probeDurations(ctx, input.Drama, wanted, pending, results)
		for _, index := range pending {
			id := wanted[index].ID
			if duration := results[index].DurationMS; duration > 0 {
				record.Items[id] = duration
				delete(record.Missed, id)
				continue
			}
			record.Missed[id] = now.UnixMilli()
		}
		record.Updated = now.UnixMilli()
		engine.saveDurationCache(disk)
	}
	return nativeDurationsResult{Items: results}, nil
}

// probeDurations 用固定并发把待解析的集跑一遍，结果写回 results。
// 单集失败不影响其他集：拿不到就是 0，前端据此把这一集算作「时长未知」。
func (engine *nativeEngine) probeDurations(ctx context.Context, drama LibraryDrama, chapters []Chapter, pending []int, results []nativeDurationItem) {
	queue := make(chan int)
	workers := min(nativeDurationWorkers, len(pending))
	var group sync.WaitGroup
	for worker := 0; worker < workers; worker++ {
		group.Add(1)
		go func() {
			defer group.Done()
			for index := range queue {
				results[index].DurationMS = engine.probeChapterDuration(ctx, drama, chapters[index])
			}
		}()
	}
	for _, index := range pending {
		select {
		case queue <- index:
		case <-ctx.Done():
			close(queue)
			group.Wait()
			return
		}
	}
	close(queue)
	group.Wait()
}

func (engine *nativeEngine) probeChapterDuration(ctx context.Context, drama LibraryDrama, chapter Chapter) int64 {
	if err := ctx.Err(); err != nil {
		return 0
	}
	task := Task{
		DramaID:    drama.ID,
		DramaTitle: drama.Title,
		Chapter:    chapter,
		Index:      chapterEpisodeNumber(chapter),
	}
	media, err := engine.downloader.resolveProviderMedia(ctx, task)
	if err != nil {
		return 0
	}
	duration := media.Duration
	if duration <= 0 {
		// +175：统计链路此前只认 resolve 直接给的 media.Duration 和 media.Playlist，
		// 但模块的 resolve 常把主播放列表放在 media.URL、Playlist 字段留空——
		// 播放页走 finishProviderMedia 抓 media.URL 的 #EXTINF 才有时长，统计却拿
		// duration=0 记为失败并进 10 分钟冷却，于是「32/35」反复补不回来。
		// 这里补齐同一条解析路径：URL 是 http(s) 就抓播放列表按 #EXTINF 求和。
		handled := false
		if IsProviderHTTPMediaURL(media.URL) {
			playlist, finalURL, err := engine.downloader.fetchMediaPlaylist(ctx, media.URL, media.Referer)
			if err == nil {
				handled = true
				if fromMaster := M3u8Duration(playlist); fromMaster > 0 {
					duration = fromMaster
				} else {
					// 主列表只有 #EXT-X-STREAM-INF：把抓回的列表交给子列表逻辑，
					// 挑一路再抓一次拿真正的 #EXTINF。带上凭证，否则站点会 403。
					media.Playlist = playlist
					media.URL = finalURL
					duration = engine.variantPlaylistDuration(ctx, media)
				}
			}
		}
		// 老兜底：模块已把主列表塞进 Playlist 字段、但 URL 不可抓取时走子列表解析。
		if duration <= 0 && !handled && media.Playlist != "" {
			duration = engine.variantPlaylistDuration(ctx, media)
		}
	}
	value := duration.Milliseconds()
	if value <= 0 || value > nativeDurationMaxMS {
		return 0
	}
	return value
}

// variantPlaylistDuration 从总播放列表里挑一路子列表，抓回来按 #EXTINF 求和。
// 只抓第一路：一集的时长跟线路无关，没必要把每一路都拉一遍。
func (engine *nativeEngine) variantPlaylistDuration(ctx context.Context, media ProviderMedia) time.Duration {
	base, err := url.Parse(media.URL)
	if err != nil {
		return 0
	}
	// 子列表同样要带上这集的凭证（柚子的 Cookie 只对同一次会话的有效），
	// 否则会拿到 403、时长算成 0。
	if media.Credentials != nil {
		ctx = providerMediaContext(ctx, media.Credentials)
	}
	lines := strings.Split(media.Playlist, "\n")
	for index, raw := range lines {
		if !strings.HasPrefix(strings.TrimSpace(raw), "#EXT-X-STREAM-INF:") {
			continue
		}
		for next := index + 1; next < len(lines); next++ {
			text := strings.TrimSpace(lines[next])
			if text == "" || strings.HasPrefix(text, "#") {
				continue
			}
			reference, err := url.Parse(text)
			if err != nil {
				return 0
			}
			playlist, _, err := engine.downloader.fetchMediaPlaylist(ctx, base.ResolveReference(reference).String(), media.Referer)
			if err != nil {
				return 0
			}
			return M3u8Duration(playlist)
		}
	}
	return 0
}

func chapterEpisodeNumber(chapter Chapter) int {
	// 分集编号有的是数字、有的是字符串，统一走 Chapter.EpisodeString。
	number, err := strconv.Atoi(chapter.EpisodeString(1))
	if err != nil || number < 1 {
		return 1
	}
	return number
}

func (engine *nativeEngine) loadDurationCache() *nativeDurationDisk {
	disk := &nativeDurationDisk{Version: 1, Dramas: map[string]*nativeDurationRecord{}}
	if engine.cacheDirectory == "" {
		return disk
	}
	file, err := os.Open(filepath.Join(engine.cacheDirectory, nativeDurationFile))
	if err != nil {
		return disk
	}
	defer file.Close()
	body, err := io.ReadAll(io.LimitReader(file, nativeDurationMaxBytes+1))
	if err != nil || len(body) > nativeDurationMaxBytes {
		return disk
	}
	var saved nativeDurationDisk
	if json.Unmarshal(body, &saved) != nil || saved.Dramas == nil {
		return disk
	}
	saved.Version = 1
	return &saved
}

func (engine *nativeEngine) saveDurationCache(disk *nativeDurationDisk) {
	if engine.cacheDirectory == "" || disk == nil {
		return
	}
	trimNativeDurations(disk.Dramas)
	body, err := json.Marshal(disk)
	if err != nil {
		return
	}
	_ = writeNativeCacheFile(filepath.Join(engine.cacheDirectory, nativeDurationFile), body)
}

// trimNativeDurations 按「最后一次刷新」淘汰，超过上限时把最老的整部丢掉，
// 免得缓存文件一直长。
func trimNativeDurations(dramas map[string]*nativeDurationRecord) {
	if len(dramas) <= nativeDurationDramaLimit {
		return
	}
	ids := make([]string, 0, len(dramas))
	for id := range dramas {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(left, right int) bool {
		return dramas[ids[left]].Updated < dramas[ids[right]].Updated
	})
	for _, id := range ids[:len(dramas)-nativeDurationDramaLimit] {
		delete(dramas, id)
	}
}
