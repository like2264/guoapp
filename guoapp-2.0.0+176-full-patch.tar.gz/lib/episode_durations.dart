import 'dart:async';

import 'package:flutter/material.dart';

import 'core_bridge.dart';
import 'models.dart';

/// 选集面板上的「本剧总时长」：把每一集的时长加起来。
///
/// 站点的详情接口几乎都不带每集时长，只能按集解析一次播放列表（HLS 的
/// #EXTINF 求和，或者模块自己给的 durationMs）。因此这里分批向原生要，
/// 边拿边报进度；原生侧按「剧 → 分集」落盘缓存，第二次打开详情页直接读
/// 缓存，不再联网。
///
/// 集数变了（站点上新）会重新统计一遍：已经缓存的集直接命中，只补新增的。
class EpisodeDurations extends ChangeNotifier {
  EpisodeDurations(this.repository, this.drama);

  final AppRepository repository;
  final Drama drama;

  /// 一批问多少集：太小会把一次统计拆成太多次往返，太大则单次等待变长、
  /// 进度条一次跳一大截。十来集一批，手机上大约两三秒一跳。
  static const _batchSize = 12;

  final Map<String, int> _durations = {};

  /// 每集的最高画质档（高度像素）。时长探测会带回站点声明的档位；单路
  /// m3u8 站没声明的，另有后台字节探测补齐，播过之后再由解码真值覆盖。
  final Map<String, int> _qualities = {};
  List<Episode> _episodes = const [];
  String _signature = '';
  int _known = 0;
  int _generation = 0;
  bool _running = false;
  bool _stalled = false;
  bool _disposed = false;

  /// 当前统计的分集数。
  int get episodes => _episodes.length;

  /// 已经有常长的集数。
  int get known => _known;

  /// 还在统计中。
  bool get running => _running;

  /// 一集都还没量到、正在挨集问站点 —— 选集面板右上角要转圈的那种状态。
  bool get counting => _running && _known == 0 && !_stalled;

  /// 拿到的所有集时长之和（毫秒）。
  int get totalMs {
    var total = 0;
    for (final episode in _episodes) {
      total += _durations[episode.id] ?? 0;
    }
    return total;
  }

  /// 选集格子左下角那行画质标注：1080 → `1080P`，未知返回空串不占位。
  String qualityLabel(String episodeId) {
    final height = _qualities[episodeId] ?? 0;
    return height > 0 ? '${height}P' : '';
  }

  /// 选集面板右上角那一行字；还没拿到任何一集时长时返回 null（不占位）。
  String? get summary {
    if (_episodes.isEmpty) return null;
    if (_known == 0) return _running && !_stalled ? '总时长 统计中…' : null;
    final text = '总时长 ${formatDuration(totalMs)}';
    if (_known >= _episodes.length) return text;
    // 有集拿不到时长（站点没给、或这一集解析失败）：把「统计了几集」摆出来，
    // 免得用户把这个偏小的数当成作品本身的总时长。
    return '$text（$_known/${_episodes.length} 集）';
  }

  /// 分集列表变了才重新统计；同一份列表反复 sync 不重复发请求。
  void sync(List<Episode> episodes) {
    // 没有分集 ID 的集没法按集取时长（也认不出是哪一集），直接不参与统计。
    final usable = [
      for (final episode in episodes)
        if (episode.id.isNotEmpty) episode,
    ];
    final signature = usable.isEmpty
        ? '0'
        : '${usable.length}:${usable.first.id}:${usable.last.id}';
    if (signature == _signature) return;
    _signature = signature;
    _episodes = List<Episode>.unmodifiable(usable);
    _known = _episodes.where((episode) => _has(episode)).length;
    _stalled = false;
    final generation = ++_generation;
    _notify();
    if (_episodes.isEmpty) {
      _running = false;
      return;
    }
    if (_known >= _episodes.length) {
      _running = false;
      return;
    }
    unawaited(_probe(generation));
    // 画质走独立后台任务：单路 m3u8 站点的分辨率要从分片字节里量，慢，
    // 不能让它挡住「已统计 N 集」。已有标注的集原生侧会跳过，不重复探测。
    unawaited(_probeQualities(generation));
  }

  bool _has(Episode episode) => (_durations[episode.id] ?? 0) > 0;

  /// 后台探测画质：拿到一集就填一集、立即刷新界面，不等整批跑完。
  /// 跟 _probe 分开，两边各自生成、互不阻塞。
  Future<void> _probeQualities(int generation) async {
    try {
      final heights = await repository.probeQualities(drama, _episodes);
      if (!_alive(generation) || heights.isEmpty) return;
      var changed = false;
      for (final entry in heights.entries) {
        // 只在还没有标注时填：站点声明、播放真值优先级都比字节探测高，
        // 别让慢一步回来的探测值把已经拿到的真值降级。
        if (entry.value > 0 && !_qualities.containsKey(entry.key)) {
          _qualities[entry.key] = entry.value;
          changed = true;
        }
      }
      if (changed) _notify();
    } catch (_) {}
  }

  /// 从播放页返回后重拉一次画质标注：播放时解码的真值已回写进原生缓存，
  /// 这里只读回来填 [_qualities]，不动时长统计状态，也不重复发时长请求。
  Future<void> refreshQualities() async {
    if (_disposed || _episodes.isEmpty) return;
    try {
      final facts = await repository.chapterFacts(drama, _episodes);
      if (_disposed) return;
      var changed = false;
      for (final entry in facts.entries) {
        final height = entry.value.qualityHeight;
        if (height > 0 && _qualities[entry.key] != height) {
          _qualities[entry.key] = height;
          changed = true;
        }
      }
      if (changed) _notify();
    } catch (_) {}
  }

  Future<void> _probe(int generation) async {
    _running = true;
    _notify();
    final queue = [
      for (final episode in _episodes)
        if (!_has(episode)) episode,
    ];
    while (queue.isNotEmpty && _alive(generation)) {
      final batch = queue.take(_batchSize).toList();
      Map<String, ChapterFacts> got = const {};
      try {
        got = await repository.chapterFacts(drama, batch);
      } catch (_) {
        got = const {};
      }
      if (!_alive(generation)) return;
      queue.removeRange(0, batch.length);
      var found = 0;
      for (final episode in batch) {
        final facts = got[episode.id];
        if (facts == null) continue;
        if (facts.qualityHeight > 0) {
          _qualities[episode.id] = facts.qualityHeight;
        }
        if (facts.durationMs > 0) {
          _durations[episode.id] = facts.durationMs;
          found++;
        }
      }
      _known = _episodes.where(_has).length;
      // 整批一个都没拿到：站点这边要不通、要不这一集就是没时长，继续往下
      // 死磕只是白等。把已经拿到的交回去，剩下的留到下次打开详情页再试。
      if (found == 0 && queue.isNotEmpty) {
        _stalled = true;
        break;
      }
      _notify();
    }
    // 期间如果又 sync 了一份新列表，收尾交给新的那一轮，别把它的「统计中」熄掉。
    if (!_alive(generation)) return;
    _running = false;
    _notify();
  }

  bool _alive(int generation) => !_disposed && generation == _generation;

  void _notify() {
    if (_disposed) return;
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _generation++;
    super.dispose();
  }
}

/// 时长按用户要的口径写成「125 mins 30 s」。
String formatDuration(int milliseconds) {
  final seconds = (milliseconds / 1000).round();
  return '${seconds ~/ 60} mins ${seconds % 60} s';
}

/// 选集栏上那一行「总时长 …」。
///
/// 2.0.0+156 按反馈改回 +151 的样子：标题下面单独一行，纯文字，没有转圈。
/// 统计中显示「统计中…」，全部集数都拿到就只留最终数字；一集都拿不到时整块不占位，
/// 免得给用户一个「0 mins 0 s」的假数字。
class EpisodeDurationLabel extends StatelessWidget {
  const EpisodeDurationLabel({super.key, required this.stats, this.fontSize});

  final EpisodeDurations stats;
  final double? fontSize;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: stats,
    builder: (context, _) {
      final text = stats.summary;
      if (text == null) return const SizedBox.shrink();
      return Text(
        text,
        style: TextStyle(
          fontSize: fontSize,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      );
    },
  );
}
