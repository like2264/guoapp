import 'dart:convert';
import 'dart:io';

import 'package:duanju_app/core_bridge.dart';
import 'package:duanju_app/local_files.dart';
import 'package:duanju_app/local_profiles.dart';
import 'package:duanju_app/local_store.dart';
import 'package:duanju_app/models.dart';
import 'package:duanju_app/ranking_models.dart';
import 'package:duanju_app/resource_settings.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as path;
import 'package:shared_preferences/shared_preferences.dart';

Drama drama(
  String key, {
  String source = 'hongguo',
  String? title,
  String category = '',
  int episodes = 80,
}) => Drama(
  id: '$source:$key',
  source: source,
  title: title ?? key,
  category: category,
  episodes: episodes,
);

WatchEntry watching(Drama drama, {int episode = 1, double position = 10}) =>
    WatchEntry(
      drama: drama,
      episode: episode,
      position: position,
      duration: 100,
      updatedAt: DateTime(2026, 10, 20),
    );

final viewerPreferences = <String, Object>{
  'profiles': jsonEncode([
    LocalProfile(
      id: 'default',
      name: '管理员',
      admin: true,
      salt: '0' * 32,
      pinHash: '1' * 64,
    ).toJson(),
    const LocalProfile(
      id: 'viewer',
      name: '访客',
      sources: ['hongguo'],
      download: false,
    ).toJson(),
  ]),
  'activeProfile': 'viewer',
};

LocalFiles temporaryFiles() {
  final directory = Directory.systemTemp.createTempSync('local-store-');
  addTearDown(
    () => directory.delete(recursive: true).catchError((Object _) => directory),
  );
  return LocalFiles(Directory(path.join(directory.path, 'store')));
}

class MemoryFiles extends LocalFiles {
  MemoryFiles() : super(Directory('memory'));
  final contents = <String, String>{};

  @override
  Future<bool> exists() async => contents.containsKey(LocalFiles.marker);

  @override
  Future<Object?> read(String name) async =>
      contents[name] == null ? null : jsonDecode(contents[name]!);

  @override
  Future<void> write(String name, Object? value) async =>
      contents[name] = jsonEncode(value);

  @override
  Future<void> replaceAll(Map<String, Object?> files) async => contents
    ..clear()
    ..addAll({
      for (final entry in files.entries) entry.key: jsonEncode(entry.value),
    });

  @override
  Future<void> remove(String directory) async =>
      contents.removeWhere((name, _) => name.startsWith('$directory/'));

  @override
  Future<void> quarantine(String name) async => contents.remove(name);

  @override
  Future<Map<String, String>> dump() async => Map.of(contents);
}

Future<LocalStore> openStore([
  Map<String, Object> initial = const {},
  Future<String> Function(String pin, String salt)? pinHasher,
  LocalFiles? files,
]) async {
  SharedPreferences.setMockInitialValues(Map.of(initial));
  final store = await LocalStore.open(
    await SharedPreferences.getInstance(),
    files ?? MemoryFiles(),
    pinHasher: pinHasher,
  );
  addTearDown(store.dispose);
  return store;
}

DownloadJob downloadJob(
  Drama drama,
  int episode, {
  String state = 'completed',
  double progress = 1,
  int bytes = 0,
  int created = 0,
}) => DownloadJob(
  id: '${drama.id}:$episode',
  drama: drama,
  episode: Episode(const {}, episode),
  state: state,
  progress: progress,
  bytes: bytes,
  created: created,
);

DramaDetail dramaDetail(
  Drama drama, {
  int count = 80,
  Set<int> vip = const {},
  String warning = '',
}) => DramaDetail(drama, [
  for (var number = 1; number <= count; number++)
    Episode({'currentEpisode': number, 'vip': vip.contains(number)}, number),
], warning: warning);

Future<LocalStore> restartStore(LocalStore store) async {
  final restarted = await LocalStore.open(store.preferences, store.files);
  addTearDown(restarted.dispose);
  return restarted;
}

class FakeRepository extends AppRepository {
  List<CatalogCategory> categoryList = const [
    CatalogCategory.all,
    CatalogCategory('short_play', '真人剧'),
  ];
  List<Drama> recommended = [
    drama('r1', title: '推荐剧一'),
    drama('r2', title: '推荐剧二'),
    drama('r3', title: '推荐剧三'),
  ];
  List<String> suggestionList = const [];
  List<RankingBoard> boardList = const [];
  final cachedPages = <String, CatalogPage>{};
  final catalogRequests = <String>[];
  final rankingRequests = <String>[];
  final recommendRequests = <({bool more, bool force})>[];
  String failure = '';
  List<DownloadJob>? jobs;
  int downloadRequests = 0;
  ResourceSettings resource = const ResourceSettings();
  final savedResources = <ResourceSettings>[];

  @override
  Future<ResourceSettings> resourceSettings() async => resource;

  @override
  Future<ResourceSettings> saveResourceSettings(
    ResourceSettings settings,
  ) async {
    savedResources.add(settings);
    return resource = settings;
  }

  @override
  bool get supportsDownloads => jobs != null;

  @override
  Future<List<DownloadJob>> downloads() async {
    downloadRequests++;
    return jobs ?? const [];
  }

  final enqueued = <({String drama, List<int> episodes, int quality})>[];
  final controls = <String>[];
  final failingControls = <String>{};

  @override
  Future<int> enqueueDownloads(
    DramaDetail detail,
    List<Episode> episodes, {
    int quality = 0,
  }) async {
    enqueued.add((
      drama: detail.drama.id,
      episodes: [for (final episode in episodes) episode.number],
      quality: quality,
    ));
    return episodes.length;
  }

  @override
  Future<void> controlDownloads(String command, {String id = ''}) async {
    if (failingControls.contains(id)) throw AppFailure('无法处理 $id');
    controls.add('$command|$id');
  }

  /// 目录页带回来的站源总量（0 = 站源给不出）。
  int catalogTotal = 0;

  /// 目录页还有没有下一页。默认没有（一页到顶），需要测翻页的用例自己打开。
  bool catalogHasMore = false;

  /// 分页目录：给了就按这张表一页一页地返回（page 从 1 开始）。
  ///
  /// 真实站点「全部」目录翻到底才能量出条数，测刷新后的重新统计要用它：
  /// 每一页给几部作品、总共有几页都由用例自己摆。
  List<List<Drama>>? catalogPages;

  CatalogPage pageFor(String source, String category, String query, int page) {
    final pages = catalogPages;
    if (pages != null && query.isEmpty) {
      final items = page >= 1 && page <= pages.length
          ? pages[page - 1]
          : const <Drama>[];
      return CatalogPage(
        items,
        page: page,
        total: catalogTotal,
        hasMore: page < pages.length,
      );
    }
    return CatalogPage(
      [
        query.isEmpty
            ? drama('$category-$page', source: source, title: '分类$category')
            : drama('found', source: source, title: '搜到的剧'),
      ],
      page: page,
      total: catalogTotal,
      hasMore: catalogHasMore,
    );
  }

  @override
  Future<void> initialize() async {}

  @override
  Future<List<CatalogCategory>> categories(
    String source, {
    bool force = false,
  }) async => categoryList;

  @override
  Future<CatalogPage> recommendations(
    String source,
    String genre, {
    bool more = false,
    bool force = false,
  }) async {
    recommendRequests.add((more: more, force: force));
    return CatalogPage(recommended);
  }

  @override
  Future<List<RankingBoard>> rankingBoards() async => boardList;

  @override
  Future<RankingPage> rankings(
    RankingBoard board, {
    int page = 1,
    bool force = false,
  }) async {
    rankingRequests.add('${board.id}|$page${force ? '!' : ''}');
    return RankingPage(
      items: [
        for (var rank = page * 2 - 1; rank <= page * 2; rank++)
          RankingItem(
            rank,
            drama('${board.id}-$rank', title: '${board.id}第$rank名'),
          ),
      ],
      page: page,
      hasMore: page < 2,
    );
  }

  @override
  Future<CatalogPage> catalog(
    String source, {
    int page = 1,
    String query = '',
    String category = '',
    bool force = false,
    String lane = '',
  }) async {
    catalogRequests.add('$source|$category|$query|$page${force ? '!' : ''}');
    if (failure.isNotEmpty) throw AppFailure(failure);
    return pageFor(source, category, query, page);
  }

  @override
  Future<CatalogPage> cached(String source, {String category = ''}) async =>
      cachedPages['$source|$category'] ?? CatalogPage(const []);

  @override
  Future<List<String>> suggestions(String source, String query) async =>
      suggestionList;

  @override
  Future<String> cover(Drama drama, {bool force = false}) async =>
      throw AppFailure('测试数据没有海报');

  final details = <String, DramaDetail>{};
  String detailFailure = '';
  int detailRequests = 0;

  @override
  Future<DramaDetail> detail(Drama drama) async {
    detailRequests++;
    if (detailFailure.isNotEmpty) throw AppFailure(detailFailure);
    return details[drama.id] ?? DramaDetail(drama, const []);
  }

  @override
  Future<PlaybackPlan> resolve(
    Drama drama,
    Episode episode, {
    int quality = 0,
  }) async => throw UnimplementedError();

  /// 每集时长（键：分集 ID，值：毫秒）。没登记的集当作「站点没给时长」。
  final durationMap = <String, int>{};
  final durationRequests = <List<String>>[];
  String durationFailure = '';

  /// 模拟站点慢：让「统计中」的状态能停在屏幕上被断言。
  Duration durationDelay = Duration.zero;

  @override
  Future<Map<String, int>> chapterDurations(
    Drama drama,
    List<Episode> episodes,
  ) async {
    durationRequests.add([for (final episode in episodes) episode.id]);
    if (durationFailure.isNotEmpty) throw AppFailure(durationFailure);
    if (durationDelay > Duration.zero) await Future<void>.delayed(durationDelay);
    return {
      for (final episode in episodes)
        if ((durationMap[episode.id] ?? 0) > 0)
          episode.id: durationMap[episode.id]!,
    };
  }

  @override
  Future<PlaybackPlan> fallback(PlaybackPlan current) async =>
      throw UnimplementedError();

  @override
  Future<void> cancelPlayback() async {}

  @override
  Future<void> release(String session) async {}
}
