import 'package:duanju_app/episode_durations.dart';
import 'package:duanju_app/models.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fakes.dart';

/// 选集栏那一行「总时长」：真的挂得上屏、跟着统计结果更新。
void main() {
  final show = drama('durations', title: '总时长用例');

  Widget harness(EpisodeDurations stats) => MaterialApp(
    home: Scaffold(body: Center(child: EpisodeDurationLabel(stats: stats))),
  );

  testWidgets('统计完成后显示每集相加的总时长', (tester) async {
    final repository = FakeRepository();
    for (var number = 1; number <= 12; number++) {
      repository.durationMap['ep$number'] = 300000; // 每集 5 分钟
    }
    final stats = EpisodeDurations(repository, show);
    addTearDown(stats.dispose);

    await tester.pumpWidget(harness(stats));
    // 还没开始统计：整块不占位。
    expect(find.textContaining('总时长'), findsNothing);

    stats.sync([
      for (var number = 1; number <= 12; number++)
        Episode({'id': 'ep$number', 'currentEpisode': number}, number),
    ]);
    // 请求发出、结果回来之前，模型报的是「统计中」。
    expect(stats.summary, '总时长 统计中…');
    await tester.pumpAndSettle();

    expect(find.text('总时长 60 mins 0 s'), findsOneWidget);
  });

  testWidgets('有集拿不到时长时把统计到的集数标出来', (tester) async {
    final repository = FakeRepository()
      ..durationMap['ep1'] = 600000
      ..durationMap['ep3'] = 600000;
    final stats = EpisodeDurations(repository, show);
    addTearDown(stats.dispose);

    await tester.pumpWidget(harness(stats));
    stats.sync([
      for (var number = 1; number <= 3; number++)
        Episode({'id': 'ep$number', 'currentEpisode': number}, number),
    ]);
    await tester.pumpAndSettle();

    expect(find.text('总时长 20 mins 0 s（2/3 集）'), findsOneWidget);
  });

  testWidgets('集数变多后总时长跟着涨', (tester) async {
    final repository = FakeRepository();
    for (var number = 1; number <= 4; number++) {
      repository.durationMap['ep$number'] = 120000;
    }
    final stats = EpisodeDurations(repository, show);
    addTearDown(stats.dispose);

    await tester.pumpWidget(harness(stats));
    stats.sync([
      for (var number = 1; number <= 3; number++)
        Episode({'id': 'ep$number', 'currentEpisode': number}, number),
    ]);
    await tester.pumpAndSettle();
    expect(find.text('总时长 6 mins 0 s'), findsOneWidget);

    // 站点上新第 4 集：只补这一集，总数从 6 分钟涨到 8 分钟。
    stats.sync([
      for (var number = 1; number <= 4; number++)
        Episode({'id': 'ep$number', 'currentEpisode': number}, number),
    ]);
    await tester.pumpAndSettle();

    expect(find.text('总时长 8 mins 0 s'), findsOneWidget);
    expect(repository.durationRequests.last, ['ep4']);
  });
}
