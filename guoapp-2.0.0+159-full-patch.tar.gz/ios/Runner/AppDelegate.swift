import Flutter
import UIKit
import DuanjuCore
import CFNetwork
import AVFoundation
import MediaPlayer
import BackgroundTasks

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterImplicitEngineDelegate {
  private var originalBrightness: CGFloat?
  private let volumeView = MPVolumeView(frame: CGRect(x: -100, y: -100, width: 1, height: 1))

  /// 后台下载：系统批给我们的那段运行时间用哪个标识（Info.plist 里也登记了）。
  static let downloadsTaskIdentifier = "com.guoapp.phoenix2.downloads"

  /// 现在还有下载或媒体处理在跑吗（由 Dart 侧 begin / end 维护）。
  private var downloadsActive = false

  /// 切到后台那一刻申请的临时额度。
  private var backgroundTask: UIBackgroundTaskIdentifier = .invalid

  /// 系统批下来的后台处理任务，跑完或到期要交还。
  private var processingTask: BGTask?

  /// 后台保活：一路静音音频（Info.plist 里登记了 audio 后台模式）。
  ///
  /// iOS 只会给 beginBackgroundTask 几十秒，一集 200 MB 根本下不完；BGProcessingTask
  /// 又要设备空闲、通常还得插着电才会被调度。播放静音音频能让进程在后台一直活着，
  /// 下载和转码才不会「一切后台就停」（2.0.0+158 反馈）。
  private var silenceEngine: AVAudioEngine?
  private var silenceNode: AVAudioPlayerNode?

  private var keyWindow: UIWindow? {
    UIApplication.shared.connectedScenes
      .compactMap { $0 as? UIWindowScene }
      .flatMap { $0.windows }
      .first { $0.isKeyWindow }
  }

  private var screen: UIScreen? { keyWindow?.screen }

  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    ZgjEnsureCoreLinked()
    // 处理器必须在 launch 结束前注册好，晚一步系统会直接抛异常。
    BGTaskScheduler.shared.register(
      forTaskWithIdentifier: AppDelegate.downloadsTaskIdentifier,
      using: nil
    ) { [weak self] task in
      self?.runProcessing(task)
    }
    NotificationCenter.default.addObserver(
      self,
      selector: #selector(appDidEnterBackground),
      name: UIApplication.didEnterBackgroundNotification,
      object: nil
    )
    NotificationCenter.default.addObserver(
      self,
      selector: #selector(appWillEnterForeground),
      name: UIApplication.willEnterForegroundNotification,
      object: nil
    )
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  // MARK: - 后台下载

  @objc private func appDidEnterBackground() {
    guard downloadsActive else { return }
    startSilence()
    beginExtended()
    scheduleProcessing()
  }

  @objc private func appWillEnterForeground() {
    // 回到前台就不用再占额度了，引擎自己会接着跑。
    stopSilence()
    endExtended()
    cancelProcessing()
  }

  // MARK: - 静音保活

  /// 播一路听不见的音频：进程有活跃的音频会话，系统就不会把它挂起。
  private func startSilence() {
    guard silenceEngine == nil else { return }
    let session = AVAudioSession.sharedInstance()
    do {
      // mixWithOthers：别把用户正在听的音乐、或者 App 自己的视频声音顶掉。
      try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
      try session.setActive(true)
    } catch {
      return
    }
    guard let format = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 2),
          let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: 44100) else {
      try? session.setActive(false, options: [.notifyOthersOnDeactivation])
      return
    }
    // 缓冲区默认全是 0，就是纯静音。
    buffer.frameLength = 44100
    let engine = AVAudioEngine()
    let node = AVAudioPlayerNode()
    engine.attach(node)
    engine.connect(node, to: engine.mainMixerNode, format: format)
    engine.mainMixerNode.outputVolume = 0.01
    do {
      try engine.start()
    } catch {
      try? session.setActive(false, options: [.notifyOthersOnDeactivation])
      return
    }
    node.scheduleBuffer(buffer, at: nil, options: .loops, completionHandler: nil)
    node.play()
    silenceEngine = engine
    silenceNode = node
  }

  /// 下载/处理都结束、或者回到前台：立刻停掉，别白耗电。
  private func stopSilence() {
    silenceNode?.stop()
    silenceEngine?.stop()
    silenceNode = nil
    silenceEngine = nil
    try? AVAudioSession.sharedInstance().setActive(
      false,
      options: [.notifyOthersOnDeactivation]
    )
  }

  /// 申请一段临时后台额度：切后台后还能再跑几十秒，够把正在写的集收个尾。
  private func beginExtended() {
    guard backgroundTask == .invalid else { return }
    backgroundTask = UIApplication.shared.beginBackgroundTask(
      withName: "downloads"
    ) { [weak self] in
      self?.endExtended()
    }
  }

  private func endExtended() {
    guard backgroundTask != .invalid else { return }
    UIApplication.shared.endBackgroundTask(backgroundTask)
    backgroundTask = .invalid
  }

  /// 向系统预约一段「后台处理」时间，设备空闲、有网的时候会把进程叫醒继续下。
  private func scheduleProcessing() {
    let request = BGProcessingTaskRequest(
      identifier: AppDelegate.downloadsTaskIdentifier
    )
    request.requiresNetworkConnectivity = true
    request.requiresExternalPower = false
    request.earliestBeginDate = Date(timeIntervalSinceNow: 30)
    try? BGTaskScheduler.shared.submit(request)
  }

  private func cancelProcessing() {
    BGTaskScheduler.shared.cancel(
      taskRequestWithIdentifier: AppDelegate.downloadsTaskIdentifier
    )
  }

  /// 系统把这段后台时间批给我们了：只要还有下载在跑就一直占着，
  /// 跑完或者系统收回时间就交还任务。
  private func runProcessing(_ task: BGTask) {
    guard downloadsActive else {
      task.setTaskCompleted(success: true)
      return
    }
    processingTask = task
    // 引擎在别的线程上下载，这里只负责「别让进程睡着」。
    let watchdog = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) {
      [weak self] timer in
      guard let self else {
        timer.invalidate()
        task.setTaskCompleted(success: true)
        return
      }
      if !self.downloadsActive {
        timer.invalidate()
        self.processingTask = nil
        task.setTaskCompleted(success: true)
      }
    }
    task.expirationHandler = { [weak self] in
      watchdog.invalidate()
      self?.processingTask = nil
      task.setTaskCompleted(success: true)
    }
  }

  func didInitializeImplicitFlutterEngine(_ engineBridge: FlutterImplicitEngineBridge) {
    GeneratedPluginRegistrant.register(with: engineBridge.pluginRegistry)
    // Dart 侧「还有下载在跑」的信号：只记状态，真正要额度等切后台时再申请。
    if let registrar = engineBridge.pluginRegistry.registrar(forPlugin: "BackgroundKeepAlive") {
      let downloads = FlutterMethodChannel(
        name: "duanju/background",
        binaryMessenger: registrar.messenger()
      )
      downloads.setMethodCallHandler { [weak self] call, result in
        guard let self else {
          result(nil)
          return
        }
        switch call.method {
        case "begin":
          self.downloadsActive = true
          if UIApplication.shared.applicationState != .active {
            self.startSilence()
            self.beginExtended()
            self.scheduleProcessing()
          }
          // 前台时这个值是 DBL_MAX，转 Int 会崩，只把「还有多少秒」这种能用的数交回去。
          let remaining = UIApplication.shared.backgroundTimeRemaining
          result(remaining.isFinite && remaining < 3600 ? Int(remaining) : -1)
        case "end":
          self.downloadsActive = false
          self.stopSilence()
          self.endExtended()
          self.cancelProcessing()
          result(nil)
        default:
          result(FlutterMethodNotImplemented)
        }
      }
    }
    if let registrar = engineBridge.pluginRegistry.registrar(forPlugin: "DeviceSettings") {
      let channel = FlutterMethodChannel(name: "duanju/device", binaryMessenger: registrar.messenger())
      channel.setMethodCallHandler { call, result in
        if call.method == "battery" {
          let device = UIDevice.current
          device.isBatteryMonitoringEnabled = true
          guard device.batteryLevel >= 0 else {
            result(nil)
            return
          }
          result(["level": Int((device.batteryLevel * 100).rounded()),
                  "charging": device.batteryState == .charging || device.batteryState == .full])
          return
        }
        let arguments = call.arguments as? [String: Any]
        switch call.method {
        case "getBrightness":
          result(self.screen.map { Double($0.brightness) })
          return
        case "setBrightness":
          guard let screen = self.screen, let value = arguments?["brightness"] as? Double else {
            result(nil)
            return
          }
          if self.originalBrightness == nil { self.originalBrightness = screen.brightness }
          screen.brightness = CGFloat(min(max(value, 0.01), 1))
          result(true)
          return
        case "resetBrightness":
          if let original = self.originalBrightness { self.screen?.brightness = original }
          self.originalBrightness = nil
          result(true)
          return
        case "volume":
          result(Double(AVAudioSession.sharedInstance().outputVolume))
          return
        case "setVolume":
          if let value = arguments?["volume"] as? Double {
            if self.volumeView.superview == nil { self.keyWindow?.addSubview(self.volumeView) }
            let slider = self.volumeView.subviews.first { $0 is UISlider } as? UISlider
            slider?.value = Float(min(max(value, 0), 1))
          }
          result(nil)
          return
        default:
          break
        }
        guard call.method == "systemProxy" else {
          result(FlutterMethodNotImplemented)
          return
        }
        let settings = CFNetworkCopySystemProxySettings()?.takeRetainedValue() as? [String: Any] ?? [:]
        func address(_ prefix: String) -> String {
          guard (settings["\(prefix)Enable"] as? NSNumber)?.boolValue == true,
                let host = settings["\(prefix)Proxy"] as? String,
                let port = settings["\(prefix)Port"] as? NSNumber,
                !host.isEmpty, port.intValue > 0 else { return "" }
          let name = host.contains(":") ? "[\(host)]" : host
          return "http://\(name):\(port.intValue)"
        }
        let http = address("HTTP")
        let https = address("HTTPS")
        result(["http": http, "https": https.isEmpty ? http : https,
                "bypass": settings["ExceptionsList"] as? [String] ?? [],
                "pac": (settings["ProxyAutoConfigEnable"] as? NSNumber)?.boolValue == true])
      }
    }
  }
}
