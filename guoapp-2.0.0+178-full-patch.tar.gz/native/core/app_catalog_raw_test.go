package core

import (
	"context"
	"reflect"
	"testing"
	"time"
)

// rawCatalogProvider 用来锁住「重走目录读到的是站点真值，不是旧缓存」这条回归。
type rawCatalogProvider struct {
	descriptor SourceDescriptor
	pages      map[int][]Drama
	more       map[int]bool
}

func (p *rawCatalogProvider) Descriptor() SourceDescriptor { return p.descriptor }
func (p *rawCatalogProvider) Categories(context.Context, bool) ([]Category, error) {
	return nil, nil
}
func (p *rawCatalogProvider) CatalogPage(_ context.Context, page int, _ string) ([]Drama, bool, error) {
	return p.pages[page], p.more[page], nil
}
func (p *rawCatalogProvider) Detail(context.Context, string) (Drama, []Chapter, error) {
	return Drama{}, nil, nil
}
func (p *rawCatalogProvider) ResolveMedia(context.Context, Task) (ProviderMedia, error) {
	return ProviderMedia{}, nil
}
func (p *rawCatalogProvider) Search(context.Context, int, string) ([]Drama, bool, error) {
	return nil, false, nil
}
func (p *rawCatalogProvider) Suggestions(context.Context, string) ([]string, error) {
	return nil, nil
}
func (p *rawCatalogProvider) ProvidesCapability(reflect.Type) bool { return false }

func TestCatalogRawIgnoresMergedCache(t *testing.T) {
	const source = "rawprobe"
	provider := &rawCatalogProvider{
		descriptor: SourceDescriptor{ID: source},
		pages: map[int][]Drama{
			1: {
				{ID: source + ":1", Title: "旧一部"},
				{ID: source + ":2", Title: "旧二部"},
			},
		},
		more: map[int]bool{1: true},
	}
	Register(provider.descriptor, func(Host) Provider { return provider })
	t.Cleanup(func() { Unregister(source) })

	engine := &nativeEngine{
		directory:      t.TempDir(),
		cacheDirectory: t.TempDir(),
		catalogs:       map[string][]LibraryDrama{},
		catalogStates:  map[string]nativeCatalogState{},
		downloader:     &Downloader{},
	}
	ctx := context.Background()

	// 第一次强制拉第 1 页：旧缓存为空，结果就是站点当页，hasMore=true。
	first, err := engine.nativeCatalogRaw(ctx, nativeInput{Source: source, Page: 1, Force: true})
	if err != nil {
		t.Fatalf("首次目录请求失败: %v", err)
	}
	if !first.HasMore || len(first.Items) != 2 {
		t.Fatalf("首次目录应拿到 2 部且还有下一页: %+v", first)
	}

	// 模拟用户已经翻到底：缓存状态记成第 2 页、hasMore=false。
	key := nativeCatalogKey(source, "")
	state := engine.catalogStates[key]
	state.Page, state.HasMore = 2, false
	engine.catalogStates[key] = state

	// 站点上新：第 1 页换成两部新剧。普通请求会把旧缓存重新追加回来，
	// 并沿用「已到底」的 hasMore —— 这正是重走目录此前一启动就停住的原因。
	provider.pages[1] = []Drama{
		{ID: source + ":3", Title: "新一部"},
		{ID: source + ":4", Title: "新二部"},
	}
	merged, err := engine.nativeCatalogRaw(ctx, nativeInput{Source: source, Page: 1, Force: true})
	if err != nil {
		t.Fatalf("普通目录请求失败: %v", err)
	}
	if merged.HasMore || len(merged.Items) != 4 {
		t.Fatalf("普通请求仍应合并旧缓存: hasMore=%v items=%d", merged.HasMore, len(merged.Items))
	}

	// Raw 请求必须绕开合并：站点当页 2 部、hasMore=true、页码就是 1。
	raw, err := engine.nativeCatalogRaw(ctx, nativeInput{
		Source: source, Page: 1, Force: true, Raw: true, Lane: "-probe-0",
	})
	if err != nil {
		t.Fatalf("raw 目录请求失败: %v", err)
	}
	if !raw.HasMore || raw.Page != 1 {
		t.Fatalf("raw 请求不能沿用缓存的已到底状态: %+v", raw)
	}
	if len(raw.Items) != 2 || raw.Items[0].ID != source+":3" {
		t.Fatalf("raw 请求必须返回站点当页真值: %+v", raw.Items)
	}
}

func TestCatalogRawLanesDoNotBlockEachOther(t *testing.T) {
	const source = "rawprobe2"
	provider := &rawCatalogProvider{
		descriptor: SourceDescriptor{ID: source},
		pages: map[int][]Drama{
			1: {{ID: source + ":1", Title: "一"}},
			2: {{ID: source + ":2", Title: "二"}},
		},
		more: map[int]bool{1: true, 2: true},
	}
	Register(provider.descriptor, func(Host) Provider { return provider })
	t.Cleanup(func() { Unregister(source) })

	engine := &nativeEngine{
		directory:      t.TempDir(),
		cacheDirectory: t.TempDir(),
		catalogs:       map[string][]LibraryDrama{},
		catalogStates:  map[string]nativeCatalogState{},
		downloader:     &Downloader{},
	}
	ctx := context.Background()
	// 两条不同 lane 的 raw 请求各占一把锁，不该互相排队。
	first, err := engine.lockSourceCatalog(ctx, source, "-probe-0")
	if err != nil {
		t.Fatalf("第一条道加锁失败: %v", err)
	}
	defer first()
	done := make(chan error, 1)
	go func() {
		unlock, err := engine.lockSourceCatalog(ctx, source, "-probe-1")
		if err == nil {
			unlock()
		}
		done <- err
	}()
	if err := <-done; err != nil {
		t.Fatalf("第二条道被第一条道挡住了: %v", err)
	}
	// 同一条道仍然互斥：带超时等锁，应当等到 context 超时。
	blocked, cancel := context.WithTimeout(ctx, 50*time.Millisecond)
	defer cancel()
	if unlock, err := engine.lockSourceCatalog(blocked, source, "-probe-0"); err == nil {
		unlock()
		t.Fatal("同一条道不该并发进入")
	}
}

// TestCatalogRawIgnoresRetriedSaveCache 锁住 +177 的回归：此前有一次写盘失败时，
// 下一次请求会先 retryCatalogSave 命中并把整份旧缓存当第 1 页返回。这条早退
// 原本没判断 Raw，导致 raw 重走目录拿到下架的旧作品。raw 必须永远问站点。
func TestCatalogRawIgnoresRetriedSaveCache(t *testing.T) {
	const source = "rawprobe3"
	provider := &rawCatalogProvider{
		descriptor: SourceDescriptor{ID: source},
		pages: map[int][]Drama{
			1: {{ID: source + ":new", Title: "站点新剧"}},
		},
		more: map[int]bool{1: true},
	}
	Register(provider.descriptor, func(Host) Provider { return provider })
	t.Cleanup(func() { Unregister(source) })

	engine := &nativeEngine{
		directory:        t.TempDir(),
		cacheDirectory:   t.TempDir(),
		catalogs:         map[string][]LibraryDrama{},
		catalogStates:    map[string]nativeCatalogState{},
		downloader:       &Downloader{},
		catalogSaveError: nativeSaveError("剧库", errNativeCatalogLimit),
	}
	// 缓存里塞一部已下架的旧剧，模拟写盘失败后仍留在内存的旧目录。
	key := nativeCatalogKey(source, "")
	engine.catalogs[key] = []LibraryDrama{
		{ID: source + ":old", Title: "已下架旧剧"},
	}
	engine.catalogStates[key] = nativeCatalogState{
		Page: 1, HasMore: false, Total: 1,
	}

	raw, err := engine.nativeCatalogRaw(context.Background(), nativeInput{
		Source: source, Page: 1, Force: true, Raw: true, Lane: "-probe-0",
	})
	if err != nil {
		t.Fatalf("raw 请求失败: %v", err)
	}
	if len(raw.Items) != 1 || raw.Items[0].ID != source+":new" {
		t.Fatalf("raw 请求被写盘重试的旧缓存拦下了: %+v", raw.Items)
	}
	if !raw.HasMore {
		t.Fatalf("raw 请求不该沿用旧缓存的已到底状态: %+v", raw)
	}
}
