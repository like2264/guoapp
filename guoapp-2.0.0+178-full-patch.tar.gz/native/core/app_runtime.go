package core

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Config struct {
	dataDir         string
	cacheDir        string
	MaxPagesPerSort int
	PageSize        int
	Retries         int
	InsecureTLS     bool
}

type Downloader struct {
	rankings          rankingCache
	cfg               Config
	client            *http.Client
	reserveMu         sync.Mutex
	reserveNext       uint64
	reservations      map[uint64]func()
	providerMu        sync.Mutex
	providerHosts     map[string]string
	providersMu       sync.Mutex
	providers         map[string]Provider
	providerRevisions map[string]uint64
	limiter           *requestLimiter
	proxyRouter       *proxyRouter
	directOnce        sync.Once
	direct            *http.Client
	// 下载媒体字节专用的客户端：Transport.Proxy 固定为 nil，从客户端层面保证
	// 不走任何代理（+159 反馈：只靠 context 标记仍会漏代理流量）。
	mediaDirectOnce sync.Once
	mediaDirect     *http.Client
	diagnostics     *diagnosticLog
}

func DefaultConfig() Config { return Config{MaxPagesPerSort: 50, PageSize: 30, Retries: 2} }

type LibraryDrama struct {
	MetadataSchema int      `json:"metadataSchema"`
	ID             string   `json:"id"`
	Source         string   `json:"source"`
	SourceID       string   `json:"sourceId"`
	Title          string   `json:"title"`
	Description    string   `json:"description"`
	Cover          string   `json:"cover"`
	Episodes       int      `json:"episodes"`
	Category       string   `json:"category"`
	VIP            *bool    `json:"vip"`
	Heat           string   `json:"heat,omitempty"`
	Views          string   `json:"views,omitempty"`
	OnlineDate     string   `json:"onlineDate,omitempty"`
	Score          string   `json:"score,omitempty"`
	Tags           []string `json:"tags,omitempty"`
	ReleaseStatus  string   `json:"releaseStatus,omitempty"`
	Badge          string   `json:"badge,omitempty"`
	// WebURL 是该剧在站源网页端的详情页地址，供详情页「用浏览器打开」使用。
	// 纯接口型的站源（没有可读网页）留空，Dart 侧据此隐藏按钮。
	WebURL string `json:"webUrl,omitempty"`
	// Rank 是搜索结果的相关度档位（1..7，见 app_search_precision.go）：
	// 3 及以上表示标题里就带着关键词，界面算作「精确匹配」；1、2 是标签/分类
	// 或简介命中，算「另有相关」。目录页不带这个字段（omitempty）。
	Rank int `json:"rank,omitempty"`
}

type nativeInput struct {
	SystemProxy     nativeSystemProxy       `json:"systemProxy"`
	Settings        nativeResourceSettings  `json:"settings"`
	JobIDs          []string                `json:"jobIds"`
	PlaybackSession string                  `json:"playbackSession"`
	StartMS         int64                   `json:"startMs"`
	DurationMS      int64                   `json:"durationMs"`
	Board           string                  `json:"board"`
	Entries         []nativeDownloadEpisode `json:"entries"`
	JobID           string                  `json:"jobId"`
	Command         string                  `json:"command"`
	Action          string                  `json:"action"`
	Directory       string                  `json:"directory"`
	Cache           string                  `json:"cache"`
	Downloads       string                  `json:"downloads"`
	Source          string                  `json:"source"`
	Page            int                     `json:"page"`
	Query           string                  `json:"query"`
	Category        string                  `json:"category"`
	Drama           LibraryDrama            `json:"drama"`
	Chapter         Chapter                 `json:"chapter"`
	Chapters        []Chapter               `json:"chapters"`
	Index           int                     `json:"index"`
	Quality         int                     `json:"quality"`
	Session         string                  `json:"session"`
	Sequence        int64                   `json:"sequence"`
	Force           bool                    `json:"force"`
	// Raw 表示这次目录请求只要站点当页的真值：不读旧缓存、不把旧缓存合并回
	// 结果、不沿用上一次的 page/hasMore，也不写回缓存。重走整条目录和分类
	// 补齐走这条道 —— 否则第 1 页会被合并成旧缓存全量且 hasMore=false，
	// 重走一开始就误判到底，站点上新永远进不来（+174 修）。
	Raw     bool            `json:"raw"`
	Lane    string          `json:"lane"`
	Version string          `json:"version"`
	Since   string          `json:"since"`
	Account json.RawMessage `json:"account"`
	Device  string          `json:"device"`
	File    string          `json:"file"`
	URL     string          `json:"url"`
	Token   string          `json:"token"`
}

type nativeCatalogResult struct {
	Items       []LibraryDrama `json:"items"`
	HasMore     bool           `json:"hasMore"`
	Page        int            `json:"page"`
	Warning     string         `json:"warning,omitempty"`
	LocalSearch bool           `json:"localSearch"`
	Fresh       bool           `json:"fresh"`
	// 站源目录的作品总量（部）；站源给不出时为 0，前端退回本地收录数。
	Total     int `json:"total,omitempty"`
	saveError error
}

type nativePlan struct {
	ExpiresAt       int64             `json:"expiresAt,omitempty"`
	PrefetchedBytes int64             `json:"prefetchedBytes,omitempty"`
	DanmakuID       string            `json:"danmakuId,omitempty"`
	Local           bool              `json:"local"`
	URL             string            `json:"url"`
	Headers         map[string]string `json:"headers"`
	Key             string            `json:"decryptionKey,omitempty"`
	Quality         int               `json:"quality"`
	Qualities       []int             `json:"qualities"`
	Session         string            `json:"session,omitempty"`
	RouteIndex      int               `json:"routeIndex"`
	RouteCount      int               `json:"routeCount"`
	// DurationMS 是本集播放列表的总时长（HLS 的 #EXTINF 求和，或模块自己给的
	// durationMs）。选集面板的「本剧总时长」靠它累加，拿不到时为 0。
	DurationMS int64 `json:"durationMs,omitempty"`
}

type nativeEngine struct {
	settingsMu       sync.Mutex
	settings         nativeResourceSettings
	readMu           sync.Mutex
	reads            map[string]nativeReadRequest
	readCount        int
	work             map[string]bool
	downloads        *nativeDownloads
	downloader       *Downloader
	directory        string
	cacheDirectory   string
	defaultDownloads string
	mu               sync.Mutex
	catalogs         map[string][]LibraryDrama
	catalogStates    map[string]nativeCatalogState
	categoryOptions  map[string][]Category
	// 磁盘目录缓存写入时的模块版本。模块换版后旧卡片必须作废，
	// 否则 saveCatalogCache 会把上一版的条目整段补回来（见 dropStaleModuleCaches）。
	moduleVersions      map[string]string
	providerStates      map[string]json.RawMessage
	providerStatesSaved []byte
	recommendations     map[string]nativeRecommendationState
	catalogSaveError    error
	covers              *nativeCoverCache
	stream              *nativeStreamServer
	cast                nativeCast
	playbacks           map[string]nativePlaybackChoice
	playbackMu          sync.Mutex
	playbackSequence    int64
	playbackCancel      context.CancelFunc
	// 选集面板的每集时长缓存（见 app_durations.go）。读写都在这个锁里，
	// 免得两批并发请求各写一次把对方的记录覆盖掉。
	durationMu      sync.Mutex
	sourceCatalogMu sync.Mutex
	sourceCatalogs  map[string]chan struct{}
	// 本地搜索索引（见 app_search_index.go）。懒加载，第一次搜索时才读盘。
	indexMu    sync.Mutex
	indexStore *searchIndexStore
	// 前台请求计数。后台索引任务靠它避开用户正在等的请求，不然两边同时打
	// 同一个站源，站点直接断连（黄果视频的搜索接口会回 EOF）。
	foregroundMu sync.Mutex
	foreground   int
}

var nativeState struct {
	sync.Mutex
	engine *nativeEngine
}

func NativeText(value any) string {
	switch v := value.(type) {
	case string:
		return strings.TrimSpace(v)
	case map[string]any:
		for _, key := range []string{"url", "src", "cover", "image", "pic"} {
			if text := NativeText(v[key]); text != "" {
				return text
			}
		}
	case []any:
		for _, entry := range v {
			if text := NativeText(entry); text != "" {
				return text
			}
		}
	case json.Number:
		return string(v)
	case float64:
		return strconv.Itoa(int(v))
	case int:
		return strconv.Itoa(v)
	}
	return ""
}

func NativeNormalize(drama Drama) LibraryDrama {
	cover := ""
	for _, value := range []any{drama.Cover, drama.CoverURL, drama.CoverURLSnake, drama.Image, drama.ImageURL, drama.ImageURLSnake, drama.Img, drama.Pic, drama.Picture, drama.Poster, drama.Thumb, drama.Thumbnail} {
		candidate := NativeText(value)
		if strings.HasPrefix(candidate, "//") {
			candidate = "https:" + candidate
		}
		if IsProviderHTTPMediaURL(candidate) {
			cover = candidate
			break
		}
	}
	episodes := 0
	for _, value := range []any{drama.TotalEpisode, drama.TotalEpisodeSnake, drama.EpisodeCount, drama.EpisodeCountSnake, drama.ChapterCount, drama.ChapterCountSnake, drama.Total, drama.Episodes} {
		if count, _ := strconv.Atoi(NativeText(value)); count > episodes {
			episodes = count
		}
	}
	source, sourceID, _ := SplitProviderDramaID(drama.ID)
	return LibraryDrama{MetadataSchema: 1, ID: drama.ID, Source: source, SourceID: sourceID, Title: drama.DisplayTitle(),
		Description: FirstNonEmpty(drama.Desc, drama.Intro), Cover: cover, Episodes: episodes,
		Category: nativeDramaCategory(drama), VIP: drama.VIP,
		Heat: drama.Heat, Views: drama.Views, OnlineDate: ProviderReleaseDate(drama.OnlineDate), Score: NativeDramaScore(drama.Score),
		Tags: append([]string(nil), drama.Tags...), ReleaseStatus: drama.ReleaseStatus, Badge: drama.Badge}
}

func NativeDramaScore(score string) string {
	score = strings.TrimSpace(strings.TrimSuffix(strings.TrimPrefix(strings.TrimSpace(score), "评分"), "分"))
	value, err := strconv.ParseFloat(score, 64)
	if err != nil || !(value > 0 && value <= 10) {
		return ""
	}
	return strconv.FormatFloat(value, 'f', 1, 64)
}

func nativeDramaCategory(drama Drama) string {
	category := FirstNonEmpty(drama.CategoryName, drama.CategoryNameSnake, drama.TypeName, drama.TypeNameSnake, drama.SortName, drama.SortNameSnake, drama.Category)
	if category != "" {
		return category
	}
	switch drama.ChannelName {
	case "真人剧", "短剧", "漫剧", "AI 剧", "AI剧", "AI 短剧", "AI 漫剧", "AI 换脸", "AI 魔改":
		return drama.ChannelName
	}
	return ""
}

func newNativeEngine(directory, cache, downloads string) (*nativeEngine, error) {
	if !filepath.IsAbs(directory) {
		return nil, errors.New("应用数据目录无效")
	}
	if !filepath.IsAbs(cache) {
		return nil, errors.New("应用缓存目录无效")
	}
	if err := os.MkdirAll(directory, 0700); err != nil {
		return nil, err
	}
	if err := os.MkdirAll(cache, 0700); err != nil {
		return nil, err
	}
	moveLegacyNativeCache(directory, cache)
	cfg := DefaultConfig()
	cfg.dataDir = directory
	cfg.cacheDir = cache
	router := &proxyRouter{}
	d := &Downloader{cfg: cfg, providerHosts: map[string]string{}, proxyRouter: router,
		limiter: newRequestLimiter(3, 250*time.Millisecond), diagnostics: newDiagnosticLog(directory)}
	transport := http.DefaultTransport.(*http.Transport).Clone()
	transport.TLSClientConfig = &tls.Config{MinVersion: tls.VersionTLS12}
	transport.MaxIdleConnsPerHost = 8
	transport.ResponseHeaderTimeout = 20 * time.Second
	transport.Proxy = router.proxy
	cdn := newCDNTransport(transport, newDNSResolver(transport))
	d.client = &http.Client{Transport: newHuangguoBrowserTransport(cdn, d), Timeout: 45 * time.Second,
		CheckRedirect: func(request *http.Request, via []*http.Request) error {
			if len(via) >= 10 {
				return errors.New("站源重定向次数过多")
			}
			if len(via) > 0 && !strings.EqualFold(request.URL.Host, via[0].URL.Host) {
				request.Header.Del("X-Preview-Token")
			}
			return nil
		}}
	engine := &nativeEngine{downloader: d, directory: directory, cacheDirectory: cache, defaultDownloads: nativeDefaultDownloads(directory), catalogs: map[string][]LibraryDrama{}, catalogStates: map[string]nativeCatalogState{}}
	if filepath.IsAbs(downloads) {
		engine.defaultDownloads = filepath.Clean(downloads)
	}
	d.loadModules()
	engine.loadResourceSettings()
	d.loadRankingCache()
	engine.loadCatalogCache()
	engine.covers = newNativeCoverCache(cache, d)
	engine.downloads = newNativeDownloads(engine)
	return engine, nil
}

func NativeRequest(raw string) (result string) {
	defer func() {
		if recover() != nil {
			result = `{"ok":false,"error":"本地核心处理失败，请重试"}`
		}
	}()
	var input nativeInput
	if len(raw) > 1<<20 || json.Unmarshal([]byte(raw), &input) != nil {
		return `{"ok":false,"error":"请求格式无效"}`
	}
	data, err := nativeDispatch(input)
	envelope := map[string]any{"ok": err == nil}
	if err != nil {
		envelope["error"] = PublicError(err).Error()
		if errors.Is(err, errNativeLocalFile) {
			envelope["code"] = "local_media"
		}
		if errors.Is(err, ErrSourceLogin) {
			envelope["code"] = "source_login"
		}
		var backoff *RequestBackoff
		if errors.As(err, &backoff) {
			envelope["code"] = "source_blocked"
			envelope["retryAt"] = backoff.until
		}
	} else {
		envelope["data"] = data
	}
	body, marshalErr := json.Marshal(envelope)
	if marshalErr != nil {
		return `{"ok":false,"error":"无法读取站源返回的数据"}`
	}
	return string(body)
}

func nativeDispatch(input nativeInput) (any, error) {
	if err := nativeAuthorizeInput(input); err != nil {
		return nil, err
	}
	nativeState.Lock()
	if input.Action == "initialize" {
		if nativeState.engine == nil {
			engine, err := newNativeEngine(input.Directory, input.Cache, input.Downloads)
			if err != nil {
				nativeState.Unlock()
				return nil, err
			}
			nativeState.engine = engine
		}
		engine := nativeState.engine
		nativeState.Unlock()
		return map[string]any{"version": "0.2.17", "standalone": true, "sources": engine.sourceList()}, nil
	}
	engine := nativeState.engine
	nativeState.Unlock()
	if engine == nil {
		return nil, errors.New("应用核心尚未就绪，请重新打开应用")
	}
	duration := 60 * time.Second
	if input.Action == "moveDownloads" {
		duration = 10 * time.Minute
	} else if input.Action == "danmaku" {
		duration = 10 * time.Second
	} else if input.Action == "preload" {
		duration = 15 * time.Second
	}
	ctx, cancel := context.WithTimeout(context.Background(), duration)
	defer cancel()
	if input.Action == "danmaku" || input.Action == "preload" || input.Session != "" && (input.Action == "catalog" || input.Action == "categories" || input.Action == "suggestions" || input.Action == "recommendations" || input.Action == "metadata") {
		work, finish, err := engine.beginRead(ctx, input)
		if err != nil {
			return nil, err
		}
		defer finish()
		ctx = work
	}
	switch input.Action {
	case "updateSystemProxy":
		return true, engine.updateSystemProxy(input.SystemProxy)
	case "resourceSettings":
		return engine.resourceSettings(), nil
	case "saveResourceSettings":
		return engine.saveResourceSettings(input.Settings)
	case "controlDownloadBatch":
		return engine.downloads.controlBatch(ctx, input.JobIDs, input.Command)
	case "preload":
		return engine.nativePreload(ctx, input)
	case "danmaku":
		return engine.nativeDanmaku(ctx, input)
	case "cancelRead":
		engine.cancelRead(input)
		return true, nil
	case "recommendations":
		return engine.nativeRecommendations(ctx, input)
	case "cachedRecommendations":
		return engine.cachedRecommendations(nativeActionSource(input), input.Category)
	case "modules":
		items, err := engine.modules()
		return map[string]any{"items": items}, err
	case "moduleIndex":
		return engine.moduleStore(ctx)
	case "prepareModule":
		return engine.prepareModule(ctx, input.File, input.URL, input.Source)
	case "installModule":
		return engine.installModule(input.Token)
	case "uninstallModule":
		return engine.uninstallModule(input.Source)
	case "sourceDevices":
		return engine.sourceDevices(ctx, nativeActionSource(input), input.Command == "register")
	case "soraniAccount", "sourceAccount":
		return engine.sourceAccount(ctx, nativeActionSource(input), input.Command, input.Account)
	case "rankingBoards":
		boards := []RankingBoard{}
		for _, board := range allRankingBoards() {
			if nativeSourceAvailable(board.Source) {
				boards = append(boards, board)
			}
		}
		return map[string]any{"items": boards}, nil
	case "rankings":
		return engine.nativeRanking(ctx, input)
	case "suggestions":
		items, err := engine.suggestions(ctx, nativeActionSource(input), input.Query)
		return map[string]any{"items": items}, err
	case "warm":
		return map[string]any{}, engine.warmSource(ctx, nativeActionSource(input))
	case "searchAll":
		return engine.nativeSearchAll(ctx, input.Query)
	case "downloadDirectory":
		engine.downloads.mu.Lock()
		root := engine.downloads.root
		engine.downloads.mu.Unlock()
		return map[string]string{"directory": root}, nil
	case "storage":
		return engine.storage()
	case "moveDownloads":
		leftover, reason, err := engine.moveDownloads(ctx, input.Directory)
		return map[string]string{"leftover": leftover, "leftoverReason": reason}, err
	case "workLease":
		count, err := engine.workLease(input.JobID, input.Command)
		return map[string]int{"count": count}, err
	case "downloads":
		return engine.downloads.snapshotSince(input.Since)
	case "enqueueDownloads":
		added, err := engine.downloads.enqueueContext(ctx, input)
		return map[string]int{"added": added}, err
	case "controlDownloads":
		return true, engine.downloads.control(input.JobID, input.Command)
	case "beginConversion":
		return engine.downloads.beginConversion(input.JobID)
	case "finishConversion":
		return true, engine.downloads.finishConversion(input.JobID, input.Command)
	case "localPlayback":
		plan, _, err := engine.downloads.localPlan(input.Drama.ID, input.Index)
		return plan, err
	case "catalog":
		return engine.nativeCatalog(ctx, input)
	case "cached":
		if !ValidNativeCategory(canonicalProviderSource(input.Source), input.Category) {
			return nil, errors.New("内容分类无效")
		}
		return engine.nativeCached(nativeCatalogKey(input.Source, input.Category)), nil
	case "categories":
		items, err := engine.nativeCategories(ctx, input.Source, input.Force)
		return map[string]any{"items": items}, err
	case "cover":
		return engine.loadCover(ctx, input.Drama, input.Force)
	case "prepareCover":
		return engine.prepareCover(ctx, input.Drama)
	case "detail":
		return engine.nativeDetail(ctx, input.Drama)
	case "chapterDurations":
		return engine.nativeChapterDurations(ctx, input)
	case "seasons":
		return engine.nativeSeasons(ctx, input.Drama)
	case "metadata":
		return engine.nativeMetadata(ctx, input.Drama)
	case "followCheck":
		return engine.nativeFollowCheck(ctx, input.Drama)
	case "resolve", "fallback":
		playback, finish, err := engine.nativeBeginPlayback(ctx, input.Sequence)
		if err != nil {
			return nil, err
		}
		defer finish()
		if input.Action == "fallback" {
			return engine.nativeNextPlayback(playback, input.Session)
		}
		return engine.nativeResolve(playback, input)
	case "cancelPlayback":
		engine.nativeCancelPlayback(input.Sequence)
		return true, nil
	case "release":
		engine.nativeReleasePlayback(input.Session)
		return true, nil
	case "cast":
		return engine.nativeCast(ctx, input)
	case "checkUpdate":
		return engine.checkUpdate(ctx, input.Version)
	case "reportUsage":
		return true, engine.reportUsage(ctx, input.Version)
	default:
		return nil, errors.New("不支持的应用操作")
	}
}

// searchProbePages 是单次搜索最多向后探测的页数：整页都对不上关键词时，
// 继续往后翻，直到拿到相关内容或站点到底，最多翻这么多页就返回（避免
// 一次请求把时间耗在连续的空页上）。前端拿到空页但 hasMore 为真时还会
// 继续往下滚，所以这里只是控制单次请求的耗时。
const searchProbePages = 6

// searchProbeBudget 是探测的时间预算：慢站源（柚子短剧单页约 20s）连翻
// 多页会撑爆调用方 70s 的超时，这里按已耗时提前收手，把已经等到的结果
// 交回去，剩下的留到用户下次下滑再取。
const searchProbeBudget = 45 * time.Second

// nativeCatalog 在搜索结果出口统一做一次精准排序与过滤：
// 完全无关的条目丢掉，其余按相关度重排（见 NativePreciseSearchStrict）。
//
// 站点的搜索接口普遍是宽匹配，一页里可能一条都对不上关键词（黄桃搜「总裁」
// 时从第 3 页起整页都是无关作品）。这种页不能原样返回给用户，所以继续往后
// 翻页探测；拿到相关内容就带上去，站点到底还没命中就返回空页并关掉 hasMore。
// 这样既不会把无关作品漏出去，也不会漏掉「后面几页才出现」的相关作品。
func (engine *nativeEngine) nativeCatalog(ctx context.Context, input nativeInput) (nativeCatalogResult, error) {
	query := strings.TrimSpace(input.Query)
	if query == "" {
		return engine.nativeCatalogRaw(ctx, input)
	}
	page := max(1, input.Page)
	// 本地索引先算一遍。站点的搜索接口大多只认标题和标签，简介里的关键词
	// 在黄果视频、黑桃、禁果短剧上根本搜不到（见 app_search_index.go 开头），
	// 索引里存着翻过的条目和后台补到的简介，这一遍就是把第 7 档捞回来的地方。
	done := engine.beginForeground()
	defer done()
	local := engine.searchIndexed(input.Source, query)
	localPage := searchIndexPageSlice(local, page)
	started := time.Now()
	kept := []LibraryDrama{}
	// scanned 是站点这一轮吐出来的原始条目（含被过滤掉的）。它们的简介里可能
	// 就有搜索词，只是站点搜索只按标题和标签召回，判不出来——交给后台补简介，
	// 下一轮搜索就能从本地索引里把它们捞回来。
	scanned := []LibraryDrama{}
	last := nativeCatalogResult{Items: []LibraryDrama{}, Page: page}
	exhausted := false
	for probe := 0; probe < searchProbePages; probe++ {
		if err := ctx.Err(); err != nil {
			// 本地索引有结果时不该因为站点超时给用户一个错误页。
			if probe == 0 && len(localPage) == 0 {
				return nativeCatalogResult{}, err
			}
			break
		}
		if probe > 0 && time.Since(started) > searchProbeBudget {
			break
		}
		next := input
		next.Page = page + probe
		result, err := engine.nativeCatalogRaw(ctx, next)
		if err != nil {
			if probe == 0 && len(localPage) == 0 {
				return result, err
			}
			break
		}
		last = result
		last.Page = next.Page
		last.HasMore = false
		if len(result.Items) == 0 {
			// 站点这一页就没内容了，说明已经到底。
			exhausted = true
			break
		}
		scanned = append(scanned, result.Items...)
		kept = append(kept, NativePreciseSearchStrict(result.Items, query)...)
		if len(kept) > 0 {
			// 本页（或前面几页累计）拿到相关内容了，正常返回。
			last.HasMore = result.HasMore
			break
		}
		if !result.HasMore {
			// 站点到底为止一条都对不上：只留本地命中的部分。
			exhausted = true
			break
		}
	}
	last.Items = mergeSearchWithIndex(kept, localPage, query)
	if last.Items == nil {
		// 合并后可能一条都不剩。JSON 里必须是 []，不能是 null：前端拿到 null
		// 会当成「没有 items 字段」直接报错。
		last.Items = []LibraryDrama{}
	}
	last.Page = page
	if exhausted {
		last.HasMore = false
	}
	// 本地还有下一页命中时，即使站点到底了也要让界面能继续翻。
	if len(local) > page*searchIndexPageSize {
		last.HasMore = true
	}
	// 搜索出口顺手让后台补索引：翻几页目录、补几条简介。
	// 只把「这一轮没判出来」的条目排队：标题/标签已经命中的那些不缺简介，
	// 排进去只会白占后台额度，把真正只有简介沾边的作品挤到后面。
	if len(scanned) > 0 {
		matched := make(map[string]bool, len(kept))
		for _, item := range kept {
			matched[item.ID] = true
		}
		pending := make([]LibraryDrama, 0, len(scanned))
		for _, item := range scanned {
			if item.ID == "" || matched[item.ID] {
				continue
			}
			pending = append(pending, item)
		}
		engine.queueIntros(input.Source, pending)
	}
	engine.queueSearch(input.Source, query)
	engine.kickSearchIndex(input.Source)
	if len(last.Items) == 0 && last.Warning == "" {
		// 一条都没有时给个方向：站点的搜索接口本来就不索引简介，索引还没补到
		// 这一块的时候搜不到是正常的，等后台补一轮再搜就有了。
		if entries, _, _ := engine.indexStats(input.Source); entries < searchIndexWarmThreshold {
			last.Warning = "本地索引还在补全，稍后再搜一次可能就有结果"
		}
	}
	return last, nil
}

func (engine *nativeEngine) nativeCatalogRaw(ctx context.Context, input nativeInput) (nativeCatalogResult, error) {
	source := canonicalProviderSource(input.Source)
	if !registeredProviderSource(source) {
		return nativeCatalogResult{}, errors.New("请选择有效站源")
	}
	category := strings.TrimSpace(input.Category)
	if !ValidNativeCategory(source, category) {
		return nativeCatalogResult{}, errors.New("内容分类无效")
	}
	cacheKey := nativeCatalogKey(source, category)
	if err := ctx.Err(); err != nil {
		return nativeCatalogResult{}, err
	}
	page := max(1, input.Page)
	query := strings.TrimSpace(input.Query)
	// 真值通道必须每次都问站点：写盘失败重试命中时不能拿整份旧缓存当「第 1 页」
	// 返回，否则下架的旧作品会被当成站点现状并回列表副本（+177）。
	if query == "" && !input.Raw {
		if retried, err := engine.retryCatalogSave(); retried {
			cached := engine.nativeCached(cacheKey)
			if err != nil || len(cached.Items) > 0 {
				return cached, nil
			}
		}
	}
	if query == "" && page == 1 && !input.Force && !input.Raw {
		if cached := engine.nativeCached(cacheKey); cached.Fresh {
			return cached, nil
		}
	}
	d := engine.downloader
	result := nativeCatalogResult{Items: []LibraryDrama{}, Page: page}
	registered, hasProvider := d.provider(source)
	if searcher, ok := providerAs[WarningSearcher](registered); ok && query != "" {
		items, more, warning, err := searcher.SearchWithWarning(ctx, page, query)
		if err != nil {
			return result, err
		}
		for _, drama := range items {
			result.Items = append(result.Items, NativeNormalize(drama))
		}
		result.Warning, result.HasMore = warning, more
		engine.indexDramas(source, result.Items)
		return result, nil
	}
	if searcher, ok := providerAs[Searcher](registered); ok && query != "" {
		items, more, err := searcher.Search(ctx, page, query)
		if err != nil {
			return result, err
		}
		for _, drama := range items {
			result.Items = append(result.Items, NativeNormalize(drama))
		}
		result.HasMore = more
		engine.indexDramas(source, result.Items)
		return result, nil
	}
	if query != "" {
		engine.mu.Lock()
		items := append([]LibraryDrama{}, engine.catalogs[source]...)
		engine.mu.Unlock()
		for _, item := range items {
			text := NativeSearchText(item.Title + " " + item.Description + " " + strings.Join(item.Tags, " "))
			matches := true
			for _, word := range strings.Fields(query) {
				matches = matches && strings.Contains(text, NativeSearchText(word))
			}
			if matches {
				result.Items = append(result.Items, item)
			}
		}
		result.LocalSearch = true
		engine.indexDramas(source, result.Items)
		return result, nil
	}
	unlock, lockErr := engine.lockSourceCatalog(ctx, source, input.Lane)
	if lockErr != nil {
		return nativeCatalogResult{}, lockErr
	}
	defer unlock()
	if err := ctx.Err(); err != nil {
		return result, err
	}
	var items []Drama
	var err error
	if !hasProvider {
		return result, errors.New("请选择有效站源")
	}
	descriptor := registered.Descriptor()
	allowEmptyCatalog := descriptor.AllowEmptyCatalog
	if descriptor.ContinuousFeed {
		engine.mu.Lock()
		known := make(map[string]bool, len(engine.catalogs[cacheKey]))
		for _, drama := range engine.catalogs[cacheKey] {
			known[drama.ID] = true
		}
		engine.mu.Unlock()
		ctx = context.WithValue(ctx, LibraryKnownKey{}, known)
		if page > 1 {
			ctx = context.WithValue(ctx, LibraryMoreKey{}, true)
		}
	}
	items, result.HasMore, err = registered.CatalogPage(ctx, page, category)
	// 这里故意不走 providerAs：模块的能力表（manifest 声明）里没有 CatalogTotaler，
	// 走能力过滤反而永远拿不到。它只是原生内部顺带传的一个数字，直接断言即可。
	if totals, ok := registered.(CatalogTotaler); ok {
		if total := totals.CatalogTotal(); total > 0 {
			result.Total = total
		}
	}
	if err != nil && len(items) == 0 {
		return result, err
	}
	if len(items) == 0 && page == 1 && !allowEmptyCatalog {
		return result, errors.New("站源暂未返回剧集，请稍后刷新")
	}
	if err != nil {
		result.Warning = PublicError(err).Error()
	}
	seen := map[string]bool{}
	for _, drama := range items {
		if drama.ID == "" || seen[drama.ID] {
			continue
		}
		seen[drama.ID] = true
		result.Items = append(result.Items, NativeNormalize(drama))
	}
	// 目录页也进索引。用户翻到哪就记到哪，这部分不花额外请求。
	engine.indexDramas(source, result.Items)
	// Raw 是「重走整条目录 / 分类补齐」专用的只读通道：把站点当页的真值
	// 原样交回，不写缓存也不做旧缓存合并。saveCatalogCache 在 page==1 时
	// 会把上次翻到底的全量缓存重新追加回结果，并把 page/hasMore 换成旧的
	// 「已到底」状态 —— 重走第 1 页就收到 1500 条旧卡片和 hasMore=false，
	// 看起来成功了，其实站点上新一部都进不来（+174 修）。
	if !input.Raw {
		engine.saveCatalogCache(cacheKey, &result)
	}
	return result, nil
}

func (engine *nativeEngine) nativeDetail(ctx context.Context, drama LibraryDrama) (any, error) {
	source, sourceID, valid := SplitProviderDramaID(drama.ID)
	if !valid {
		return nil, errors.New("剧集信息无效，请刷新剧库")
	}
	p, ok := engine.downloader.provider(source)
	if !ok {
		return nil, errors.New("请选择有效站源")
	}
	raw, chapters, err := p.Detail(ctx, sourceID)
	if err != nil {
		return nil, err
	}
	if len(chapters) == 0 {
		return nil, errors.New("该剧暂时没有可播放的分集")
	}
	if raw.ID == drama.ID {
		drama = MergeNativeDrama(drama, NativeNormalize(raw))
	}
	drama.Source, drama.SourceID, drama.Episodes = source, sourceID, len(chapters)
	if p.Descriptor().KeepDetailEpisodes {
		drama.Episodes = max(drama.Episodes, NativeNormalize(raw).Episodes)
	}
	drama.WebURL = nativeDramaWebURL(drama.WebURL, chapters)
	warning := ""
	if err := engine.saveDetailMetadata(drama); err != nil {
		warning = err.Error()
	}
	return map[string]any{"drama": drama, "chapters": chapters, "warning": warning}, nil
}

func (engine *nativeEngine) nativeResolve(ctx context.Context, input nativeInput) (nativePlan, error) {
	if _, _, valid := SplitProviderDramaID(input.Drama.ID); !valid {
		return nativePlan{}, errors.New("剧集信息无效")
	}
	if !input.Force && engine.downloads != nil {
		if plan, found, err := engine.downloads.localPlan(input.Drama.ID, input.Index); found || err != nil {
			return plan, err
		}
	}
	task := Task{DramaID: input.Drama.ID, DramaTitle: input.Drama.Title, Chapter: input.Chapter, Index: input.Index}
	media, err := engine.downloader.resolveProviderMedia(ctx, task)
	if err != nil {
		return nativePlan{}, err
	}
	choice := nativePlaybackChoices(media, input.Quality)
	// 播放途中凭证会过期（柚子这类站点的访客会话与年龄确认都有有效期），
	// 拖动进度到未缓冲位置时才会暴露。这里把「重新解析一次」交给流服务，
	// 由它在本地判定过期或收到 401/403 时调用。
	choice.refresh = func(refreshCtx context.Context) (*MediaCredentials, error) {
		fresh, err := engine.downloader.resolveProviderMedia(refreshCtx, task)
		if err != nil {
			return nil, err
		}
		if fresh.Credentials == nil {
			return nil, errors.New("预览凭证未返回，无法续期")
		}
		return fresh.Credentials, nil
	}
	if p, ok := engine.downloader.provider(SourceFromDramaID(task.DramaID)); ok {
		if danmaku, ok := providerAs[DanmakuProvider](p); ok {
			if series, video, valid := danmaku.DanmakuIDs(task); valid {
				choice.danmakuSource, choice.danmakuSeries, choice.danmakuVideo = p.Descriptor().ID, series, video
			}
		}
	}
	return engine.nativeOpenPlayback(ctx, choice)
}
