import 'package:flutter/material.dart';

import '../../local_store.dart';
import '../../models.dart';
import '../shell/app_shell.dart';
import '../widgets/focus_ring.dart';

/// 站源自定义排序：拖一下就改「全部站源」里站源出现的先后。
///
/// 排序结果写进用户设置（sourceOrder），所以换设备/换用户互不影响；
/// 没排到的站源按注册顺序排在后面，新装的站源也不会被漏掉。
Future<void> openSourceOrder(BuildContext anchor, LocalStore store) =>
    openPage<void>(anchor, (_) => _SourceOrderPage(store: store));

class _SourceOrderPage extends StatefulWidget {
  const _SourceOrderPage({required this.store});
  final LocalStore store;

  @override
  State<_SourceOrderPage> createState() => _SourceOrderPageState();
}

class _SourceOrderPageState extends State<_SourceOrderPage> {
  late List<SourceSite> _sites = widget.store.sources;
  var _dirty = false;

  void _move(int from, int to) {
    setState(() {
      if (to > from) to -= 1;
      final site = _sites.removeAt(from);
      _sites.insert(to, site);
      _dirty = true;
    });
  }

  Future<void> _save() async {
    try {
      await widget.store.setSourceOrder([for (final site in _sites) site.id]);
      if (!mounted) return;
      Navigator.pop(context);
    } catch (failure) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('$failure')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('站源排序'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: TextButton(
              onPressed: _dirty && _sites.length > 1 ? _save : null,
              child: const Text('保存'),
            ),
          ),
        ],
      ),
      body: _sites.length < 2
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Text(
                  '只有一个站源，不用排序。',
                  style: TextStyle(color: colors.onSurfaceVariant),
                ),
              ),
            )
          : ReorderableListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
              itemCount: _sites.length,
              onReorder: _move,
              proxyDecorator: (child, _, animation) => Material(
                color: colors.surfaceContainerHigh,
                elevation: 6,
                borderRadius: BorderRadius.circular(14),
                child: child,
              ),
              itemBuilder: (context, index) {
                final site = _sites[index];
                return Card(
                  key: ValueKey(site.id),
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: CircleAvatar(
                      radius: 16,
                      backgroundColor: colors.secondaryContainer,
                      child: Text(
                        '${index + 1}',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: colors.onSecondaryContainer,
                        ),
                      ),
                    ),
                    title: Text(site.name),
                    subtitle: Text(
                      site.description,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: ReorderableDragStartListener(
                      index: index,
                      child: const Padding(
                        padding: EdgeInsets.all(8),
                        child: Icon(Icons.drag_handle_rounded),
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
