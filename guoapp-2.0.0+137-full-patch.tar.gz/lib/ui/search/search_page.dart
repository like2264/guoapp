import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core_bridge.dart';
import '../../drama_feed.dart';
import '../../local_store.dart';
import '../../models.dart';
import '../../source_catalog.dart';
import '../app_scope.dart';
import '../detail/detail_page.dart';
import '../shell/app_shell.dart';
import '../theme/motion.dart';
import '../widgets/drama_grid.dart';
import '../widgets/follow_button.dart';
import '../widgets/focus_ring.dart';
import '../widgets/motion/motion_widgets.dart';
import '../widgets/search_field.dart';
import '../widgets/status_view.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({
    super.key,
    required this.store,
    required this.source,
    this.query = '',
    this.allSources = false,
  });
  final LocalStore store;
  final SourceSite source;
  final String query;

  /// 打开时是否直接进「全站源搜索」。发现页的放大镜旁边那个按钮用它。
  final bool allSources;

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  late final _controller = TextEditingController(text: widget.query);
  final _focus = FocusNode();
  late AppRepository _repository;
  late SourceCatalog _catalog;
  DramaFeed? _results;
  String _submitted = '';
  List<String> _suggestions = const [];

  /// 当前这批联想词对应的输入，用来判断能不能在本地收窄。
  String _suggestQuery = '';
  List<SourceSearchIssue> _issues = const [];
  Timer? _debounce;

  /// 拿不到结果时的重试定时器。第一次联想经常踩两个坑：站源模块要现初始化、
  /// 或者刚好有一堆封面/目录请求把并发读名额占满（native 侧会直接回
  /// 「请求较多」）。隔几百毫秒再问一次基本都能拿到。
  Timer? _retry;

  int _suggestion = 0;
  final _shownSuggestions = <Object>{};
  bool _ready = false;
  late bool _allSources = widget.allSources;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_ready) return;
    _ready = true;
    _repository = AppScope.of(context).repository;
    _catalog = SourceCatalog(_repository, widget.source);
    // 一进搜索页就在后台把站源模块热起来：模块冷启动那 1~2 秒原本正好压在
    // 第一次联想请求上，表现就是「第一次输入没有联想词，第二次才有」。
    unawaited(_repository.warm(widget.source.id));
    if (widget.query.trim().isNotEmpty) _submit(widget.query);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _retry?.cancel();
    _suggestion++;
    unawaited(_repository.cancelSuggestions());
    unawaited(_repository.cancelCatalog());
    _results?.dispose();
    _controller.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _forget(String query) {
    unawaited(HapticFeedback.selectionClick());
    unawaited(widget.store.forgetSearch(query).catchError((Object _) {}));
  }

  void _scope(bool allSources) {
    if (allSources == _allSources) return;
    unawaited(HapticFeedback.selectionClick());
    final previous = _results;
    setState(() {
      _allSources = allSources;
      _results = null;
      _issues = const [];
      _submitted = '';
    });
    previous?.dispose();
    final query = _controller.text.trim();
    if (query.isNotEmpty) _submit(query);
  }

  /// 全站搜索的取数：native 侧并发跑所有站源，再按相关度合并成一页。
  Future<CatalogPage> _searchAll(String query, int page) async {
    if (page > 1) return CatalogPage(const [], hasMore: false);
    final result = await _repository.searchAll(query);
    _issues = result.issues;
    return CatalogPage(
      result.items,
      hasMore: false,
      warning: result.warning,
    );
  }

  void _submit(String text) {
    final query = text.trim();
    if (query.isEmpty) return;
    _controller.text = query;
    _focus.unfocus();
    _debounce?.cancel();
    _retry?.cancel();
    _suggestion++;
    unawaited(widget.store.rememberSearch(query).catchError((Object _) {}));
    _results?.dispose();
    final all = _allSources;
    _issues = const [];
    final results = _results = DramaFeed(
      load: (page, _) => all
          ? _searchAll(query, page)
          : _catalog.search(query, page: page),
    )..addListener(() {
      if (mounted) setState(() {});
    });
    unawaited(results.reload());
    setState(() {
      _submitted = query;
      _suggestions = const [];
      _suggestQuery = '';
    });
  }

  /// 输入法还在选字（拼音/形码的中间态）时不要去问站点。
  ///
  /// 这不只是省流量：站点一定搜不到拼音串，而每敲一个字母就是一次 1~2 秒
  /// 的往返，等真正选完字时这些请求还占着 native 侧的并发读名额，
  /// 新请求只能排队甚至被拒 —— 表现就是「第一次输入词组联想不出来」。
  bool _composing() {
    final value = _controller.value;
    final range = value.composing;
    if (!range.isValid || range.isCollapsed) return false;
    // 选字区里已经是汉字，说明用户选过字了，可以正常联想。
    return range.textInside(value.text).runes.every((rune) => rune < 0x2E80);
  }

  void _changed(String text) {
    _debounce?.cancel();
    _retry?.cancel();
    final query = text.trim();
    final generation = ++_suggestion;
    if (!widget.source.searchSuggestions ||
        query.isEmpty ||
        _composing()) {
      setState(() {
        _suggestions = const [];
        _suggestQuery = '';
      });
      return;
    }
    // 先在本地把上一条结果按新输入收窄：继续往下打字时联想词是「立刻」变少的，
    // 不用等一次网络往返。新结果回来后再整体替换。
    final previous = _suggestQuery;
    if (previous.isNotEmpty && query.startsWith(previous)) {
      final needle = query.toLowerCase();
      final narrowed = [
        for (final item in _suggestions)
          if (item.toLowerCase().contains(needle)) item,
      ];
      if (narrowed.length != _suggestions.length) {
        setState(() => _suggestions = narrowed);
      }
    }
    // 60ms：足够挡掉连击，又不会让人觉得「打完字还在等」。
    _debounce = Timer(
      const Duration(milliseconds: 60),
      () => _fetch(generation, query),
    );
  }

  /// 取一次联想词，失败或空结果会自己重试。
  ///
  /// 之前只给三次、间隔 260ms，模块冷启动没跑完就放弃了 —— 用户看到的是
  /// 「第一次输入完全没联想」。现在放宽到四次、间隔递增（约 2 秒），
  /// 配合进页面时的预热，第一次输入也能出词。
  Future<void> _fetch(int generation, String query, {int attempt = 0}) async {
    try {
      final items = await _repository.suggestions(widget.source.id, query);
      if (!mounted || generation != _suggestion) return;
      if (items.isEmpty && attempt < 3) {
        _retry = Timer(
          Duration(milliseconds: 300 + attempt * 300),
          () => _fetch(generation, query, attempt: attempt + 1),
        );
        return;
      }
      setState(() {
        _suggestions = items;
        _suggestQuery = query;
      });
    } catch (_) {
      if (!mounted || generation != _suggestion) return;
      if (attempt < 3) {
        _retry = Timer(
          Duration(milliseconds: 240 + attempt * 300),
          () => _fetch(generation, query, attempt: attempt + 1),
        );
      }
    }
  }

  /// 联想词里把用户输入的那段标出来（加粗 + 主题色），一屏十几条也能一眼
  /// 看出每条到底匹配在哪儿。
  Widget _suggestionTitle(String text) {
    final query = _controller.text.trim();
    final colors = Theme.of(context).colorScheme;
    final base = TextStyle(fontSize: 15, color: colors.onSurface);
    if (query.isEmpty) return Text(text, style: base);
    final haystack = text.toLowerCase();
    final needle = query.toLowerCase();
    final spans = <TextSpan>[];
    var start = 0;
    while (true) {
      final hit = haystack.indexOf(needle, start);
      if (hit < 0) break;
      if (hit > start) {
        spans.add(TextSpan(text: text.substring(start, hit)));
      }
      spans.add(
        TextSpan(
          text: text.substring(hit, hit + needle.length),
          style: TextStyle(fontWeight: FontWeight.w800, color: colors.primary),
        ),
      );
      start = hit + needle.length;
    }
    if (spans.isEmpty) return Text(text, style: base);
    if (start < text.length) {
      spans.add(TextSpan(text: text.substring(start)));
    }
    return Text.rich(TextSpan(children: spans), style: base);
  }

  void _open(Drama drama) => openPage<void>(
    context,
    (_) => DetailPage(store: widget.store, drama: drama),
  );

  @override
  Widget build(BuildContext context) {
    final field = SearchField(
      hint: _allSources ? '在所有站源中搜索' : '在 ${widget.source.name} 中搜索',
      controller: _controller,
      focusNode: _focus,
      autofocus: widget.query.isEmpty,
      onChanged: _changed,
      onSubmitted: _submit,
      letterKeyboard: widget.store.televisionKeyboard,
      matches: widget.source.searchSuggestions
          ? (query) => _repository.suggestions(widget.source.id, query)
          : null,
    );
    if (AppScope.of(context).television) {
      return Scaffold(
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                televisionInset,
                27,
                televisionInset,
                0,
              ),
              child: Row(
                children: [
                  Expanded(child: field),
                  const SizedBox(width: 12),
                  _scopeChip(),
                ],
              ),
            ),
            Expanded(child: FadeSwitcher(child: _body(context))),
          ],
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Padding(
          padding: const EdgeInsets.only(right: 4),
          child: field,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Center(child: _scopeChip()),
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        bottom: false,
        child: FadeSwitcher(child: _body(context)),
      ),
    );
  }

  /// 「全站」开关：跟 1.0 一样的单颗 chip，放在搜索框右边。
  Widget _scopeChip() => FocusRing(
    radius: 999,
    child: FilterChip(
      label: const Text('全站'),
      selected: _allSources,
      onSelected: (_) => _scope(!_allSources),
      showCheckmark: false,
      visualDensity: VisualDensity.compact,
      tooltip: '同时在所有支持在线搜索的站源里查找',
    ),
  );

  Widget _body(BuildContext context) {
    final television = AppScope.of(context).television;
    if (_suggestions.isNotEmpty && _controller.text.trim() != _submitted) {
      return ListView(
        key: const ValueKey('suggest'),
        padding: television
            ? const EdgeInsets.fromLTRB(televisionInset, 8, televisionInset, 27)
            : const EdgeInsets.symmetric(vertical: 8),
        children: [
          for (final (index, item) in _suggestions.indexed)
            EnterOnce(
              key: ValueKey(index),
              id: item,
              played: _shownSuggestions,
              index: index,
              child: TileFocus(
                builder: (focusNode) => ListTile(
                  focusNode: focusNode,
                  leading: const Icon(Icons.search_rounded),
                  title: _suggestionTitle(item),
                  onTap: () => _submit(item),
                ),
              ),
            ),
        ],
      );
    }
    final results = _results;
    if (results == null) {
      return KeyedSubtree(
        key: const ValueKey('recent'),
        child: _recent(context),
      );
    }
    if (results.items.isEmpty) {
      if (results.loading) {
        return StatusView.loading(
          key: const ValueKey('loading'),
          title: _allSources ? '正在全站搜索' : '正在搜索',
        );
      }
      if (results.error.isNotEmpty) {
        return StatusView(
          key: const ValueKey('error'),
          title: '搜索失败',
          message: results.error,
          icon: Icons.cloud_off_rounded,
          action: '重试',
          onAction: () => results.reload(),
        );
      }
      return StatusView(
        key: const ValueKey('empty'),
        title: '没有找到「$_submitted」',
        message: _allSources ? '换个关键词，或稍后重试' : '换个关键词试试',
        icon: Icons.search_off_rounded,
      );
    }
    final inset = television
        ? televisionInset
        : AppScope.formFactorOf(context) == FormFactor.phone
        ? 16.0
        : 24.0;
    final colors = Theme.of(context).colorScheme;
    // 结果条数：列表还在往下加载时给「已找到 N 部」，到底了给「共 N 部」，
    // 免得用户以为只有眼前这些。
    //
    // 相关度分级之后这批结果其实混着两类：标题里就带关键词的「精确匹配」，
    // 和只在标签/分类/简介里沾边的「相关」。混成一个数字时「共找到 200 部」
    // 看起来很唬人，点进去全是擦边的 —— 所以分开报，让用户一眼知道有多少
    // 是真的对得上。没有档位信息的来源（老缓存、本地检索）仍沿用老文案。
    final total = results.items.length;
    final growing = results.hasMore || results.loadingMore;
    var exact = 0;
    var ranked = false;
    for (final item in results.items) {
      if (!item.hasRank) continue;
      ranked = true;
      if (item.titleMatched) exact++;
    }
    final related = total - exact;
    final String counter;
    if (!ranked) {
      counter = growing ? '已找到 $total 部 · 还在继续' : '共找到 $total 部';
    } else if (exact == 0) {
      counter = growing ? '另有 $related 部相关 · 还在继续' : '另有 $related 部相关';
    } else if (related == 0) {
      counter = growing ? '精确匹配 $exact 部 · 还在继续' : '精确匹配 $exact 部';
    } else {
      counter = growing
          ? '精确匹配 $exact 部 · 另有 $related 部相关 · 还在继续'
          : '精确匹配 $exact 部 · 另有 $related 部相关';
    }
    return LayoutBuilder(
      key: ValueKey(('results', _submitted, _allSources)),
      builder: (context, constraints) => AutoLoadMore(
        feed: results,
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: EdgeInsets.fromLTRB(inset, television ? 6 : 4, inset, 0),
              sliver: SliverToBoxAdapter(
                child: Text(
                  counter,
                  style: TextStyle(fontSize: 12, color: colors.onSurfaceVariant),
                ),
              ),
            ),
            if (_allSources && _issues.isNotEmpty)
              SliverPadding(
                padding: EdgeInsets.fromLTRB(inset, 4, inset, 0),
                sliver: SliverToBoxAdapter(child: _IssueNote(_issues)),
              ),
            SliverPadding(
              padding: EdgeInsets.fromLTRB(
                inset,
                television ? 16 : 8,
                inset,
                0,
              ),
              sliver: DramaSliverGrid(
                width: constraints.maxWidth - inset * 2,
                items: results.items,
                autofocus: television,
                heroScope: 'drama',
                highlight: _submitted,
                subtitleOf: _allSources
                    ? (drama) => SourceSite.byId(drama.source).name
                    : null,
                onOpen: _open,
                onMore: (drama) => quickFollow(context, widget.store, drama),
              ),
            ),
            SliverPadding(
              padding: EdgeInsets.fromLTRB(
                inset,
                8,
                inset,
                television ? 27 : 16,
              ),
              sliver: SliverToBoxAdapter(child: FeedFooter(feed: results)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _recent(BuildContext context) => ListenableBuilder(
    listenable: widget.store,
    builder: (context, _) {
      final recent = widget.store.recentSearches;
      return FadeSwitcher(child: _recentContent(context, recent));
    },
  );

  Widget _recentContent(BuildContext context, List<String> recent) {
    if (recent.isEmpty) {
      return StatusView(
        key: const ValueKey('empty'),
        title: _allSources ? '全站搜索' : '在 ${widget.source.name} 中搜索',
        message: _allSources ? '一次搜完所有已安装站源' : '输入剧名或关键词',
        icon: Icons.search_rounded,
      );
    }
    final theme = Theme.of(context);
    return ListView(
      key: const ValueKey('recent'),
      padding: AppScope.of(context).television
          ? const EdgeInsets.fromLTRB(televisionInset, 8, televisionInset, 27)
          : const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                '最近搜索',
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            FocusRing(
              radius: 999,
              child: TextButton(
                onPressed: () => widget.store.clearRecentSearches().catchError(
                  (Object _) {},
                ),
                child: const Text('清空'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        AnimatedSize(
          duration: Motion.of(context, Motion.medium),
          curve: Motion.enter,
          alignment: Alignment.topLeft,
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final query in recent)
                FocusRing(
                  radius: 8,
                  child: GestureDetector(
                    onLongPress: () => _forget(query),
                    onSecondaryTap: () => _forget(query),
                    child: ActionChip(
                      avatar: const Icon(Icons.history_rounded, size: 16),
                      label: Text(query),
                      onPressed: () => _submit(query),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _IssueNote extends StatelessWidget {
  const _IssueNote(this.issues);
  final List<SourceSearchIssue> issues;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(
        '${issues.length} 个站源没搜到：${issues.map((issue) => issue.name).join('、')}',
        style: TextStyle(fontSize: 12, color: colors.onSurfaceVariant),
      ),
    );
  }
}
