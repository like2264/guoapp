import 'package:flutter/material.dart';

import '../app_scope.dart';
import 'glass_tab_bar.dart';

/// 玻璃底栏浮在页面内容之上（`extendBody: true`），所以 tab 根页面的滚动区域
/// 要自己留出这段高度，否则最后一条内容会被玻璃条压住——模块页的「从地址安装」
/// 被挡住就是这么来的。
///
/// 非 Liquid Glass 时返回 0：那时底栏是普通 NavigationBar，Scaffold 已经留位。
double shellBottomInset(BuildContext context) {
  if (!AppScope.of(context).liquidGlass) return 0;
  return GlassTabBar.reservedHeight(context);
}

/// 给列表底部内边距加上底栏高度，写法统一一点。
EdgeInsets shellListPadding(
  BuildContext context, {
  double left = 16,
  double top = 8,
  double right = 16,
  double bottom = 24,
}) => EdgeInsets.fromLTRB(
  left,
  top,
  right,
  bottom + shellBottomInset(context),
);
