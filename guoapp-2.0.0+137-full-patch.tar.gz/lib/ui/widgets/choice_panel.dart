import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app_scope.dart';
import '../theme/glass.dart';
import 'focus_ring.dart';

class ChoiceOption<T> {
  const ChoiceOption(this.value, this.label);
  final T value;
  final String label;
}

class ChoiceGrid {
  const ChoiceGrid({
    required this.phone,
    required this.wide,
    required this.television,
    required this.wideWidth,
    required this.televisionWidth,
  });
  final int phone;
  final int wide;
  final int television;
  final double wideWidth;
  final double televisionWidth;

  static const sources = ChoiceGrid(
    phone: 3,
    wide: 3,
    television: 2,
    wideWidth: 420,
    televisionWidth: 400,
  );
  static const categories = ChoiceGrid(
    phone: 4,
    wide: 5,
    television: 4,
    wideWidth: 520,
    televisionWidth: 440,
  );
}

typedef ChoiceAction = ({String label, IconData icon, VoidCallback onPressed});

/// 玻璃面板顶部的小横条。系统自带的 drag handle 是画在 sheet 自己的
/// 不透明底上的，底透明后会浮在玻璃外面，所以这里自己画一条，
/// 位置跟着玻璃走；往下甩依然能关掉面板（sheet 的 enableDrag 兜着）。
class _SheetGrip extends StatelessWidget {
  const _SheetGrip();

  @override
  Widget build(BuildContext context) {
    final ink = Theme.of(context).colorScheme.onSurface;
    return Padding(
      padding: const EdgeInsets.only(top: 9, bottom: 5),
      child: Container(
        width: 40,
        height: 4,
        decoration: BoxDecoration(
          color: ink.withValues(alpha: 0.30),
          borderRadius: BorderRadius.circular(999),
        ),
      ),
    );
  }
}

Future<T?> showChoicePanel<T>({
  required BuildContext context,
  required String title,
  required List<ChoiceOption<T>> options,
  required T? selected,
  required ChoiceGrid grid,
  ChoiceAction? action,
  List<ChoiceAction> actions = const [],
}) {
  final form = AppScope.formFactorOf(context);
  Widget panel(BuildContext context) => _ChoicePanel<T>(
    form: form,
    title: title,
    options: options,
    selected: selected,
    columns: switch (form) {
      FormFactor.phone => grid.phone,
      FormFactor.pad || FormFactor.window => grid.wide,
      FormFactor.television => grid.television,
    },
    actions: [if (action case final action?) action, ...actions],
  );
  switch (form) {
    case FormFactor.phone:
      // 烟熏玻璃面板：贴边浮起一小截，四角圆掉，后面的封面透上来但糊开了。
      final dark = Theme.of(context).brightness == Brightness.dark;
      return showModalBottomSheet<T>(
        context: context,
        isScrollControlled: true,
        showDragHandle: false,
        useSafeArea: true,
        enableDrag: true,
        isDismissible: true,
        constraints: const BoxConstraints(maxHeight: 640),
        backgroundColor: Colors.transparent,
        // 透明底 + 0 阴影已经不会画出系统的底板了；showModalBottomSheet 本身没有
        // shadowColor / surfaceTintColor 这两个命名参数（只有 BottomSheet 组件和
        // BottomSheetThemeData 才有），别照组件那套传，会编译不过。
        elevation: 0,
        // 面板自己那圈玻璃描边就够了；这里不画形状，否则系统 sheet 会再描一圈，
        // 和玻璃边错开半个像素，看着就是面板周围多了一层线框。
        shape: const RoundedRectangleBorder(),
        clipBehavior: Clip.antiAlias,
        barrierColor: Colors.black.withValues(alpha: 0.30),
        builder: (context) => Padding(
          padding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
          child: GlassPanel(
            radius: 28,
            blur: 12,
            tint: 1.5,
            shade: dark ? 0.60 : 0,
            padding: EdgeInsets.zero,
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const _SheetGrip(),
                  Flexible(child: panel(context)),
                ],
              ),
            ),
          ),
        ),
      );
    case FormFactor.pad || FormFactor.window:
      return showAnchoredPanel<T>(
        context: context,
        width: grid.wideWidth,
        builder: panel,
      );
    case FormFactor.television:
      return showGeneralDialog<T>(
        context: context,
        barrierDismissible: true,
        barrierLabel: MaterialLocalizations.of(
          context,
        ).modalBarrierDismissLabel,
        barrierColor: Colors.black54,
        transitionDuration: const Duration(milliseconds: 220),
        pageBuilder: (context, _, _) => Align(
          alignment: Alignment.centerRight,
          child: Material(
            color: Theme.of(context).colorScheme.surfaceContainerLow,
            elevation: 8,
            child: SizedBox(
              width: grid.televisionWidth,
              height: double.infinity,
              child: panel(context),
            ),
          ),
        ),
        transitionBuilder: (_, animation, _, child) => SlideTransition(
          position: Tween(begin: const Offset(1, 0), end: Offset.zero).animate(
            CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
          ),
          child: child,
        ),
      );
  }
}

Future<T?> showAnchoredPanel<T>({
  required BuildContext context,
  required double width,
  required WidgetBuilder builder,
}) {
  final navigator = Navigator.of(context);
  final overlay = navigator.overlay!.context.findRenderObject()! as RenderBox;
  final anchor = context.findRenderObject()! as RenderBox;
  return navigator.push(
    _AnchoredRoute<T>(
      anchor:
          anchor.localToGlobal(Offset.zero, ancestor: overlay) & anchor.size,
      width: width,
      builder: builder,
      barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
    ),
  );
}

class _ChoicePanel<T> extends StatelessWidget {
  const _ChoicePanel({
    required this.form,
    required this.title,
    required this.options,
    required this.selected,
    required this.columns,
    required this.actions,
  });
  final FormFactor form;
  final String title;
  final List<ChoiceOption<T>> options;
  final T? selected;
  final int columns;
  final List<ChoiceAction> actions;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final colors = Theme.of(context).colorScheme;
    final television = form == FormFactor.television;
    final spacing = television ? 12.0 : 8.0;
    final header = Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: (television ? text.headlineSmall : text.titleLarge)
                    ?.copyWith(
                      fontWeight: FontWeight.w700,
                      fontSize: television || form == FormFactor.phone
                          ? null
                          : 17,
                    ),
              ),
              Text(
                '${options.length} 个',
                style: (television ? text.bodyMedium : text.bodySmall)
                    ?.copyWith(color: colors.onSurfaceVariant),
              ),
            ],
          ),
        ),
        if (form == FormFactor.phone)
          IconButton(
            tooltip: '关闭',
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.close_rounded),
          ),
      ],
    );
    return Padding(
      padding: switch (form) {
        FormFactor.phone => const EdgeInsets.fromLTRB(16, 0, 4, 20),
        FormFactor.pad ||
        FormFactor.window => const EdgeInsets.fromLTRB(16, 12, 16, 12),
        FormFactor.television => const EdgeInsets.fromLTRB(32, 36, 48, 32),
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          header,
          SizedBox(height: television ? 20 : 12),
          Flexible(
            child: Padding(
              padding: EdgeInsets.only(
                right: form == FormFactor.phone ? 12 : 0,
              ),
              child: GridView.builder(
                shrinkWrap: true,
                padding: EdgeInsets.all(television ? 12 : 6),
                itemCount: options.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: columns,
                  mainAxisSpacing: spacing,
                  crossAxisSpacing: spacing,
                  mainAxisExtent: switch (form) {
                    FormFactor.phone => 44,
                    FormFactor.pad || FormFactor.window => 36,
                    FormFactor.television => 48,
                  },
                ),
                itemBuilder: (context, index) => _ChoiceCell<T>(
                  option: options[index],
                  selected: options[index].value == selected,
                  form: form,
                ),
              ),
            ),
          ),
          if (actions.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Wrap(
                spacing: 4,
                runSpacing: 4,
                children: [
                  for (final action in actions)
                    FocusRing(
                      radius: 999,
                      child: TextButton.icon(
                        onPressed: () {
                          Navigator.pop(context);
                          action.onPressed();
                        },
                        icon: Icon(action.icon),
                        label: Text(action.label),
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _ChoiceCell<T> extends StatelessWidget {
  const _ChoiceCell({
    required this.option,
    required this.selected,
    required this.form,
  });
  final ChoiceOption<T> option;
  final bool selected;
  final FormFactor form;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final radius = switch (form) {
      FormFactor.phone => 12.0,
      FormFactor.pad || FormFactor.window => 10.0,
      FormFactor.television => 14.0,
    };
    return FocusRing(
      radius: radius,
      child: Material(
        color: selected ? colors.secondaryContainer : Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radius),
          side: selected
              ? BorderSide.none
              : BorderSide(color: colors.outlineVariant),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          autofocus: selected,
          focusColor: Colors.transparent,
          onTap: () => Navigator.pop(context, option.value),
          child: Semantics(
            selected: selected,
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  option.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: form == FormFactor.television ? 15 : 14,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                    color: selected
                        ? colors.onSecondaryContainer
                        : colors.onSurface,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AnchoredRoute<T> extends PopupRoute<T> {
  _AnchoredRoute({
    required this.anchor,
    required this.width,
    required this.builder,
    required this.barrierLabel,
  });
  final Rect anchor;
  final double width;
  final WidgetBuilder builder;
  @override
  final String barrierLabel;

  @override
  Color? get barrierColor => null;
  @override
  bool get barrierDismissible => true;
  @override
  Duration get transitionDuration => const Duration(milliseconds: 150);

  @override
  Widget buildPage(BuildContext context, _, _) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return CustomSingleChildLayout(
      delegate: _AnchoredLayout(anchor, width),
      child: GlassPanel(
        radius: 18,
        blur: 20,
        tint: 1.2,
        shade: dark ? 0.55 : 0,
        padding: EdgeInsets.zero,
        child: builder(context),
      ),
    );
  }

  @override
  Widget buildTransitions(
    BuildContext context,
    Animation<double> animation,
    _,
    Widget child,
  ) => FadeTransition(
    opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
    child: child,
  );
}

class _AnchoredLayout extends SingleChildLayoutDelegate {
  const _AnchoredLayout(this.anchor, this.width);
  final Rect anchor;
  final double width;
  static const _margin = 16.0;

  @override
  BoxConstraints getConstraintsForChild(BoxConstraints constraints) {
    final top = anchor.bottom + 6;
    return BoxConstraints(
      maxWidth: math.min(width, constraints.maxWidth - _margin * 2),
      minWidth: math.min(width, constraints.maxWidth - _margin * 2),
      maxHeight: math.max(0, constraints.maxHeight - top - _margin),
    );
  }

  @override
  Offset getPositionForChild(Size size, Size childSize) => Offset(
    (anchor.right - childSize.width).clamp(
      _margin,
      math.max(_margin, size.width - childSize.width - _margin),
    ),
    anchor.bottom + 6,
  );

  @override
  bool shouldRelayout(_AnchoredLayout oldDelegate) =>
      anchor != oldDelegate.anchor || width != oldDelegate.width;
}
