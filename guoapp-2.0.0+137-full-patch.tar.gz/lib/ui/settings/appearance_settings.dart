import 'package:flutter/material.dart';

import '../../local_store.dart';
import '../../theme_color.dart';
import '../app_scope.dart';
import '../theme/glass.dart';
import '../theme/motion.dart';
import '../widgets/focus_ring.dart';
import '../widgets/group_card.dart';
import '../widgets/motion/motion_widgets.dart';
import 'settings_rows.dart';

const themeModes = {'light': '浅色', 'dark': '深色', 'system': '跟随系统'};

const displayModes = {
  'auto': '自动识别设备',
  'television': '电视',
  'phone': '手机',
  'pad': '平板',
  'window': '窗口',
};

Map<String, String> get availableDisplayModes => {
  for (final MapEntry(:key, :value) in displayModes.entries)
    if (desktopPlatform || key != 'window') key: value,
};

String platformDisplayMode(String mode) =>
    mode == 'window' && !desktopPlatform ? 'pad' : mode;

class AppearanceSettings extends StatelessWidget {
  const AppearanceSettings({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final colors = Theme.of(context).colorScheme;
    final systemColorAvailable = AppScope.of(context).systemColorAvailable;
    final following = systemColorAvailable && store.followSystemColor;
    return Column(
      spacing: 12,
      children: [
        GroupCard(
          children: [
            SettingsTile(
              title: '主题模式',
              subtitle: themeModes[store.themeMode] ?? themeModes['system']!,
              onTap: () async {
                final selection = await showOptionDialog(
                  context,
                  title: '主题模式',
                  options: themeModes,
                  selected: store.themeMode,
                );
                if (selection != null && context.mounted) {
                  await saveSetting(
                    context,
                    () => store.setThemeMode(selection),
                  );
                }
              },
            ),
            const Divider(indent: 16, endIndent: 16),
            SwitchTile(
              title: '纯黑深色模式',
              subtitle: '深色时背景改为纯黑，适合 OLED 屏幕（会暂时关掉玻璃外观）',
              value: store.pureBlack,
              onChanged: (value) => saveSetting(
                context,
                () => store.setPureBlack(value),
              ),
            ),
            const Divider(indent: 16, endIndent: 16),
            SwitchTile(
              title: 'Liquid Glass 外观',
              subtitle: '半透明玻璃质感：背景模糊、细高光边、浮动玻璃标签栏（默认开启）',
              value: store.liquidGlass,
              onChanged: (value) => saveSetting(context, () async {
                await store.setLiquidGlass(value);
                if (value) await store.setPureBlack(false);
              }),
            ),
            if (store.liquidGlass)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                child: GlassPanel(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Icon(
                        Icons.auto_awesome_rounded,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          '玻璃卡片示例：半透明底色 + 背景模糊 + 高光边',
                          style: TextStyle(fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            const Divider(indent: 16, endIndent: 16),
            TileFocus(
              builder: (focusNode) => SwitchListTile(
                focusNode: focusNode,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                title: const Text('跟随系统取色'),
                subtitle: Text(
                  systemColorAvailable
                      ? 'Android 12 及以上跟随壁纸，Windows 跟随系统强调色'
                      : '本机不支持系统取色，使用预设色板',
                ),
                value: following,
                onChanged: systemColorAvailable
                    ? (value) => saveSetting(
                        context,
                        () => store.setFollowSystemColor(value),
                      )
                    : null,
              ),
            ),
            const Divider(indent: 16, endIndent: 16),
            Opacity(
              opacity: following ? 0.45 : 1,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  spacing: 12,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      spacing: 2,
                      children: [
                        Text('预设色板', style: text.titleMedium),
                        Text(
                          following ? '关闭「跟随系统取色」后可选' : '选一个种子色生成整套配色',
                          style: text.bodyMedium?.copyWith(
                            color: colors.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        for (final color in ThemeColor.values)
                          Expanded(
                            child: _Swatch(
                              color: color,
                              selected: !following && store.themeColor == color,
                              onPressed: following
                                  ? null
                                  : () => saveSetting(
                                      context,
                                      () => store.setThemeColor(color),
                                    ),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        GroupCard(
          children: [
            if (!AppScope.of(context).television) ...[
              SwitchTile(
                title: '在主页底栏显示历史',
                subtitle: '默认关闭（历史在「我的 → 最近观看」里），打开后底栏会多一个「历史」',
                value: store.historyTab,
                onChanged: (value) =>
                    saveSetting(context, () => store.setHistoryTab(value)),
              ),
              const Divider(indent: 16, endIndent: 16),
              SwitchTile(
                title: '在主页显示模糊封面按钮',
                subtitle: '发现页站源按钮左边显示眼睛按钮，点一下模糊封面，再点恢复',
                value: store.blurCoversButton,
                onChanged: (value) => saveSetting(
                  context,
                  () => store.setBlurCoversButton(value),
                ),
              ),
              const Divider(indent: 16, endIndent: 16),
              SwitchTile(
                title: '模糊所有界面的封面',
                subtitle: store.blurCoversButton
                    ? '关闭后只模糊发现页的封面'
                    : '需先打开在主页显示模糊封面按钮',
                value: store.blurCoversButton && store.blurAllCovers,
                onChanged: store.blurCoversButton
                    ? (value) => saveSetting(
                        context,
                        () => store.setBlurAllCovers(value),
                      )
                    : null,
              ),
              const Divider(indent: 16, endIndent: 16),
              SettingsTile(
                title: '开屏自动模糊封面',
                subtitle: store.blurCoversButton
                    ? coverBlurLaunchModes[store.blurCoversLaunch]!
                    : '需先打开在主页显示模糊封面按钮',
                enabled: store.blurCoversButton,
                onTap: store.blurCoversButton
                    ? () async {
                        final selection = await showOptionDialog(
                          context,
                          title: '开屏自动模糊封面',
                          options: coverBlurLaunchModes,
                          selected: store.blurCoversLaunch,
                        );
                        if (selection != null && context.mounted) {
                          await saveSetting(
                            context,
                            () => store.setBlurCoversLaunch(selection),
                          );
                        }
                      }
                    : null,
              ),
            ],
            if (AppScope.of(context).television)
              SwitchTile(
                title: '搜索用字母键盘',
                subtitle: '开启后按确认键弹出字母键盘，可按拼音首字母搜；关闭时使用系统输入法',
                value: store.televisionKeyboard,
                onChanged: (value) => saveSetting(
                  context,
                  () => store.setTelevisionKeyboard(value),
                ),
              ),
          ],
        ),
        GroupCard(
          children: [
            SettingsTile(
              title: '界面模式',
              subtitle: displayModes[platformDisplayMode(store.displayMode)]!,
              onTap: () async {
                final selection = await showOptionDialog(
                  context,
                  title: '界面模式',
                  options: availableDisplayModes,
                  selected: platformDisplayMode(store.displayMode),
                );
                if (selection != null && context.mounted) {
                  await saveSetting(
                    context,
                    () => store.setDisplayMode(selection),
                  );
                }
              },
            ),
          ],
        ),
      ],
    );
  }
}

class _Swatch extends StatelessWidget {
  const _Swatch({
    required this.color,
    required this.selected,
    required this.onPressed,
  });
  final ThemeColor color;
  final bool selected;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = ColorScheme.fromSeed(
      seedColor: Color(color.seed),
      brightness: theme.brightness,
    );
    return Column(
      spacing: 6,
      children: [
        Semantics(
          button: true,
          selected: selected,
          label: color.label,
          excludeSemantics: true,
          child: FocusRing(
            radius: 999,
            child: AnimatedContainer(
              duration: Motion.of(context, Motion.short),
              curve: Motion.standard,
              width: 50,
              height: 50,
              padding: const EdgeInsets.all(3),
              decoration: ShapeDecoration(
                shape: CircleBorder(
                  side: BorderSide(
                    color: selected ? scheme.primary : Colors.transparent,
                    width: 2,
                  ),
                ),
              ),
              child: Material(
                color: scheme.primary,
                shape: const CircleBorder(),
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                  onTap: onPressed,
                  child: ToggleIconSwitcher(
                    child: selected
                        ? Icon(
                            Icons.check_rounded,
                            key: const ValueKey(true),
                            color: scheme.onPrimary,
                          )
                        : const SizedBox.shrink(key: ValueKey(false)),
                  ),
                ),
              ),
            ),
          ),
        ),
        Text(
          color.label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}
