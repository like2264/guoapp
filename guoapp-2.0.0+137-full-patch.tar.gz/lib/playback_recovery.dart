import 'models.dart';

enum PlaybackRecoveryAction { alternative, refresh, stop }

class PlaybackRecovery {
  // 站点侧分片要跨网取，拖到未缓冲位置时首片常常要几秒到十几秒；
  // 之前 3 次就收手，慢网络下会把还能救的播放直接判死（黑屏）。
  static const maxAttempts = 4;
  int _attempts = 0;
  bool _refreshed = false;

  void reset() {
    _attempts = 0;
    _refreshed = false;
  }

  /// [preferRefresh]：拖动失败时优先「重新取一次播放地址」。
  /// 站点给的播放地址带签名/时限，拖到未缓冲位置才去取新分片；这时旧地址
  /// 往往已经不能用了，换个线路也是同一个过期地址，换新地址才有救。
  PlaybackRecoveryAction next(PlaybackPlan plan, {bool preferRefresh = false}) {
    if (_attempts >= maxAttempts) {
      return PlaybackRecoveryAction.stop;
    }
    if (preferRefresh && !_refreshed) {
      _attempts++;
      _refreshed = true;
      return PlaybackRecoveryAction.refresh;
    }
    if (plan.hasAlternative) {
      _attempts++;
      return PlaybackRecoveryAction.alternative;
    }
    if (!_refreshed) {
      _attempts++;
      _refreshed = true;
      return PlaybackRecoveryAction.refresh;
    }
    return PlaybackRecoveryAction.stop;
  }
}

class PlaybackHealth {
  // 20 秒对跨网站源太紧：拖进度后首片就要 5~15 秒，还没到数据就把会话判死，
  // 于是「卡一下 → 跳下一集 / 黑屏」。
  //
  // 2.0.0+136 从 40 秒收到 24 秒：+135 真机日志里那条「卡住 40 秒才自动恢复」
  // 用户是完全感知得到的（画面停在那儿，什么提示都没有）。24 秒仍然够跨网站源
  // 取两三片，但不会让人干等。
  static const stallTimeout = Duration(seconds: 24);

  // 拖动之后播放器在等分片时不会报 buffering（它自认为还在播），
  // 所以「拖完多久没进度」要单独盯：2 秒先亮加载圈，等够 10 秒还没跳到目标
  // 位置才动手。柚子这类站点的分片是现场查库生成的，一片要 2~4 秒，拖到
  // 未缓冲位置要连取三四片；早先定在 5 秒，等于数据还在路上就把会话拆了重建，
  // 重建又要重新解析地址、重新取片，表现就是一直转圈然后黑屏。
  static const seekStallTimeout = Duration(seconds: 10);
  static const seekSpinnerDelay = Duration(seconds: 2);

  /// 拖过之后多久之内仍按「拖动卡住」的节奏判（10 秒），而不是普通卡顿的 24 秒。
  /// 播放器有时先把位置跳到目标、再慢慢等分片，这段时间 `seeking` 已经变 false，
  /// 只靠它判断就会退回长超时。
  static const seekGrace = Duration(seconds: 60);

  Duration? _position;
  DateTime? _lastProgress;

  void reset() {
    _position = null;
    _lastProgress = null;
  }

  /// 距离上一次进度变化过了多久。位置一变就归零。
  Duration idle({
    required Duration position,
    required bool playing,
    required bool foreground,
    required DateTime now,
  }) {
    if (!playing || !foreground || position != _position) {
      _position = position;
      _lastProgress = now;
      return Duration.zero;
    }
    _lastProgress ??= now;
    return now.difference(_lastProgress!);
  }

  bool stalled({
    required Duration position,
    required bool playing,
    required bool foreground,
    required DateTime now,
    Duration timeout = stallTimeout,
  }) => idle(
    position: position,
    playing: playing,
    foreground: foreground,
    now: now,
  ) >= timeout;
}
