import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// 缓存与数据清理（设置 → 存储）。
///
/// 只碰应用沙盒里自己的目录：
/// - 缓存 = 系统临时目录（封面、解码中间文件、模块下载包等）；
/// - 全部数据 = 应用支持目录（用户、追剧、观看记录、下载的视频）+ 临时目录。
///
/// 不碰外部下载目录（用户可能在「存储」里把下载指到了共享存储），
/// 那里由用户自己在文件管理器处理，程序删库外目录太危险。
class StorageCleanup {
  const StorageCleanup._();

  static int _bytes(Directory root) {
    if (!root.existsSync()) return 0;
    var total = 0;
    for (final entity in root.listSync(recursive: true, followLinks: false)) {
      if (entity is File) {
        try {
          total += entity.lengthSync();
        } catch (_) {}
      }
    }
    return total;
  }

  /// 缓存占用（字节）。
  static Future<int> cacheBytes() async {
    try {
      return _bytes(await getTemporaryDirectory());
    } catch (_) {
      return 0;
    }
  }

  /// 清空缓存，返回释放的字节数。
  static Future<int> clearCache() async {
    try {
      final root = await getTemporaryDirectory();
      final freed = _bytes(root);
      for (final entity in root.listSync(followLinks: false)) {
        try {
          entity.deleteSync(recursive: true);
        } catch (_) {
          // 正在被播放器占用的文件删不掉，跳过就好。
        }
      }
      return freed;
    } catch (_) {
      return 0;
    }
  }

  /// 删掉应用自己的全部数据。调用方负责随后退出应用。
  static Future<void> eraseAll() async {
    for (final directory in [
      await getApplicationSupportDirectory(),
      await getTemporaryDirectory(),
    ]) {
      for (final entity in directory.listSync(followLinks: false)) {
        try {
          entity.deleteSync(recursive: true);
        } catch (_) {}
      }
    }
  }
}
