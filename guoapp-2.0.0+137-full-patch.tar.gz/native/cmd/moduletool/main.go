package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"duanjuapp/native/core"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "用法：moduletool <模块目录> <请求 JSON> [<请求 JSON> ...]")
		os.Exit(2)
	}
	data, err := os.MkdirTemp("", "moduletool-")
	if err != nil {
		panic(err)
	}
	defer os.RemoveAll(data)
	module, err := filepath.Abs(os.Args[1])
	if err != nil {
		panic(err)
	}
	if err := os.CopyFS(filepath.Join(data, "modules", filepath.Base(module)), os.DirFS(module)); err != nil {
		panic(err)
	}
	initialize, _ := json.Marshal(map[string]string{"action": "initialize", "directory": data, "cache": filepath.Join(data, "cache")})
	fmt.Println(core.NativeRequest(string(initialize)))
	for _, request := range os.Args[2:] {
		// --wait=N 用来在两次请求之间给后台索引任务留时间（补简介、扩页）。
		if strings.HasPrefix(request, "--wait=") {
			seconds, err := strconv.Atoi(strings.TrimPrefix(request, "--wait="))
			if err == nil && seconds > 0 {
				time.Sleep(time.Duration(seconds) * time.Second)
			}
			continue
		}
		fmt.Println(core.NativeRequest(request))
	}
	if log, err := os.ReadFile(filepath.Join(data, "logs", "app.log")); err == nil {
		fmt.Fprintln(os.Stderr, string(log))
	}
}
