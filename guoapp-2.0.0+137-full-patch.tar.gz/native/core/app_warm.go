package core

import (
	"context"
	"errors"
	"time"
)

// 站源预热。
//
// 运行时 JS 模块第一次被调用时要现建 goja 运行时、加载并执行模块脚本，
// 冷启动 1~2 秒。联想搜索是「打一个字问一次」，第一下正好撞上这段冷启动，
// 拿到的是空结果；用户以为这个站源没有联想词，第二次再搜（模块已经热了）
// 才出来。切站源时那几秒空白也主要吃在这里。
//
// 所以在搜索页/切源前先在后台把模块跑起来：只做一次最轻的 JS 调用，
// 不联网、不产生目录请求，纯把运行时和模块脚本热好。
const nativeWarmBudget = 12 * time.Second

type warmsUp interface {
	Warm(ctx context.Context) error
}

func (engine *nativeEngine) warmSource(ctx context.Context, source string) error {
	source = canonicalProviderSource(source)
	if !registeredProviderSource(source) {
		return errors.New("请选择有效站源")
	}
	p, ok := engine.downloader.provider(source)
	if !ok {
		return errors.New("请选择有效站源")
	}
	w, ok := p.(warmsUp)
	if !ok {
		// 原生实现的站源没有冷启动问题，直接算热好了。
		return nil
	}
	budget, cancel := context.WithTimeout(ctx, nativeWarmBudget)
	defer cancel()
	return w.Warm(budget)
}
