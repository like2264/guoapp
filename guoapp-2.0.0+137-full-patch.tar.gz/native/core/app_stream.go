package core

import (
	"bufio"
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"path"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

type nativeStreamAsset struct {
	kind        string
	address     string
	data        []byte
	contentType string
	total       int64
	etag        string
	modified    string
	usedAt      time.Time
}

type nativeStreamSession struct {
	credentials  *MediaCredentials
	mu           sync.Mutex
	assets       map[string]nativeStreamAsset
	referer      string
	key          []byte
	ctx          context.Context
	cancel       context.CancelFunc
	lastUsed     time.Time
	diagnosticID string
	cencKey      []byte
	cencMu       sync.Mutex
	cenc         *cencLayout
	// refresh 用于播放途中凭证失效时重新解析一次播放地址。柚子这类站点的
	// 访客会话与年龄确认都有有效期，而拖动进度到未缓冲位置才会去取新分片，
	// 这时凭证若已过期站点回 403，播放器就会一直等，最后被健康检查判死。
	refresh     func(context.Context) (*MediaCredentials, error)
	refreshMu   sync.Mutex
	refreshing  bool
	refreshedAt time.Time
	// 分片预取：next 记录播放列表里「这一片之后是哪一片」，prefetching 记
	// 正在预取中的分片，用来去重和限并发。
	//
	// 柚子的分片只有 2 秒长，跨网单段要 0.6~1.3 秒，纯按需取的话拖动到未缓冲
	// 位置后播放器要连取 3~4 片才有画面，中间就是一段黑屏。这里一边给播放器
	// 当前这片，一边把后面几片先拉进会话缓存，下一次拖动/续播就直接命中本地。
	next        map[string]string
	prefetching map[string]bool
	// 同一个分片连续失败几次。站点签名地址过期时，播放器会拿着旧地址
	// 一直重发，我们若一直回 503 它就一直等，画面永远黑着；重试到第 3 次
	// 就回 410，让播放器把这一片当致命错误报上来，上层才有机会重新解析地址。
	failures map[string]int
}

type nativeStreamServer struct {
	mu         sync.Mutex
	downloader *Downloader
	address    string
	sessions   map[string]*nativeStreamSession
	server     *http.Server
	lan        *http.Server
	lanPort    int
}

func (stream *nativeStreamServer) lanOrigin(device string) (string, error) {
	if _, _, err := net.SplitHostPort(device); err != nil {
		device = net.JoinHostPort(device, "80")
	}
	probe, err := net.Dial("udp4", device)
	if err != nil {
		return "", fmt.Errorf("无法确定本机在局域网中的地址：%w", err)
	}
	host := probe.LocalAddr().(*net.UDPAddr).IP.String()
	_ = probe.Close()
	stream.mu.Lock()
	defer stream.mu.Unlock()
	if stream.lan == nil {
		listener, err := net.Listen("tcp4", ":0")
		if err != nil {
			return "", fmt.Errorf("无法开启局域网投屏服务：%w", err)
		}
		stream.lan = &http.Server{Handler: stream.server.Handler, ReadHeaderTimeout: 5 * time.Second, IdleTimeout: 30 * time.Second, MaxHeaderBytes: 16384}
		stream.lanPort = listener.Addr().(*net.TCPAddr).Port
		go func(server *http.Server) { _ = server.Serve(listener) }(stream.lan)
	}
	return "http://" + net.JoinHostPort(host, strconv.Itoa(stream.lanPort)), nil
}

func (stream *nativeStreamServer) lanClose() {
	stream.mu.Lock()
	defer stream.mu.Unlock()
	if stream.lan != nil {
		_ = stream.lan.Close()
		stream.lan = nil
	}
}

func (stream *nativeStreamServer) lanPlaylist(request *http.Request, body string) string {
	if origin := "http://" + request.Host; origin != stream.address {
		return strings.ReplaceAll(body, stream.address+"/", origin+"/")
	}
	return body
}

func (stream *nativeStreamServer) nativeRequest(request *http.Request) (*http.Response, error) {
	client := *stream.downloader.client
	client.Timeout = 0
	idleContext, releaseIdle := context.WithCancel(request.Context())
	request = request.WithContext(idleContext)
	idle := time.AfterFunc(nativeStreamIdleTimeout, releaseIdle)
	info, _ := request.Context().Value(nativeStreamDiagnosticKey{}).(nativeStreamDiagnostic)
	response, err := stream.downloader.doMediaRequestWithClient(request, &client)
	if err != nil {
		idle.Stop()
		releaseIdle()
		stream.nativeLogError(info, "upstream_error", request.URL.String(), err, "")
		return response, err
	}
	address := request.URL.String()
	if response.Request != nil && response.Request.URL != nil {
		address = response.Request.URL.String()
	}
	if response.StatusCode != http.StatusOK && response.StatusCode != http.StatusPartialContent {
		stream.nativeLog(info, "upstream_status", address, "", response.StatusCode, response.Header.Get("Content-Type"))
	}
	body := &nativeDiagnosticBody{ReadCloser: response.Body, stream: stream, info: info, address: address}
	response.Body = &nativeIdleBody{ReadCloser: body, timer: idle, cancel: releaseIdle}
	return response, nil
}

// nativeReplay 用给定凭证重发一次相同的媒体请求，保留 Range/If-Range。
// 上游掐断分片时靠它原地补一次，避免把「读了一半」直接当成流结束；
// 凭证过期时也靠它带着新凭证重来一次，播放器不会看到 403/502。
func (stream *nativeStreamServer) nativeReplay(ctx context.Context, session *nativeStreamSession, original *http.Request, address string, credentials *MediaCredentials) (*http.Response, *http.Request) {
	if credentials == nil {
		credentials = session.credentialSnapshot()
	}
	replay, err := http.NewRequestWithContext(providerMediaContext(ctx, credentials), original.Method, address, nil)
	if err != nil {
		return nil, nil
	}
	replay.Header.Set("User-Agent", UserAgent)
	replay.Header.Set("Referer", session.referer)
	for _, name := range []string{"Range", "If-Range", "Accept"} {
		if value := original.Header.Get(name); value != "" {
			replay.Header.Set(name, value)
		}
	}
	response, err := stream.nativeRequest(replay)
	if err != nil {
		return nil, nil
	}
	return response, replay
}

// nativeReplayReferer 换一个 Referer 重发同一次媒体请求。
// CDN 对 Referer 的校验口径不一致时，靠它把「403 黑屏」救回来。
func (stream *nativeStreamServer) nativeReplayReferer(ctx context.Context, session *nativeStreamSession, original *http.Request, address, referer string) (*http.Response, *http.Request) {
	replay, err := http.NewRequestWithContext(providerMediaContext(ctx, session.credentialSnapshot()), original.Method, address, nil)
	if err != nil {
		return nil, nil
	}
	replay.Header.Set("User-Agent", UserAgent)
	if referer != "" {
		replay.Header.Set("Referer", referer)
	}
	for _, name := range []string{"Range", "If-Range", "Accept"} {
		if value := original.Header.Get(name); value != "" {
			replay.Header.Set(name, value)
		}
	}
	response, err := stream.nativeRequest(replay)
	if err != nil {
		return nil, nil
	}
	return response, replay
}

var nativePlaylistURI = regexp.MustCompile(`URI="([^"]+)"`)

// nativeRangeOverlaps 判断播放器要的 Range 起点是否落在已缓冲的数据里。
// 没有 Range（整段请求）或解析失败时按「可覆盖」处理。
func nativeRangeOverlaps(request *http.Request, buffered int64) bool {
	value := request.Header.Get("Range")
	if !strings.HasPrefix(value, "bytes=") || buffered <= 0 {
		return true
	}
	start := strings.SplitN(strings.TrimPrefix(value, "bytes="), "-", 2)[0]
	offset, err := strconv.ParseInt(start, 10, 64)
	if err != nil {
		return true
	}
	return offset < buffered
}

// nativeStreamIdleTimeout 是上游「一直没有新数据」的容忍时间。柚子的分片只有
// 2 秒长，站点偶尔会把某个分片请求挂住不返回（拖动到未缓冲位置时尤其明显），
// 本地流服务若一直等下去，播放器只会看到进度条卡死，最后被健康检查判死；
// 这里主动掐断，让播放器重发这一片，而不是整集结束。
const nativeStreamIdleTimeout = 30 * time.Second

// 站点对带 Range 的分片请求也回整段 200（实测柚子分片不支持 Range），
// 播放器每次拖动都要整段重下；跨网链路一段就要 0.6~1.3 秒，连续拖几下
// 播放器就会放弃并报 EOF。这里把装得下的分片整段读进来：本地就能按 Range
// 切片、Content-Length 也是精确值，重复拖动不再走网络。
const (
	nativeSegmentBufferLimit = 16 << 20
	nativeSegmentCacheBytes  = 32 << 20
	// 同一片连续失败这么多次就当成地址失效（410），别再让播放器无限重试。
	nativeMediaFailureLimit = 3
)

// nativeCacheAsset 把整段分片存进会话缓存，并按内存预算淘汰旧分片。
// total 置 0 表示「这段数据就是完整分片」，nativeServe 会直接用本地内容
// 出响应（带精确 Content-Length 并支持 Range），不再回源。
func (stream *nativeStreamServer) nativeCacheAsset(session *nativeStreamSession, id string, data []byte, contentType string) {
	if len(data) == 0 {
		return
	}
	session.mu.Lock()
	defer session.mu.Unlock()
	asset, found := session.assets[id]
	if !found {
		return
	}
	asset.data = data
	asset.total = 0
	asset.usedAt = time.Now()
	if asset.contentType == "" {
		asset.contentType = contentType
	}
	session.assets[id] = asset
	total := int64(0)
	for _, item := range session.assets {
		total += int64(len(item.data))
	}
	if total <= nativeSegmentCacheBytes {
		return
	}
	type cached struct {
		id   string
		used time.Time
	}
	items := make([]cached, 0, len(session.assets))
	for key, item := range session.assets {
		if key == id || len(item.data) == 0 || item.kind == "entry_playlist" || item.kind == "child_playlist" {
			continue
		}
		items = append(items, cached{id: key, used: item.usedAt})
	}
	sort.Slice(items, func(i, j int) bool { return items[i].used.Before(items[j].used) })
	for _, item := range items {
		if total <= nativeSegmentCacheBytes {
			break
		}
		dropped := session.assets[item.id]
		total -= int64(len(dropped.data))
		dropped.data = nil
		session.assets[item.id] = dropped
	}
}

// nativePrefetchAhead 是「往后预取几片」。柚子一片 2 秒，播放器拖动后一般
// 要连吃 3~4 片才出画面；预取 3 片够它起步，又不至于把整集都拉下来。
const nativePrefetchAhead = 3

// nativePrefetchChain 从刚发出的这一片往后预取几片进会话缓存。
// 由 nativeServe 在分片请求里异步调用，不阻塞播放器当前这一片。
func (stream *nativeStreamServer) nativePrefetchChain(session *nativeStreamSession, id string) {
	for step := 0; step < nativePrefetchAhead; step++ {
		session.mu.Lock()
		next := session.next[id]
		if next == "" {
			session.mu.Unlock()
			return
		}
		asset, found := session.assets[next]
		if found && len(asset.data) > 0 {
			session.mu.Unlock()
			id = next
			continue
		}
		if session.prefetching == nil {
			session.prefetching = make(map[string]bool, nativePrefetchAhead)
		}
		// 同时最多预取 3 片：拖动时播放器会连着要好几个分片，每个请求都往后
		// 预取的话很容易把站点的并发打满，反而更慢。
		if session.prefetching[next] || len(session.prefetching) >= nativePrefetchAhead {
			session.mu.Unlock()
			return
		}
		session.prefetching[next] = true
		session.mu.Unlock()
		id = next
		stream.nativePrefetchOne(session, id, asset, found)
		session.mu.Lock()
		delete(session.prefetching, id)
		session.mu.Unlock()
	}
}

// nativePrefetchOne 取一个分片并塞进会话缓存。失败就安静放弃：这只是抢时间，
// 真取不到时播放器照样会自己发请求，走正常那条路径并带上重试与凭证续领。
func (stream *nativeStreamServer) nativePrefetchOne(session *nativeStreamSession, id string, asset nativeStreamAsset, found bool) {
	if !found || asset.kind != "segment" || asset.address == "" {
		return
	}
	ctx, cancel := context.WithTimeout(session.ctx, 25*time.Second)
	defer cancel()
	ctx = providerMediaContext(ctx, session.credentialSnapshot())
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, asset.address, nil)
	if err != nil {
		return
	}
	request.Header.Set("User-Agent", UserAgent)
	if session.referer != "" {
		request.Header.Set("Referer", session.referer)
	}
	response, err := stream.nativeRequest(request)
	if err != nil {
		return
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK ||
		response.ContentLength <= 0 ||
		response.ContentLength > nativeSegmentBufferLimit {
		return
	}
	data, readErr := io.ReadAll(io.LimitReader(response.Body, nativeSegmentBufferLimit+1))
	if readErr != nil || int64(len(data)) != response.ContentLength {
		return
	}
	stream.nativeCacheAsset(session, id, data, response.Header.Get("Content-Type"))
	stream.nativeLog(
		nativeStreamDiagnostic{session: session.diagnosticID, asset: "segment"},
		"segment_prefetch",
		asset.address,
		"bytes="+strconv.Itoa(len(data)),
		response.StatusCode,
		response.Header.Get("Content-Type"),
	)
}

// nativeIdleBody 在读取上游响应体时不断重置空闲计时器，读取中断就取消请求。
type nativeIdleBody struct {
	io.ReadCloser
	timer  *time.Timer
	cancel context.CancelFunc
}

func (body *nativeIdleBody) Read(chunk []byte) (int, error) {
	read, err := body.ReadCloser.Read(chunk)
	if read > 0 {
		body.timer.Reset(nativeStreamIdleTimeout)
	}
	return read, err
}

func (body *nativeIdleBody) Close() error {
	body.timer.Stop()
	err := body.ReadCloser.Close()
	body.cancel()
	return err
}

func newNativeStreamServer(d *Downloader) (*nativeStreamServer, error) {
	listener, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		return nil, errors.New("无法初始化本机播放器")
	}
	stream := &nativeStreamServer{downloader: d, address: "http://" + listener.Addr().String(), sessions: map[string]*nativeStreamSession{}}
	server := &http.Server{Handler: http.HandlerFunc(stream.nativeServe), ReadHeaderTimeout: 5 * time.Second, IdleTimeout: 30 * time.Second, MaxHeaderBytes: 16384}
	stream.server = server
	go func() { _ = server.Serve(listener) }()
	return stream, nil
}

// credentialSnapshot 取当前生效的播放凭证。
func (session *nativeStreamSession) credentialSnapshot() *MediaCredentials {
	session.mu.Lock()
	defer session.mu.Unlock()
	return session.credentials
}

// refreshCredential 在播放途中凭证失效时重新解析一次播放地址。
// 5 秒内不重复尝试，避免一批分片同时失败时把站点打爆。
// nativeNoteFailure 记一次媒体失败，返回这一片已经连续失败了几次。
func (session *nativeStreamSession) nativeNoteFailure(id string) int {
	session.mu.Lock()
	defer session.mu.Unlock()
	if session.failures == nil {
		session.failures = map[string]int{}
	}
	session.failures[id]++
	return session.failures[id]
}

// nativeClearFailure 成功取到数据后清掉失败计数。
func (session *nativeStreamSession) nativeClearFailure(id string) {
	session.mu.Lock()
	defer session.mu.Unlock()
	delete(session.failures, id)
}

func (session *nativeStreamSession) refreshCredential(ctx context.Context) *MediaCredentials {
	if session.refresh == nil {
		return nil
	}
	session.refreshMu.Lock()
	if session.refreshing || time.Since(session.refreshedAt) < 5*time.Second {
		session.refreshMu.Unlock()
		return nil
	}
	session.refreshing = true
	session.refreshMu.Unlock()
	fresh, err := session.refresh(ctx)
	session.refreshMu.Lock()
	session.refreshing = false
	session.refreshedAt = time.Now()
	session.refreshMu.Unlock()
	if err != nil || fresh == nil {
		return nil
	}
	session.mu.Lock()
	session.credentials = fresh
	session.mu.Unlock()
	return fresh
}

func (stream *nativeStreamServer) nativeOpen(media ProviderMedia, refresh func(context.Context) (*MediaCredentials, error)) (string, string) {
	tokenBytes := make([]byte, 24)
	if _, err := rand.Read(tokenBytes); err != nil {
		panic(err)
	}
	token := hex.EncodeToString(tokenBytes)
	ctx, cancel := context.WithCancel(providerMediaContext(context.Background(), media.Credentials))
	session := &nativeStreamSession{assets: map[string]nativeStreamAsset{}, referer: media.Referer, key: media.HLSKey, ctx: ctx, cancel: cancel, lastUsed: time.Now(), credentials: media.Credentials, diagnosticID: nativeStreamID(token), refresh: refresh, failures: map[string]int{}}
	stream.mu.Lock()
	for id, old := range stream.sessions {
		if time.Since(old.lastUsed) > 10*time.Minute {
			stream.nativeCancel(old, "idle_expired")
			delete(stream.sessions, id)
		}
	}
	if len(stream.sessions) >= 8 {
		oldest := ""
		for id, old := range stream.sessions {
			if oldest == "" || old.lastUsed.Before(stream.sessions[oldest].lastUsed) {
				oldest = id
			}
		}
		stream.nativeCancel(stream.sessions[oldest], "capacity_eviction")
		delete(stream.sessions, oldest)
	}
	stream.sessions[token] = session
	stream.mu.Unlock()
	entry := nativeStreamAsset{kind: "media", address: media.URL, contentType: "video/mp4"}
	parsedURL, parseErr := url.Parse(media.URL)
	isHLS := media.Playlist != "" || (parseErr == nil && strings.HasSuffix(strings.ToLower(parsedURL.Path), ".m3u8"))
	if isHLS {
		entry.contentType = "application/vnd.apple.mpegurl"
	}
	if media.Playlist != "" {
		entry.data = []byte(media.Playlist)
		entry.contentType = "application/vnd.apple.mpegurl"
	}
	if isHLS || strings.Contains(entry.contentType, "mpegurl") {
		entry.kind = "entry_playlist"
	}
	return stream.nativeAsset(token, session, entry), token
}

func (stream *nativeStreamServer) nativeCancel(session *nativeStreamSession, reason string) {
	if reason != "release" {
		stream.nativeLog(nativeStreamDiagnostic{session: session.diagnosticID}, "session_cancel", "", "reason="+reason, 0, "")
	}
	session.cancel()
}

func (stream *nativeStreamServer) nativeRelease(token string) {
	stream.mu.Lock()
	if session := stream.sessions[token]; session != nil {
		stream.nativeCancel(session, "release")
		delete(stream.sessions, token)
	}
	stream.mu.Unlock()
}

func (stream *nativeStreamServer) nativeAsset(token string, session *nativeStreamSession, asset nativeStreamAsset) string {
	digest := sha256.Sum256([]byte(asset.address + "\x00" + asset.contentType))
	extension := ".ts"
	if parsed, err := url.Parse(asset.address); err == nil {
		switch candidate := strings.ToLower(path.Ext(parsed.Path)); candidate {
		case ".m3u8", ".ts", ".m4s", ".mp4", ".aac", ".m4a", ".mp3", ".vtt", ".webvtt", ".key":
			extension = candidate
		}
	}
	switch asset.contentType {
	case "application/vnd.apple.mpegurl":
		extension = ".m3u8"
	case "application/octet-stream":
		extension = ".key"
	case "video/mp4":
		extension = ".mp4"
	}
	id := hex.EncodeToString(digest[:12]) + extension
	session.mu.Lock()
	if previous, found := session.assets[id]; !found || len(previous.data) == 0 || len(asset.data) > 0 {
		session.assets[id] = asset
	}
	session.mu.Unlock()
	return stream.address + "/" + token + "/" + id
}

func (stream *nativeStreamServer) nativeRewrite(token string, session *nativeStreamSession, body, base string) (string, error) {
	var output []string
	// ladder 是这份播放列表里分片的先后顺序（本地资源 id）。记下来才能在
	// 播放途中「往后多取几片」，见 nativePrefetchChain。
	var ladder []string
	nextPlaylist := false
	for _, line := range strings.Split(strings.ReplaceAll(body, "\r\n", "\n"), "\n") {
		text := strings.TrimSpace(line)
		rewrite := func(reference string, key bool, contentType string) string {
			if strings.HasPrefix(reference, "data:") {
				return reference
			}
			parsed, err := url.Parse(base)
			if err != nil {
				return ""
			}
			relative, err := url.Parse(reference)
			if err != nil {
				return ""
			}
			address := parsed.ResolveReference(relative).String()
			if !IsProviderHTTPMediaURL(address) {
				return ""
			}
			kind := "segment"
			switch contentType {
			case "application/vnd.apple.mpegurl":
				kind = "child_playlist"
			case "application/octet-stream":
				kind = "key"
			case "video/mp4":
				kind = "map"
			}
			asset := nativeStreamAsset{kind: kind, address: address, contentType: contentType}
			if key && len(session.key) == 16 {
				asset.data = append([]byte{}, session.key...)
				asset.contentType = "application/octet-stream"
			}
			return stream.nativeAsset(token, session, asset)
		}
		if text != "" && !strings.HasPrefix(text, "#") {
			contentType := ""
			if nextPlaylist {
				contentType = "application/vnd.apple.mpegurl"
			}
			line = rewrite(text, false, contentType)
			nextPlaylist = false
			if line == "" {
				return "", errors.New("播放列表中的媒体地址无效")
			}
			if contentType == "" {
				ladder = append(ladder, line)
			}
		} else if strings.Contains(text, "URI=") {
			invalid := false
			line = nativePlaylistURI.ReplaceAllStringFunc(line, func(match string) string {
				reference := nativePlaylistURI.FindStringSubmatch(match)[1]
				key := strings.HasPrefix(text, "#EXT-X-KEY:") || strings.HasPrefix(text, "#EXT-X-SESSION-KEY:")
				contentType := ""
				switch {
				case key:
					contentType = "application/octet-stream"
				case strings.HasPrefix(text, "#EXT-X-MAP:"):
					contentType = "video/mp4"
				case strings.HasPrefix(text, "#EXT-X-MEDIA:"), strings.HasPrefix(text, "#EXT-X-I-FRAME-STREAM-INF:"), strings.HasPrefix(text, "#EXT-X-RENDITION-REPORT:"):
					contentType = "application/vnd.apple.mpegurl"
				}
				updated := rewrite(reference, key, contentType)
				if updated == "" {
					invalid = true
				}
				return "URI=\"" + updated + "\""
			})
			if invalid {
				return "", errors.New("播放列表中的附属地址无效")
			}
		}
		if strings.HasPrefix(text, "#EXT-X-STREAM-INF:") {
			nextPlaylist = true
		}
		output = append(output, line)
	}
	if len(ladder) > 1 {
		session.mu.Lock()
		if session.next == nil {
			session.next = make(map[string]string, len(ladder))
		}
		for index := 0; index+1 < len(ladder); index++ {
			session.next[ladder[index]] = ladder[index+1]
		}
		session.mu.Unlock()
	}
	return strings.Join(output, "\n"), nil
}

func (stream *nativeStreamServer) nativeServe(writer http.ResponseWriter, request *http.Request) {
	if request.Method != http.MethodGet && request.Method != http.MethodHead {
		writer.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	parts := strings.Split(strings.Trim(request.URL.Path, "/"), "/")
	if len(parts) != 2 {
		http.NotFound(writer, request)
		return
	}
	stream.mu.Lock()
	session := stream.sessions[parts[0]]
	if session != nil {
		session.lastUsed = time.Now()
	}
	stream.mu.Unlock()
	if session == nil {
		http.Error(writer, "播放已结束", http.StatusGone)
		return
	}
	session.mu.Lock()
	asset, found := session.assets[parts[1]]
	session.mu.Unlock()
	info := nativeStreamDiagnostic{session: session.diagnosticID, asset: asset.kind}
	// 一边给播放器当前这一片，一边把后面几片先拉进缓存：柚子这类分片只有
	// 2 秒的站点，拖动到未缓冲位置后播放器要连吃好几片才有画面，不预取的
	// 话中间就是一段黑屏。
	if asset.kind == "segment" && request.Method == http.MethodGet {
		go stream.nativePrefetchChain(session, parts[1])
	}
	if !found {
		stream.nativeLog(info, "asset_missing", "", "", 0, "")
		http.NotFound(writer, request)
		return
	}
	// 凭证快到点就提前续一次：等到真正过期时，apply 会在本地直接把请求
	// 挡回来，这时再去续领已经晚了一拍（拖动卡死就是这条路径）。
	credentials := session.credentialSnapshot()
	if credentials != nil && credentials.expiringWithin(60*time.Second, time.Now()) {
		if fresh := session.refreshCredential(request.Context()); fresh != nil {
			credentials = fresh
		}
	}
	ctx, cancel := context.WithCancel(providerMediaContext(request.Context(), credentials))
	defer cancel()
	ctx = context.WithValue(ctx, nativeStreamDiagnosticKey{}, info)
	stop := context.AfterFunc(session.ctx, cancel)
	defer stop()
	writer.Header().Set("Cache-Control", "no-store")
	if len(asset.data) > 0 && asset.total > int64(len(asset.data)) {
		if stream.nativeServePrefix(ctx, writer, request, session, asset) {
			return
		}
		asset.data = nil
	}
	if len(asset.data) > 0 {
		if strings.Contains(asset.contentType, "mpegurl") {
			body, err := stream.nativeRewrite(parts[0], session, string(asset.data), asset.address)
			if err != nil {
				stream.nativeLog(info, "playlist_rewrite", asset.address, "kind="+nativePlaylistKind(string(asset.data))+" error="+nativeStreamError(err), 0, "")
				http.Error(writer, err.Error(), http.StatusBadGateway)
				return
			}
			writer.Header().Set("Content-Type", "application/vnd.apple.mpegurl")
			if request.Method == http.MethodGet {
				_, _ = io.WriteString(writer, stream.lanPlaylist(request, body))
			}
		} else {
			writer.Header().Set("Content-Type", asset.contentType)
			if asset.etag != "" {
				writer.Header().Set("ETag", asset.etag)
			}
			http.ServeContent(writer, request, parts[1], time.Time{}, bytes.NewReader(asset.data))
		}
		return
	}
	if len(session.cencKey) > 0 && asset.kind == "media" {
		stream.nativeServeDecrypted(ctx, writer, request, session, asset)
		return
	}
	upstream, err := http.NewRequestWithContext(ctx, request.Method, asset.address, nil)
	if err != nil {
		http.Error(writer, "媒体地址无效", http.StatusBadGateway)
		return
	}
	upstream.Header.Set("User-Agent", UserAgent)
	upstream.Header.Set("Referer", session.referer)
	for _, name := range []string{"Range", "If-Range"} {
		if value := request.Header.Get(name); value != "" {
			upstream.Header.Set(name, value)
		}
	}
	response, err := stream.nativeRequest(upstream)
	// 本地判定凭证过期时请求根本没发出去。这时续领一次再原样重发，
	// 否则拖到未缓冲位置会直接拿到 502，播放器只能一直等。
	if err != nil && errors.Is(err, errMediaCredentialsExpired) {
		if fresh := session.refreshCredential(ctx); fresh != nil {
			if retried, retriedRequest := stream.nativeReplay(ctx, session, request, asset.address, fresh); retried != nil {
				response, upstream, err = retried, retriedRequest, nil
				stream.nativeLog(info, "credential_refreshed", asset.address, "trigger=expired", retried.StatusCode, "")
			}
		}
	}
	if err != nil {
		http.Error(writer, "读取媒体失败，请重试", http.StatusBadGateway)
		return
	}
	// 播放凭证过期（或站点换了签名）时，拖动进度到未缓冲位置才会暴露：
	// 这时才去取新分片，站点回 403，播放器会一直等，最后被健康检查判死。
	// 这里续领一次凭证并原样重试，成功就当没发生过。
	if response.StatusCode == http.StatusUnauthorized || response.StatusCode == http.StatusForbidden {
		_, _ = io.Copy(io.Discard, io.LimitReader(response.Body, 64<<10))
		response.Body.Close()
		if fresh := session.refreshCredential(ctx); fresh != nil {
			if retried, retriedRequest := stream.nativeReplay(ctx, session, request, asset.address, fresh); retried != nil {
				response, upstream = retried, retriedRequest
				stream.nativeLog(info, "credential_refreshed", asset.address, "trigger=status", response.StatusCode, "")
			}
		}
	}
	// 凭证没问题但 CDN 还是回 403：多半是对 Referer 的口径不一样
	// （有的只认站点根，有的不认 Referer 却讨厌带 Origin 的请求）。
	// 拖动到未缓冲位置时才会真正去取这片，卡在这里就是一整块黑屏。
	if response.StatusCode == http.StatusForbidden || response.StatusCode == http.StatusUnauthorized {
		_, _ = io.Copy(io.Discard, io.LimitReader(response.Body, 64<<10))
		response.Body.Close()
		recovered := false
		for _, referer := range mediaRefererVariants(asset.address, session.referer) {
			if referer == session.referer || ctx.Err() != nil {
				continue
			}
			retried, retriedRequest := stream.nativeReplayReferer(ctx, session, request, asset.address, referer)
			if retried == nil {
				continue
			}
			if retried.StatusCode == http.StatusOK || retried.StatusCode == http.StatusPartialContent {
				upstream, response = retriedRequest, retried
				recovered = true
				stream.nativeLog(info, "referer_variant", asset.address, "referer="+referer, response.StatusCode, "")
				break
			}
			_, _ = io.Copy(io.Discard, io.LimitReader(retried.Body, 64<<10))
			retried.Body.Close()
		}
		if !recovered {
			// 前两次回 503：播放器（libmpv/ffmpeg）会重发这一片，网络抖动
			// 能自己缓过来。第三次还是 401/403 说明地址或凭证已经彻底不可用，
			// 继续回 503 就是无限黑屏，这时回 410 让播放器报错，上层收到错误
			// 才会重新解析一份播放地址并从当前位置续播。
			count := session.nativeNoteFailure(parts[1])
			if count >= nativeMediaFailureLimit {
				stream.nativeLog(info, "media_forbidden", asset.address, "attempts="+strconv.Itoa(count), response.StatusCode, "")
				http.Error(writer, "播放地址已失效，请重新解析", http.StatusGone)
				return
			}
			writer.Header().Set("Retry-After", "1")
			http.Error(writer, "读取媒体失败，请重试", http.StatusServiceUnavailable)
			return
		}
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK && response.StatusCode != http.StatusPartialContent {
		body, _ := io.ReadAll(io.LimitReader(response.Body, 64<<10))
		err := stream.downloader.catalogResponseError(upstream, response, body)
		http.Error(writer, err.Error(), response.StatusCode)
		return
	}
	contentType := strings.ToLower(response.Header.Get("Content-Type"))
	finalURL := upstream.URL
	if response.Request != nil && response.Request.URL != nil {
		finalURL = response.Request.URL
	}
	contentIsMP4 := strings.Contains(contentType, "video/mp4")
	playlist := strings.Contains(contentType, "mpegurl") ||
		(strings.HasSuffix(strings.ToLower(finalURL.Path), ".m3u8") && !contentIsMP4)
	reader := bufio.NewReader(response.Body)
	if request.Method == http.MethodGet {
		peek, _ := reader.Peek(512)
		bodyIsPlaylist := strings.HasPrefix(strings.TrimSpace(strings.TrimPrefix(string(peek), "\ufeff")), "#EXTM3U")
		if bodyIsPlaylist {
			playlist = true
		} else if contentIsMP4 {
			playlist = false
		}
	}
	if playlist && request.Method == http.MethodHead {
		writer.Header().Set("Content-Type", "application/vnd.apple.mpegurl")
		writer.WriteHeader(http.StatusOK)
		return
	}
	if playlist && request.Method == http.MethodGet {
		body, err := io.ReadAll(io.LimitReader(reader, 4<<20+1))
		if err != nil || len(body) > 4<<20 {
			stream.nativeLogError(info, "playlist_read_failed", finalURL.String(), err, contentType)
			http.Error(writer, "播放列表过大或读取失败", http.StatusBadGateway)
			return
		}
		text := strings.TrimSpace(strings.TrimPrefix(string(body), "\ufeff"))
		if !strings.HasPrefix(text, "#EXTM3U") {
			stream.nativeLog(info, "playlist_invalid", finalURL.String(), "", 0, contentType)
			http.Error(writer, "播放列表无效", http.StatusBadGateway)
			return
		}
		rewritten, err := stream.nativeRewrite(parts[0], session, text, finalURL.String())
		if err != nil {
			stream.nativeLog(info, "playlist_rewrite", finalURL.String(), "kind="+nativePlaylistKind(text)+" error="+nativeStreamError(err), 0, contentType)
			http.Error(writer, err.Error(), http.StatusBadGateway)
			return
		}
		writer.Header().Set("Content-Type", "application/vnd.apple.mpegurl")
		_, _ = io.WriteString(writer, stream.lanPlaylist(request, rewritten))
		return
	}
	// 分片整段读进内存再本地切 Range：站点不认 Range，只给整段 200；
	// 播放器拖动时若拿到「整段 + 无精确长度」，跨网一慢就会放弃并报 EOF，
	// 上层只能看到「播完了」，于是判断为结束。这里补齐精确 Content-Length
	// 与 Range 支持，并把分片留在会话缓存里供重复拖动复用。
	// 上游自己按 Range 回了 206 的，保持原样透传，别二次切片。
	// 没有 Content-Length（chunked）的分片同样整段读进来：否则本地也没有
	// 精确长度，拖动时播放器一边等一边超时，最后报播放器错误。
	if request.Method != http.MethodHead &&
		response.StatusCode == http.StatusOK &&
		(asset.kind == "segment" || asset.kind == "map") &&
		(response.ContentLength <= 0 || response.ContentLength <= nativeSegmentBufferLimit) {
		buffered, readErr := io.ReadAll(io.LimitReader(reader, nativeSegmentBufferLimit+1))
		oversized := int64(len(buffered)) > nativeSegmentBufferLimit
		complete := readErr == nil &&
			!oversized &&
			len(buffered) > 0 &&
			(response.ContentLength <= 0 || int64(len(buffered)) == response.ContentLength)
		if complete {
			stream.nativeCacheAsset(session, parts[1], buffered, response.Header.Get("Content-Type"))
			writer.Header().Set("Content-Type", response.Header.Get("Content-Type"))
			http.ServeContent(writer, request, parts[1], time.Time{}, bytes.NewReader(buffered))
			return
		}
		// 上游掐流、空闲超时或长度对不上。以前这里走透传，播放器的 HLS
		// 解复用器（ffmpeg hls）拿不到完整分片就当这条流结束，上层看到的
		// 就是「播到一半自己跳下一集」或拖动后卡住。现在先原地重试一次
		// 上游：能读全就照常出，两次都读不全就把已经拿到的那部分按精确
		// 长度回 200，让播放器自己重试这一片，而不是整集结束。
		stream.nativeLogError(info, "segment_partial", finalURL.String(), readErr, response.Header.Get("Content-Type"))
		response.Body.Close()
		if retried, _ := stream.nativeReplay(ctx, session, request, asset.address, nil); retried != nil {
			if retried.StatusCode == http.StatusOK &&
				retried.ContentLength > 0 &&
				retried.ContentLength <= nativeSegmentBufferLimit {
				second, secondErr := io.ReadAll(io.LimitReader(retried.Body, nativeSegmentBufferLimit+1))
				if secondErr == nil && int64(len(second)) == retried.ContentLength {
					retried.Body.Close()
					stream.nativeCacheAsset(session, parts[1], second, retried.Header.Get("Content-Type"))
					writer.Header().Set("Content-Type", retried.Header.Get("Content-Type"))
					http.ServeContent(writer, request, parts[1], time.Time{}, bytes.NewReader(second))
					stream.nativeLog(info, "segment_retried", finalURL.String(), "attempt=2", retried.StatusCode, "")
					return
				}
				if len(second) > len(buffered) {
					buffered = second
				}
			}
			retried.Body.Close()
		}
		// 已经读到的那部分如果覆盖了播放器要的位置，就按精确长度回 200，
		// 让播放器先接着放；覆盖不到（拖动落在没读到的区间）就回可重试的 503，
		// 不然播放器会等一个永远不来的 Content-Length，表现就是黑屏卡死。
		if len(buffered) > 0 && nativeRangeOverlaps(request, int64(len(buffered))) {
			writer.Header().Set("Content-Type", response.Header.Get("Content-Type"))
			writer.Header().Set("Content-Length", strconv.Itoa(len(buffered)))
			writer.WriteHeader(http.StatusOK)
			_, _ = writer.Write(buffered)
			return
		}
		writer.Header().Set("Retry-After", "1")
		http.Error(writer, "读取媒体失败，请重试", http.StatusServiceUnavailable)
		return
	}
	session.nativeClearFailure(parts[1])
	for _, name := range []string{"Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "ETag", "Last-Modified"} {
		if value := response.Header.Get(name); value != "" {
			writer.Header().Set(name, value)
		}
	}
	writer.WriteHeader(response.StatusCode)
	if request.Method == http.MethodGet {
		_, _ = io.Copy(writer, reader)
	}
}
