package core

import (
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
)

// 索引测试用的站源 id。Register 会 panic 重复注册，这里用一个没人用的名字，
// 只为了让 SplitProviderDramaID 认「idxprobe:1」这种带前缀的完整 id。
const indexProbeSource = "idxprobe"

func indexProbeEngine(t *testing.T, directory string) *nativeEngine {
	t.Helper()
	return &nativeEngine{
		directory:      directory,
		cacheDirectory: directory,
		catalogs:       map[string][]LibraryDrama{},
		catalogStates:  map[string]nativeCatalogState{},
	}
}

func TestSearchIndexFindsIntroAndTags(t *testing.T) {
	engine := indexProbeEngine(t, t.TempDir())
	engine.indexDramas(indexProbeSource, []LibraryDrama{
		{ID: "idxprobe:1", Title: "都市龙傲天", Description: "林浩哲踏入豪门，成了最年轻的管家", Category: "都市", Tags: []string{"逆袭"}},
		{ID: "idxprobe:2", Title: "夜色温柔", Description: "苏芸在雨夜离开这座城市", Category: "情感", Tags: []string{"虐恋"}},
	})

	// 简介命中：只有 description 里出现关键词，必须落在第 7 档（rank 1）。
	hits := engine.searchIndexed(indexProbeSource, "林浩哲")
	if len(hits) != 1 || hits[0].ID != "idxprobe:1" {
		t.Fatalf("简介关键词没有命中: %+v", hits)
	}
	if hits[0].Rank != int(searchRelevanceIntro) {
		t.Fatalf("简介命中档位应为 %d，实际 %d", int(searchRelevanceIntro), hits[0].Rank)
	}
	if hits[0].Description == "" {
		t.Fatal("索引命中没带简介，卡片会少一段文字")
	}

	// 标签命中：第 6 档。
	tagged := engine.searchIndexed(indexProbeSource, "虐恋")
	if len(tagged) != 1 || tagged[0].Rank != int(searchRelevanceMeta) {
		t.Fatalf("标签命中档位不对: %+v", tagged)
	}

	// 标题命中：档位要比标签高，排序也在前面。
	title := engine.searchIndexed(indexProbeSource, "都市")
	if len(title) != 1 || title[0].Rank != int(searchRelevancePrefix) {
		t.Fatalf("标题命中档位不对: %+v", title)
	}

	// 完全不沾边的词应该一条都不给。
	if loose := engine.searchIndexed(indexProbeSource, "量子力学"); len(loose) != 0 {
		t.Fatalf("无关词不该命中: %+v", loose)
	}
}

func TestSearchIndexSurvivesRestart(t *testing.T) {
	directory := t.TempDir()
	engine := indexProbeEngine(t, directory)
	engine.indexDramas(indexProbeSource, []LibraryDrama{
		{ID: "idxprobe:1", Title: "都市龙傲天", Description: "林浩哲踏入豪门", Category: "都市", Tags: []string{"逆袭"}},
		{ID: "idxprobe:2", Title: "夜色温柔", Description: "苏芸在雨夜离开这座城市", Category: "情感"},
	})
	// 节流窗口内第二次写入不会立刻落盘，这里强制写一次再重启。
	engine.flushIndex(indexProbeSource)
	if _, err := os.Stat(filepath.Join(directory, searchIndexFolder, indexProbeSource+".tsv")); err != nil {
		t.Fatalf("索引文件没落盘: %v", err)
	}

	restarted := indexProbeEngine(t, directory)
	hits := restarted.searchIndexed(indexProbeSource, "苏芸")
	if len(hits) != 1 || hits[0].ID != "idxprobe:2" {
		t.Fatalf("重启后读不回简介命中: %+v", hits)
	}
	if hits[0].Category != "情感" {
		t.Fatalf("重启后分类丢了: %+v", hits[0])
	}
	entries, intros, _ := restarted.indexStats(indexProbeSource)
	if entries != 2 || intros != 2 {
		t.Fatalf("统计不对: entries=%d intros=%d", entries, intros)
	}
}

// 简介抓回来只补一次，短的不能盖掉长的。
func TestIndexSetIntroKeepsLongerText(t *testing.T) {
	engine := indexProbeEngine(t, t.TempDir())
	engine.indexDramas(indexProbeSource, []LibraryDrama{{ID: "idxprobe:1", Title: "都市龙傲天"}})
	engine.indexSetIntro("idxprobe:1", "短简介")
	engine.indexSetIntro("idxprobe:1", "这是一段更长的简介，里面提到了苏芸和豪门")
	engine.indexSetIntro("idxprobe:1", "短")
	_, intros, _ := engine.indexStats(indexProbeSource)
	if intros != 1 {
		t.Fatalf("简介计数应为 1，实际 %d", intros)
	}
	hits := engine.searchIndexed(indexProbeSource, "苏芸")
	if len(hits) != 1 || !strings.Contains(hits[0].Description, "更长") {
		t.Fatalf("短简介盖掉了长简介: %+v", hits)
	}
}

// 索引是行式存储，字段里混进制表符和换行会把整行解析错位。
func TestSearchIndexEscapesSeparators(t *testing.T) {
	directory := t.TempDir()
	engine := indexProbeEngine(t, directory)
	engine.indexDramas(indexProbeSource, []LibraryDrama{{
		ID:          "idxprobe:1",
		Title:       "都市\t龙傲天\n第二行",
		Description: "第一段\t第二段\n第三段",
	}})
	engine.flushIndex(indexProbeSource)

	restarted := indexProbeEngine(t, directory)
	entries, _, _ := restarted.indexStats(indexProbeSource)
	if entries != 1 {
		t.Fatalf("换行把一条拆成了 %d 条", entries)
	}
	hits := restarted.searchIndexed(indexProbeSource, "龙傲天")
	if len(hits) != 1 {
		t.Fatalf("标题里的制表符处理坏了: %+v", hits)
	}
	if strings.ContainsAny(hits[0].Title, "\t\n") {
		t.Fatalf("落盘字段里还留着分隔符: %q", hits[0].Title)
	}
}

// 同一部剧站点和本地都有时只留一条，且优先站点那条（字段更全）。
func TestMergeSearchWithIndexDeduplicates(t *testing.T) {
	remote := []LibraryDrama{{
		ID: "idxprobe:1", Title: "都市龙傲天", Description: "站点给的简介", Episodes: 88,
		Rank: int(searchRelevancePrefix),
	}}
	local := []LibraryDrama{
		{ID: "idxprobe:1", Title: "都市龙傲天", Rank: int(searchRelevancePrefix)},
		{ID: "idxprobe:3", Title: "豪门弃女", Description: "林浩哲的逆袭之路", Rank: int(searchRelevanceIntro)},
	}
	merged := mergeSearchWithIndex(remote, local, "都市")
	if len(merged) != 1 {
		t.Fatalf("同一部剧应合成一条，实际 %d 条: %+v", len(merged), merged)
	}
	if merged[0].Episodes != 88 {
		t.Fatalf("应保留站点那条的集数: %+v", merged[0])
	}

	// 站点一条都没有时，本地命中要能单独顶上。
	onlyLocal := mergeSearchWithIndex(nil, local, "林浩哲")
	if len(onlyLocal) != 1 || onlyLocal[0].ID != "idxprobe:3" {
		t.Fatalf("站点空时本地没有顶上: %+v", onlyLocal)
	}
	if onlyLocal[0].Rank != int(searchRelevanceIntro) {
		t.Fatalf("本地简介命中的档位丢了: %+v", onlyLocal[0])
	}
}

func TestSearchIndexPageSlice(t *testing.T) {
	items := make([]LibraryDrama, 45)
	for index := range items {
		items[index] = LibraryDrama{ID: "idxprobe:" + strconv.Itoa(index)}
	}
	if got := searchIndexPageSlice(items, 1); len(got) != searchIndexPageSize {
		t.Fatalf("第一页应为 %d 条，实际 %d", searchIndexPageSize, len(got))
	}
	if got := searchIndexPageSlice(items, 3); len(got) != 5 {
		t.Fatalf("最后一页应为 5 条，实际 %d", len(got))
	}
	if got := searchIndexPageSlice(items, 9); len(got) != 0 {
		t.Fatalf("越界页应为空，实际 %d", len(got))
	}
}
