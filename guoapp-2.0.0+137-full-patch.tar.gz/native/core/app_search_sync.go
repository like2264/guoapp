package core

// 搜索索引的后台补充（2.0.0+128 起）
//
// 索引里的条目有两个来源：用户自己翻过的目录页（免费，翻到哪记到哪），
// 以及这里的后台任务。后台任务做两件事：
//
//  1. 目录扩页：按页往后翻，把没见过的条目补进索引。每次只翻几页，站点的
//     限流和慢站源（柚子短剧单页三秒起）都不至于被拖死。
//  2. 简介补全：索引里存着条目的标题和标签，但目录页大多不带简介，只有
//     详情接口才有。这里按游标轮转，一次给十几条补上简介——简介一进索引，
//     之后搜简介里的词就能命中，这正是黄果视频、黑桃、禁果短剧缺的第 7 档。
//
// 两个动作都是后台跑的，失败就下次再说，绝不影响这次搜索的返回。

import (
	"context"
	"time"
)

const (
	// searchSyncCatalogPages 是单次后台扩页的页数。翻三页大约 60~120 条。
	searchSyncCatalogPages = 3
	// searchSyncIntroBatch 是单次后台补简介的条数。详情接口一次一部，太多会
	// 把站点的限流额度吃干净，用户自己的请求反而变慢。
	searchSyncIntroBatch = 20
	// searchSyncIntroQueue 是每个站源排队等简介的条目上限。搜索结果一次最多
	// 一百多条，留出余量即可；再多也补不完，反而白占内存。
	searchSyncIntroQueue = 400
	// searchSyncIntroRounds 是一轮后台任务里连续补简介的轮数上限。队列没清空
	// 就接着补，用户不操作也能自己补齐；补不完留给下次搜索。
	searchSyncIntroRounds = 8
	// searchSyncCatalogGap 是同一站源两次扩页之间的冷却。
	searchSyncCatalogGap = 45 * time.Second
	// searchSyncIntroGap 是同一站源两次补简介之间的冷却。队列里有活儿时用
	// searchSyncIntroQueueGap，快一些，别让用户等太久才看到结果变多。
	searchSyncIntroGap = 40 * time.Second
	// searchSyncIntroQueueGap 是队列非空时的冷却。
	searchSyncIntroQueueGap = 8 * time.Second
	// searchSyncStepGap 是页与页、条与条之间的间隔，给站点喘口气。
	searchSyncStepGap = 350 * time.Millisecond
	// searchSyncTimeout 是单个请求的超时。柚子这类慢站单页五秒以上，留足。
	searchSyncTimeout = 30 * time.Second
)

// kickSearchIndex 在搜索出口触发一次后台补充。同一站源同时只跑一个任务，
// 两个动作各自有冷却，所以连续搜索不会把站点打爆。
func (engine *nativeEngine) kickSearchIndex(source string) {
	if engine.downloader == nil {
		return
	}
	source = canonicalProviderSource(source)
	if !registeredProviderSource(source) {
		return
	}
	store := engine.index()
	store.mu.Lock()
	if store.busy[source] {
		store.mu.Unlock()
		return
	}
	now := time.Now()
	queued := len(store.pending[source]) > 0
	introGap := searchSyncIntroGap
	if queued {
		introGap = searchSyncIntroQueueGap
	}
	catalogDue := now.Sub(store.synced[source]) >= searchSyncCatalogGap
	introDue := now.Sub(store.introAt[source]) >= introGap
	if !catalogDue && !introDue {
		store.mu.Unlock()
		return
	}
	store.busy[source] = true
	if catalogDue {
		store.synced[source] = now
	}
	if introDue {
		store.introAt[source] = now
	}
	store.mu.Unlock()

	go func() {
		// 刚返回的这次搜索很可能马上要翻页，先让开一个呼吸的时间。
		time.Sleep(1500 * time.Millisecond)
		defer func() {
			store.mu.Lock()
			delete(store.busy, source)
			store.mu.Unlock()
		}()
		if catalogDue {
			engine.indexCatalogPages(source)
		}
		if introDue {
			engine.drainIntros(source)
		}
		// 把这次搜索剩下的页翻完：站点一页三十条，简介档的条目可能排在后面
		// 几页，前端只拿第一页就永远看不见它们。翻完的条目进索引、排队补简介。
		if query := engine.takeSearchQuery(source); query != "" {
			engine.indexSearchPages(source, query)
			engine.drainIntros(source)
		}
	}()
}

// drainIntros 连续补几轮简介，直到队列清空或轮数用尽。
func (engine *nativeEngine) drainIntros(source string) {
	engine.indexIntros(source)
	for round := 1; round < searchSyncIntroRounds; round++ {
		if !engine.hasQueuedIntros(source) {
			return
		}
		if !engine.waitForeground() {
			return
		}
		time.Sleep(2 * time.Second)
		engine.indexIntros(source)
	}
}

// queueSearch 记下这次搜索的关键词，后台接着把后面的页翻完。
func (engine *nativeEngine) queueSearch(source, query string) {
	if engine.downloader == nil || query == "" {
		return
	}
	source = canonicalProviderSource(source)
	if !registeredProviderSource(source) {
		return
	}
	engine.index().mu.Lock()
	engine.index().query[source] = query
	engine.index().mu.Unlock()
}

func (engine *nativeEngine) takeSearchQuery(source string) string {
	store := engine.index()
	store.mu.Lock()
	defer store.mu.Unlock()
	query := store.query[source]
	delete(store.query, source)
	return query
}

// indexSearchPages 按搜索词把第二页往后翻完，把条目补进索引并排队补简介。
func (engine *nativeEngine) indexSearchPages(source, query string) {
	provider, ok := engine.downloader.provider(source)
	if !ok {
		return
	}
	searcher, ok := providerAs[Searcher](provider)
	if !ok {
		return
	}
	for page := 2; page <= searchProbePages; page++ {
		if !engine.waitForeground() {
			return
		}
		ctx, cancel := context.WithTimeout(context.Background(), searchSyncTimeout)
		items, more, err := searcher.Search(ctx, page, query)
		cancel()
		if err != nil || len(items) == 0 {
			return
		}
		normalized := make([]LibraryDrama, 0, len(items))
		for _, drama := range items {
			if drama.ID == "" {
				continue
			}
			normalized = append(normalized, NativeNormalize(drama))
		}
		engine.indexDramas(source, normalized)
		engine.queueIntros(source, normalized)
		if !more {
			return
		}
		time.Sleep(searchSyncStepGap)
	}
}

// queueIntros 把「这次搜索里站点返回、但还没简介」的条目排进后台队列。
//
// 站点搜索接口只按标题和标签召回，简介里出现关键词的条目要等补完简介才判
// 得出来。把这些条目提前排上，用户这次看不到，下一次搜索（或列表刷新）就
// 能从本地索引里捞回来，而不是永远卡在「站点不返回简介」上。
func (engine *nativeEngine) queueIntros(source string, items []LibraryDrama) {
	if engine.downloader == nil || len(items) == 0 {
		return
	}
	source = canonicalProviderSource(source)
	if !registeredProviderSource(source) {
		return
	}
	store := engine.index()
	store.mu.Lock()
	if store.pendingSeen[source] == nil {
		store.pendingSeen[source] = map[string]bool{}
	}
	queue := store.pending[source]
	seen := store.pendingSeen[source]
	for _, item := range items {
		if item.ID == "" || seen[item.ID] {
			continue
		}
		if len(queue) >= searchSyncIntroQueue {
			break
		}
		seen[item.ID] = true
		// nativeCatalog 里已经是 LibraryDrama（归一化过了），不能再套 NativeNormalize。
		queue = append(queue, item)
	}
	store.pending[source] = queue
	store.mu.Unlock()
}

func (engine *nativeEngine) hasQueuedIntros(source string) bool {
	store := engine.index()
	store.mu.Lock()
	defer store.mu.Unlock()
	return len(store.pending[source]) > 0
}

// takeQueuedIntros 取走队首的一批（取走就不在队列里了，失败不重排）。
func (engine *nativeEngine) takeQueuedIntros(source string, limit int) []LibraryDrama {
	store := engine.index()
	store.mu.Lock()
	defer store.mu.Unlock()
	queue := store.pending[source]
	if len(queue) == 0 {
		return nil
	}
	if limit <= 0 || limit > len(queue) {
		limit = len(queue)
	}
	batch := append([]LibraryDrama(nil), queue[:limit]...)
	rest := append([]LibraryDrama(nil), queue[limit:]...)
	store.pending[source] = rest
	if len(rest) == 0 {
		store.pendingSeen[source] = map[string]bool{}
	}
	return batch
}

// indexCatalogPages 往后翻几页目录，把新条目补进索引。
func (engine *nativeEngine) indexCatalogPages(source string) {
	provider, ok := engine.downloader.provider(source)
	if !ok {
		return
	}
	for step := 0; step < searchSyncCatalogPages; step++ {
		if !engine.waitForeground() {
			return
		}
		page := engine.indexNextPage(source)
		if page <= 0 {
			return
		}
		ctx, cancel := context.WithTimeout(context.Background(), searchSyncTimeout)
		unlock, lockErr := engine.lockSourceCatalog(ctx, source)
		if lockErr != nil {
			cancel()
			return
		}
		items, more, err := provider.CatalogPage(ctx, page, "")
		unlock()
		cancel()
		if err != nil || len(items) == 0 {
			return
		}
		normalized := make([]LibraryDrama, 0, len(items))
		for _, drama := range items {
			if drama.ID == "" {
				continue
			}
			normalized = append(normalized, NativeNormalize(drama))
		}
		engine.indexDramas(source, normalized)
		engine.indexMarkPage(source, page)
		if !more {
			return
		}
		time.Sleep(searchSyncStepGap)
	}
}

// indexIntros 给索引里还没简介的条目补简介。只补文字，不动分集和播放信息。
//
// 先清搜索结果排上来的队列（用户刚搜过的那批），再轮到索引里的普通轮转。
func (engine *nativeEngine) indexIntros(source string) {
	provider, ok := engine.downloader.provider(source)
	if !ok {
		return
	}
	queued := engine.takeQueuedIntros(source, searchSyncIntroBatch)
	budget := searchSyncIntroBatch - len(queued)
	if budget < 4 {
		budget = 0
	}
	var targets []string
	if budget > 0 {
		targets = engine.indexIntroTargets(source, budget)
	}
	fill := func(id string) bool {
		_, sourceID, valid := SplitProviderDramaID(id)
		if !valid {
			return false
		}
		ctx, cancel := context.WithTimeout(context.Background(), searchSyncTimeout)
		drama, _, err := provider.Detail(ctx, sourceID)
		cancel()
		if err != nil {
			return false
		}
		description := FirstNonEmpty(drama.Desc, drama.Intro)
		if drama.ID == "" {
			drama.ID = id
		}
		// 顺手把详情里的分类和标签也写进索引：剧果这类站点的列表页和搜索接口
		// 都不带标签，只有详情页有。不补的话它的第 6 档（标签/分类）永远是空的，
		// 用户看到的就是「这个站只有五档」。
		engine.indexDramas(source, []LibraryDrama{NativeNormalize(drama)})
		if description == "" {
			return false
		}
		engine.indexSetIntro(id, description)
		return true
	}
	for _, drama := range queued {
		if !engine.waitForeground() {
			return
		}
		// 先把列表页那份（标题/封面/集数）写进索引：详情取不到时这条也还在。
		engine.indexDramas(source, []LibraryDrama{drama})
		fill(drama.ID)
		time.Sleep(searchSyncStepGap)
	}
	for _, id := range targets {
		if !engine.waitForeground() {
			return
		}
		fill(id)
		time.Sleep(searchSyncStepGap)
	}
}

// beginForeground 标记一次用户正在等待的搜索请求。后台任务看到有前台请求
// 就让路：同一个站源同时挨两份请求，轻则变慢，重则被站点断连。
func (engine *nativeEngine) beginForeground() func() {
	engine.foregroundMu.Lock()
	engine.foreground++
	engine.foregroundMu.Unlock()
	return func() {
		engine.foregroundMu.Lock()
		if engine.foreground > 0 {
			engine.foreground--
		}
		engine.foregroundMu.Unlock()
	}
}

func (engine *nativeEngine) foregroundBusy() bool {
	engine.foregroundMu.Lock()
	defer engine.foregroundMu.Unlock()
	return engine.foreground > 0
}

// waitForeground 在前台请求期间让步，最多等九秒。用户连着翻页时后台就
// 放弃这一轮，下次搜索再补。
func (engine *nativeEngine) waitForeground() bool {
	for attempt := 0; attempt < 30; attempt++ {
		if !engine.foregroundBusy() {
			return true
		}
		time.Sleep(300 * time.Millisecond)
	}
	return !engine.foregroundBusy()
}
