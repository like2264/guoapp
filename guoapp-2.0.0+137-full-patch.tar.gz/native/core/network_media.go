package core

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
)

func mediaRequestHeaders(request *http.Request, referer string) {
	request.Header.Set("User-Agent", UserAgent)
	if referer != "" {
		request.Header.Set("Referer", referer)
		request.Header.Set("Sec-Fetch-Mode", "cors")
		request.Header.Set("Sec-Fetch-Dest", "empty")
		if origin, err := url.Parse(referer); err == nil && origin.Host != "" {
			request.Header.Set("Origin", origin.Scheme+"://"+origin.Host)
		}
	}
	request.Header.Set("Accept", "*/*")
	request.Header.Set("Accept-Language", "zh-CN,zh;q=0.9")
}

func (d *Downloader) doMediaRequest(request *http.Request) (*http.Response, error) {
	return d.doMediaRequestWithClient(request, d.client)
}

func (d *Downloader) doMediaRequestWithClient(request *http.Request, client *http.Client) (*http.Response, error) {
	mediaRequestHeaders(request, request.Header.Get("Referer"))
	if credentials, _ := request.Context().Value(MediaCredentialsKey{}).(*MediaCredentials); credentials != nil {
		if err := credentials.apply(request); err != nil {
			return nil, err
		}
		client = credentials.client(client)
	}
	authorizer := d.mediaAuthorizer(request.URL)
	authorization := ""
	for attempt := 0; attempt < 2; attempt++ {
		if authorizer != nil {
			header, value, err := authorizer.MediaAuthorization(request.Context(), request.URL, request.Header.Get("Referer"))
			if err != nil {
				return nil, fmt.Errorf("获取播放凭证失败: %w", err)
			}
			request.Header.Set(header, value)
			authorization = header
		}
		response, err := client.Do(request)
		if err != nil {
			return nil, err
		}
		if authorizer != nil && attempt == 0 && (response.StatusCode == http.StatusUnauthorized || response.StatusCode == http.StatusForbidden) {
			body, readErr := io.ReadAll(io.LimitReader(response.Body, 64<<10))
			response.Body.Close()
			if readErr == nil && catalogResponseBlockReason(response, body) == "" {
				authorizer.RejectMediaAuthorization(request.URL, request.Header.Get(authorization))
				continue
			}
			response.Body = io.NopCloser(bytes.NewReader(body))
		}
		if d.limiter != nil {
			d.limiter.observeMedia(request, response)
		}
		return response, nil
	}
	return nil, errors.New("播放凭证刷新失败")
}

// fetchMediaPlaylist 取 m3u8。站点 CDN 对 Referer 的口径各不相同：有的要播放页、
// 有的只认站点根、有的干脆不认 Referer 却讨厌带 Origin 的跨站请求。实测夜社
// （vods3 那台）在部分网络下对播放页 Referer 回 403，换站点根就正常，所以这里
// 一旦拿到 403/401 就按「站点根 → CDN 根 → 不带 Referer」的顺序再试两轮。
func (d *Downloader) fetchMediaPlaylist(ctx context.Context, address, referer string) (string, string, error) {
	if !IsProviderHTTPMediaURL(address) {
		return "", "", errors.New("播放列表地址无效")
	}
	text, finalURL, status, err := d.fetchMediaPlaylistOnce(ctx, address, referer)
	if err == nil {
		return text, finalURL, nil
	}
	if status != http.StatusForbidden && status != http.StatusUnauthorized {
		return text, finalURL, err
	}
	for _, variant := range mediaRefererVariants(address, referer) {
		if variant == referer {
			continue
		}
		if err := ctx.Err(); err != nil {
			break
		}
		variantText, variantURL, _, variantErr := d.fetchMediaPlaylistOnce(ctx, address, variant)
		if variantErr == nil {
			return variantText, variantURL, nil
		}
	}
	return text, finalURL, err
}

// mediaRefererVariants 给出播放列表请求的 Referer 备选值（含空串＝不带 Referer）。
func mediaRefererVariants(address, referer string) []string {
	out := make([]string, 0, 3)
	seen := map[string]bool{}
	add := func(value string) {
		if seen[value] {
			return
		}
		seen[value] = true
		out = append(out, value)
	}
	if parsed, err := url.Parse(referer); err == nil && parsed.Host != "" {
		add(parsed.Scheme + "://" + parsed.Host + "/")
	}
	if parsed, err := url.Parse(address); err == nil && parsed.Host != "" {
		add(parsed.Scheme + "://" + parsed.Host + "/")
	}
	add("")
	return out
}

func (d *Downloader) fetchMediaPlaylistOnce(ctx context.Context, address, referer string) (string, string, int, error) {
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, address, nil)
	if err != nil {
		return "", "", 0, err
	}
	request.Header.Set("Referer", referer)
	response, err := d.doMediaRequest(request)
	if err != nil {
		return "", "", 0, err
	}
	defer response.Body.Close()
	body, err := io.ReadAll(io.LimitReader(response.Body, (4<<20)+1))
	if err != nil || len(body) > 4<<20 {
		return "", "", response.StatusCode, errors.New("播放列表过大或读取失败")
	}
	if response.StatusCode != http.StatusOK || catalogResponseBlockReason(response, body) != "" {
		return "", "", response.StatusCode, d.catalogResponseError(request, response, body)
	}
	text := strings.TrimSpace(strings.TrimPrefix(string(body), "\ufeff"))
	if !strings.HasPrefix(text, "#EXTM3U") {
		return "", "", response.StatusCode, &PlaylistError{Body: body}
	}
	finalURL := address
	if response.Request != nil && response.Request.URL != nil {
		finalURL = response.Request.URL.String()
	}
	return text, finalURL, response.StatusCode, nil
}
