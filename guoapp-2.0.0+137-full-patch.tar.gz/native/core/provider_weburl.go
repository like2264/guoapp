package core

import (
	"net/url"
	"strings"
)

// nativeDramaWebURL 给出「该剧在站源网页上的详情页地址」，供 App 详情页的
// 「用浏览器打开」按钮使用。
//
// 2.0 的站源是运行时加载的模块，模块没有义务单独给出系列页地址；但它给每条
// 分集都带了 pageUrl（模块里就是真正能打开的那一页）。用第一集的地址当
// 「网页版入口」是最稳的做法：地址一定真实存在，也和 App 里看到的对得上。
// 纯接口型模块（不返回 pageUrl）打开按钮就不显示，不会给出死链。
func nativeDramaWebURL(current string, chapters []Chapter) string {
	if value := strings.TrimSpace(current); value != "" {
		return value
	}
	for _, chapter := range chapters {
		page := strings.TrimSpace(chapter.PageURL)
		if page == "" {
			continue
		}
		parsed, err := url.Parse(page)
		if err != nil || parsed.Host == "" {
			continue
		}
		if parsed.Scheme != "http" && parsed.Scheme != "https" {
			continue
		}
		return page
	}
	return ""
}
