const siteBaseUrl = "https://huangguo.video";
const userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1";
const channel = "huangguo.video";
const sourceAliases = ["huangguo-video", "huangguo.video"];

const videoCardPattern = /<article\b[^>]*class=["'][^"']*\bvideo-card\b[^"']*["'][^>]*>[\s\S]*?<\/article>/gi;
const cardMetaPattern = /<p\b[^>]*class=["'][^"']*\bfont-mono-meta\b[^"']*["'][^>]*>([\s\S]*?)<\/p>/i;
const detailMetaPattern = /<\/h1>[\s\S]*?<p\b[^>]*class=["'][^"']*\bfont-mono-meta\b[^"']*["'][^>]*>([\s\S]*?)<\/p>/i;
const anyArticlePattern = /<article\b[^>]*>[\s\S]*?<\/article>/gi;
const linkPattern = /<a\b[^>]*href=["']([^"']*\/(?:series|video)\/([^"'/?#]+)[^"']*)["'][^>]*>[\s\S]*?<\/a>/i;
const linkPatternAll = new RegExp(linkPattern.source, "gi");
const dataHlsPattern = /data-hls=["']([^"']+)["']/i;
const jsonLdPattern = /<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
const metaTagPattern = /<meta\b[^>]*>/gi;
const nonContentPattern = /<!--[\s\S]*?-->|<script\b[^>]*>[\s\S]*?<\/script\s*>|<style\b[^>]*>[\s\S]*?<\/style\s*>/gi;
const htmlTagPattern = /<(\/?)([a-z][a-z0-9:-]*)\b(?:[^<>"']|"[^"]*"|'[^']*')*>/gi;
const anchorPattern = /<a\b([^>]*)>([\s\S]*?)<\/a>/gi;
const titleTagPattern = /<title[^>]*>([\s\S]*?)<\/title>/i;
const headingPattern = /<h1[^>]*>([\s\S]*?)<\/h1>/i;
const ogTitlePattern = /<meta\b[^>]*property=["']og:title["'][^>]*content=["']([^"']+)["'][^>]*>/i;
const descriptionPattern = /<meta\b[^>]*(?:name|property)=["'](?:description|og:description)["'][^>]*content=["']([^"']+)["'][^>]*>/i;
const tagPattern = /<[^>]+class=["'][^"']*hg-tag[^"']*["'][^>]*>([\s\S]*?)<\/[^>]+>/gi;
const episodeNumberPattern = /(?:第\s*0*(\d+)\s*(?:集|话|期)|(?:更新至|共|全)\s*0*(\d+)\s*(?:集|话|期)|(?:episode|ep)\s*#?\s*0*(\d+))/i;
const viewsPattern = /[0-9]+(?:\.[0-9]+)?\s*[w万]?\s*次播放/i;
const datePattern = /\d{4}-\d{1,2}-\d{1,2}/;
const finishedRemarkPattern = /(?:全\s*\d+\s*集|\d+\s*集全|已完结|大结局)/;
const sourceIdPattern = /^[a-zA-Z0-9_-]{1,100}$/;

function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function firstNonEmpty(...values) {
  for (const value of values) {
    if (typeof value === "string" && value.trim() !== "") {
      return value.trim();
    }
  }
  return "";
}

function htmlUnescape(text) {
  const named = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: "\u00a0" };
  return text.replace(/&(#[xX][0-9a-fA-F]+|#[0-9]+|[a-zA-Z]+);/g, (entity, body) => {
    if (body[0] === "#") {
      const code = body[1] === "x" || body[1] === "X" ? parseInt(body.slice(2), 16) : parseInt(body.slice(1), 10);
      return code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : entity;
    }
    return Object.prototype.hasOwnProperty.call(named, body) ? named[body] : entity;
  });
}

function cleanText(text) {
  text = text.replace(/<script\b[\s\S]*?<\/script>/gi, " ").replace(/<style\b[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ");
  return htmlUnescape(text).replace(/[\t\n\f\r ]+/g, " ").trim();
}

function quoteMeta(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function allMatches(pattern, text) {
  const found = [];
  pattern.lastIndex = 0;
  let match;
  while ((match = pattern.exec(text)) !== null) {
    found.push(match);
    if (match[0] === "") {
      pattern.lastIndex++;
    }
  }
  return found;
}

function extractAttr(block, ...names) {
  for (const name of names) {
    const match = block.match(new RegExp("\\b" + quoteMeta(name) + "\\s*=\\s*[\"']([^\"']+)[\"']", "i"));
    if (match) {
      return htmlUnescape(match[1]).trim();
    }
  }
  return "";
}

function classText(raw, className) {
  if (className === "") {
    return "";
  }
  const match = raw.match(new RegExp("<[^>]+class=[\"'][^\"']*" + quoteMeta(className) + "[^\"']*[\"'][^>]*>([\\s\\S]*?)</[^>]+>", "i"));
  return match ? cleanText(match[1]) : "";
}

function pageTitle(body) {
  const heading = body.match(headingPattern);
  if (heading) {
    const text = cleanText(heading[1]);
    if (text !== "") {
      return text;
    }
  }
  const og = body.match(ogTitlePattern);
  if (og) {
    const text = htmlUnescape(og[1]).trim();
    if (text !== "") {
      return text;
    }
  }
  const title = body.match(titleTagPattern);
  return title ? cleanText(title[1]) : "";
}

function pageDescription(body) {
  const match = body.match(descriptionPattern);
  return match ? htmlUnescape(match[1]).trim() : "";
}

function pageTags(body) {
  const tags = [];
  for (const match of allMatches(tagPattern, body)) {
    const value = cleanText(match[1]);
    if (value !== "" && !tags.includes(value)) {
      tags.push(value);
    }
  }
  return tags;
}

function releaseStatusFromRemark(remark) {
  if (remark.includes("未完结") || remark.includes("更新至") || remark.includes("连载")) {
    return "ongoing";
  }
  if (finishedRemarkPattern.test(remark) || remark.includes("完结")) {
    return "finished";
  }
  return "unknown";
}

function episodeIndex(text, fallback) {
  const match = text.match(episodeNumberPattern);
  if (match) {
    for (const group of match.slice(1)) {
      if (group !== undefined && group !== "") {
        const number = parseInt(group, 10);
        if (number > 0) {
          return number;
        }
      }
    }
  }
  return fallback;
}

function normalizeViews(text) {
  text = text.trim();
  if (text === "") {
    return "";
  }
  if (text.includes("次播放")) {
    return text;
  }
  if (/[w万]/.test(text.toLowerCase())) {
    return text + "次播放";
  }
  if (!/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(text)) {
    return text;
  }
  const number = Number(text);
  return number <= 0 ? "" : String(number) + "次播放";
}

function firstMatchText(pattern, text) {
  const match = text.match(pattern);
  return match ? match[0].trim() : "";
}

function pad2(value) {
  return value < 10 ? "0" + value : String(value);
}

function normalizeDate(text) {
  const matches = String(text).trim().match(/\d{4}-\d{1,2}-\d{1,2}/g) || [];
  for (const match of matches) {
    const [year, month, day] = match.split("-").map((part) => parseInt(part, 10));
    if (year >= 2000 && year <= 2100 && month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      return year + "-" + pad2(month) + "-" + pad2(day);
    }
  }
  return "";
}

function validDate(date) {
  const [year, month, day] = date.split("-").map((part) => parseInt(part, 10));
  const parsed = new Date(Date.UTC(year, month - 1, day));
  return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month - 1 && parsed.getUTCDate() === day;
}

function releaseDate(value) {
  value = String(value || "").trim();
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value)) {
    const stamp = Date.parse(value.replace(/(\.\d{3})\d+/, "$1"));
    if (!isNaN(stamp)) {
      const date = new Date(stamp + 8 * 3600 * 1000);
      value = date.getUTCFullYear() + "-" + pad2(date.getUTCMonth() + 1) + "-" + pad2(date.getUTCDate());
    }
  }
  const date = normalizeDate(value);
  return date !== "" && validDate(date) ? date : "";
}

function parseAddress(raw) {
  try {
    return host.parseUrl(raw);
  } catch (error) {
    return null;
  }
}

function httpAddress(raw) {
  const parsed = parseAddress(String(raw).trim());
  return parsed !== null && (parsed.scheme === "http" || parsed.scheme === "https") && parsed.hostname !== "" && !parsed.userInfo;
}

function resolveUrl(base, ref) {
  ref = htmlUnescape(String(ref || "")).trim();
  if (ref === "") {
    return "";
  }
  ref = ref.replace(/\\\//g, "/");
  if (ref.startsWith("//")) {
    return "https:" + ref;
  }
  const parsed = parseAddress(ref);
  if (!parsed) {
    return ref;
  }
  let resolved = parsed.href;
  if (parsed.scheme === "") {
    try {
      resolved = host.resolveUrl(base, ref);
    } catch (error) {
      return ref;
    }
  }
  return resolved.replace(/^http:/, "https:");
}

function goUnquote(text) {
  if (text.includes("\n")) {
    return null;
  }
  const simple = { a: 7, b: 8, f: 12, n: 10, r: 13, t: 9, v: 11, "\\": 92, '"': 34 };
  const bytes = [];
  const pushText = (value) => {
    for (const byte of host.utf8Encode(value)) {
      bytes.push(byte);
    }
  };
  for (let index = 0; index < text.length; index++) {
    const character = text[index];
    if (character === '"') {
      return null;
    }
    if (character !== "\\") {
      pushText(character);
      continue;
    }
    const escape = text[++index];
    if (escape === undefined) {
      return null;
    }
    if (Object.prototype.hasOwnProperty.call(simple, escape)) {
      bytes.push(simple[escape]);
    } else if (escape === "x") {
      const hex = text.slice(index + 1, index + 3);
      if (!/^[0-9a-fA-F]{2}$/.test(hex)) {
        return null;
      }
      bytes.push(parseInt(hex, 16));
      index += 2;
    } else if (escape === "u" || escape === "U") {
      const size = escape === "u" ? 4 : 8;
      const hex = text.slice(index + 1, index + 1 + size);
      const code = /^[0-9a-fA-F]+$/.test(hex) && hex.length === size ? parseInt(hex, 16) : -1;
      if (code < 0 || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) {
        return null;
      }
      pushText(String.fromCodePoint(code));
      index += size;
    } else if (escape >= "0" && escape <= "7") {
      const octal = text.slice(index, index + 3);
      if (!/^[0-7]{3}$/.test(octal) || parseInt(octal, 8) > 255) {
        return null;
      }
      bytes.push(parseInt(octal, 8));
      index += 2;
    } else {
      return null;
    }
  }
  return host.utf8Decode(bytes);
}

function normalizeMediaUrl(pageUrl, raw) {
  raw = htmlUnescape(String(raw || "")).trim().replace(/^[ \t\r\n"']+|[ \t\r\n"']+$/g, "");
  if (raw === "") {
    return "";
  }
  const unquoted = goUnquote(raw.replace(/"/g, '\\"'));
  if (unquoted !== null) {
    raw = unquoted;
  }
  raw = raw.replace(/\\\//g, "/");
  const resolved = resolveUrl(pageUrl, raw);
  const lower = resolved.toLowerCase();
  return lower.includes(".m3u8") || lower.includes(".mp4") ? resolved : "";
}

function coverAddress(value, pageUrl) {
  if (Array.isArray(value)) {
    for (const entry of value) {
      const found = coverAddress(entry, pageUrl);
      if (found !== "") {
        return found;
      }
    }
  } else if (isRecord(value)) {
    for (const key of ["url", "contentUrl", "thumbnailUrl"]) {
      const found = coverAddress(value[key], pageUrl);
      if (found !== "") {
        return found;
      }
    }
  } else if (typeof value === "string" && value.trim() !== "") {
    let resolved;
    try {
      resolved = host.resolveUrl(pageUrl, value.trim());
    } catch (error) {
      return "";
    }
    if (httpAddress(resolved)) {
      return resolved;
    }
  }
  return "";
}

function percentDecode(text, plusIsSpace) {
  if (/%(?![0-9a-fA-F]{2})/.test(text)) {
    return null;
  }
  const bytes = [];
  for (let index = 0; index < text.length; index++) {
    const character = text[index];
    if (character === "%") {
      bytes.push(parseInt(text.slice(index + 1, index + 3), 16));
      index += 2;
    } else if (plusIsSpace && character === "+") {
      bytes.push(32);
    } else {
      for (const byte of host.utf8Encode(character)) {
        bytes.push(byte);
      }
    }
  }
  return host.utf8Decode(bytes);
}

function queryValue(query, name) {
  for (const part of query.split("&")) {
    if (part === "" || part.includes(";")) {
      continue;
    }
    const separator = part.indexOf("=");
    const key = percentDecode(separator < 0 ? part : part.slice(0, separator), true);
    const value = percentDecode(separator < 0 ? "" : part.slice(separator + 1), true);
    if (key === name && value !== null) {
      return value;
    }
  }
  return "";
}

function queryEscape(text) {
  return encodeURIComponent(text)
    .replace(/[!'()*]/g, (character) => "%" + character.charCodeAt(0).toString(16).toUpperCase())
    .replace(/%20/g, "+");
}

function validCategory(category) {
  return /^[+-]?\d+$/.test(category) && parseInt(category, 10) > 0;
}

function fetchText(address, referer) {
  return host.fetchText({ url: address, referer }).body;
}

function cleanId(text) {
  text = htmlUnescape(text).trim().replace(/^[ /\t\r\n"']+|[ /\t\r\n"']+$/g, "");
  const cut = text.search(/[?#]/);
  return cut < 0 ? text : text.slice(0, cut);
}

function videoSourceId(href) {
  const parsed = parseAddress(htmlUnescape(href));
  const path = (parsed ? parsed.path : href).replace(/^\/+|\/+$/g, "");
  const parts = path.split("/");
  for (let index = 0; index + 1 < parts.length; index++) {
    if (parts[index] === "series" || parts[index] === "video") {
      const code = cleanId(parts[index + 1]);
      return code === "" ? "" : parts[index] + "/" + code;
    }
  }
  return "";
}

function dataHls(raw, pageUrl) {
  const match = raw.match(dataHlsPattern);
  return match ? normalizeMediaUrl(pageUrl, match[1]) : "";
}

function elementBlock(raw, start, end, tag) {
  let depth = 1;
  const rest = raw.slice(end);
  for (const match of allMatches(htmlTagPattern, rest)) {
    if (match[2].toLowerCase() !== tag.toLowerCase()) {
      continue;
    }
    if (match[1] !== "") {
      depth--;
    } else if (!match[0].trim().endsWith("/>")) {
      depth++;
    }
    if (depth === 0) {
      return raw.slice(start, end + match.index + match[0].length);
    }
  }
  return raw.slice(start, end);
}

function classBlock(raw, className) {
  for (const match of allMatches(htmlTagPattern, raw)) {
    if (match[1] !== "") {
      continue;
    }
    if (extractAttr(match[0], "class").split(/[\t\n\f\r ]+/).includes(className)) {
      return elementBlock(raw, match.index, match.index + match[0].length, match[2]);
    }
  }
  return "";
}

function stringField(value) {
  return value === undefined || value === null || typeof value === "string";
}

function jsonLdEntry(value) {
  if (value === null) {
    return {};
  }
  if (!isRecord(value) || !["@type", "@id", "url", "name", "datePublished", "uploadDate"].every((key) => stringField(value[key]))) {
    return null;
  }
  return value;
}

function jsonLdRows(text) {
  let value;
  try {
    value = JSON.parse(text);
  } catch (error) {
    return null;
  }
  const entry = jsonLdEntry(value);
  if (entry === null) {
    return null;
  }
  const graph = entry["@graph"];
  const rows = [];
  if (graph !== undefined && graph !== null) {
    if (!Array.isArray(graph)) {
      return null;
    }
    for (const item of graph) {
      const row = jsonLdEntry(item);
      if (row === null) {
        return null;
      }
      rows.push(row);
    }
  }
  rows.push(entry);
  return rows;
}

function sameSourceHost(address) {
  return sourceAliases.includes(address.hostname.toLowerCase());
}

function sortDetail(body, pageUrl, patch) {
  const expected = parseAddress(pageUrl);
  const trimPath = (path) => path.replace(/\/+$/, "");
  let matched = false;
  for (const block of allMatches(jsonLdPattern, body)) {
    const rows = jsonLdRows(block[1]);
    if (rows === null) {
      continue;
    }
    for (const row of rows) {
      const type = row["@type"] || "";
      if (!["WebPage", "VideoObject", "TVSeries", "Movie"].includes(type)) {
        continue;
      }
      const name = row.name || "";
      const actual = parseAddress(firstNonEmpty(row.url || "", row["@id"] || ""));
      if (!actual || (actual.host !== "" && actual.host.toLowerCase() !== expected.host.toLowerCase() && !sameSourceHost(actual)) || trimPath(actual.path) !== trimPath(expected.path) || name === "") {
        continue;
      }
      matched = true;
      patch.title = name;
      const cover = firstNonEmpty(coverAddress(row.image, pageUrl), coverAddress(row.thumbnailUrl, pageUrl));
      if (cover !== "") {
        patch.cover = cover;
        patch.coverUrl = cover;
      }
      const date = releaseDate(firstNonEmpty(row.uploadDate || "", row.datePublished || ""));
      if (date !== "" && (!patch.onlineDate || type === "VideoObject")) {
        patch.onlineDate = date;
      }
    }
  }
  if (!matched) {
    throw new Error("黄果详情没有返回所请求剧集的元数据");
  }
  if (!patch.cover) {
    for (const match of allMatches(metaTagPattern, body)) {
      if (extractAttr(match[0], "property", "name").toLowerCase() === "og:image") {
        const cover = coverAddress(extractAttr(match[0], "content"), pageUrl);
        if (cover !== "") {
          patch.cover = cover;
          patch.coverUrl = cover;
          break;
        }
      }
    }
  }
  const meta = cleanText(classBlock(body.replace(nonContentPattern, ""), "hg-web-detail__meta"));
  patch.views = normalizeViews(firstMatchText(viewsPattern, meta));
  if (!patch.onlineDate && meta.includes("上线")) {
    patch.onlineDate = releaseDate(firstMatchText(datePattern, meta));
  }
  return patch;
}

function detailMetadata(body, pageUrl, sourceId) {
  let drama = {
    id: host.dramaId(sourceId),
    source: host.source,
    sourceId,
    title: firstNonEmpty(pageTitle(body), "短剧"),
    desc: pageDescription(body),
    tags: pageTags(body),
  };
  try {
    drama = sortDetail(body, pageUrl, Object.assign({}, drama));
  } catch (error) {
    drama = Object.assign({}, drama);
  }
  drama.name = drama.title;
  drama.intro = drama.desc;
  const meta = cleanText(classBlock(body.replace(nonContentPattern, ""), "hg-web-detail__meta"));
  drama.releaseStatus = releaseStatusFromRemark(meta);
  if (drama.releaseStatus === "unknown" && !sourceId.startsWith("video/")) {
    const header = body.match(detailMetaPattern);
    if (header) {
      drama.releaseStatus = releaseStatusFromRemark(cleanText(header[1]));
    }
  }
  return drama;
}

function displayTitle(drama) {
  if ((drama.title || "").trim() !== "") {
    return drama.title;
  }
  if ((drama.name || "").trim() !== "") {
    return drama.name;
  }
  return "短剧";
}

function parseCards(raw, pageUrl) {
  let blocks = allMatches(videoCardPattern, raw).map((match) => match[0]);
  if (blocks.length === 0) {
    // 搜索页 / 分类页的卡片不带 video-card class，只要求「article 里有一个
    // 剧集链接」就算一张卡；以前这里还要求包含 video-card 字样，结果搜索页
    // 一条都解析不出来，搜索看起来「没有结果」。
    blocks = allMatches(anyArticlePattern, raw)
      .map((match) => match[0])
      .filter((block) => linkPattern.test(block));
  }
  if (blocks.length === 0) {
    // 连 article 都没有时，退到直接用剧集链接当块，标题仍可取自链接内部。
    blocks = allMatches(linkPatternAll, raw).map((match) => match[0]);
  }
  const seen = new Set();
  const items = [];
  for (const block of blocks) {
    const link = block.match(linkPattern);
    if (!link) {
      continue;
    }
    const sourceId = videoSourceId(link[1]);
    if (sourceId === "" || seen.has(sourceId)) {
      continue;
    }
    seen.add(sourceId);
    const title = firstNonEmpty(extractAttr(block, "title", "alt", "aria-label"), cleanText(block));
    const cover = resolveUrl(pageUrl, extractAttr(block, "data-src", "data-original", "src"));
    const category = sourceId.startsWith("series/") ? "series" : "video";
    const description = firstNonEmpty(extractAttr(block, "data-description", "description"), pageDescription(block));
    let status = "";
    if (category === "series") {
      const meta = block.match(cardMetaPattern);
      if (meta) {
        status = releaseStatusFromRemark(cleanText(meta[1]));
      }
    }
    // 会员剧：站点在封面右上角插了一个 <span class="hg-card-tag hg-card-tag--vip">会员</span>。
    // 以前没解析，卡片上看不出哪部要会员，点进去才被拦。
    const vip = /hg-card-tag--vip/.test(block);
    const remark = firstNonEmpty(classText(block, "bg-black/55"), classText(block, "text-gold-dim"));
    // 卡片角标「更新至第 11 集」里本来就写着集数，以前只当文案用，
    // 列表条目的集数一直是 0 —— 顶栏「今日更新」只有在原有剧集数变大时
    // 才算增量，列表不给集数就永远是 0 集。
    const episodes = episodeIndex(remark, 0);
    items.push({
      id: host.dramaId(sourceId),
      source: host.source,
      sourceId,
      title,
      name: title,
      desc: description,
      intro: description,
      cover,
      coverUrl: cover,
      categoryName: category,
      channelName: channel,
      remark,
      releaseStatus: status,
      ...(vip ? { vip: true } : {}),
      ...(episodes > 0 ? { episodeCount: episodes, totalEpisode: episodes } : {}),
    });
  }
  return items;
}

function nextUnusedIndex(preferred, used) {
  if (preferred <= 0) {
    preferred = 1;
  }
  if (!used.has(preferred)) {
    return preferred;
  }
  for (let index = 1; ; index++) {
    if (!used.has(index)) {
      return index;
    }
  }
}

function parseEpisodes(raw, pageUrl) {
  let blocks = allMatches(videoCardPattern, raw).map((match) => match[0]);
  if (blocks.length === 0) {
    blocks = allMatches(linkPatternAll, raw).map((match) => match[0]);
  }
  const positions = new Map();
  const episodes = [];
  let numbered = false;
  for (const block of blocks) {
    const link = block.match(linkPattern);
    if (!link) {
      continue;
    }
    const key = videoSourceId(link[1]);
    if (key === "" || !key.startsWith("video/")) {
      continue;
    }
    const fullUrl = resolveUrl(pageUrl, link[1]);
    const title = firstNonEmpty(extractAttr(block, "title"), extractAttr(block, "alt"), cleanText(block));
    const index = episodeIndex(cleanText(block), episodeIndex(title, 0));
    numbered = numbered || index > 0;
    // 会员集：`<a class="series-ep-chip ... has-vip">`，里面还有一段「VIP」角标。
    // 只标这两种标记里的集，免费集不加。
    const vip = /has-vip|is-vip/.test(block);
    const episode = {
      key,
      title,
      url: fullUrl,
      index,
      hls: dataHls(block, pageUrl),
      ...(vip ? { vip: true } : {}),
    };
    if (positions.has(fullUrl)) {
      const position = positions.get(fullUrl);
      if (episodes[position].index <= 0 && index > 0) {
        episodes[position] = episode;
      }
    } else {
      positions.set(fullUrl, episodes.length);
      episodes.push(episode);
    }
  }
  const result = [];
  const used = new Set();
  for (const episode of episodes) {
    if (numbered && episode.index <= 0) {
      continue;
    }
    episode.index = nextUnusedIndex(episode.index, used);
    used.add(episode.index);
    result.push(episode);
  }
  return result
    .map((episode, position) => ({ episode, position }))
    .sort((left, right) => left.episode.index - right.episode.index || (left.episode.key < right.episode.key ? -1 : left.episode.key > right.episode.key ? 1 : left.position - right.position))
    .map((entry) => entry.episode);
}

function sortChapters(chapters) {
  return chapters
    .map((chapter, position) => ({ chapter, position }))
    .sort((left, right) => left.chapter.currentEpisode - right.chapter.currentEpisode || (left.chapter.id < right.chapter.id ? -1 : left.chapter.id > right.chapter.id ? 1 : left.position - right.position))
    .map((entry) => entry.chapter);
}

function uniqueChapters(chapters) {
  const seen = new Set();
  return chapters.filter((chapter, index) => {
    const key = chapter.id || chapter.videoUrl || "idx_" + index;
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
}

function fetchDetail(sourceId) {
  sourceId = sourceId.trim().replace(/^\/+|\/+$/g, "");
  if (sourceId === "") {
    throw new Error("empty huangguo-video sourceID");
  }
  let detailPath = sourceId;
  if (!detailPath.startsWith("series/") && !detailPath.startsWith("video/")) {
    detailPath = "series/" + detailPath;
  }
  const detailUrl = siteBaseUrl + "/" + detailPath;
  const body = fetchText(detailUrl, siteBaseUrl + "/");
  const drama = detailMetadata(body, detailUrl, sourceId);
  const title = displayTitle(drama);
  let episodes = [];
  if (detailPath.startsWith("video/")) {
    const hls = dataHls(body, detailUrl);
    if (hls !== "") {
      episodes = [{ key: "1", title, url: detailUrl, index: 1, hls }];
    }
  } else {
    episodes = parseEpisodes(body, detailUrl);
  }
  if (episodes.length === 0) {
    const hls = dataHls(body, detailUrl);
    if (hls !== "") {
      episodes = [{ key: "1", title, url: detailUrl, index: 1, hls }];
    }
  }
  const chapters = [];
  for (const episode of episodes) {
    const index = episode.index > 0 ? episode.index : chapters.length + 1;
    chapters.push({
      id: host.chapterId(sourceId, episode.key || String(index)),
      source: host.source,
      title: episode.title.trim() || "第" + index + "集",
      videoUrl: episode.hls,
      pageUrl: episode.url,
      currentEpisode: index,
      // 会员集要带到界面上打「VIP」，原来在这里被裁掉了。
      ...(episode.vip ? { vip: true } : {}),
    });
  }
  return { drama, chapters: uniqueChapters(sortChapters(chapters)) };
}

function previewTokenValid(token) {
  return token.length <= 4096 && !/[\r\n\t ]/.test(token);
}

function optionalInteger(value) {
  return value === undefined || value === null || Number.isInteger(value);
}

function fetchPreviewToken(siteOrigin, referer) {
  const failure = new Error("黄果视频未返回有效播放凭证，请稍后重试");
  const headers = {
    "User-Agent": userAgent,
    Referer: referer,
    Accept: "application/json",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Dest": "empty",
  };
  const page = parseAddress(referer);
  if (page && page.host !== "") {
    headers.Origin = page.scheme + "://" + page.host;
  }
  const response = host.fetch({ method: "GET", url: siteOrigin + "/api/preview-token", headers, limit: 16 << 10, timeoutMs: 12000, followRedirects: true });
  let result;
  try {
    result = JSON.parse(response.body);
  } catch (error) {
    throw failure;
  }
  if (result === null) {
    result = {};
  }
  if (
    response.status !== 200 ||
    !isRecord(result) ||
    !(result.ok === undefined || result.ok === null || typeof result.ok === "boolean") ||
    !stringField(result.token) ||
    !optionalInteger(result.expires_at) ||
    !optionalInteger(result.expires_in) ||
    result.ok !== true ||
    !result.token ||
    !previewTokenValid(result.token)
  ) {
    throw failure;
  }
  const now = Date.now();
  let expires = now + Math.max(30, Math.min(result.expires_in || 0, 1800)) * 1000;
  if (result.expires_at > 0) {
    expires = result.expires_at * 1000;
  }
  if (expires <= now) {
    throw new Error("黄果视频返回的播放凭证已过期，请重试；反复出现时请检查设备时间");
  }
  return { token: result.token, expires };
}

function cachedToken(siteOrigin) {
  const cached = host.cacheGet("preview:" + siteOrigin);
  if (cached === null) {
    return null;
  }
  const session = JSON.parse(cached);
  return Date.now() + 15000 < session.expires ? session : null;
}

function addressOrigin(address) {
  const parsed = parseAddress(address);
  return parsed.scheme + "://" + parsed.host;
}


function fetchCatalog(address) {
  const items = parseCards(fetchText(address, siteBaseUrl + "/"), address);
  return { items, hasMore: items.length >= 20 };
}

// 列表页页眉写着「共 2056 部已发布作品 · 按分类探索」，这就是整个目录从第一页
// 到最后一页的作品数。站点是无限流，HTML 里不渲染翻页链接，别处拿不到这个数；
// 分类页那一行是分类自己的量，顶栏统计的是站源整体，所以只认不带分类的那页。
const catalogTotalPattern = /共\s*([\d,]+)\s*部\s*已发布作品/;
const catalogTotalBackup = /共\s*([\d,]+)\s*部/;

function catalogTotal(body) {
  const text = String(body || "").replace(/<[^>]*>/g, " ");
  const match = catalogTotalPattern.exec(text) || catalogTotalBackup.exec(text);
  if (!match) {
    return 0;
  }
  const value = parseInt(String(match[1]).replace(/,/g, ""), 10);
  return Number.isInteger(value) && value > 0 && value < 1000000 ? value : 0;
}
// 搜索结果补简介。
//
// 搜索页的卡片只有标题（简介在详情页的 meta description 里）。缺简介时 native
// 判不到「仅简介命中」这一档，这些条目会被当成无关丢掉。这里对「标题和标签
// 都没命中」的条目按需补一次简介，按 id 缓存 7 天。
const INTRO_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const INTRO_PAGE_BUDGET = 12;
const INTRO_PAGE_BUDGET_MS = 4000;
// 第二页往后每页少补一点：只补第一页的话，用户往下翻到的那些「只有简介
// 沾边」的作品会被 native 当无关丢掉，看起来就是搜不全。
const INTRO_LATER_BUDGET = 6;
const INTRO_LATER_BUDGET_MS = 2500;

function introUnknown(drama, keyword, words) {
  const title = String(drama.title || drama.name || "").toLowerCase();
  if (title.includes(keyword)) return false;
  for (const word of words) {
    if (title.includes(word)) return false;
  }
  const meta = [String(drama.categoryName || drama.category || ""), ...(drama.tags || [])];
  for (const raw of meta) {
    const value = String(raw || "").toLowerCase();
    if (value === "") continue;
    if (value.includes(keyword)) return false;
    for (const word of words) {
      if (value.includes(word)) return false;
    }
  }
  return true;
}

function attachIntros(items, keyword, page) {
  // 首屏补得多一点，后面几页补得少一点：只补第一页的话，用户往下翻到的
  // 那些「只有简介沾边」的作品会被 native 当无关丢掉，看起来就是搜不全。
  const budget = page === 1 ? INTRO_PAGE_BUDGET : INTRO_LATER_BUDGET;
  const budgetMs = page === 1 ? INTRO_PAGE_BUDGET_MS : INTRO_LATER_BUDGET_MS;
  const lowered = String(keyword || "").toLowerCase().trim();
  if (lowered === "") return;
  const words = lowered.split(/\s+/).filter((word) => word !== "");
  const started = Date.now();
  let filled = 0;
  for (const drama of items) {
    if (filled >= budget || Date.now() - started > budgetMs) return;
    if (drama.desc || drama.intro) continue;
    if (!introUnknown(drama, lowered, words)) continue;
    const id = String(drama.sourceId || "");
    if (id === "") continue;
    let cached = null;
    try {
      cached = host.cacheGet("intro:" + id);
    } catch (error) {
      cached = null;
    }
    if (cached !== null && cached !== "") {
      drama.desc = cached;
      drama.intro = cached;
      continue;
    }
    let intro = "";
    try {
      intro = fetchIntro(id);
    } catch (error) {
      intro = "";
    }
    if (intro === "") continue;
    drama.desc = intro;
    drama.intro = intro;
    try {
      host.cacheSet("intro:" + id, intro, INTRO_TTL_MS);
    } catch (error) {}
    filled++;
  }
}

function fetchIntro(sourceId) {
  let path = String(sourceId || "").trim().replace(/^\/+|\/+$/g, "");
  if (path === "") return "";
  if (!path.startsWith("series/") && !path.startsWith("video/")) {
    path = "series/" + path;
  }
  const url = siteBaseUrl + "/" + path;
  const body = fetchText(url, siteBaseUrl + "/");
  const drama = detailMetadata(body, url, sourceId);
  return truncate(String(drama.desc || drama.intro || ""), 4000);
}

module.exports = {
  validCategory,

  categories() {
    const body = fetchText(siteBaseUrl + "/videos", siteBaseUrl + "/");
    const categories = [];
    const seen = new Set();
    for (const match of allMatches(anchorPattern, body)) {
      const href = htmlUnescape(extractAttr("<a " + match[1] + ">", "href"));
      const address = parseAddress(href);
      if (!address || (address.path !== "" && address.path.replace(/\/+$/, "") !== "/videos")) {
        continue;
      }
      const id = queryValue(address.query, "category");
      const name = htmlUnescape(match[2].replace(/<[^>]*>/g, "")).trim();
      if (id === "" || id.length > 128 || /[|/\\\u0000\r\n]/.test(id) || !validCategory(id) || seen.has(id) || name === "" || Array.from(name).length > 24) {
        continue;
      }
      seen.add(id);
      categories.push({ id, name });
    }
    return categories;
  },

  catalogPage(page, category) {
    let address = siteBaseUrl + "/videos?page=" + page;
    if (category !== "") {
      address += "&category=" + queryEscape(category);
    }
    const body = fetchText(address, siteBaseUrl + "/");
    const items = parseCards(body, address);
    const result = { items, hasMore: items.length >= 20 };
    if (category === "") {
      const total = catalogTotal(body);
      if (total > 0) {
        result.total = total;
      }
    }
    return result;
  },

  // 搜索页是服务端渲染的 /search?q=，卡片结构跟列表页不同（靠 parseCards 的
  // 兜底分支解析），一页 24 条。翻页参数是 content_page（page/p/size 都被忽略，
  // 之前按 page 试过就得出「站点只给第一页」的错误结论，导致搜「妈妈」只出
  // 24 部、站内其实有 54 部）。
  search(page, query) {
    const keyword = String(query === null || query === undefined ? "" : query).trim();
    if (keyword === "" || Array.from(keyword).length > 64) {
      throw new Error("黄果搜索关键词无效");
    }
    const index = Number(page) >= 1 ? Math.floor(Number(page)) : 1;
    // 站点搜索页明确写着「至少需要 2 个字符」，单字（搜「妈」「婚」）一律返回空。
    // 这时改为在本地目录里筛：目录页本身能出这些作品，只是站内搜索不给搜。
    if (Array.from(keyword).length < 2) {
      const key = "single-char:" + keyword;
      let all = null;
      const cached = host.cacheGet(key);
      if (cached !== null) {
        try { all = JSON.parse(cached); } catch (error) { all = null; }
      }
      if (all === null) {
        all = [];
        const seen = new Set();
        for (let p = 1; p <= 30; p++) {
          let pageAddress = siteBaseUrl + "/videos?page=" + p;
          const part = fetchCatalog(pageAddress);
          for (const item of part.items) {
            const id = item.id || item.sourceId;
            if (seen.has(id)) continue;
            seen.add(id);
            const hay = [item.title, item.description, item.intro, (item.tags || []).join(" ")]
              .filter((v) => typeof v === "string")
              .join(" ").replace(/[\s,，。.、\-_/\\]/g, "");
            if (hay.indexOf(keyword) >= 0) all.push(item);
          }
          if (!part.hasMore) break;
        }
        try { host.cacheSet(key, JSON.stringify(all), 30 * 60 * 1000); } catch (error) {}
      }
      const start = (index - 1) * 24;
      if (start >= all.length) return { items: [], hasMore: false };
      const end = Math.min(start + 24, all.length);
      const page = all.slice(start, end);
      attachIntros(page, keyword, index);
      return { items: page, hasMore: end < all.length };
    }
    let address = siteBaseUrl + "/search?q=" + queryEscape(keyword);
    if (index > 1) {
      address += "&content_page=" + index;
    }
    const raw = fetchText(address, siteBaseUrl + "/");
    const items = parseCards(raw, address);
    // 站点不在这页 HTML 里渲染翻页链接（找 content_page=N 永远找不到），
    // 但它认这个参数：实测「妈妈」第 1/2 页各 24 条、第 3 页 6 条，共 54 部。
    // 所以改成按「这一页是否够满」判断还有没有下一页，末页不满就收尾。
    attachIntros(items, keyword, index);
    return { items, hasMore: items.length >= 12 };
  },

  detail(sourceId) {
    return fetchDetail(sourceId);
  },

  resolveMedia(task) {
    let chapter = task.chapter;
    if (!chapter.pageUrl) {
      const dramaId = task.dramaId.trim();
      const separator = dramaId.indexOf(":");
      const sourceId = separator < 0 ? "" : dramaId.slice(separator + 1).trim();
      if (separator >= 0 && sourceId !== "" && dramaId.slice(0, separator).trim().toLowerCase() === host.source) {
        let chapters;
        try {
          chapters = fetchDetail(sourceId).chapters;
        } catch (error) {
          throw new Error("刷新旧任务播放地址失败: " + error.message);
        }
        const fresh = chapters.find((item) => item.id === chapter.id);
        if (!fresh) {
          throw new Error("原章节已变化，请更新该合集后重新下载");
        }
        chapter = fresh;
      }
    }
    const media = { url: chapter.videoUrl, referer: firstNonEmpty(chapter.referer || "", siteBaseUrl + "/") };
    if (chapter.pageUrl) {
      const response = host.fetchText({ url: chapter.pageUrl, referer: media.referer });
      media.url = dataHls(response.body, response.url);
      media.referer = response.url;
    }
    return host.finishMedia(media);
  },

  coverAddress(drama, sourceId) {
    let parts = sourceId.split("/");
    if (parts.length === 1) {
      parts = ["series", sourceId];
    }
    if (parts.length !== 2 || (parts[0] !== "series" && parts[0] !== "video") || !sourceIdPattern.test(parts[1])) {
      throw new Error("无效的黄果剧集 ID");
    }
    const pageUrl = siteBaseUrl + "/" + parts[0] + "/" + encodeURIComponent(parts[1]);
    const body = fetchText(pageUrl, siteBaseUrl + "/");
    return sortDetail(body, pageUrl, { id: drama.id, source: host.source, sourceId }).cover || "";
  },

  mediaAuthorization(address, referer) {
    const siteOrigin = addressOrigin(address);
    let session = cachedToken(siteOrigin);
    if (session === null) {
      session = host.exclusive(() => {
        const current = cachedToken(siteOrigin);
        if (current !== null) {
          return current;
        }
        const fresh = fetchPreviewToken(siteOrigin, referer);
        host.cacheSet("preview:" + siteOrigin, JSON.stringify(fresh), 0);
        return fresh;
      });
    }
    return { header: "X-Preview-Token", value: session.token };
  },

  rejectMediaAuthorization(address, value) {
    const key = "preview:" + addressOrigin(address);
    const cached = host.cacheGet(key);
    if (cached !== null && JSON.parse(cached).token === value) {
      host.cacheSet(key, null, 0);
    }
  },
};
