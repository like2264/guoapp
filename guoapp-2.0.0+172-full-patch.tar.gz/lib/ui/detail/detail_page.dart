import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../drama_details.dart';
import '../../episode_durations.dart';
import '../../local_store.dart';
import '../../models.dart';
import '../app_scope.dart';
import '../downloads/download_picker_page.dart';
import '../player/playback_handle.dart';
import '../player/playback_page.dart';
import '../shell/app_shell.dart';
import '../widgets/cover_backdrop.dart';
import '../widgets/cover_image.dart';
import '../theme/glass.dart';
import '../widgets/focus_ring.dart';
import '../widgets/follow_button.dart';
import '../theme/motion.dart';
import '../widgets/choice_panel.dart';
import '../widgets/motion/motion_widgets.dart';
import '../widgets/status_view.dart';
import '../widgets/swipe_switch.dart';

class _Metrics {
  const _Metrics({
    required this.cover,
    required this.coverRadius,
    required this.title,
    required this.meta,
    required this.tag,
    required this.note,
    required this.body,
    required this.bodyHeight,
    required this.button,
    required this.buttonText,
    required this.buttonIcon,
    required this.section,
    required this.summary,
    required this.chip,
    required this.chipRadius,
    required this.chipText,
    required this.chipPadding,
    required this.cell,
    required this.cellRadius,
    required this.cellText,
    required this.cellGap,
    this.columns = 0,
    this.cellWidth = 0,
    this.vipBadge = false,
    this.follow = 40,
  });
  final Size cover;
  final double coverRadius;
  final double title;
  final double meta;
  final double tag;
  final double note;
  final double body;
  final double bodyHeight;
  final double button;
  final double buttonText;
  final double buttonIcon;
  final double section;
  final double summary;
  final double chip;
  final double chipRadius;
  final double chipText;
  final double chipPadding;
  final double cell;
  final double cellRadius;
  final double cellText;
  final double cellGap;
  final int columns;
  final double cellWidth;
  final bool vipBadge;
  final double follow;

  int columnsFor(double width) => columns > 0
      ? columns
      : math.max(4, ((width + cellGap) / (cellWidth + cellGap)).floor());
}

const _phone = _Metrics(
  cover: Size(120, 180),
  coverRadius: 12,
  title: 22,
  meta: 13,
  tag: 12,
  note: 12,
  body: 14,
  bodyHeight: 1.6,
  button: 52,
  buttonText: 16,
  buttonIcon: 24,
  section: 17,
  summary: 13,
  chip: 32,
  chipRadius: 8,
  chipText: 13,
  chipPadding: 14,
  cell: 54,
  cellRadius: 12,
  cellText: 16,
  cellGap: 10,
  columns: 5,
);

const _desktop = _Metrics(
  cover: Size(160, 240),
  coverRadius: 14,
  title: 28,
  meta: 14,
  tag: 12,
  note: 13,
  body: 14,
  bodyHeight: 1.7,
  button: 48,
  buttonText: 15,
  buttonIcon: 22,
  section: 18,
  summary: 13,
  chip: 32,
  chipRadius: 8,
  chipText: 13,
  chipPadding: 14,
  cell: 52,
  cellRadius: 12,
  cellText: 16,
  cellGap: 10,
  cellWidth: 72,
);

const _pad = _Metrics(
  cover: Size(150, 225),
  coverRadius: 14,
  title: 24,
  meta: 14,
  tag: 13,
  note: 13,
  body: 15,
  bodyHeight: 1.6,
  button: 56,
  buttonText: 16,
  buttonIcon: 24,
  section: 18,
  summary: 13,
  chip: 40,
  chipRadius: 10,
  chipText: 14,
  chipPadding: 16,
  cell: 56,
  cellRadius: 12,
  cellText: 17,
  cellGap: 12,
  cellWidth: 76,
  follow: 44,
);

const _television = _Metrics(
  cover: Size(140, 210),
  coverRadius: 12,
  title: 28,
  meta: 16,
  tag: 14,
  note: 15,
  body: 15,
  bodyHeight: 1.65,
  button: 52,
  buttonText: 18,
  buttonIcon: 24,
  section: 20,
  summary: 15,
  chip: 40,
  chipRadius: 12,
  chipText: 16,
  chipPadding: 18,
  cell: 60,
  cellRadius: 12,
  cellText: 20,
  cellGap: 12,
  columns: 6,
  vipBadge: true,
  follow: 52,
);

class DetailPage extends StatefulWidget {
  const DetailPage({
    super.key,
    required this.store,
    required this.drama,
    this.autoplay = false,
  });
  final LocalStore store;
  final Drama drama;
  final bool autoplay;

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  DramaDetails? _details;
  PlaybackHandle? _handle;
  bool _watching = false;
  var _currentEpisode = GlobalKey();
  String _keyedDrama = '';
  bool _expanded = false;
  final _playFocus = FocusNode();
  final _followFocus = FocusNode();
  final _played = <Object>{};
  final _descriptionFocus = FocusNode();
  final _groupFocus = <FocusNode>[];
  final _seasonFocus = <FocusNode>[];
  final _groupKeys = <GlobalKey>[];
  final _episodeFocus = List.generate(episodeGroupSize, (_) => FocusNode());
  bool _entered = false;
  PlaybackHandle? _watched;
  late bool _autoplayPending = widget.autoplay;
  late bool _curtain = widget.autoplay;
  // 选集面板里的「本剧总时长」统计（见 episode_durations.dart）。按剧缓存
  // 实例，切季回来不用重新统计。
  final _durationStats = <String, EpisodeDurations>{};

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _details ??= DramaDetails(
      AppScope.of(context).repository,
      widget.store,
      widget.drama,
    )..addListener(_detailsChanged);
  }

  @override
  void dispose() {
    _handle?.dispose();
    for (final stats in _durationStats.values) {
      stats.dispose();
    }
    _details?.dispose();
    for (final node in [
      _playFocus,
      _followFocus,
      _descriptionFocus,
      ..._groupFocus,
      ..._seasonFocus,
      ..._episodeFocus,
    ]) {
      node.dispose();
    }
    super.dispose();
  }

  bool get _canDownload =>
      AppScope.of(context).repository.supportsDownloads &&
      widget.store.canDownload;

  bool get _ready => !_details!.loading && _details!.episodes.isNotEmpty;

  Future<void> _refresh() async {
    final details = _details!;
    await details.load();
    if (!mounted || details.error == null || details.episodes.isEmpty) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(details.error!)));
  }

  double _startAt(int index, {required bool resume}) {
    final watch = _details!.watch;
    return resume &&
            watch?.episode == _details!.episodes[index].number &&
            !watch!.finished
        ? watch.position
        : 0.0;
  }

  DramaDetail get _detail {
    final details = _details!;
    return DramaDetail(
      details.drama,
      details.episodes,
      warning: details.warning,
      seasons: details.seasons,
    );
  }

  PlaybackHandle _open(
    int index, {
    required double position,
    bool autoplay = true,
  }) => PlaybackHandle(
    repository: AppScope.of(context).repository,
    store: widget.store,
    detail: _detail,
    index: index,
    position: position,
    autoplay: autoplay,
    preopen: widget.store.playbackPreferences.preopens(
      television: AppScope.of(context).television,
    ),
  );

  void _detailsChanged() {
    final seasons = _details!.seasons;
    _handle?.session.syncSeasons(seasons);
    _watched?.session.syncSeasons(seasons);
    _preopen();
    unawaited(_autoplay());
    _syncDurations();
  }

  /// 分集列表变了就让「总时长」统计跟着走：同一份列表不会重复发请求，
  /// 集数增加时只补新的那几集（原生侧按集缓存）。
  void _syncDurations() {
    final details = _details;
    if (details == null || details.episodes.isEmpty) return;
    // sync 会同步回调通知，放到这一帧之后，免得在 build/通知途中再 setState。
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final details = _details;
      if (details == null || details.episodes.isEmpty) return;
      durationsOf(details).sync(details.episodes);
    });
  }

  EpisodeDurations durationsOf(DramaDetails details) =>
      _durationStats.putIfAbsent(
        details.drama.id,
        () => EpisodeDurations(AppScope.of(context).repository, details.drama),
      );

  Future<void> _autoplay() async {
    final details = _details!;
    if (!_autoplayPending || !mounted || details.loading) return;
    _autoplayPending = false;
    if (_ready && details.allowed) {
      await _play(details.resumeIndex, resume: true);
      if (!mounted) return;
    }
    if (_curtain) {
      setState(() => _curtain = false);
    } else if (AppScope.of(context).television &&
        details.currentIndex == null) {
      _playFocus.requestFocus();
    }
  }

  void _liftCurtainAfter(Animation<double> entering) {
    void lift(AnimationStatus status) {
      if (status != AnimationStatus.completed) return;
      entering.removeStatusListener(lift);
      if (!mounted || !_curtain) return;
      _entered = true;
      setState(() => _curtain = false);
    }

    entering.addStatusListener(lift);
    lift(entering.status);
  }

  void _preopen() {
    final details = _details!;
    if (_handle != null ||
        _watching ||
        !mounted ||
        !_ready ||
        !details.allowed) {
      return;
    }
    final index = details.resumeIndex;
    _handle = _open(
      index,
      position: _startAt(index, resume: true),
      autoplay: false,
    );
  }

  Future<void> _play(int index, {bool resume = false}) async {
    final details = _details!;
    final episode = details.episodes[index];
    if (episode.vip &&
        SourceSite.byId(details.drama.source).vipPrompt &&
        await showDialog<bool>(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text('这是一集 VIP 内容'),
                content: const Text('站源可能只提供试看或限制播放。'),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('取消'),
                  ),
                  FilledButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('尝试播放'),
                  ),
                ],
              ),
            ) !=
            true) {
      return;
    }
    if (!mounted || !details.allowed) return;
    final position = _startAt(index, resume: resume);
    final handle = _handle ?? _open(index, position: position);
    _handle = null;
    handle.session.syncSeasons(details.seasons);
    handle.session.start(index, position: position);
    _watching = true;
    _watched = handle;
    final route = MaterialPageRoute<void>(
      builder: (_) => PlaybackPage(store: widget.store, handle: handle),
    );
    final closed = Navigator.of(context, rootNavigator: true).push(route);
    if (_curtain) _liftCurtainAfter(route.animation!);
    await closed;
    _watching = false;
    _watched = null;
    if (!mounted) return;
    final played = handle.session.detail.drama.id;
    if (played != details.drama.id) {
      final season = details.seasons
          .where((season) => season.drama.id == played)
          .firstOrNull;
      if (season != null) await details.selectSeason(season);
      if (!mounted) return;
    }
    if (AppScope.of(context).television) _focusWatched(details);
  }

  void _focusWatched(DramaDetails details) {
    final index = details.currentIndex;
    if (index == null) return;
    details.selectGroup(index ~/ episodeGroupSize);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _episodeFocus[index % episodeGroupSize].requestFocus();
    });
  }

  void _download() => openPage<void>(
    context,
    (_) => DownloadPickerPage(store: widget.store, detail: _detail),
  );

  void _locate(int index) {
    _details!.selectGroup(index ~/ episodeGroupSize);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final target = _currentEpisode.currentContext;
      if (target == null || !target.mounted) return;
      Scrollable.ensureVisible(
        target,
        alignment: 0.3,
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: _details!,
    builder: (context, _) {
      final details = _details!;
      _renewKeys(details.drama.id);
      if (!details.allowed) {
        return Scaffold(
          appBar: AppBar(),
          body: const StatusView(
            title: '当前用户无权访问',
            message: '请返回剧库后重新选择。',
            icon: Icons.lock_outline_rounded,
          ),
        );
      }
      if (_curtain) {
        return const Scaffold(
          backgroundColor: Colors.black,
          body: Center(child: CircularProgressIndicator()),
        );
      }
      final form = AppScope.formFactorOf(context);
      if (form == FormFactor.television) return _televisionPage(details);
      if (form == FormFactor.phone || MediaQuery.sizeOf(context).width < 840) {
        return _phonePage(details);
      }
      return _widePage(details, desktop: form == FormFactor.window);
    },
  );

  PreferredSizeWidget _appBar(DramaDetails details, double height) {
    final colors = Theme.of(context).colorScheme;
    return AppBar(
      toolbarHeight: height,
      backgroundColor: WidgetStateColor.resolveWith(
        (states) => states.contains(WidgetState.scrolledUnder)
            ? colors.surfaceContainer
            : Colors.transparent,
      ),
      actions: [
        if (details.drama.webUrl.isNotEmpty)
          IconButton(
            tooltip: '在浏览器中打开',
            onPressed: () => _openWebsite(details.drama.webUrl),
            icon: const Icon(Icons.open_in_new_rounded),
          ),
        IconButton(
          tooltip: '更新剧集信息',
          onPressed: details.loading ? null : _refresh,
          icon: const Icon(Icons.refresh_rounded),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  /// 跳到站源网页版的详情页。
  ///
  /// 站源没有网页详情页（webUrl 为空）时按钮不显示；
  /// 打开失败就退回剪贴板，至少能把地址带走。
  Future<void> _openWebsite(String url) async {
    final opened = await launchUrl(
      Uri.parse(url),
      mode: LaunchMode.externalApplication,
    ).catchError((_) => false);
    if (opened || !mounted) return;
    await Clipboard.setData(ClipboardData(text: url));
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('无法打开浏览器，链接已复制')));
  }

  bool get _liquidGlass => AppScope.of(context).liquidGlass;

  /// Liquid Glass 打开时给内容套一层玻璃；关掉时原样返回，现有外观不变。
  Widget _glass(
    Widget child, {
    EdgeInsetsGeometry padding = const EdgeInsets.all(16),
    double radius = 28,
    double tint = 1,
    double blur = 22,
    bool border = true,
  }) {
    if (!_liquidGlass) return child;
    return GlassPanel(
      padding: padding,
      radius: radius,
      tint: tint,
      blur: blur,
      border: border,
      child: child,
    );
  }

  Widget _withBackdrop(Drama drama, double height, Widget child) {
    final theme = Theme.of(context);
    final surface = theme.colorScheme.surface;
    return Stack(
      children: [
        Positioned(
          left: 0,
          right: 0,
          top: 0,
          height: height,
          child: CoverBackdrop(
            drama: drama,
            sigma: 36,
            opacity: theme.brightness == Brightness.dark ? 0.55 : 0.45,
            overlay: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: const [0, 0.92],
              colors: [surface.withValues(alpha: 0), surface],
            ),
          ),
        ),
        child,
      ],
    );
  }

  Widget _enter(int index, Widget child) => EnterOnce(
    id: 'section-$index',
    played: _played,
    index: index,
    child: child,
  );

  Widget _phonePage(DramaDetails details) {
    const m = _phone;
    final top = MediaQuery.paddingOf(context).top + kToolbarHeight;
    final drama = details.drama;
    final glass = _liquidGlass;
    final actions = Row(
      spacing: 12,
      children: [
        if (_canDownload)
          FocusRing(
            radius: m.button / 2,
            child: IconButton.filledTonal(
              tooltip: '下载选集',
              onPressed: _ready ? _download : null,
              style: IconButton.styleFrom(minimumSize: Size.square(m.button)),
              icon: const Icon(Icons.download_rounded),
            ),
          ),
        Expanded(child: _playButton(details, m)),
      ],
    );
    return Scaffold(
      extendBodyBehindAppBar: true,
      extendBody: glass,
      appBar: _appBar(details, kToolbarHeight),
      body: RefreshIndicator(
        edgeOffset: top,
        onRefresh: _refresh,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: _withBackdrop(
                drama,
                top + 250,
                Padding(
                  padding: EdgeInsets.fromLTRB(
                    glass ? 12 : 20,
                    top + 4,
                    glass ? 12 : 20,
                    0,
                  ),
                  child: _glass(
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          spacing: 16,
                          children: [
                            _cover(drama, m),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(top: 6),
                                child: _enter(
                                  0,
                                  _followingHeadline(details, m, 6),
                                ),
                              ),
                            ),
                          ],
                        ),
                        if (_stats(drama, m) case final stats?)
                          Padding(
                            padding: const EdgeInsets.only(top: 14),
                            child: _enter(1, stats),
                          ),
                        if (_tags(drama, m) case final tags?)
                          Padding(
                            padding: const EdgeInsets.only(top: 10),
                            child: _enter(2, tags),
                          ),
                        if (drama.description.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 12),
                            child: _enter(3, _description(drama, m)),
                          ),
                        if (details.warning.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: _warning(details.warning, m),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            if (details.seasons.isNotEmpty)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
                  child: _seasonRow(details, m),
                ),
              ),
            if (details.episodes.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: _episodeStatus(details),
              )
            else
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(
                    glass ? 12 : 0,
                    8,
                    glass ? 12 : 0,
                    // 玻璃播放条是浮在正文上的（extendBody），底部要把它整条
                    // 高度让出来，否则最后一行选集被「立即播放」压住半截。
                    glass
                        ? 24 +
                              m.button +
                              24 +
                              MediaQuery.viewPaddingOf(context).bottom
                        : 24,
                  ),
                  child: _glass(
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Padding(
                          padding: EdgeInsets.fromLTRB(
                            glass ? 0 : 20,
                            0,
                            glass ? 0 : 8,
                            0,
                          ),
                          child: _episodeHeader(details, m),
                        ),
                        if (details.groupCount > 1)
                          Padding(
                            padding: EdgeInsets.fromLTRB(
                              glass ? 0 : 20,
                              2,
                              glass ? 0 : 20,
                              0,
                            ),
                            child: SizedBox(
                              height: m.chip + 2,
                              child: ListView.separated(
                                scrollDirection: Axis.horizontal,
                                padding: EdgeInsets.zero,
                                itemCount: details.groupCount,
                                separatorBuilder: (_, _) =>
                                    const SizedBox(width: 8),
                                itemBuilder: (context, group) =>
                                    _groupChip(details, m, group),
                              ),
                            ),
                          ),
                        Padding(
                          padding: EdgeInsets.fromLTRB(
                            glass ? 0 : 20,
                            12,
                            glass ? 0 : 20,
                            0,
                          ),
                          child: _swipeGroups(details, m),
                        ),
                      ],
                    ),
                    padding: EdgeInsets.fromLTRB(
                      glass ? 16 : 0,
                      glass ? 14 : 0,
                      glass ? 16 : 0,
                      glass ? 14 : 0,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
      bottomNavigationBar: glass
          ? SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
                child: GlassPanel(
                  radius: 28,
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  child: actions,
                ),
              ),
            )
          : Material(
              color: Theme.of(context).colorScheme.surfaceContainerLow,
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
                  child: actions,
                ),
              ),
            ),
    );
  }

  Widget _widePage(DramaDetails details, {required bool desktop}) {
    final m = desktop ? _desktop : _pad;
    final top = MediaQuery.paddingOf(context).top + 64;
    final inset = desktop ? 32.0 : 24.0;
    final gap = desktop ? 40.0 : 32.0;
    final side = desktop ? 420.0 : 380.0;
    final drama = details.drama;
    final info = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          spacing: desktop ? 20 : 18,
          children: [
            _cover(drama, m),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 4),
                child: _enter(0, _followingHeadline(details, m, 4)),
              ),
            ),
          ],
        ),
        if (_stats(drama, m) case final stats?)
          Padding(
            padding: EdgeInsets.only(top: desktop ? 18 : 16),
            child: _enter(1, stats),
          ),
        if (_tags(drama, m) case final tags?)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: _enter(2, tags),
          ),
        Padding(
          padding: EdgeInsets.only(top: desktop ? 22 : 20),
          child: Row(
            spacing: 12,
            children: [
              Expanded(child: _playButton(details, m)),
              if (_canDownload) _downloadButton(m),
            ],
          ),
        ),
        if (drama.description.isNotEmpty)
          Padding(
            padding: EdgeInsets.only(top: desktop ? 22 : 20),
            child: _enter(3, _description(drama, m)),
          ),
        if (details.warning.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: _warning(details.warning, m),
          ),
      ],
    );
    final episodeList = details.episodes.isEmpty
        ? SizedBox(
            key: const ValueKey('status'),
            height: 320,
            child: _episodeStatus(details),
          )
        : _glass(
            Column(
              key: const ValueKey('episodes'),
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(
                  height: desktop ? 44 : 48,
                  child: _episodeHeader(details, m),
                ),
                if (details.groupCount > 1)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (var group = 0; group < details.groupCount; group++)
                          _groupChip(details, m, group),
                      ],
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.only(top: 14),
                  child: desktop ? _grid(details, m) : _swipeGroups(details, m),
                ),
              ],
            ),
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
          );
    final episodes = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (details.seasons.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: _seasonRow(details, m),
          ),
        FadeSwitcher(alignment: Alignment.topCenter, child: episodeList),
      ],
    );
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: _appBar(details, 64),
      body: SingleChildScrollView(
        child: _withBackdrop(
          drama,
          top + 336,
          Padding(
            padding: EdgeInsets.fromLTRB(inset, top + 4, inset, 40),
            child: LayoutBuilder(
              builder: (context, constraints) =>
                  constraints.maxWidth >= side + gap + 480
                  ? Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      spacing: gap,
                      children: [
                        SizedBox(width: side, child: info),
                        Expanded(child: episodes),
                      ],
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      spacing: gap,
                      children: [info, episodes],
                    ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _televisionPage(DramaDetails details) {
    const m = _television;
    if (_ready && !_entered) {
      _entered = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _playFocus.requestFocus();
      });
    }
    while (_groupFocus.length < details.groupCount) {
      _groupFocus.add(FocusNode());
    }
    while (_seasonFocus.length < details.seasons.length) {
      _seasonFocus.add(FocusNode());
    }
    const focusBleed = 12.0;
    final page = Scaffold(
      body: _withBackdrop(
        details.drama,
        340,
        Padding(
          padding: const EdgeInsets.fromLTRB(
            televisionInset,
            40,
            televisionInset - focusBleed,
            27,
          ),
          child: Focus(
            canRequestFocus: false,
            skipTraversal: true,
            onKeyEvent: (_, event) => _televisionKey(details, m, event),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              spacing: 40 - focusBleed,
              children: [
                SizedBox(width: 380, child: _televisionInfo(details, m)),
                Expanded(
                  child: details.seasons.isEmpty
                      ? Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: focusBleed,
                          ),
                          child: FadeSwitcher(
                            alignment: Alignment.topCenter,
                            child: _televisionEpisodes(details, m),
                          ),
                        )
                      : SingleChildScrollView(
                          padding: const EdgeInsets.symmetric(
                            horizontal: focusBleed,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(bottom: 10),
                                child: _seasonRow(details, m),
                              ),
                              FadeSwitcher(
                                alignment: Alignment.topCenter,
                                child: _televisionEpisodes(details, m),
                              ),
                            ],
                          ),
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    return ListenableBuilder(
      listenable: _playFocus,
      builder: (context, child) => PopScope(
        canPop: !_ready || _playFocus.hasFocus,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) _playFocus.requestFocus();
        },
        child: child!,
      ),
      child: page,
    );
  }

  KeyEventResult _televisionKey(
    DramaDetails details,
    _Metrics m,
    KeyEvent event,
  ) {
    final node = FocusManager.instance.primaryFocus;
    final key = event.logicalKey;
    if (event is KeyUpEvent ||
        node == null ||
        !{
          LogicalKeyboardKey.arrowUp,
          LogicalKeyboardKey.arrowDown,
          LogicalKeyboardKey.arrowLeft,
          LogicalKeyboardKey.arrowRight,
        }.contains(key)) {
      return KeyEventResult.ignored;
    }
    final group = _groupFocus.indexOf(node);
    final season = _seasonFocus.indexOf(node);
    final episode = _episodeFocus.indexOf(node);
    if (season >= 0) {
      if (key == LogicalKeyboardKey.arrowLeft) {
        season == 0
            ? _playFocus.requestFocus()
            : revealFocus(_seasonFocus[season - 1]);
      } else if (key == LogicalKeyboardKey.arrowRight &&
          season + 1 < details.seasons.length) {
        revealFocus(_seasonFocus[season + 1]);
      } else if (key == LogicalKeyboardKey.arrowDown) {
        if (details.episodes.isEmpty) return KeyEventResult.ignored;
        details.groupCount > 1
            ? revealFocus(_groupFocus[details.group])
            : _focusEpisodes(details);
      }
    } else if (node == _playFocus ||
        node == _followFocus ||
        node == _descriptionFocus) {
      if (key == LogicalKeyboardKey.arrowRight && node == _playFocus) {
        _followFocus.requestFocus();
      } else if (key == LogicalKeyboardKey.arrowRight) {
        _focusEpisodes(details);
      } else if (key == LogicalKeyboardKey.arrowLeft && node == _followFocus) {
        _playFocus.requestFocus();
      } else if (key == LogicalKeyboardKey.arrowDown &&
          node != _descriptionFocus &&
          _descriptionFocus.context != null) {
        _descriptionFocus.requestFocus();
      } else if (key == LogicalKeyboardKey.arrowUp &&
          node == _descriptionFocus) {
        _playFocus.requestFocus();
      }
    } else if (group >= 0) {
      if (key == LogicalKeyboardKey.arrowLeft) {
        group == 0
            ? _playFocus.requestFocus()
            : _focusGroup(details, group - 1);
      } else if (key == LogicalKeyboardKey.arrowRight &&
          group + 1 < details.groupCount) {
        _focusGroup(details, group + 1);
      } else if (key == LogicalKeyboardKey.arrowDown) {
        _focusEpisodes(details);
      } else if (key == LogicalKeyboardKey.arrowUp) {
        _focusSeason(details);
      }
    } else if (episode >= 0) {
      final columns = m.columns;
      final count = details.groupEpisodes.length;
      final column = episode % columns;
      final target = switch (key) {
        LogicalKeyboardKey.arrowLeft when column == 0 => null,
        LogicalKeyboardKey.arrowLeft => episode - 1,
        LogicalKeyboardKey.arrowRight
            when column < columns - 1 && episode + 1 < count =>
          episode + 1,
        LogicalKeyboardKey.arrowUp when episode >= columns => episode - columns,
        LogicalKeyboardKey.arrowDown
            when episode ~/ columns < (count - 1) ~/ columns =>
          math.min(episode + columns, count - 1),
        _ => episode,
      };
      if (target == null) {
        _playFocus.requestFocus();
      } else if (key == LogicalKeyboardKey.arrowUp &&
          episode < columns &&
          details.groupCount > 1) {
        revealFocus(_groupFocus[details.group]);
      } else if (key == LogicalKeyboardKey.arrowUp && episode < columns) {
        _focusSeason(details);
      } else {
        _episodeFocus[target].requestFocus();
      }
    } else {
      return KeyEventResult.ignored;
    }
    return KeyEventResult.handled;
  }

  void _focusGroup(DramaDetails details, int group) {
    details.selectGroup(group);
    revealFocus(_groupFocus[group]);
  }

  void _focusSeason(DramaDetails details) {
    if (details.seasons.isEmpty) return;
    final index = details.seasons.indexWhere(
      (season) => season.drama.id == details.drama.id,
    );
    revealFocus(_seasonFocus[math.max(index, 0)]);
  }

  void _focusEpisodes(DramaDetails details) {
    final count = details.groupEpisodes.length;
    if (count == 0) return;
    final start = details.group * episodeGroupSize;
    final offset = (details.currentIndex ?? -1) - start;
    _episodeFocus[offset >= 0 && offset < count ? offset : 0].requestFocus();
  }

  Widget _televisionInfo(DramaDetails details, _Metrics m) {
    final drama = details.drama;
    final colors = Theme.of(context).colorScheme;
    final sub = TextStyle(
      fontSize: m.note,
      height: 1.4,
      color: colors.onSurfaceVariant,
    );
    final meta = [
      SourceSite.byId(drama.source).name,
      if (drama.releaseStatus.isNotEmpty && drama.releaseStatus != 'unknown')
        drama.releaseLabel,
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          spacing: 20,
          children: [
            _cover(drama, m),
            Expanded(
              child: _enter(
                0,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  spacing: 6,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: Text(
                        drama.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: m.title,
                          fontWeight: FontWeight.w800,
                          height: 1.25,
                        ),
                      ),
                    ),
                    Text(
                      meta.join(' · '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: sub.copyWith(fontSize: m.meta),
                    ),
                    if (drama.score.isNotEmpty)
                      Text('评分 ${drama.score}', style: sub),
                    if (drama.category.isNotEmpty)
                      Text(
                        drama.category,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: sub,
                      ),
                    if (drama.onlineDate.isNotEmpty)
                      Text('${drama.onlineDate} 上线', style: sub),
                    if (drama.tags.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: SizedBox(
                          height: 28,
                          child: Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            clipBehavior: Clip.hardEdge,
                            children: [
                              for (final tag in drama.tags.take(12))
                                Container(
                                  height: 28,
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                  ),
                                  decoration: BoxDecoration(
                                    color: colors.surfaceContainerHighest,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Center(
                                    widthFactor: 1,
                                    child: Text(
                                      tag,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(fontSize: m.tag),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(top: 24),
          child: Row(
            spacing: 12,
            children: [
              Expanded(child: _playButton(details, m, focusNode: _playFocus)),
              FollowPill(
                store: widget.store,
                drama: drama,
                height: m.follow,
                focusNode: _followFocus,
              ),
            ],
          ),
        ),
        if (drama.description.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 18),
            child: _enter(3, _televisionDescription(drama, m)),
          ),
      ],
    );
  }

  Widget _televisionDescription(Drama drama, _Metrics m) {
    final colors = Theme.of(context).colorScheme;
    final style = TextStyle(
      fontSize: m.body,
      height: m.bodyHeight,
      color: colors.onSurfaceVariant,
    );
    return LayoutBuilder(
      builder: (context, constraints) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            drama.description,
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
            style: style,
          ),
          if (_exceeds(drama.description, style, 4, constraints.maxWidth))
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: FocusRing(
                radius: 18,
                child: FilledButton(
                  focusNode: _descriptionFocus,
                  onPressed: () => showDialog<void>(
                    context: context,
                    builder: (_) => _DescriptionDialog(drama: drama),
                  ),
                  style: FilledButton.styleFrom(
                    backgroundColor: colors.surfaceContainerHighest,
                    foregroundColor: colors.onSurface,
                    minimumSize: const Size(0, 36),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    textStyle: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  child: const Text('展开简介'),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _televisionEpisodes(DramaDetails details, _Metrics m) {
    if (details.episodes.isEmpty) {
      return KeyedSubtree(
        key: const ValueKey('status'),
        child: _episodeStatus(details, autofocus: true),
      );
    }
    final grouped = details.groupCount > 1;
    return Column(
      key: const ValueKey('episodes'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: 40,
          child: Align(
            alignment: Alignment.centerLeft,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _episodeTitle(details, m, prefix: '共 '),
                const SizedBox(width: 12),
                _durationText(details, m),
              ],
            ),
          ),
        ),
        if (grouped)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Transform.translate(
              offset: const Offset(-4, 0),
              child: SizedBox(
                height: m.chip + 8,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.all(4),
                  child: Row(
                    spacing: 12,
                    children: [
                      for (var group = 0; group < details.groupCount; group++)
                        _groupChip(
                          details,
                          m,
                          group,
                          focusNode: _groupFocus[group],
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        Padding(
          padding: EdgeInsets.only(top: grouped ? 14 : 18),
          child: _grid(details, m, focus: _episodeFocus),
        ),
      ],
    );
  }

  Widget _cover(Drama drama, _Metrics m) => DecoratedBox(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(m.coverRadius),
      boxShadow: const [
        BoxShadow(
          color: Color(0x4D000000),
          blurRadius: 26,
          offset: Offset(0, 10),
        ),
      ],
    ),
    child: SizedBox.fromSize(
      size: m.cover,
      child: DramaCover(
        drama: drama,
        radius: m.coverRadius,
        heroScope: 'drama',
      ),
    ),
  );

  Widget _headline(
    DramaDetails details,
    _Metrics m, {
    double spacing = 8,
    List<Widget> trailing = const [],
  }) {
    final drama = details.drama;
    TextStyle sub(double size) => TextStyle(
      fontSize: size,
      height: 1.5,
      color: Theme.of(context).colorScheme.onSurfaceVariant,
    );
    final meta = [
      SourceSite.byId(drama.source).name,
      if (drama.episodes > 0) '共 ${drama.episodes} 集',
      if (drama.releaseStatus.isNotEmpty && drama.releaseStatus != 'unknown')
        drama.releaseLabel,
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      spacing: spacing,
      children: [
        Text(
          drama.title,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: m.title,
            fontWeight: FontWeight.w800,
            height: 1.3,
          ),
        ),
        Text(meta.join(' · '), style: sub(m.meta)),
        if (drama.score.isNotEmpty)
          Text('评分 ${drama.score}', style: sub(m.meta)),
        if (drama.category.isNotEmpty) Text(drama.category, style: sub(m.meta)),
        if (drama.source == 'huangdou')
          Text(
            drama.vipStatus == null
                ? 'VIP 状态待补齐'
                : drama.vip
                ? 'VIP 内容'
                : '免费内容',
            style: sub(m.tag),
          ),
        ...trailing,
      ],
    );
  }

  Widget _followingHeadline(DramaDetails details, _Metrics m, double top) =>
      ConstrainedBox(
        constraints: BoxConstraints(minHeight: m.cover.height - top),
        child: IntrinsicHeight(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _headline(details, m),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: FollowPill(
                  store: widget.store,
                  drama: details.drama,
                  height: m.follow,
                ),
              ),
            ],
          ),
        ),
      );

  Widget? _stats(Drama drama, _Metrics m) {
    final stats = [
      if (drama.onlineDate.isNotEmpty) '${drama.onlineDate} 上线',
      if (drama.views.isNotEmpty && drama.views != '0') '播放 ${drama.views}',
    ];
    if (stats.isEmpty) return null;
    return Text(
      stats.join(' · '),
      style: TextStyle(
        fontSize: m.note,
        color: Theme.of(context).colorScheme.onSurfaceVariant,
      ),
    );
  }

  Widget? _tags(Drama drama, _Metrics m) {
    if (drama.tags.isEmpty) return null;
    final colors = Theme.of(context).colorScheme;
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        for (final tag in drama.tags.take(12))
          DecoratedBox(
            decoration: BoxDecoration(
              color: colors.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
              child: Text(tag, style: TextStyle(fontSize: m.tag)),
            ),
          ),
      ],
    );
  }

  Widget _description(Drama drama, _Metrics m) {
    final colors = Theme.of(context).colorScheme;
    final style = TextStyle(
      fontSize: m.body,
      height: m.bodyHeight,
      color: colors.onSurfaceVariant,
    );
    return LayoutBuilder(
      builder: (context, constraints) {
        final overflows = _exceeds(
          drama.description,
          style,
          3,
          constraints.maxWidth,
        );
        final label = Text(_expanded ? '收起简介' : '展开简介');
        void toggle() => setState(() => _expanded = !_expanded);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AnimatedSize(
              duration: Motion.of(context, Motion.long),
              curve: Motion.standard,
              alignment: Alignment.topCenter,
              child: Text(
                drama.description,
                maxLines: _expanded ? null : 3,
                overflow: _expanded ? null : TextOverflow.ellipsis,
                style: style,
              ),
            ),
            if (overflows)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: toggle,
                  child: FadeSwitcher(
                    duration: Motion.short,
                    child: KeyedSubtree(key: ValueKey(_expanded), child: label),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  bool _exceeds(String text, TextStyle style, int maxLines, double width) {
    final painter = TextPainter(
      text: TextSpan(text: text, style: style),
      maxLines: maxLines,
      textDirection: Directionality.of(context),
      textScaler: MediaQuery.textScalerOf(context),
    )..layout(maxWidth: width);
    final exceeds = painter.didExceedMaxLines;
    painter.dispose();
    return exceeds;
  }

  Widget _warning(String text, _Metrics m) {
    final color = Theme.of(context).colorScheme.error;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      spacing: 6,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Icon(
            Icons.error_outline_rounded,
            size: m.note + 3,
            color: color,
          ),
        ),
        Expanded(
          child: Text(
            text,
            style: TextStyle(fontSize: m.note, height: 1.5, color: color),
          ),
        ),
      ],
    );
  }

  Widget _playButton(DramaDetails details, _Metrics m, {FocusNode? focusNode}) {
    final label = details.watch != null && details.episodes.isNotEmpty
        ? '继续播放 · 第 ${details.episodes[details.resumeIndex].number} 集'
        : '立即播放';
    return FocusRing(
      radius: m.button / 2,
      child: FilledButton.icon(
        key: const ValueKey('detail-play'),
        focusNode: focusNode,
        onPressed: _ready
            ? () => _play(details.resumeIndex, resume: true)
            : null,
        style: FilledButton.styleFrom(
          minimumSize: Size(0, m.button),
          iconSize: m.buttonIcon,
          textStyle: TextStyle(
            fontSize: m.buttonText,
            fontWeight: FontWeight.w700,
          ),
        ),
        icon: const Icon(Icons.play_arrow_rounded),
        label: FadeSwitcher(
          child: Text(
            label,
            key: ValueKey(label),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    );
  }

  Widget _downloadButton(_Metrics m) => FocusRing(
    radius: m.button / 2,
    child: FilledButton.tonalIcon(
      onPressed: _ready ? _download : null,
      style: FilledButton.styleFrom(
        minimumSize: Size(0, m.button),
        iconSize: m.buttonIcon - 2,
        textStyle: TextStyle(
          fontSize: m.buttonText - 1,
          fontWeight: FontWeight.w600,
        ),
      ),
      icon: const Icon(Icons.download_rounded),
      label: const Text('下载选集'),
    ),
  );

  Widget _episodeStatus(DramaDetails details, {bool autofocus = false}) =>
      FadeSwitcher(
        child: details.loading
            ? const StatusView.loading(key: ValueKey('loading'))
            : _episodeError(details, autofocus),
      );

  Widget _episodeError(DramaDetails details, bool autofocus) {
    return StatusView(
      key: const ValueKey('error'),
      title: details.error != null ? '剧集信息暂时不可用' : '暂时没有可播放的集数',
      message: details.error ?? '可以更新剧集信息后重试。',
      icon: Icons.error_outline_rounded,
      action: '重试',
      onAction: details.load,
      autofocus: autofocus,
    );
  }

  Widget _episodeTitle(DramaDetails details, _Metrics m, {String prefix = ''}) {
    final current = details.currentIndex;
    final summary = [
      '$prefix${details.episodes.length} 集',
      if (current != null) '当前第 ${details.episodes[current].number} 集',
    ].join(' · ');
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          '选集',
          style: TextStyle(fontSize: m.section, fontWeight: FontWeight.w700),
        ),
        const SizedBox(width: 8),
        Text(
          summary,
          style: TextStyle(
            fontSize: m.summary,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Widget _episodeHeader(DramaDetails details, _Metrics m) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Row(
        children: [
          Expanded(
            child: Align(
              alignment: Alignment.centerLeft,
              child: _episodeTitle(details, m),
            ),
          ),
          if (details.currentIndex case final current?)
            TextButton(
              onPressed: () => _locate(current),
              child: const Text('定位当前'),
            ),
        ],
      ),
      _durationLine(details, m),
    ],
  );

  /// 选集栏上的「本剧总时长 = 每一集的时长相加」。
  /// 2.0.0+156 按反馈改回 +151 的样子：标题下面单独一行。
  Widget _durationLine(DramaDetails details, _Metrics m) => Padding(
    padding: const EdgeInsets.only(top: 2),
    child: _durationText(details, m),
  );

  Widget _durationText(DramaDetails details, _Metrics m) {
    if (details.episodes.isEmpty) return const SizedBox.shrink();
    return EpisodeDurationLabel(
      stats: durationsOf(details),
      fontSize: m.summary,
    );
  }

  Widget _seasonRow(DramaDetails details, _Metrics m) => _SeasonStrip(
    seasons: details.seasons,
    current: details.drama.id,
    store: widget.store,
    metrics: m,
    swipeHint: !AppScope.of(context).television,
    collapsed: AppScope.formFactorOf(context) == FormFactor.window,
    focus: AppScope.of(context).television ? _seasonFocus : const [],
    onSelected: (season) => unawaited(_selectSeason(season)),
  );

  Future<void> _selectSeason(DramaSeason season) async {
    final details = _details!;
    if (season.drama.id == details.drama.id) return;
    _handle?.dispose();
    _handle = null;
    await details.selectSeason(season);
  }

  Widget _groupChip(
    DramaDetails details,
    _Metrics m,
    int group, {
    FocusNode? focusNode,
  }) => _GroupChip(
    key: _groupKey(group),
    label: details.groupLabel(group),
    selected: group == details.group,
    metrics: m,
    focusNode: focusNode,
    onPressed: () => details.selectGroup(group),
  );

  Widget _swipeGroups(DramaDetails details, _Metrics m) {
    return SwipeSwitch(
      index: details.group,
      count: details.groupCount,
      onSwitch: (group) => _swipeTo(details, group),
      child: _grid(details, m),
    );
  }

  void _renewKeys(String drama) {
    if (drama == _keyedDrama) return;
    _keyedDrama = drama;
    _currentEpisode = GlobalKey();
    _groupKeys.clear();
  }

  GlobalKey _groupKey(int group) {
    while (_groupKeys.length <= group) {
      _groupKeys.add(GlobalKey());
    }
    return _groupKeys[group];
  }

  void _swipeTo(DramaDetails details, int group) {
    details.selectGroup(group);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final chip = _groupKey(group).currentContext;
      if (chip == null || !chip.mounted) return;
      final position = Scrollable.maybeOf(
        chip,
        axis: Axis.horizontal,
      )?.position;
      final box = chip.findRenderObject();
      if (position == null || box == null) return;
      unawaited(
        position.ensureVisible(
          box,
          alignment: .5,
          duration: Motion.of(chip, Motion.medium),
          curve: Motion.standard,
        ),
      );
    });
  }

  Widget _grid(
    DramaDetails details,
    _Metrics m, {
    List<FocusNode> focus = const [],
  }) {
    final extent = math.max(
      m.cell,
      MediaQuery.textScalerOf(context).scale(m.cellText) + 28,
    );
    final current = details.currentIndex;
    final start = details.group * episodeGroupSize;
    final episodes = details.groupEpisodes;
    // 画质标注跟总时长同一批探测回来；探测进度一到就重画格子。
    final stats = durationsOf(details);
    Widget cell(int offset) {
      final index = start + offset;
      final episode = episodes[offset];
      return _EpisodeCell(
        key: index == current
            ? _currentEpisode
            : ValueKey('episode-${episode.number}'),
        episode: episode,
        metrics: m,
        focusNode: offset < focus.length ? focus[offset] : null,
        current: index == current,
        watched: current != null && index < current,
        quality: stats.qualityLabel(episode.id),
        onPressed: () => _play(index),
      );
    }

    return ListenableBuilder(
      listenable: stats,
      builder: (context, _) => LayoutBuilder(
        builder: (context, constraints) {
          final columns = m.columnsFor(constraints.maxWidth);
          final fade = Motion.of(context, Motion.medium);
          return TweenAnimationBuilder<double>(
            tween: Tween(begin: fade == Duration.zero ? 1 : 0, end: 1),
            duration: fade,
            curve: Motion.standard,
            builder: (context, value, child) =>
                Opacity(opacity: value, child: child),
            child: Column(
              spacing: m.cellGap,
              children: [
                for (var row = 0; row < episodes.length; row += columns)
                  SizedBox(
                    height: extent,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      spacing: m.cellGap,
                      children: [
                        for (var offset = row; offset < row + columns; offset++)
                          Expanded(
                            child: offset < episodes.length
                                ? cell(offset)
                                : const SizedBox.shrink(),
                          ),
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _SeasonStrip extends StatefulWidget {
  const _SeasonStrip({
    required this.seasons,
    required this.current,
    required this.store,
    required this.metrics,
    required this.swipeHint,
    required this.collapsed,
    required this.focus,
    required this.onSelected,
  });
  final bool collapsed;
  final List<FocusNode> focus;
  final List<DramaSeason> seasons;
  final String current;
  final LocalStore store;
  final _Metrics metrics;
  final bool swipeHint;
  final ValueChanged<DramaSeason> onSelected;

  @override
  State<_SeasonStrip> createState() => _SeasonStripState();
}

class _SeasonStripState extends State<_SeasonStrip> {
  static const _cardWidth = 116.0;
  static const _gap = 8.0;
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _reveal(animate: false);
  }

  @override
  void didUpdateWidget(_SeasonStrip oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.current != widget.current) _reveal(animate: true);
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  void _reveal({required bool animate}) {
    final index = widget.seasons.indexWhere(
      (season) => season.drama.id == widget.current,
    );
    if (index <= 0) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_scroll.hasClients) return;
      final offset = (index * (_cardWidth + _gap) - _cardWidth / 2).clamp(
        0.0,
        _scroll.position.maxScrollExtent,
      );
      if (animate) {
        _scroll.animateTo(
          offset,
          duration: Motion.medium,
          curve: Curves.easeOut,
        );
      } else {
        _scroll.jumpTo(offset);
      }
    });
  }

  String _status(DramaSeason season, bool selected) {
    if (selected) return '正在浏览';
    final watched = widget.store.watched(season.drama.id);
    if (watched != null && !watched.finished) return '看至第${watched.episode}集';
    if (season.upcoming) return '待上线';
    return season.drama.episodes > 0 ? '共 ${season.drama.episodes} 集' : '';
  }

  void _openMenu() {
    unawaited(
      showAnchoredPanel<void>(
        context: context,
        width: context.size!.width,
        builder: (_) => GridView.builder(
          shrinkWrap: true,
          padding: const EdgeInsets.all(12),
          itemCount: widget.seasons.length,
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 150,
            mainAxisExtent: 82,
            mainAxisSpacing: _gap,
            crossAxisSpacing: _gap,
          ),
          itemBuilder: (menu, index) =>
              _card(menu, widget.seasons[index], null, (season) {
                Navigator.pop(menu);
                widget.onSelected(season);
              }),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final m = widget.metrics;
    final background = colors.surfaceContainerHighest.withValues(alpha: .55);
    final currentLabel = widget.seasons
        .where((season) => season.drama.id == widget.current)
        .firstOrNull
        ?.label;
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      spacing: 10,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              Icon(Icons.layers_rounded, size: 16, color: colors.primary),
              const SizedBox(width: 6),
              Text(
                '系列多季',
                style: TextStyle(
                  fontSize: m.section,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: colors.primary.withValues(alpha: .16),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '共 ${widget.seasons.length} 季',
                  style: TextStyle(fontSize: m.tag, color: colors.primary),
                ),
              ),
              const Spacer(),
              if (widget.collapsed) ...[
                if (currentLabel != null)
                  Text(
                    currentLabel,
                    style: TextStyle(
                      fontSize: m.tag,
                      color: colors.onSurfaceVariant,
                    ),
                  ),
                Icon(
                  Icons.expand_more_rounded,
                  size: 20,
                  color: colors.onSurfaceVariant,
                ),
              ] else if (widget.swipeHint)
                Text(
                  '左右滑动切换',
                  style: TextStyle(
                    fontSize: m.tag,
                    color: colors.onSurfaceVariant,
                  ),
                ),
            ],
          ),
        ),
        if (!widget.collapsed)
          SizedBox(
            height: 90,
            child: ListView.separated(
              controller: _scroll,
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              itemCount: widget.seasons.length,
              separatorBuilder: (_, _) => const SizedBox(width: _gap),
              itemBuilder: (context, index) => _card(
                context,
                widget.seasons[index],
                index < widget.focus.length ? widget.focus[index] : null,
                widget.onSelected,
              ),
            ),
          ),
      ],
    );
    if (widget.collapsed) {
      return Material(
        color: background,
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: _openMenu,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(4, 10, 4, 10),
            child: content,
          ),
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.fromLTRB(4, 10, 4, 12),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(16),
      ),
      child: content,
    );
  }

  Widget _card(
    BuildContext context,
    DramaSeason season,
    FocusNode? focusNode,
    ValueChanged<DramaSeason> onSelected,
  ) {
    final colors = Theme.of(context).colorScheme;
    final m = widget.metrics;
    final selected = season.drama.id == widget.current;
    final foreground = selected ? colors.onPrimaryContainer : colors.onSurface;
    final muted = selected
        ? colors.onPrimaryContainer.withValues(alpha: .8)
        : colors.onSurfaceVariant;
    final status = _status(season, selected);
    final online = season.onlineLabel;
    return FocusRing(
      radius: 12,
      child: Material(
        color: selected ? colors.primaryContainer : colors.surfaceContainer,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          focusNode: focusNode,
          onTap: selected && focusNode == null
              ? null
              : () => onSelected(season),
          child: Container(
            width: _cardWidth,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              spacing: 3,
              children: [
                Row(
                  spacing: 4,
                  children: [
                    Flexible(
                      child: Text(
                        season.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: m.meta,
                          fontWeight: FontWeight.w700,
                          color: foreground,
                        ),
                      ),
                    ),
                    if (selected)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 1,
                        ),
                        decoration: BoxDecoration(
                          color: colors.onPrimaryContainer.withValues(
                            alpha: .14,
                          ),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          '当前',
                          style: TextStyle(
                            fontSize: m.tag * .85,
                            color: colors.onPrimaryContainer,
                          ),
                        ),
                      ),
                  ],
                ),
                if (status.isNotEmpty)
                  Text(
                    status,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: m.tag, color: muted),
                  ),
                if (online != null)
                  Text(
                    online,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: m.tag * .85,
                      color: muted.withValues(alpha: .7),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GroupChip extends StatelessWidget {
  const _GroupChip({
    super.key,
    required this.label,
    required this.selected,
    required this.metrics,
    required this.onPressed,
    this.focusNode,
  });
  final String label;
  final bool selected;
  final _Metrics metrics;
  final VoidCallback onPressed;
  final FocusNode? focusNode;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final m = metrics;
    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(m.chipRadius),
    );
    final padding = EdgeInsets.symmetric(horizontal: m.chipPadding);
    final size = Size(0, m.chip);
    return FocusRing(
      radius: m.chipRadius,
      child: selected
          ? FilledButton.tonal(
              focusNode: focusNode,
              onPressed: onPressed,
              style: FilledButton.styleFrom(
                shape: shape,
                padding: padding,
                minimumSize: size,
                textStyle: TextStyle(
                  fontSize: m.chipText,
                  fontWeight: FontWeight.w600,
                ),
              ),
              child: Text(label),
            )
          : OutlinedButton(
              focusNode: focusNode,
              onPressed: onPressed,
              style: OutlinedButton.styleFrom(
                shape: shape,
                padding: padding,
                minimumSize: size,
                foregroundColor: colors.onSurfaceVariant,
                side: BorderSide(color: colors.outlineVariant),
                textStyle: TextStyle(fontSize: m.chipText),
              ),
              child: Text(label),
            ),
    );
  }
}

class _EpisodeCell extends StatelessWidget {
  const _EpisodeCell({
    super.key,
    required this.episode,
    required this.metrics,
    required this.current,
    required this.watched,
    required this.onPressed,
    this.focusNode,
    this.quality = '',
  });
  final Episode episode;
  final _Metrics metrics;
  final bool current;
  final bool watched;
  final VoidCallback onPressed;
  final FocusNode? focusNode;

  /// 该集播放列表里的最高画质档，例如 `1080P`；空串表示站点没给档位。
  final String quality;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final dark = theme.brightness == Brightness.dark;
    // Liquid Glass 打开时选集格子换成半透明胶囊：当前集是主题色玻璃块 + 亮边，
    // 其余是极淡的一层白，跟播放器里的选集面板保持同一套语言。
    final glass = AppScope.of(context).liquidGlass;
    final corner = glass ? 18.0 : metrics.cellRadius;
    final radius = BorderRadius.circular(corner);
    // 玻璃胶囊在深色下是「白字 + 淡白底」，到了浅色模式还是白字就整个糊住了：
    // 底色是 16% 的白，字也是白，选集数字看不见。浅色下换成深字 + 淡黑底。
    final foreground = glass
        ? current
              ? (dark ? Colors.white : colors.onPrimary)
              : watched
              ? (dark ? Colors.white70 : colors.onSurfaceVariant)
              : (dark ? Colors.white : colors.onSurface)
        : current
        ? colors.onPrimaryContainer
        : watched
        ? colors.onSurfaceVariant
        : colors.onSurface;
    return FocusRing(
      radius: corner,
      child: Semantics(
        button: true,
        label: '第 ${episode.number} 集${episode.vip ? '，VIP' : ''}',
        excludeSemantics: true,
        child: Material(
          color: current
              ? (glass
                    ? colors.primary.withValues(alpha: 0.55)
                    : colors.primaryContainer)
              : glass
              ? (dark
                    ? Colors.white.withValues(alpha: 0.10)
                    : colors.onSurface.withValues(alpha: 0.06))
              : colors.surfaceContainer,
          shape: RoundedRectangleBorder(
            borderRadius: radius,
            side: glass
                ? BorderSide(
                    color: dark
                        ? Colors.white.withValues(alpha: 0.18)
                        : colors.onSurface.withValues(alpha: 0.12),
                  )
                : BorderSide.none,
          ),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            focusNode: focusNode,
            onTap: onPressed,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Center(
                  child: Text(
                    '${episode.number}',
                    style: TextStyle(
                      fontSize: metrics.cellText,
                      fontWeight: current
                          ? FontWeight.w800
                          : watched
                          ? FontWeight.w400
                          : FontWeight.w600,
                      color: foreground,
                    ),
                  ),
                ),
                if (quality.isNotEmpty)
                  Positioned(
                    // 玻璃格子圆角有 18px，贴着角放会被 Clip.antiAlias 切掉
                    // 首个字母和文字下缘，往里收一点。
                    left: 8,
                    bottom: 6,
                    child: Text(
                      quality,
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        height: 1.1,
                        color: foreground.withValues(alpha: 0.82),
                        shadows: [
                          Shadow(
                            blurRadius: 2,
                            color: Colors.black.withValues(alpha: 0.35),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (episode.vip && metrics.vipBadge)
                  const Positioned(
                    right: 0,
                    top: 0,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: Color(0xFFF2C14E),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(6),
                        ),
                      ),
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 1,
                        ),
                        child: Text(
                          'VIP',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            height: 1.4,
                            color: Color(0xFF3A2A00),
                          ),
                        ),
                      ),
                    ),
                  )
                else if (episode.vip)
                  Positioned(
                    right: 5,
                    top: 4,
                    child: Text(
                      'VIP',
                      style: TextStyle(
                        fontSize: metrics.cellText - 7,
                        fontWeight: FontWeight.w800,
                        color: dark ? vipGold : const Color(0xFFB08200),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _DescriptionDialog extends StatefulWidget {
  const _DescriptionDialog({required this.drama});
  final Drama drama;

  @override
  State<_DescriptionDialog> createState() => _DescriptionDialogState();
}

class _DescriptionDialogState extends State<_DescriptionDialog> {
  final _scroll = ScrollController();

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  KeyEventResult _onKey(KeyEvent event) {
    final step = switch (event.logicalKey) {
      LogicalKeyboardKey.arrowUp => -120.0,
      LogicalKeyboardKey.arrowDown => 120.0,
      _ => null,
    };
    if (event is KeyUpEvent || step == null) return KeyEventResult.ignored;
    if (_scroll.hasClients) {
      final position = _scroll.position;
      _scroll.animateTo(
        (position.pixels + step).clamp(0, position.maxScrollExtent),
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeOut,
      );
    }
    return KeyEventResult.handled;
  }

  @override
  Widget build(BuildContext context) => Focus(
    canRequestFocus: false,
    skipTraversal: true,
    onKeyEvent: (_, event) => _onKey(event),
    child: AlertDialog(
      title: Text(widget.drama.title),
      content: SizedBox(
        width: 560,
        child: SingleChildScrollView(
          controller: _scroll,
          child: Text(
            widget.drama.description,
            style: const TextStyle(fontSize: 16, height: 1.7),
          ),
        ),
      ),
      actions: [
        FocusRing(
          radius: 20,
          child: TextButton(
            autofocus: true,
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('关闭'),
          ),
        ),
      ],
    ),
  );
}
