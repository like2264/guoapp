#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\34482\.flutter-sdk\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\34482\WorkBuddy\2026-11-10-16-02-07\guoapp2"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=C:\Users\34482\WorkBuddy\2026-11-10-16-02-07\guoapp2\macos\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=2.0.0"
export "FLUTTER_BUILD_NUMBER=171"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
