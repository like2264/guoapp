package core

import (
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// 有些站源的播放列表是单路列表（#EXTINF + 分片，没有 #EXT-X-STREAM-INF），
// 网站并没有把分辨率写在文本里；播放器解码后日记里才有 size=854x480 这种数。
// 选集面板要在不播放的情况下标档位，只能取一小段真实媒体自己解析：
//   - TS 分片里的 H.264 SPS 直接带宽高；
//   - MP4 / fMP4 初始化段的 tkhd 直接带宽高；
//   - 都没有再看地址上有没有明确的 720p/1080p 标记。
//
// 只在原本拿不到档位时才走这里，取 256KB 就够，失败就留空，绝不拿猜测值冒充。
const (
	nativeProbeBudget = 4 * time.Second
	nativeProbeBytes  = int64(256 << 10)
)

var nativeQualityHints = []*regexp.Regexp{
	regexp.MustCompile(`(?i)(?:^|[^0-9])(2160|1080|720|480|360)p(?:$|[^0-9])`),
	regexp.MustCompile(`(?i)(?:quality|definition|resolution|clip|q)=(\d{3,4})(?:$|[^0-9])`),
	regexp.MustCompile(`(?i)/(2160|1080|720|480|360)(?:/|$)`),
}

// probeMediaHeight 在站点没有明说档位时，从媒体字节里量一次实际分辨率，
// 返回短边（竖屏 720x1280 归为 720P），跟下载选档的口径一致。
func (engine *nativeEngine) probeMediaHeight(ctx context.Context, media ProviderMedia) int64 {
	ctx, cancel := context.WithTimeout(ctx, nativeProbeBudget)
	defer cancel()
	if media.Credentials != nil {
		ctx = providerMediaContext(ctx, media.Credentials)
	}
	address, data := media.URL, media.Playlist
	if !strings.HasPrefix(strings.TrimSpace(data), "#EXTM3U") {
		data = ""
	}
	if data != "" {
		segment := nativePlaylistProbeSegment(data, media.URL)
		if segment == "" {
			return 0
		}
		address = segment
		data = ""
	} else if parsed, err := url.Parse(address); err == nil && strings.HasSuffix(strings.ToLower(parsed.Path), ".m3u8") {
		list, finalURL, err := engine.downloader.fetchMediaPlaylist(ctx, address, media.Referer)
		if err != nil || strings.HasPrefix(strings.TrimSpace(list), "#EXT-X-STREAM-INF:") {
			return 0
		}
		segment := nativePlaylistProbeSegment(list, finalURL)
		if segment == "" {
			return 0
		}
		address = segment
	}
	if hint := nativeURLQualityHint(address); hint > 0 {
		return hint
	}
	body, total, err := engine.fetchProbeBytes(ctx, address, media.Referer, 0)
	if err != nil {
		return 0
	}
	if height := nativeMediaBytesHeight(body, address); height > 0 {
		return height
	}
	// moov 常被写在 MP4 末尾，开头这一截只有 mdat；再取尾部一次。
	if total > nativeProbeBytes && total > int64(len(body)) && strings.Contains(strings.ToLower(string(body[:min(len(body), 64)])), "ftyp") {
		tail, _, err := engine.fetchProbeBytes(ctx, address, media.Referer, total-nativeProbeBytes)
		if err == nil {
			if height := nativeMediaBytesHeight(tail, address); height > 0 {
				return height
			}
		}
	}
	return 0
}

// fetchProbeBytes 只取 bounded 的一段，Range 不被支持时服务端会回整段，
// LimitReader 保证最多只读 nativeProbeBytes。
func (engine *nativeEngine) fetchProbeBytes(ctx context.Context, address, referer string, offset int64) ([]byte, int64, error) {
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, address, nil)
	if err != nil {
		return nil, 0, err
	}
	if referer != "" {
		request.Header.Set("Referer", referer)
	}
	request.Header.Set("Range", fmt.Sprintf("bytes=%d-%d", offset, offset+nativeProbeBytes-1))
	response, err := engine.downloader.doMediaRequest(request)
	if err != nil {
		return nil, 0, err
	}
	defer response.Body.Close()
	if response.StatusCode >= 400 {
		return nil, 0, fmt.Errorf("探测媒体返回 %d", response.StatusCode)
	}
	body, err := io.ReadAll(io.LimitReader(response.Body, nativeProbeBytes))
	if err != nil {
		return nil, 0, err
	}
	var total int64
	if _, value, found := strings.Cut(response.Header.Get("Content-Range"), "/"); found {
		total, _ = strconv.ParseInt(strings.TrimSpace(value), 10, 64)
	}
	if total <= 0 {
		total = response.ContentLength
	}
	return body, total, nil
}

// nativePlaylistProbeSegment 取播放列表里第一个分片。fMP4 的分辨率在
// #EXT-X-MAP 指向的初始化段里，那一段比视频分片更靠前，优先用它。
func nativePlaylistProbeSegment(playlist, base string) string {
	baseURL, err := url.Parse(base)
	if err != nil {
		return ""
	}
	var firstURI string
	for _, raw := range strings.Split(playlist, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			if strings.HasPrefix(line, "#EXT-X-MAP:") {
				attributes := nativeHLSAttributes(line)
				if reference := attributes["URI"]; reference != "" {
					firstURI = reference
				}
			}
			continue
		}
		if firstURI != "" {
			continue
		}
		firstURI = line
	}
	if firstURI == "" {
		return ""
	}
	reference, err := url.Parse(firstURI)
	if err != nil {
		return ""
	}
	return baseURL.ResolveReference(reference).String()
}

func nativeURLQualityHint(address string) int64 {
	for _, pattern := range nativeQualityHints {
		match := pattern.FindStringSubmatch(address)
		if len(match) < 2 {
			continue
		}
		value, err := strconv.ParseInt(match[1], 10, 64)
		if err == nil && value >= 360 && value <= 2160 {
			return value
		}
	}
	return 0
}

func nativeMediaBytesHeight(data []byte, address string) int64 {
	if width, height := nativeMP4Resolution(data); width > 0 && height > 0 {
		return int64(min(width, height))
	}
	if width, height := nativeH264SPSResolution(data); width > 0 && height > 0 {
		return int64(min(width, height))
	}
	return 0
}

// nativeMP4Resolution 从 moov/trak/tkhd 读宽高。tkhd 里的宽高是 16.16 定点数。
func nativeMP4Resolution(data []byte) (int, int) {
	for index := 0; index+8 <= len(data); index++ {
		if string(data[index+4:index+8]) != "moov" {
			continue
		}
		boxes, err := mp4Boxes(data, index, len(data))
		if err != nil || len(boxes) == 0 {
			continue
		}
		tracks, err := mp4Boxes(data, boxes[0].body, boxes[0].end)
		if err != nil {
			continue
		}
		for _, track := range tracks {
			if track.kind != "trak" {
				continue
			}
			header, found := mp4Child(data, track.body, track.end, "tkhd")
			if !found || header.end-header.body < 92 {
				continue
			}
			offset := header.body + 76
			if data[header.body] == 1 {
				offset = header.body + 88
			}
			if offset+8 > header.end {
				continue
			}
			width := int(binary.BigEndian.Uint32(data[offset:]) >> 16)
			height := int(binary.BigEndian.Uint32(data[offset+4:]) >> 16)
			if width > 0 && height > 0 && width <= 8192 && height <= 8192 {
				return width, height
			}
		}
	}
	return 0, 0
}

// nativeH264SPSResolution 在 TS / Annex-B 分片里找 H.264 SPS（NAL type 7），
// 直接读里面的宽高。SPS 一般就在分片头部几 KB 内，不需要拼完整 PES。
func nativeH264SPSResolution(data []byte) (int, int) {
	for index := 0; index+4 < len(data); index++ {
		if data[index] != 0 || data[index+1] != 0 || data[index+2] != 1 {
			continue
		}
		if data[index+3]&0x1f != 7 {
			continue
		}
		end := len(data)
		for next := index + 3; next+3 < len(data); next++ {
			if data[next] == 0 && data[next+1] == 0 && data[next+2] == 1 {
				end = next
				break
			}
		}
		return nativeParseH264SPS(data[index+3 : end])
	}
	return 0, 0
}

type nativeBitReader struct {
	data []byte
	bit  int
}

func (reader *nativeBitReader) read(count int) int {
	value := 0
	for index := 0; index < count; index++ {
		position := reader.bit / 8
		if position >= len(reader.data) {
			return -1
		}
		value = value<<1 | int((reader.data[position]>>(7-uint(reader.bit%8)))&1)
		reader.bit++
	}
	return value
}

func (reader *nativeBitReader) ue() int {
	zeros := 0
	for {
		bit := reader.read(1)
		if bit < 0 {
			return -1
		}
		if bit == 1 {
			break
		}
		zeros++
		if zeros > 32 {
			return -1
		}
	}
	value := (1 << zeros) - 1
	if zeros > 0 {
		tail := reader.read(zeros)
		if tail < 0 {
			return -1
		}
		value += tail
	}
	return value
}

func (reader *nativeBitReader) se() int {
	value := reader.ue()
	if value < 0 {
		return -1
	}
	if value%2 == 0 {
		return -(value / 2)
	}
	return (value + 1) / 2
}

// nativeUnescapeRBSP 去掉 H.264 为了防止伪起始码插入的 0x03。
func nativeUnescapeRBSP(nal []byte) []byte {
	out := make([]byte, 0, len(nal))
	zeros := 0
	for _, value := range nal {
		if zeros >= 2 && value == 3 {
			zeros = 0
			continue
		}
		out = append(out, value)
		if value == 0 {
			zeros++
		} else {
			zeros = 0
		}
	}
	return out
}

func nativeSkipScalingList(reader *nativeBitReader, size int) bool {
	last, next := 8, 8
	for index := 0; index < size; index++ {
		if next != 0 {
			delta := reader.se()
			if delta < 0 {
				return false
			}
			next = (last + delta + 256) % 256
		}
		if next != 0 {
			last = next
		}
	}
	return true
}

func nativeParseH264SPS(nal []byte) (int, int) {
	rbsp := nativeUnescapeRBSP(nal)
	if len(rbsp) < 8 || rbsp[0]&0x1f != 7 {
		return 0, 0
	}
	reader := &nativeBitReader{data: rbsp[1:]}
	profile := reader.read(8)
	if reader.read(8) < 0 || reader.read(8) < 0 { // constraints + level
		return 0, 0
	}
	if reader.ue() < 0 { // seq_parameter_set_id
		return 0, 0
	}
	chroma := 1
	switch profile {
	case 100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135:
		value := reader.ue()
		if value < 0 {
			return 0, 0
		}
		chroma = value
		if chroma == 3 && reader.read(1) < 0 {
			return 0, 0
		}
		if reader.ue() < 0 || reader.ue() < 0 || reader.read(1) < 0 {
			return 0, 0
		}
		if reader.read(1) == 1 {
			lists := 8
			if chroma != 3 {
				lists = 12
			}
			for index := 0; index < lists; index++ {
				if reader.read(1) == 1 && !nativeSkipScalingList(reader, min(16+(index/6)*48, 64)) {
					return 0, 0
				}
			}
		}
	}
	if reader.ue() < 0 { // log2_max_frame_num_minus4
		return 0, 0
	}
	pocType := reader.ue()
	if pocType < 0 {
		return 0, 0
	}
	switch pocType {
	case 0:
		if reader.ue() < 0 {
			return 0, 0
		}
	case 1:
		if reader.read(1) < 0 || reader.se() < 0 || reader.se() < 0 {
			return 0, 0
		}
		count := reader.ue()
		if count < 0 {
			return 0, 0
		}
		for index := 0; index < count; index++ {
			if reader.se() < 0 {
				return 0, 0
			}
		}
	}
	if reader.ue() < 0 || reader.read(1) < 0 { // max refs + gaps flag
		return 0, 0
	}
	widthUnits, heightUnits := reader.ue(), reader.ue()
	frameOnly := reader.read(1)
	if frameOnly < 0 || widthUnits < 0 || heightUnits < 0 {
		return 0, 0
	}
	if frameOnly == 0 && reader.read(1) < 0 {
		return 0, 0
	}
	if reader.read(1) < 0 { // direct_8x8_inference_flag
		return 0, 0
	}
	var left, top, right, bottom int
	if reader.read(1) == 1 {
		left, top = reader.ue(), reader.ue()
		right, bottom = reader.ue(), reader.ue()
		if left < 0 || top < 0 || right < 0 || bottom < 0 {
			return 0, 0
		}
	}
	width := (widthUnits + 1) * 16
	height := (2 - frameOnly) * (heightUnits + 1) * 16
	unitX, unitY := 1, 2-frameOnly
	if chroma == 1 || chroma == 2 {
		unitX, unitY = 2, unitY*2
	}
	width -= (left + right) * unitX
	height -= (top + bottom) * unitY
	if width <= 0 || height <= 0 || width > 8192 || height > 8192 {
		return 0, 0
	}
	return width, height
}
