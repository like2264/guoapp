import 'dart:ui';

import 'package:flutter/material.dart';

/// 浮动玻璃标签栏：半透明胶囊 + 背景模糊 + 细高光边，选中项再浮起一层亮胶囊。
/// 边框和高光按参考视频保留，内容仍能透过胶囊看到。
class GlassTabBar extends StatelessWidget {
  const GlassTabBar({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
    required this.destinations,
    this.onSwipe,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final List<GlassTabDestination> destinations;

  /// 在底栏上左右滑时回调：-1 = 上一栏，+1 = 下一栏。
  /// 手势只挂在底栏这一条上，页面本身不响应横滑。
  final ValueChanged<int>? onSwipe;

  /// 胶囊本体高度（不含底部安全区）。
  static const barHeight = 62.0;

  /// 底栏上下的留白。内容要躲开底栏时，用 [reservedHeight]。
  static const horizontalInset = 14.0;
  static const bottomGap = 10.0;

  /// 底栏实际占用的总高度（胶囊 + 上下留白 + 安全区）。
  /// 页面底部留白按它算，内容就不会被浮起来的玻璃条盖住。
  static double reservedHeight(BuildContext context) =>
      barHeight +
      bottomGap +
      MediaQuery.viewPaddingOf(context).bottom +
      8;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors = Theme.of(context).colorScheme;
    final inset = MediaQuery.viewPaddingOf(context).bottom;
    final bar = Padding(
      padding: EdgeInsets.fromLTRB(
        horizontalInset,
        0,
        horizontalInset,
        bottomGap + inset,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(34),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: 8,
            sigmaY: 8,
            tileMode: TileMode.clamp,
          ),
          child: Container(
            height: barHeight,
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(34),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: dark
                    ? [
                        Colors.white.withValues(alpha: 0.16),
                        Colors.white.withValues(alpha: 0.08),
                      ]
                    : [
                        Colors.white.withValues(alpha: 0.58),
                        Colors.white.withValues(alpha: 0.36),
                      ],
              ),
              border: Border.all(
                color: dark
                    ? Colors.white.withValues(alpha: 0.55)
                    : Colors.white.withValues(alpha: 0.9),
                width: 1.1,
              ),
              boxShadow: [
                BoxShadow(
                  color: dark
                      ? Colors.black.withValues(alpha: 0.22)
                      : Colors.black.withValues(alpha: 0.12),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Row(
              children: [
                for (var index = 0; index < destinations.length; index++)
                  Expanded(child: _item(context, index, dark, colors)),
              ],
            ),
          ),
        ),
      ),
    );
    final swipe = onSwipe;
    if (swipe == null) return bar;
    return _SwipeDetector(onSwipe: swipe, child: bar);
  }

  Widget _item(
    BuildContext context,
    int index,
    bool dark,
    ColorScheme colors,
  ) {
    final destination = destinations[index];
    final selected = index == selectedIndex;
    final idle = dark
        ? Colors.white.withValues(alpha: 0.92)
        : Colors.black.withValues(alpha: 0.78);
    // 背景全透明后，内容可能很亮也可能很暗，给字加一圈很轻的影子保证可读。
    final legibility = <Shadow>[
      Shadow(
        offset: const Offset(0, 1),
        blurRadius: 2,
        color: dark
            ? Colors.black.withValues(alpha: 0.65)
            : Colors.white.withValues(alpha: 0.85),
      ),
    ];
    return Semantics(
      button: true,
      selected: selected,
      label: destination.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => onSelected(index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 240),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            color: selected
                ? (dark
                      ? Colors.white.withValues(alpha: 0.22)
                      : Colors.white.withValues(alpha: 0.72))
                : Colors.transparent,
            border: selected
                ? Border.all(
                    color: dark
                        ? Colors.white.withValues(alpha: 0.34)
                        : Colors.white.withValues(alpha: 0.95),
                  )
                : null,
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: colors.primary.withValues(alpha: dark ? 0.18 : 0.12),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconTheme.merge(
                data: IconThemeData(
                  size: 22,
                  color: selected ? colors.primary : idle,
                ),
                child: selected ? destination.selectedIcon : destination.icon,
              ),
              const SizedBox(height: 2),
              Text(
                destination.label,
                maxLines: 1,
                overflow: TextOverflow.fade,
                softWrap: false,
                style: TextStyle(
                  fontSize: 11,
                  height: 1.1,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  color: selected ? colors.primary : idle,
                  shadows: legibility,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GlassTabDestination {
  const GlassTabDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
  });

  final String label;
  final Widget icon;
  final Widget selectedIcon;
}

/// 底栏上的横滑识别：直接读指针事件 + 手势拖动双保险。
/// 任意一种识别到横向位移就切栏，用时间戳防重复触发。
class _SwipeDetector extends StatefulWidget {
  const _SwipeDetector({required this.onSwipe, required this.child});

  final ValueChanged<int> onSwipe;
  final Widget child;

  @override
  State<_SwipeDetector> createState() => _SwipeDetectorState();
}

class _SwipeDetectorState extends State<_SwipeDetector> {
  int? _pointer;
  double _startX = 0;
  double _lastX = 0;
  DateTime? _lastFired;

  static const _threshold = 18.0;

  void _fire(double dx) {
    final now = DateTime.now();
    final last = _lastFired;
    if (dx.abs() < _threshold || (last != null && now.difference(last).inMilliseconds < 220)) {
      return;
    }
    _lastFired = now;
    widget.onSwipe(dx < 0 ? 1 : -1);
  }

  @override
  Widget build(BuildContext context) => Listener(
    behavior: HitTestBehavior.opaque,
    onPointerDown: (event) {
      if (_pointer != null) return;
      _pointer = event.pointer;
      _startX = event.localPosition.dx;
      _lastX = _startX;
    },
    onPointerMove: (event) {
      if (event.pointer != _pointer) return;
      _lastX = event.localPosition.dx;
      _fire(_lastX - _startX);
    },
    onPointerUp: (event) {
      if (event.pointer != _pointer) return;
      _fire(_lastX - _startX);
      _pointer = null;
    },
    onPointerCancel: (event) {
      if (event.pointer == _pointer) _pointer = null;
    },
    child: GestureDetector(
      behavior: HitTestBehavior.opaque,
      onHorizontalDragUpdate: (details) => _fire(details.delta.dx),
      onHorizontalDragEnd: (details) {
        final velocity = details.primaryVelocity ?? 0;
        if (velocity.abs() >= 90) _fire(velocity);
      },
      child: widget.child,
    ),
  );
}
