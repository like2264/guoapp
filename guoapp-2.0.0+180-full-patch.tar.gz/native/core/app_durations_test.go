package core

import (
	"bytes"
	"context"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"
	"time"
)

// durationURLProvider 模拟「resolve 不给时长、Playlist 留空，主列表在 URL 里」的站点。
// 这正是 +175 之前时长统计算出 0 的原因。
type durationURLProvider struct {
	url     string
	referer string
}

func (p *durationURLProvider) Descriptor() SourceDescriptor { return SourceDescriptor{ID: "durationurl"} }
func (p *durationURLProvider) Categories(context.Context, bool) ([]Category, error) {
	return nil, nil
}
func (p *durationURLProvider) CatalogPage(context.Context, int, string) ([]Drama, bool, error) {
	return nil, false, nil
}
func (p *durationURLProvider) Detail(context.Context, string) (Drama, []Chapter, error) {
	return Drama{}, nil, nil
}
func (p *durationURLProvider) ResolveMedia(context.Context, Task) (ProviderMedia, error) {
	return ProviderMedia{URL: p.url, Referer: p.referer, Duration: 0, Playlist: ""}, nil
}
func (p *durationURLProvider) Search(context.Context, int, string) ([]Drama, bool, error) {
	return nil, false, nil
}
func (p *durationURLProvider) Suggestions(context.Context, string) ([]string, error) { return nil, nil }
func (p *durationURLProvider) ProvidesCapability(reflect.Type) bool                { return false }

func TestChapterEpisodeNumber(t *testing.T) {
	cases := []struct {
		chapter Chapter
		want    int
	}{
		{Chapter{}, 1},
		{Chapter{CurrentEpisode: json.RawMessage(`7`)}, 7},
		{Chapter{CurrentEpisode: json.RawMessage(`"8"`)}, 8},
		{Chapter{CurrentEpisode: json.RawMessage(`0`)}, 1},
		{Chapter{CurrentEpisode: json.RawMessage(`null`)}, 1},
	}
	for _, test := range cases {
		if got := chapterEpisodeNumber(test.chapter); got != test.want {
			t.Fatalf("chapterEpisodeNumber(%s) = %d，期望 %d", test.chapter.CurrentEpisode, got, test.want)
		}
	}
}

func TestDurationCacheRoundTrip(t *testing.T) {
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	disk := engine.loadDurationCache()
	disk.Dramas["yeguo:1"] = &nativeDurationRecord{
		Updated: 12,
		Items:   map[string]int64{"yeguo:1:1": 305000},
		Missed:  map[string]int64{"yeguo:1:2": 34},
	}
	engine.saveDurationCache(disk)

	again := engine.loadDurationCache()
	record := again.Dramas["yeguo:1"]
	if record == nil {
		t.Fatal("缓存没有落盘")
	}
	if record.Items["yeguo:1:1"] != 305000 || record.Missed["yeguo:1:2"] != 34 {
		t.Fatalf("缓存内容不对：%+v", record)
	}
}

// 播放页回写真值：写进 Items、清掉 Missed，之后统计链路再读能直接命中。
// 这正是「32/35 点进缺的那几集播一遍再退出就能补上」的核心断言。
func TestSaveDurationsClearsMissed(t *testing.T) {
	const source = "yeguo"
	descriptor := SourceDescriptor{ID: source}
	Register(descriptor, func(Host) Provider { return &registryTestProvider{descriptor: descriptor} })
	t.Cleanup(func() { Unregister(source) })
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	// 先按统计链路的样子造一条 Missed 冷却记录。
	disk := engine.loadDurationCache()
	disk.Dramas["yeguo:9"] = &nativeDurationRecord{
		Updated: time.Now().UnixMilli(),
		Items:   map[string]int64{"yeguo:9:1": 100000},
		Missed:  map[string]int64{"yeguo:9:2": time.Now().UnixMilli(), "yeguo:9:3": time.Now().UnixMilli()},
	}
	engine.saveDurationCache(disk)

	changed, err := engine.nativeSaveDurations(context.Background(), nativeInput{
		Drama: LibraryDrama{ID: "yeguo:9"},
		DurationItems: []nativeDurationItem{
			{ID: "yeguo:9:2", DurationMS: 95000},
			{ID: "yeguo:9:3", DurationMS: 0}, // 无效值应被忽略，Missed 保留
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	if !changed {
		t.Fatal("有效回写应报告有变更")
	}
	again := engine.loadDurationCache()
	record := again.Dramas["yeguo:9"]
	if record.Items["yeguo:9:2"] != 95000 {
		t.Fatalf("回写时长未落盘：%+v", record.Items)
	}
	if _, found := record.Missed["yeguo:9:2"]; found {
		t.Fatal("回写成功的集没有清掉 Missed，统计仍会被冷却挡住")
	}
	if _, found := record.Missed["yeguo:9:3"]; !found {
		t.Fatal("无效时长的集不该被清掉 Missed")
	}
	// 同一值重复回写不应再产生变更（避免每次播放都重写缓存）。
	changed, err = engine.nativeSaveDurations(context.Background(), nativeInput{
		Drama:         LibraryDrama{ID: "yeguo:9"},
		DurationItems: []nativeDurationItem{{ID: "yeguo:9:2", DurationMS: 95000}},
	})
	if err != nil || changed {
		t.Fatalf("重复回写应无变更，实际 changed=%v err=%v", changed, err)
	}
}

func TestLoadDurationCacheIgnoresBrokenFile(t *testing.T) {
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	if err := writeNativeCacheFile(engine.cacheDirectory+"/"+nativeDurationFile, []byte("{ 坏掉的")); err != nil {
		t.Fatal(err)
	}
	disk := engine.loadDurationCache()
	if disk == nil || len(disk.Dramas) != 0 {
		t.Fatalf("坏掉的缓存应退回空表，实际 %+v", disk)
	}
}

func TestTrimNativeDurations(t *testing.T) {
	dramas := map[string]*nativeDurationRecord{}
	for index := 0; index < nativeDurationDramaLimit+10; index++ {
		dramas[fmt.Sprintf("d%d", index)] = &nativeDurationRecord{Updated: int64(index)}
	}
	trimNativeDurations(dramas)
	if len(dramas) != nativeDurationDramaLimit {
		t.Fatalf("淘汰后应剩 %d 部，实际 %d", nativeDurationDramaLimit, len(dramas))
	}
	if _, found := dramas["d0"]; found {
		t.Fatal("最久没刷新的那部没有淘汰")
	}
	if _, found := dramas[fmt.Sprintf("d%d", nativeDurationDramaLimit+9)]; !found {
		t.Fatal("最新刷新的那部被误删")
	}
}

func TestChapterDurationsRejectsInvalidDrama(t *testing.T) {
	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	_, err := engine.nativeChapterDurations(context.Background(), nativeInput{
		Drama:    LibraryDrama{},
		Chapters: []Chapter{{ID: "x"}},
	})
	if err == nil {
		t.Fatal("无效剧集应该报错")
	}
}

// +175：resolve 不给时长、Playlist 留空时，统计链路要像播放页一样抓 media.URL
// 的主列表按 #EXTINF 求和，不能就着 duration=0 记失败进冷却（那样就卡在 32/35）。
func TestProbeChapterDurationFetchesMasterPlaylist(t *testing.T) {
	const source = "durationurl"
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/vnd.apple.mpegurl")
		// 三集各 90 秒；主列表没有 #EXT-X-STREAM-INF，应直接按 #EXTINF 求和。
		fmt.Fprint(w, "#EXTM3U\n#EXT-X-VERSION:3\n#EXTINF:90,\nseg0.ts\n#EXTINF:90,\nseg1.ts\n#EXTINF:90,\nseg2.ts\n")
	}))
	defer server.Close()

	provider := &durationURLProvider{url: server.URL + "/master.m3u8", referer: server.URL + "/"}
	descriptor := provider.Descriptor()
	Register(descriptor, func(Host) Provider { return provider })
	t.Cleanup(func() { Unregister(source) })

	engine := &nativeEngine{
		cacheDirectory: t.TempDir(),
		downloader:     &Downloader{cfg: DefaultConfig(), client: server.Client()},
	}
	got := engine.probeChapterDuration(context.Background(), LibraryDrama{ID: source + ":1"},
		Chapter{ID: source + ":1:1"})
	if want := int64(270 * time.Second / time.Millisecond); got != want {
		t.Fatalf("主列表 #EXTINF 求和 = %dms，期望 %dms", got, want)
	}
}

// +178：91短剧个别集只给直链 MP4（没有 m3u8、接口 durationSeconds=0），
// 统计链路必须像播放页一样从 mvhd 读时长；moov 在文件尾时也要靠 Range 拿到。
func TestProbeChapterDurationFetchesMP4Duration(t *testing.T) {
	const source = "durationurl"
	makeAtom := func(seconds uint32) []byte {
		atom := make([]byte, 28)
		binary.BigEndian.PutUint32(atom[0:4], 28) // atom size
		copy(atom[4:8], "mvhd")
		binary.BigEndian.PutUint32(atom[20:24], 1000) // timescale
		binary.BigEndian.PutUint32(atom[24:28], seconds*1000)
		return atom
	}
	headFile := append([]byte("ftyp"), makeAtom(210)...)
	tailFile := append(bytes.Repeat([]byte{0x2a}, 320*1024), makeAtom(195)...)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Accept-Ranges", "bytes")
		w.Header().Set("Content-Type", "video/mp4")
		file := headFile
		if r.URL.Path == "/tail.mp4" {
			file = tailFile
		}
		w.WriteHeader(http.StatusPartialContent)
		if strings.HasPrefix(r.Header.Get("Range"), "bytes=-") && len(file) > mp4ProbeWindow {
			w.Write(file[len(file)-mp4ProbeWindow:])
			return
		}
		if len(file) > mp4ProbeWindow {
			w.Write(file[:mp4ProbeWindow])
			return
		}
		w.Write(file)
	}))
	defer server.Close()

	descriptor := SourceDescriptor{ID: source}
	provider := &durationURLProvider{referer: server.URL + "/"}
	Register(descriptor, func(Host) Provider { return provider })
	t.Cleanup(func() { Unregister(source) })
	engine := &nativeEngine{
		cacheDirectory: t.TempDir(),
		downloader:     &Downloader{cfg: DefaultConfig(), client: server.Client()},
	}

	for _, test := range []struct {
		name string
		url  string
		want int64
	}{
		{name: "moov 在文件头", url: server.URL + "/head.mp4", want: 210000},
		{name: "moov 在文件尾", url: server.URL + "/tail.mp4", want: 195000},
	} {
		t.Run(test.name, func(t *testing.T) {
			provider.url = test.url
			got := engine.probeChapterDuration(context.Background(), LibraryDrama{ID: source + ":1"},
				Chapter{ID: source + ":1:1"})
			if got != test.want {
				t.Fatalf("MP4 mvhd 时长 = %dms，期望 %dms", got, test.want)
			}
		})
	}
}

func TestChapterDurationsEmptyChapters(t *testing.T) {
	const source = "durationprobe"
	descriptor := SourceDescriptor{ID: source}
	factory := func(Host) Provider {
		return &registryTestProvider{descriptor: descriptor}
	}
	Register(descriptor, factory)
	t.Cleanup(func() { Unregister(source) })

	engine := &nativeEngine{cacheDirectory: t.TempDir()}
	result, err := engine.nativeChapterDurations(context.Background(), nativeInput{
		Drama: LibraryDrama{ID: source + ":1"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(result.Items) != 0 {
		t.Fatalf("没有分集时不该有结果，实际 %+v", result.Items)
	}
}
