package core

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/url"
	"path"
	"strconv"
	"strings"
	"time"
)

func mediaRequestHeaders(request *http.Request, referer string) {
	request.Header.Set("User-Agent", UserAgent)
	if referer != "" {
		request.Header.Set("Referer", referer)
		request.Header.Set("Sec-Fetch-Mode", "cors")
		request.Header.Set("Sec-Fetch-Dest", "empty")
		if origin, err := url.Parse(referer); err == nil && origin.Host != "" {
			request.Header.Set("Origin", origin.Scheme+"://"+origin.Host)
		}
	}
	request.Header.Set("Accept", "*/*")
	request.Header.Set("Accept-Language", "zh-CN,zh;q=0.9")
}

func (d *Downloader) doMediaRequest(request *http.Request) (*http.Response, error) {
	return d.doMediaRequestWithClient(request, d.client)
}

// noProxyMediaClient 是一条「绝对不过代理」的媒体通道。
//
// +156 起下载用 context 上的 directNetworkKey 告诉路由别走代理，但请求最终用的
// http.Client 仍带着 router.proxy 的 Transport；只要标记在某些路径上没传下去
// （重定向、模块内新起的请求、凭证刷新），字节就会重新从代理走一遍（+159 反馈）。
// 这里从客户端层面把 Proxy 摘掉，媒体请求只能直连；只有某个 host 直连失败被记下
// （downloadPlaylistPreferred / downloadFileAttempt 会标 10 分钟），才退回带代理的
// 那条 client，这时 context 上的标记已经被关掉。
func (d *Downloader) noProxyMediaClient() *http.Client {
	d.mediaDirectOnce.Do(func() {
		transport := http.DefaultTransport.(*http.Transport).Clone()
		transport.Proxy = nil
		transport.TLSHandshakeTimeout = 0
		d.mediaDirect = &http.Client{Transport: transport}
	})
	return d.mediaDirect
}

func (d *Downloader) doMediaRequestWithClient(request *http.Request, client *http.Client) (*http.Response, error) {
	mediaRequestHeaders(request, request.Header.Get("Referer"))
	// 标记在、且这个 host 没被记成「直连不通」，就整条链路换成无代理客户端。
	if mediaDirect(request.Context()) &&
		(d.proxyRouter == nil || !d.proxyRouter.directBlockedHost(request.URL.Hostname())) {
		client = d.noProxyMediaClient()
	}
	if credentials, _ := request.Context().Value(MediaCredentialsKey{}).(*MediaCredentials); credentials != nil {
		if err := credentials.apply(request); err != nil {
			return nil, err
		}
		client = credentials.client(client)
	}
	authorizer := d.mediaAuthorizer(request.URL)
	authorization := ""
	for attempt := 0; attempt < 2; attempt++ {
		if authorizer != nil {
			header, value, err := authorizer.MediaAuthorization(request.Context(), request.URL, request.Header.Get("Referer"))
			if err != nil {
				return nil, fmt.Errorf("获取播放凭证失败: %w", err)
			}
			request.Header.Set(header, value)
			authorization = header
		}
		response, err := client.Do(request)
		if err != nil {
			return nil, err
		}
		if authorizer != nil && attempt == 0 && (response.StatusCode == http.StatusUnauthorized || response.StatusCode == http.StatusForbidden) {
			body, readErr := io.ReadAll(io.LimitReader(response.Body, 64<<10))
			response.Body.Close()
			if readErr == nil && catalogResponseBlockReason(response, body) == "" {
				authorizer.RejectMediaAuthorization(request.URL, request.Header.Get(authorization))
				continue
			}
			response.Body = io.NopCloser(bytes.NewReader(body))
		}
		if d.limiter != nil {
			d.limiter.observeMedia(request, response)
		}
		return response, nil
	}
	return nil, errors.New("播放凭证刷新失败")
}

// fetchMediaPlaylist 取 m3u8。站点 CDN 对 Referer 的口径各不相同：有的要播放页、
// 有的只认站点根、有的干脆不认 Referer 却讨厌带 Origin 的跨站请求。实测夜社
// （vods3 那台）在部分网络下对播放页 Referer 回 403，换站点根就正常，所以这里
// 一旦拿到 403/401 就按「站点根 → CDN 根 → 不带 Referer」的顺序再试两轮。
//
// +173 反馈：夜社「时不时」403——Referer 全试过仍失败时，问题不在 Referer 而在
// 出口 IP：播放解析走带代理的 d.client，代理出口被 vods3 拒就能稳定 403。这里在
// Referer 变体之后再加一轮「直连通道」重试（noProxyMediaClient），专门兜代理被拒。
// 直连只在 403/401 后才试，且同样带全套 Referer 变体；正常路径不受影响。
func (d *Downloader) fetchMediaPlaylist(ctx context.Context, address, referer string) (string, string, error) {
	if !IsProviderHTTPMediaURL(address) {
		return "", "", errors.New("播放列表地址无效")
	}
	text, finalURL, status, err := d.fetchMediaPlaylistOnce(ctx, address, referer)
	if err == nil {
		return text, finalURL, nil
	}
	if status != http.StatusForbidden && status != http.StatusUnauthorized {
		return text, finalURL, err
	}
	for _, variant := range mediaRefererVariants(address, referer) {
		if variant == referer {
			continue
		}
		if err := ctx.Err(); err != nil {
			break
		}
		variantText, variantURL, _, variantErr := d.fetchMediaPlaylistOnce(ctx, address, variant)
		if variantErr == nil {
			return variantText, variantURL, nil
		}
	}
	// 代理/凭证都被拒：换一条不带代理的通道，用同样的 Referer 口径再试一轮。
	// 每次直连单独限时，避免某个网络下直连一直挂住把整个解析拖死。
	direct := d.noProxyMediaClient()
	for _, variant := range mediaRefererVariants(address, referer) {
		if err := ctx.Err(); err != nil {
			break
		}
		probeCtx, cancel := context.WithTimeout(ctx, 6*time.Second)
		variantText, variantURL, _, variantErr := d.fetchMediaPlaylistOnceWithClient(probeCtx, direct, address, variant)
		cancel()
		if variantErr == nil {
			return variantText, variantURL, nil
		}
	}
	return text, finalURL, err
}

// mediaRefererVariants 给出播放列表请求的 Referer 备选值（含空串＝不带 Referer）。
func mediaRefererVariants(address, referer string) []string {
	out := make([]string, 0, 3)
	seen := map[string]bool{}
	add := func(value string) {
		if seen[value] {
			return
		}
		seen[value] = true
		out = append(out, value)
	}
	if parsed, err := url.Parse(referer); err == nil && parsed.Host != "" {
		add(parsed.Scheme + "://" + parsed.Host + "/")
	}
	if parsed, err := url.Parse(address); err == nil && parsed.Host != "" {
		add(parsed.Scheme + "://" + parsed.Host + "/")
	}
	add("")
	return out
}

func (d *Downloader) fetchMediaPlaylistOnce(ctx context.Context, address, referer string) (string, string, int, error) {
	return d.fetchMediaPlaylistOnceWithClient(ctx, d.client, address, referer)
}

// fetchMediaPlaylistOnceWithClient 允许指定 client：直连兜底走 noProxyMediaClient，
// 常规路径仍走 d.client（带代理）。其余请求头、错误口径完全一致。
func (d *Downloader) fetchMediaPlaylistOnceWithClient(ctx context.Context, client *http.Client, address, referer string) (string, string, int, error) {
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, address, nil)
	if err != nil {
		return "", "", 0, err
	}
	request.Header.Set("Referer", referer)
	response, err := d.doMediaRequestWithClient(request, client)
	if err != nil {
		return "", "", 0, err
	}
	defer response.Body.Close()
	body, err := io.ReadAll(io.LimitReader(response.Body, (4<<20)+1))
	if err != nil || len(body) > 4<<20 {
		return "", "", response.StatusCode, errors.New("播放列表过大或读取失败")
	}
	if response.StatusCode != http.StatusOK || catalogResponseBlockReason(response, body) != "" {
		return "", "", response.StatusCode, d.catalogResponseError(request, response, body)
	}
	text := strings.TrimSpace(strings.TrimPrefix(string(body), "\ufeff"))
	if !strings.HasPrefix(text, "#EXTM3U") {
		return "", "", response.StatusCode, &PlaylistError{Body: body}
	}
	finalURL := address
	if response.Request != nil && response.Request.URL != nil {
		finalURL = response.Request.URL.String()
	}
	return text, finalURL, response.StatusCode, nil
}

// 直链 MP4 的时长不在接口里，站点也不给 m3u8（91短剧 2589 的第 15/16/18 集就是
// 这种）。播放页能从文件本身读到时长，统计链路也要能：只需 mvhd 原子的
// timescale/duration，用 Range 取文件头尾各 256KB 就够，不必下载整集。
const mp4ProbeWindow = 256 << 10

func isMP4MediaURL(address string) bool {
	parsed, err := url.Parse(address)
	if err != nil {
		return false
	}
	switch strings.ToLower(path.Ext(parsed.Path)) {
	case ".mp4", ".m4v", ".mov":
		return true
	}
	return false
}

// mp4Duration 从 ftyp/moov 片段里找 mvhd，按 version 0/1 的布局读时长。
// 片段里可能有别处碰巧出现同样四个字节，遇到解析不通的候选就继续往后找。
func mp4Duration(data []byte) time.Duration {
	for offset := 0; offset+4 <= len(data); {
		index := bytes.Index(data[offset:], []byte("mvhd"))
		if index < 0 {
			return 0
		}
		at := offset + index
		var timescale uint32
		var units uint64
		switch {
		case at+24 <= len(data) && data[at+4] == 0:
			timescale = binary.BigEndian.Uint32(data[at+16 : at+20])
			units = uint64(binary.BigEndian.Uint32(data[at+20 : at+24]))
		case at+36 <= len(data) && data[at+4] == 1:
			timescale = binary.BigEndian.Uint32(data[at+24 : at+28])
			units = binary.BigEndian.Uint64(data[at+28 : at+36])
		}
		if timescale > 0 && units > 0 && units <= uint64(math.MaxInt64/int64(time.Second)) {
			return time.Duration(units) * time.Second / time.Duration(timescale)
		}
		offset = at + 4
	}
	return 0
}

func (d *Downloader) fetchMP4Duration(ctx context.Context, address, referer string) time.Duration {
	if !isMP4MediaURL(address) || d == nil || d.client == nil {
		return 0
	}
	clients := []*http.Client{d.client}
	if direct := d.noProxyMediaClient(); direct != nil && direct != d.client {
		clients = append(clients, direct)
	}
	for _, client := range clients {
		for _, rng := range []string{
			"bytes=0-" + strconv.Itoa(mp4ProbeWindow-1),
			"bytes=-" + strconv.Itoa(mp4ProbeWindow),
		} {
			request, err := http.NewRequestWithContext(ctx, http.MethodGet, address, nil)
			if err != nil {
				return 0
			}
			mediaRequestHeaders(request, referer)
			request.Header.Set("Range", rng)
			response, err := d.doMediaRequestWithClient(request, client)
			if err != nil {
				continue
			}
			body, readErr := io.ReadAll(io.LimitReader(response.Body, mp4ProbeWindow+1))
			response.Body.Close()
			if readErr != nil {
				continue
			}
			if duration := mp4Duration(body); duration > 0 {
				return duration
			}
			// 源文件本身已经 404，换一条网络通道也不会有结果。
			if response.StatusCode == http.StatusNotFound {
				return 0
			}
		}
	}
	return 0
}
