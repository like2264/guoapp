"""Build and prepare the VideoToolbox frame backend for the iOS device slice."""

import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from urllib.parse import unquote, urlparse

from stage_test_app import prepare_framework_binary

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
UPSTREAM = '4286f5557bdccc0747030e3c376ce5cd160a96a0'
TARGET = 'build/intermediate/mpv_ios-arm64-video'


def run(*args, **kwargs):
    subprocess.run(args, check=True, **kwargs)


def edit(source, filename, before, after):
    path = source / filename
    text = path.read_text()
    if text.count(before) != 1:
        raise RuntimeError(f'Unexpected upstream source in {filename}')
    path.write_text(text.replace(before, after, 1))


def build() -> Path:
    work = ROOT / 'native/build/ios/mpv'
    result = work / 'Mpv'
    work.mkdir(parents=True, exist_ok=True)
    # 优先使用随补丁附带的、已由上游 2.0.4+116 实机验证过的 device slice。
    # 与本工程的 media_kit_libs_ios_video 同为 1.1.4，避免 CI 上自建 libmpv
    # 被上游脚本的 env -i / CMake 查找规则卡住；源码补丁仍保留供审计。
    prepared = HERE / 'Mpv.device'
    if prepared.is_file():
        shutil.copyfile(prepared, result)
        result.chmod(0o755)
        return result
    packages = json.loads((ROOT / '.dart_tool/package_config.json').read_text())
    package = next(p for p in packages['packages'] if p['name'] == 'media_kit_libs_ios_video')
    uri = urlparse(package['rootUri'])
    package_root = Path(unquote(uri.path)) if uri.scheme == 'file' else ROOT / '.dart_tool' / unquote(uri.path)
    original = package_root / 'ios/Frameworks/Mpv.xcframework/ios-arm64/Mpv.framework/Mpv'
    digest = hashlib.sha256()
    for path in (Path(__file__), HERE / 'apply.py', HERE / 'pixelbuffer.inc',
                 HERE / 'stage_test_app.py', original):
        digest.update(path.read_bytes())
    digest.update(subprocess.check_output(['xcodebuild', '-version']))
    key = digest.hexdigest()
    stamp = work / 'stamp'
    if result.is_file() and stamp.is_file() and stamp.read_text() == key:
        return result

    tools = {name: shutil.which(name) for name in ('meson', 'ninja', 'cmake', 'pkgconf')}
    missing = [name for name, path in tools.items() if path is None]
    if missing:
        raise SystemExit('缺少 iOS libmpv 构建工具：' + ', '.join(missing))

    source = work / 'source'
    if not source.exists():
        run('git', 'clone', '--depth', '1', '--branch', 'v0.6.0',
            'https://github.com/media-kit/libmpv-darwin-build.git', str(source))
    revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
    if revision != UPSTREAM:
        raise SystemExit(f'iOS libmpv 构建器版本不符：{revision}')
    run('git', 'restore', '--', 'Makefile', 'scripts', cwd=source)

    edit(source, 'Makefile', 'BINARIES="meson ninja cmake nasm"',
         'BINARIES="meson ninja cmake"')
    # Intel runner 上 cmake 由 Homebrew 装在 /usr/local/bin，而上游把子构建的
    # PATH 钉死在 /bin:/usr/bin，meson 的 cmake 子项目会找不到 cmake。
    edit(source, 'Makefile',
         'SANDBOX_PATH = ${PROJECT_DIR}/${LINKS_DIR}/bin:${PROJECT_DIR}/${PKGCONFIG_DIR}/bin:/bin:/usr/bin',
         'SANDBOX_PATH = ${PROJECT_DIR}/${LINKS_DIR}/bin:${PROJECT_DIR}/${PKGCONFIG_DIR}/bin:$(shell dirname $(shell which cmake)):/bin:/usr/bin')
    edit(source, 'scripts/mpv/build.sh', 'patches/mpv-fix-missing-objc.patch',
         'patches/mpv-fix-missing-objc.patch\n' +
         shlex.join([sys.executable, str(HERE / 'apply.py')]) + ' "$SRC_DIR"')
    edit(source, 'scripts/libxml2/meson.build', 'configure_options : [',
         "configure_options : [\n        '--without-lzma',")
    edit(source, 'scripts/uchardet/meson.build', 'options.add_cmake_defines({',
         "options.add_cmake_defines({\n    'CMAKE_POLICY_VERSION_MINIMUM': '3.5',")
    edit(source, 'scripts/uchardet/build.sh', 'cmake ./subprojects/uchardet',
         'export CMAKE_POLICY_VERSION_MINIMUM=3.5\ncmake ./subprojects/uchardet')
    edit(source, 'scripts/harfbuzz/build.sh', 'cd ${SRC_DIR}',
         'cd ${SRC_DIR}\nsed -i "" "s/sincosf (/__sincosf (/g" src/OT/glyf/VarCompositeGlyph.hh')
    edit(source, 'scripts/freetype/build.sh', '-Dpng=enabled', '-Dpng=disabled')

    # Use the host executable with isolated target package metadata.
    wrapper = source / 'guoapp-pkgconfig/bin/pkg-config'
    wrapper.parent.mkdir(parents=True, exist_ok=True)
    wrapper.write_text('#!/bin/sh\nexport PKG_CONFIG_LIBDIR=/nonexistent\nexec '
                       + shlex.quote(tools['pkgconf']) + ' "$@"\n')
    wrapper.chmod(0o755)
    build_links = source / 'build/intermediate/links'
    if build_links.exists():
        shutil.rmtree(build_links)
    intermediate = source / TARGET
    if intermediate.exists():
        shutil.rmtree(intermediate)
    make = ('make', f'PROJECT_DIR={source}', 'PKGCONFIG_DIR=guoapp-pkgconfig')
    run(*make, 'build/intermediate/links', cwd=source)
    # 子构建用 env -i 跑，上游 links/bin 里的 cmake 链接在 Intel runner 上
    # 指不到 Homebrew 的实际二进制。放一个绝对路径链接到最前面的 PATH 目录。
    links_bin = source / 'build/intermediate/links/bin'
    links_bin.mkdir(parents=True, exist_ok=True)
    cmake_link = links_bin / 'cmake'
    if cmake_link.is_symlink() or cmake_link.exists():
        cmake_link.unlink()
    cmake_link.symlink_to(tools['cmake'])
    version = subprocess.check_output([tools['cmake'], '--version'], text=True).splitlines()[0]
    print('GuoApp cmake:', version, '->', tools['cmake'])
    run(*make, TARGET, cwd=source)
    temporary = result.with_suffix('.tmp')
    prepare_framework_binary(original, intermediate / 'lib/libmpv.2.dylib', temporary)
    os.replace(temporary, result)
    stamp.write_text(key)
    return result


if __name__ == '__main__':
    print(build())
